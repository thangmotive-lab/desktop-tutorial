<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';
$token=trim($_GET['token'] ?? '');
if($token===''){ http_response_code(404); die('Portal not found'); }
try{
  $stmt=$pdo->prepare('SELECT a.*,c.* FROM client_portal_access a JOIN clients c ON c.id=a.client_id WHERE a.token=? AND a.is_active=1 LIMIT 1');
  $stmt->execute([$token]);
  $client=$stmt->fetch();
}catch(Exception $e){ $client=false; }
if(!$client){ http_response_code(404); die('Portal inactive or not found'); }
$clientName=$client['name'];
$projects=safe_rows($pdo,"SELECT p.*,u.name owner_name,u.avatar owner_avatar,
  (SELECT COUNT(*) FROM tasks t WHERE t.project_id=p.id) task_total,
  (SELECT COUNT(*) FROM tasks t WHERE t.project_id=p.id AND t.status='Done') task_done
  FROM projects p LEFT JOIN users u ON u.id=p.owner_id
  WHERE p.client_name=".$pdo->quote($clientName)." ORDER BY p.end_date ASC,p.id DESC LIMIT 20");
$quotes=safe_rows($pdo,"SELECT id,quote_code,client_name,quote_date,status,grand_total,total_amount FROM quotations WHERE client_name=".$pdo->quote($clientName)." ORDER BY id DESC LIMIT 10");
$contracts=safe_rows($pdo,"SELECT id,contract_code,client_name,total_value,status,signed_date,created_at FROM contracts WHERE client_name=".$pdo->quote($clientName)." ORDER BY id DESC LIMIT 10");
?>
<!doctype html><html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title><?= e($clientName) ?> · Motive Client Portal</title>
<style>
:root{--text:#101828;--muted:#667085;--line:#e5e7eb;--coral:#ff6b4a;--purple:#7c3aed;--green:#10b981;--bg:#f7fafc}*{box-sizing:border-box}body{margin:0;font-family:Inter,Arial,sans-serif;color:var(--text);background:linear-gradient(135deg,#fff7ed,#ecfeff,#f5f3ff)}.wrap{max-width:1180px;margin:0 auto;padding:28px}.hero{position:relative;overflow:hidden;border-radius:34px;background:linear-gradient(135deg,#e0f2fe,#fff7ed 55%,#dcfce7);padding:34px;box-shadow:0 24px 70px rgba(15,23,42,.10)}.brand{display:flex;align-items:center;gap:12px;font-weight:950}.logo{width:46px;height:46px;border-radius:16px;background:#111827;color:white;display:flex;align-items:center;justify-content:center}.hero h1{font-size:44px;letter-spacing:-.06em;margin:18px 0 8px}.muted{color:var(--muted)}.grid{display:grid;grid-template-columns:1.2fr .8fr;gap:18px;margin-top:18px}.card{background:rgba(255,255,255,.94);border:1px solid var(--line);border-radius:26px;padding:22px;box-shadow:0 14px 38px rgba(15,23,42,.06)}.card h2{margin:0 0 14px}.project{border:1px solid var(--line);border-radius:20px;padding:16px;margin:10px 0}.progress{height:9px;background:#f1f5f9;border-radius:99px;overflow:hidden;margin:10px 0}.progress span{display:block;height:100%;background:linear-gradient(90deg,var(--coral),#fbbf24)}.badge{display:inline-flex;border-radius:999px;padding:6px 10px;font-size:12px;font-weight:950;background:#f5f3ff;color:#6d28d9}.row{display:flex;justify-content:space-between;gap:14px;padding:12px 0;border-bottom:1px solid #edf2f7}.row:last-child{border-bottom:0}.pill{border-radius:999px;background:#fff1ed;color:#c2410c;padding:7px 10px;font-weight:900;font-size:12px;white-space:nowrap}@media(max-width:860px){.grid{grid-template-columns:1fr}.hero h1{font-size:32px}.wrap{padding:16px}}
</style></head><body><div class="wrap">
  <section class="hero"><div class="brand"><div class="logo">M</div><div>Motive Agency<br><span class="muted">Client Portal</span></div></div><h1>Xin chào, <?= e($clientName) ?> 👋</h1><p class="muted">Đây là không gian theo dõi tiến độ dự án, báo giá và hợp đồng của bạn với Motive.</p></section>
  <div class="grid"><main>
    <section class="card"><h2>Project Progress</h2><?php foreach($projects as $p): $pct=(int)($p['task_total']?round($p['task_done']/$p['task_total']*100):($p['progress']??0)); ?><div class="project"><b><?= e($p['name']) ?></b><br><span class="muted">PM: <?= e($p['owner_name'] ?? '-') ?> · End: <?= e($p['end_date'] ?? '-') ?></span><div class="progress"><span style="width:<?= $pct ?>%"></span></div><span class="badge"><?= $pct ?>% hoàn thành</span> <span class="badge"><?= e($p['status'] ?? 'In Progress') ?></span></div><?php endforeach; ?><?php if(empty($projects)): ?><p class="muted">Chưa có project được gắn với khách hàng này.</p><?php endif; ?></section>
  </main><aside>
    <section class="card"><h2>Báo giá</h2><?php foreach($quotes as $q): ?><div class="row"><div><b><?= e($q['quote_code'] ?? ('#'.$q['id'])) ?></b><br><span class="muted"><?= e($q['quote_date'] ?? '') ?></span></div><span class="pill"><?= e($q['status'] ?? 'Draft') ?></span></div><?php endforeach; ?><?php if(empty($quotes)): ?><p class="muted">Chưa có báo giá.</p><?php endif; ?></section>
    <section class="card" style="margin-top:18px"><h2>Hợp đồng</h2><?php foreach($contracts as $c): ?><div class="row"><div><b><?= e($c['contract_code'] ?? ('#'.$c['id'])) ?></b><br><span class="muted"><?= e($c['signed_date'] ?? $c['created_at'] ?? '') ?></span></div><span class="pill"><?= e($c['status'] ?? 'Draft') ?></span></div><?php endforeach; ?><?php if(empty($contracts)): ?><p class="muted">Chưa có hợp đồng.</p><?php endif; ?></section>
  </aside></div>
</div></body></html>
