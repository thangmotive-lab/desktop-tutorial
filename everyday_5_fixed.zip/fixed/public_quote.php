<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';
$token = $_GET['token'] ?? '';
$stmt = $pdo->prepare('SELECT * FROM quotations WHERE public_token=? LIMIT 1');
$stmt->execute([$token]);
$q = $stmt->fetch();
if (!$q) die('Báo giá không tồn tại hoặc link không hợp lệ.');

$versionId = 0;
if (table_exists($pdo, 'quotation_versions') && column_exists($pdo, 'quotation_items', 'quotation_version_id')) {
  $versionNo = (int)($q['current_version'] ?? 0);
  if ($versionNo > 0) {
    $vstmt = $pdo->prepare('SELECT id FROM quotation_versions WHERE quotation_id=? AND version_no=? LIMIT 1');
    $vstmt->execute([$q['id'], $versionNo]);
    $versionId = (int)$vstmt->fetchColumn();
  }
  if ($versionId <= 0) {
    $vstmt = $pdo->prepare('SELECT id FROM quotation_versions WHERE quotation_id=? ORDER BY version_no DESC LIMIT 1');
    $vstmt->execute([$q['id']]);
    $versionId = (int)$vstmt->fetchColumn();
  }
}

if ($versionId > 0) {
  $stmt = $pdo->prepare('SELECT * FROM quotation_items WHERE quotation_version_id=? ORDER BY sort_order,id');
  $stmt->execute([$versionId]);
  $items = $stmt->fetchAll();
  $t = quotation_version_totals($pdo, $versionId);
} else {
  $stmt = $pdo->prepare('SELECT * FROM quotation_items WHERE quotation_id=? ORDER BY sort_order,id');
  $stmt->execute([$q['id']]);
  $items = $stmt->fetchAll();
  $t = quotation_totals($pdo,$q['id']);
}

$stmt = $pdo->prepare('SELECT * FROM payment_schedules WHERE quotation_id=? ORDER BY due_date,id');
$stmt->execute([$q['id']]);
$payments = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <title><?= e($q['quote_code']) ?> - <?= e($q['client_name']) ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    *{box-sizing:border-box}
    body{margin:0;background:#f3f4f6;color:#111827;font-family:Arial,Helvetica,sans-serif}
    .quote-a4{width:210mm;min-height:297mm;margin:16px auto;background:white;padding:14mm;box-shadow:0 12px 40px rgba(15,23,42,.12)}
    .quote-head{display:flex;justify-content:space-between;gap:18px;border-bottom:2px solid #111827;padding-bottom:14px;margin-bottom:14px}
    .brand{display:flex;align-items:flex-start;gap:12px;font-size:22px;font-weight:950;letter-spacing:-.04em;color:#111827}
    .brand img{max-height:54px;max-width:210px;object-fit:contain;display:block}
    .company-info{margin-top:8px;font-size:10.6px;line-height:1.55;color:#4b5563;max-width:360px}
    .company-info b{color:#111827;font-size:11px;text-transform:uppercase;letter-spacing:.035em}
    .company-info .line{display:block}
    .meta{text-align:right;font-size:11px;line-height:1.5;color:#4b5563;min-width:160px}.meta b{color:#111827}
    h1{font-size:24px;line-height:1.05;margin:10px 0 6px;letter-spacing:-.05em}
    h2{font-size:13px;margin:16px 0 8px;text-transform:uppercase;letter-spacing:.06em}
    p{font-size:11.5px;line-height:1.45;margin:5px 0;color:#374151}
    .client-line{display:flex;gap:16px;align-items:flex-start;margin-bottom:12px}
    .client-box{flex:1;background:#f9fafb;border:1px solid #e5e7eb;border-radius:10px;padding:9px 10px;font-size:11.5px}
    table{width:100%;border-collapse:collapse;font-size:10.5px;table-layout:fixed}
    th{background:#111827;color:white;text-align:left;font-size:9.5px;text-transform:uppercase;letter-spacing:.03em;padding:7px 6px;vertical-align:top}
    td{border-bottom:1px solid #e5e7eb;padding:7px 6px;vertical-align:top;white-space:normal;overflow:visible;word-break:normal;overflow-wrap:break-word;line-height:1.35}
    td.money,th.money{text-align:right;white-space:nowrap;overflow-wrap:normal}
    .service{white-space:normal;overflow:visible}
    .service b{display:block;font-size:11px;line-height:1.25;white-space:normal;overflow:visible;text-overflow:unset}
    .muted{color:#6b7280;font-size:10px;line-height:1.35}
    .service .muted{display:block;margin-top:4px;white-space:pre-line;overflow:visible;text-overflow:unset;max-height:none}
    .summary-area{display:grid;grid-template-columns:1.3fr .7fr;gap:14px;margin-top:12px}
    .terms{background:#f9fafb;border:1px solid #e5e7eb;border-radius:10px;padding:10px}
    .summary{border:1px solid #111827;border-radius:10px;overflow:hidden}
    .summary .row{display:flex;justify-content:space-between;gap:10px;padding:8px 10px;border-bottom:1px solid #e5e7eb;font-size:11px}
    .summary .row:last-child{border-bottom:0;background:#111827;color:white;font-weight:950;font-size:13px}
    .workflow{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:10px}
    .step{border:1px solid #e5e7eb;border-radius:10px;padding:9px;font-size:10.5px;background:#fff}
    .print-btn{position:fixed;right:18px;top:18px;border:0;background:#ff6b4a;color:white;border-radius:999px;padding:11px 16px;font-weight:900;cursor:pointer}
    @media(max-width:760px){
      .quote-a4{width:auto;min-height:auto;margin:0;padding:18px;box-shadow:none}
      .quote-head{flex-direction:column;gap:10px}
      .meta{text-align:left}
      .summary-area,.workflow{grid-template-columns:1fr}
      .client-line{flex-direction:column;gap:10px}
      .brand img{max-width:180px;max-height:46px}
      .print-btn{right:12px;top:12px;padding:9px 12px;font-size:12px}
      table{font-size:10px;min-width:760px}
      main{overflow-x:auto}
    }
    @page{size:A4;margin:8mm}
    @media print{
      body{background:white}.quote-a4{width:auto;min-height:auto;margin:0;padding:0;box-shadow:none}.print-btn{display:none}
      h1{font-size:22px} h2{font-size:12px}
      table{font-size:9.5px;table-layout:fixed} th{font-size:8.5px;padding:5px} td{padding:5px;line-height:1.3}
      .service b{font-size:10px}.service .muted{font-size:9px;line-height:1.25}
      .terms,.client-box,.step{break-inside:avoid}
      tr{break-inside:avoid;page-break-inside:avoid}
    }
  </style>
</head>
<body>
<button onclick="window.print()" class="print-btn">Print / PDF</button>
<main class="quote-a4">
  <section class="quote-head">
    <div>
      <?php
        $logo = get_setting($pdo,'logo_dark','');
        if (!$logo && file_exists(__DIR__ . '/assets/img/motive_logo_2026.png')) {
          $logo = 'assets/img/motive_logo_2026.png';
        }
      ?>
      <div class="brand"><?php if($logo): ?><img src="<?= e($logo) ?>" alt="Motive Agency"><?php else: ?>Motive Agency<?php endif; ?></div>
      <div class="company-info">
        <b>CÔNG TY TNHH TRUYỀN THÔNG MOTIVE</b>
        <span class="line">MST: 0110212832</span>
        <span class="line">Địa chỉ: Số 5 ngách 15 ngõ 82 Yên Lãng, Đống Đa, Hà Nội</span>
        <span class="line">Hotline: 0965.980.886 · Email: hello.motivesocial@gmail.com</span>
        <span class="line">Website: motiveagency.vn</span>
      </div>
      <h1><?= e($q['title'] ?: 'Báo giá dịch vụ') ?></h1>
      <p><?= nl2br(e(mb_substr($q['intro_text'] ?: 'Cảm ơn Quý khách đã quan tâm tới dịch vụ của Motive Agency.',0,220))) ?></p>
    </div>
    <div class="meta">
      <div><b>Quotation</b> <?= e($q['quote_code']) ?></div>
      <div><b>Date</b> <?= e(date('d/m/Y',strtotime($q['created_at']))) ?></div>
      <div><b>Valid until</b> <?= e($q['valid_until']) ?></div>
    </div>
  </section>

  <section class="client-line">
    <div class="client-box"><b>Prepared for</b><br><?= e($q['client_name']) ?><?php if($q['client_contact']): ?><br><?= e($q['client_contact']) ?><?php endif; ?></div>
    <div class="client-box"><b>Prepared by</b><br>Công ty TNHH Truyền thông Motive<br>MST: 0110212832<br>Hotline: 0965.980.886<br>Email: hello.motivesocial@gmail.com</div>
  </section>

  <h2>Scope & Quotation</h2>
  <table>
    <thead><tr><th style="width:28px">#</th><th style="width:33%">Dịch vụ</th><th style="width:64px">SL</th><th style="width:76px">Thời gian</th><th class="money" style="width:86px">Đơn giá</th><th class="money" style="width:92px">Thành tiền</th><th style="width:42px">VAT</th><th class="money" style="width:92px">Tổng</th></tr></thead>
    <tbody>
    <?php foreach($items as $idx=>$it):
      $desc = trim((string)($it['description'] ?? ''));
      $note = trim((string)($it['note'] ?? ''));
      $descText = $desc;
      if ($note !== '') $descText .= ($descText !== '' ? "\n" : '') . $note;
      $timeText = $it['duration'] ?: ($it['working_time'] ?? '');
      $vatRate = $it['vat_rate'] ?? $it['vat_percent'] ?? 0;
    ?>
      <tr>
        <td><?= $idx+1 ?></td>
        <td class="service"><b><?= e($it['service_name']) ?></b><?php if($descText !== ''): ?><span class="muted"><?= e($descText) ?></span><?php endif; ?></td>
        <td><?= num($it['quantity']) ?> <?= e($it['unit']) ?></td>
        <td><?= e($timeText) ?></td>
        <td class="money"><?= money($it['unit_price']) ?></td>
        <td class="money"><?= money($it['subtotal']) ?></td>
        <td><?= (float)$vatRate ?>%</td>
        <td class="money"><b><?= money($it['total']) ?></b></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>

  <section class="summary-area">
    <div class="terms">
      <h2 style="margin-top:0">Payment Terms</h2>
      <p><?= nl2br(e(mb_substr($q['payment_terms'] ?: 'Thanh toán theo thỏa thuận giữa hai bên.',0,280))) ?></p>
      <?php if($payments): ?>
      <table><thead><tr><th>Đợt</th><th>%</th><th class="money">Số tiền</th><th>Due</th></tr></thead><tbody><?php foreach($payments as $p): ?><tr><td><?= e($p['milestone']) ?></td><td><?= (float)$p['percent'] ?>%</td><td class="money"><?= money($p['amount']) ?></td><td><?= e($p['due_date']) ?></td></tr><?php endforeach; ?></tbody></table>
      <?php endif; ?>
    </div>
    <div class="summary">
      <div class="row"><span>Tạm tính</span><b><?= money($t['subtotal']) ?></b></div>
      <div class="row"><span>VAT</span><b><?= money($t['vat']) ?></b></div>
      <div class="row"><span>Tổng</span><b><?= money($t['total']) ?></b></div>
    </div>
  </section>

  <h2>Workflow</h2>
  <div class="workflow">
    <div class="step"><b>01</b><br>Chốt scope</div>
    <div class="step"><b>02</b><br>Ký hợp đồng / thanh toán</div>
    <div class="step"><b>03</b><br>Triển khai & nghiệm thu</div>
  </div>
</main>
</body>
</html>
