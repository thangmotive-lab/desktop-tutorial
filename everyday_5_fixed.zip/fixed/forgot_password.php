<?php
ob_start();
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';

if (is_logged_in()) redirect('app.php?page=workspace');

$message='';
$resetLink='';
$error='';

if($_SERVER['REQUEST_METHOD']==='POST'){
  $email=trim($_POST['email'] ?? '');
  if($email===''){
    $error='Vui lòng nhập email.';
  } else {
    $stmt=$pdo->prepare("SELECT id,email,name FROM users WHERE email=? AND status='active' LIMIT 1");
    $stmt->execute([$email]);
    $user=$stmt->fetch();
    if($user){
      $token=bin2hex(random_bytes(32));
      $expires=date('Y-m-d H:i:s',strtotime('+2 hours'));
      $pdo->prepare("UPDATE users SET reset_token=?, reset_expires_at=? WHERE id=?")->execute([$token,$expires,$user['id']]);
      $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
      $base = $scheme.'://'.$_SERVER['HTTP_HOST'].rtrim(dirname($_SERVER['SCRIPT_NAME']),'/\\');
      $resetLink = $base.'/reset_password.php?token='.$token;
    }
    $message='Nếu email tồn tại trong hệ thống, link đặt lại mật khẩu đã được tạo.';
  }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <title>Quên mật khẩu - Motive Everyday</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    *{box-sizing:border-box} body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px;font-family:Inter,Arial,sans-serif;color:#101828;background:linear-gradient(135deg,#fff7ed,#ecfeff,#f5f3ff)}
    .auth-card{width:min(520px,100%);background:rgba(255,255,255,.88);border:1px solid rgba(255,255,255,.7);border-radius:30px;padding:34px;box-shadow:0 24px 70px rgba(15,23,42,.12)}
    .eyebrow{font-size:12px;font-weight:950;letter-spacing:.08em;text-transform:uppercase;color:#ff6b4a} h1{font-size:36px;letter-spacing:-.06em;margin:8px 0 10px} p{color:#667085;line-height:1.55}
    label{display:block;font-weight:850;margin:18px 0 8px} input{width:100%;min-height:52px;border:1px solid #e5e7eb;border-radius:18px;padding:12px 14px;font-size:15px}
    button,a.btn{display:inline-flex;align-items:center;justify-content:center;text-decoration:none;border:0;border-radius:18px;min-height:50px;padding:12px 16px;font-weight:900;cursor:pointer}
    button{width:100%;background:#111827;color:#fff;margin-top:18px}.btn{background:#f3f4f6;color:#111827;margin-top:12px}
    .alert{padding:12px 14px;border-radius:16px;margin:12px 0;font-weight:800}.ok{background:#ecfdf5;color:#047857}.err{background:#fff1f2;color:#be123c}.linkbox{word-break:break-all;background:#f8fafc;border:1px dashed #cbd5e1;border-radius:16px;padding:12px;font-size:13px;color:#344054}
  </style>
</head>
<body>
  <main class="auth-card">
    <span class="eyebrow">Password Recovery</span>
    <h1>Quên mật khẩu</h1>
    <p>Nhập email tài khoản. Hệ thống sẽ tạo link đặt lại mật khẩu có hiệu lực trong 2 giờ.</p>
    <?php if($error): ?><div class="alert err"><?= e($error) ?></div><?php endif; ?>
    <?php if($message): ?><div class="alert ok"><?= e($message) ?></div><?php endif; ?>
    <?php if($resetLink): ?><p class="muted">Tạm thời chưa cấu hình SMTP, bạn copy link này để đặt lại mật khẩu:</p><div class="linkbox"><?= e($resetLink) ?></div><?php endif; ?>
    <form method="post">
      <label>Email</label>
      <input type="email" name="email" placeholder="you@motive.vn" required autofocus>
      <button>Tạo link đặt lại mật khẩu</button>
    </form>
    <a class="btn" href="login.php">← Quay lại đăng nhập</a>
  </main>
</body>
</html>
