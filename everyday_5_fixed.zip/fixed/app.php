<?php
echo '<!-- RUNNING_APP_REAL_PATH: ' . __FILE__ . ' -->';
ob_start();
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';
require_login();

$page = $_GET['page'] ?? 'workspace';

// Sprint 4 route aliases: allow old Generate Project links to open the Quote → Project Generator module.
if ($page === 'quote_generate_project' || $page === 'generate_project_from_quote') {
    $page = 'quote_project_generator';
}
if (isset($_GET['quote_id']) && !isset($_GET['quotation_id'])) {
    $_GET['quotation_id'] = $_GET['quote_id'];
}
if (isset($_GET['quotation_id']) && !isset($_GET['id'])) {
    $_GET['id'] = $_GET['quotation_id'];
}
$allowed = ['workspace','profile','personal_rates','calendar','chat','okr','dashboard','clients','users','permissions','integrations','settings','ratecard','quotation_create','quotation_list','quotation_edit','internal_costs','contracts','payments','acceptances','projects','project_detail','tasks','leave_requests','attendance','payroll','kpi','notifications','activity','files','contract_templates','contract_generate','contract_detail','task_mentions','mood_checkin','my_preferences','my_finance','business_finance','monthly_closing','payroll_manager','ctv_payroll','ctv_approval','sales_commissions','contract_owners','finance_operations','approval_center','ai_center','ai_quote','ai_knowledge','ai_documents','ai_workspace','ai_knowledge_base','ai_document_library','ai_generate_center','ai_proposal_engine','ai_prompt_studio','document_templates','doc_templates','doc_generate','revenue_overview','document_generate','cash_forecast','search','task_detail','payroll_batch','need_help','kudos','client_portal','approval_workflow','quote_project_generator','quote_generate_project','generate_project_from_quote','project_templates'];
if (!in_array($page, $allowed)) $page = 'dashboard';

$titles = [
  'workspace'=>'My Workspace',
  'mood_checkin'=>'Mood Check-in',
  'my_preferences'=>'My Preferences',
  'profile'=>'Profile cá nhân',
  'personal_rates'=>'Personal Rate',
  'calendar'=>'Lịch',
  'chat'=>'Chat nhóm',
  'okr'=>'OKR',
  'ai_quote'=>'AI Quote',
  'ai_center'=>'AI Center',
  'ai_documents'=>'AI Documents',
  'doc_generate'=>'Generate DOCX',
  'document_generate'=>'Generate DOCX',
  'doc_templates'=>'Document Templates',
  'document_templates'=>'Document Templates',
  'ai_knowledge'=>'AI Knowledge',
  'ai_workspace'=>'AI Workspace',
  'ai_knowledge_base'=>'AI Knowledge Base',
  'ai_document_library'=>'AI Document Library',
  'ai_generate_center'=>'AI Generate Center',
  'ai_proposal_engine'=>'AI Proposal Engine',
  'ai_prompt_studio'=>'AI Prompt Studio',
  'dashboard'=>'CEO Dashboard',
  'attendance'=>'Bảng công',
  'approval_center'=>'Approval Center',
  'clients'=>'CRM Khách hàng',
  'users'=>'User Manager / Profile',
  'permissions'=>'Phân quyền tài khoản',
  'integrations'=>'Google Drive Integration',
  'settings'=>'Admin Settings',
  'ratecard'=>'Ratecard Manager',
  'quotation_create'=>'Smart Generate Quotation',
  'quotation_list'=>'Quotations',
  'quotation_edit'=>'Quotation Builder',
  'internal_costs'=>'Internal Cost Sheet',
  'contracts'=>'Contracts',
  'contract_templates'=>'Contract Templates',
  'contract_generate'=>'Generate Contract',
  'contract_detail'=>'Contract Detail',
  'payments'=>'Payment Schedule',
  'acceptances'=>'Acceptance & Settlement',
  'projects'=>'Projects',
  'project_detail'=>'Project Detail',
  'tasks'=>'Tasks & Brief',
  'task_mentions'=>'Task Mentions',
  'leave_requests'=>'Đơn từ nhân sự',
  'attendance'=>'Chấm công',
  'payroll'=>'Payroll',
  'payroll_manager'=>'Payroll Manager',
  'monthly_closing'=>'Monthly Closing',
  'business_finance'=>'Business Finance',
  'finance_operations'=>'Finance Operations',
  'my_finance'=>'My Finance',
  'contract_owners'=>'Contract Owners',
  'sales_commissions'=>'Sales Commission',
  'ctv_approval'=>'CTV Approval',
  'ctv_payroll'=>'CTV Payroll',
  'kpi'=>'KPI Dashboard',
  
  'activity'=>'Activity Log',
  'files'=>'File Links',
  'need_help'=>'Need Help',
  'kudos'=>'Kudos Board',
  'client_portal'=>'Client Portal',
  'approval_workflow'=>'Approval Workflow',
  'quote_project_generator'=>'Quote → Project Generator',
  'quote_generate_project'=>'Quote → Project Generator',
  'generate_project_from_quote'=>'Quote → Project Generator',
  'project_templates'=>'Project Templates',
  'cash_forecast'=>'Cash Forecast',
  'task_detail'=>'Task Detail',
  'payroll_batch'=>'Payroll Batch',
  'search'=>'Tìm kiếm',
  'revenue_overview'=>'Revenue Overview',
];

// Stabilization access guards — MUST run BEFORE header.php to allow clean redirect()
$me = current_user();
$role = $me['role'] ?? '';

if (in_array($page, ['ai_center','ai_quote','ai_knowledge','ai_documents','document_templates']) && !is_director_role($me) && !is_finance_role($me)) {
  redirect('app.php?page=workspace');
}
if (in_array($page, ['approval_workflow','client_portal']) && !is_director_role($me) && !is_finance_role($me)) {
  redirect('app.php?page=workspace');
}
if ($page === 'dashboard' && !is_director_role($me)) {
  redirect('app.php?page=workspace');
}
if (in_array($page, ['business_finance','finance_operations','payroll_manager','monthly_closing','ctv_approval','sales_commissions','contract_owners']) && !is_finance_role($me)) {
  redirect('app.php?page=workspace');
}
if ($page === 'personal_rates' && !is_ctv_role($me) && !is_finance_role($me)) {
  redirect('app.php?page=workspace');
}
if ($page === 'my_finance' && !is_fulltime_role($me) && !is_finance_role($me)) {
  redirect('app.php?page=workspace');
}
if ($page === 'ctv_payroll' && !is_ctv_role($me) && !is_finance_role($me)) {
  redirect('app.php?page=workspace');
}

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';


if (isset($_POST['header_check_action'])) {
    $today = date('Y-m-d');
    $now = date('H:i:s');
    $stmt = $pdo->prepare('SELECT * FROM attendance WHERE user_id=? AND work_date=? LIMIT 1');
    $stmt->execute([$me['id'], $today]);
    $attRow = $stmt->fetch();

    if ($_POST['header_check_action'] === 'in') {
        if (!$attRow) {
            $pdo->prepare('INSERT INTO attendance(user_id,work_date,checkin_time,work_mode,status,note) VALUES(?,?,?,?,?,?)')
                ->execute([$me['id'],$today,$now,'Office','working','Header check-in']);
        } else {
            if (($attRow['status'] ?? '') === 'paused') {
                // Continue from paused state: keep accumulated total_minutes and start counting from now.
                $pdo->prepare("UPDATE attendance SET checkin_time=?, checkout_time=NULL, work_mode='Office', status='working', note='Header resume' WHERE id=?")
                    ->execute([$now,$attRow['id']]);
            } else {
                // Fresh restart only when record is not paused.
                $pdo->prepare("UPDATE attendance SET checkin_time=?, checkout_time=NULL, total_minutes=0, work_mode='Office', status='working', note='Header check-in' WHERE id=?")
                    ->execute([$now,$attRow['id']]);
            }
        }
        log_activity($pdo,'checkin','attendance',$me['id'],'Header check-in');
        if(function_exists('mcoin_award')){ mcoin_award($pdo,(int)$me['id'],(int)mcoin_get_setting($pdo,'attendance_checkin',1500),'Chấm công đúng ngày','attendance',(int)($attRow['id'] ?? 0),'attendance:'.(int)$me['id'].':'.$today); }
        redirect('app.php?page='.$page.'&sound=checkin');
    }

    if ($_POST['header_check_action'] === 'pause' && $attRow) {
        $start = strtotime($attRow['work_date'].' '.$attRow['checkin_time']);
        $mins = (int)($attRow['total_minutes'] ?? 0) + max(0, round((time()-$start)/60));
        $pdo->prepare("UPDATE attendance SET checkout_time=?, total_minutes=?, status='paused', note='Header pause' WHERE id=?")
            ->execute([$now,$mins,$attRow['id']]);
        log_activity($pdo,'pause','attendance',$me['id'],'Header pause');
        redirect('app.php?page='.$page.'&sound=notification');
    }

    if ($_POST['header_check_action'] === 'out' && $attRow) {
        $mins = (int)($attRow['total_minutes'] ?? 0);
        if(!empty($attRow['checkin_time']) && ($attRow['status'] ?? '') === 'working'){
          $start = strtotime($attRow['work_date'].' '.$attRow['checkin_time']);
          $mins += max(0, round((time()-$start)/60));
        }
        $pdo->prepare("UPDATE attendance SET checkout_time=?, total_minutes=?, status='done', note='Header stop' WHERE id=?")
            ->execute([$now,$mins,$attRow['id']]);
        log_activity($pdo,'checkout','attendance',$me['id'],'Header stop');
        redirect('app.php?page='.$page.'&sound=checkout');
    }
}
$stmt = $pdo->prepare("SELECT * FROM attendance WHERE user_id=? AND work_date=CURDATE() AND status IN ('working','paused') LIMIT 1");
$stmt->execute([$me['id']]);
$working = $stmt->fetch();
if(function_exists('mcoin_ensure_schema')) mcoin_ensure_schema($pdo);
$mcoinBalance = function_exists('mcoin_balance') ? mcoin_balance($pdo,(int)$me['id']) : 0;
$recentNotifications = safe_rows($pdo, "SELECT id,title,message,type,link,created_at,is_read FROM notifications WHERE user_id=".(int)$me['id']." ORDER BY id DESC LIMIT 6");
$unreadNotifications = (int)safe_sum($pdo, "SELECT COUNT(*) FROM notifications WHERE user_id=".(int)$me['id']." AND is_read=0");
?>
<main class="main">
  <header class="topbar topbar-v2 compact-topbar">
    <button class="mobile-menu-btn" type="button" onclick="toggleMobileMenu()" aria-label="Mở menu"><i data-lucide="menu"></i></button>
    <div class="topbar-title">
      <span class="eyebrow">Motive Agency Workspace</span>
      <h1><?= e($titles[$page] ?? ucwords(str_replace('_',' ', $page))) ?></h1>
    </div>
    <div class="header-actions">
      <button class="header-search-btn icon-btn" type="button" onclick="openGlobalSearchOverlay()" title="Tìm kiếm (Ctrl/⌘ + K)" aria-label="Tìm kiếm"><i data-lucide="search"></i></button>
      <div class="header-notify-menu">
        <button class="header-notify-btn" type="button" onclick="toggleHeaderNotifications()" aria-label="Thông báo"><i data-lucide="bell"></i><?php if($unreadNotifications>0): ?><em><?= min($unreadNotifications,9) ?></em><?php endif; ?></button>
        <div class="header-notify-popover" id="headerNotifyPopover">
          <div class="notify-pop-head"><div><span class="eyebrow">Notifications</span><b>Thông báo gần đây</b></div><a href="app.php?page=notifications">Xem tất cả</a></div>
          <div class="notify-pop-list" id="headerNotifyList">
            <?php foreach($recentNotifications as $n): $ico = ($n['type']??'')==='task'?'square-check':(($n['type']??'')==='chat'?'message-circle':(($n['type']??'')==='help'?'circle-help':'bell')); ?>
              <a class="notify-pop-card <?= empty($n['is_read'])?'unread':'' ?>" href="<?= e($n['link'] ?: 'app.php?page=notifications') ?>"><span><?= $ico ?></span><div><b><?= e($n['title']) ?></b><small><?= e(mb_substr($n['message'] ?? '',0,90)) ?></small></div></a>
            <?php endforeach; ?>
            <?php if(empty($recentNotifications)): ?><p class="muted">Chưa có thông báo mới.</p><?php endif; ?>
          </div>
        </div>
      </div>
      <a class="header-vcoin-chip" href="admin.php?page=vcoin_manager" title="Mcoin của tôi"><span><i data-lucide="coins"></i></span><b><?= number_format((int)$mcoinBalance,0,',','.') ?></b></a>
      <?php if($working): ?>
        <?php $isPaused = (($working['status'] ?? '') === 'paused'); ?>
        <form method="post"
              class="header-timer header-check-form timer-v5 <?= $isPaused ? 'paused' : 'active' ?>"
              data-start="<?= e(!$isPaused ? $working['work_date'].' '.$working['checkin_time'] : '') ?>"
              id="headerWorkTimer"
              data-base-minutes="<?= (int)($working['total_minutes'] ?? 0) ?>">
          <span class="timer-v5-icon"><?= $isPaused ? '⏸' : '⏱' ?></span>
          <b id="headerTimerTime"><?= sprintf('%02d:%02d:%02d', floor(($working['total_minutes']??0)/60), (($working['total_minutes']??0)%60), 0) ?></b>
          <span class="timer-status-dot" aria-hidden="true"></span>
          <div class="timer-v5-actions">
            <?php if($isPaused): ?>
              <button name="header_check_action" value="in" class="timer-btn start" type="submit" aria-label="Tiếp tục">▶</button>
            <?php else: ?>
              <button name="header_check_action" value="pause" class="timer-btn pause" type="submit" aria-label="Tạm nghỉ">Ⅱ</button>
            <?php endif; ?>
            <button name="header_check_action" value="out" class="timer-btn stop" type="submit" aria-label="Kết thúc ca">■</button>
          </div>
        </form>
      <?php else: ?>
        <form method="post" class="header-timer header-check-form timer-v5 idle" id="headerWorkTimer" data-base-minutes="0">
          <span class="timer-v5-icon">⏱</span>
          <b id="headerTimerTime">Bắt đầu</b>
          <button name="header_check_action" value="in" class="timer-btn start" type="submit" aria-label="Bắt đầu">▶</button>
        </form>
      <?php endif; ?>

      <div class="account-menu">
        <button class="account-chip" type="button" onclick="toggleAccountMenu()">
          <?= avatar_html($me,true) ?>
          <span><?= e($me['name'] ?? 'Account') ?></span>
          <b>⌄</b>
        </button>
        <div class="account-dropdown" id="accountDropdown">
          <a href="app.php?page=profile">Profile</a>
          <a href="app.php?page=my_preferences">Preferences</a>
          <?php if(user_is_admin()): ?><a href="admin.php?page=users">Admin Studio</a><?php endif; ?>
          <a href="logout.php">Logout</a>
        </div>
      </div>
    </div>
  </header>

  <?php
  $moduleFile = __DIR__ . '/modules/' . $page . '.php';
  if (!is_file($moduleFile) && $page === 'quote_project_generator') {
      $moduleFile = __DIR__ . '/modules/quotation_project_generator.php';
  }
  if (!is_file($moduleFile)) {
      echo '<div class="card"><h2>Module chưa sẵn sàng</h2><p class="muted">Không tìm thấy file module: <code>' . htmlspecialchars(basename($moduleFile)) . '</code></p></div>';
  } else {
      require $moduleFile;
  }
  ?>
</main>

<?php if(!empty($_GET['sound'])): ?>
<script>
document.addEventListener('DOMContentLoaded', function(){
  window.soundParam = <?= json_encode($_GET['sound']) ?>;
  setTimeout(function(){ if(window.playTone) playTone(window.soundParam === 'checkin' ? 'checkin' : 'notification'); }, 250);
});
</script>
<?php endif; ?>

<!-- 8E Stable Inline Search + Task Delight Safety Layer -->
<div class="global-search-overlay" id="globalSearchOverlay">
  <div class="global-search-backdrop" onclick="closeGlobalSearchOverlay()"></div>
  <form class="global-search-panel" method="get" action="app.php">
    <input type="hidden" name="page" value="search">
    <span><i data-lucide="search"></i></span>
    <input id="globalSearchInput" name="q" placeholder="Tìm task, project, khách hàng, báo giá..." autocomplete="off">
    <button type="submit">Tìm</button>
  </form>
</div>

<style>
.global-search-overlay{position:fixed;inset:0;z-index:99990;display:none}
.global-search-overlay.open{display:block}
.global-search-backdrop{position:absolute;inset:0;background:rgba(15,23,42,.32);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px)}
.global-search-panel{position:absolute;left:50%;top:92px;width:min(720px,calc(100vw - 32px));transform:translateX(-50%);display:grid;grid-template-columns:42px 1fr auto;gap:10px;align-items:center;padding:14px;border-radius:28px;background:rgba(255,255,255,.97);border:1px solid #e5e7eb;box-shadow:0 28px 90px rgba(15,23,42,.2)}
.global-search-panel span{width:42px;height:42px;border-radius:16px;background:#f5f3ff;color:#7c3aed;display:flex;align-items:center;justify-content:center;font-size:22px;font-weight:950}
.global-search-panel input{border:0!important;background:transparent!important;font-size:20px!important;font-weight:850!important;min-height:46px!important;outline:0!important}
.task-delight-v2{position:fixed;inset:0;z-index:100500;display:flex;align-items:center;justify-content:center;pointer-events:none;opacity:0;transition:opacity .18s ease}
.task-delight-v2.show{opacity:1}.task-delight-v2.hide{opacity:0}
.tdv2-card{position:relative;padding:24px 34px 22px;border-radius:34px;background:rgba(255,255,255,.86);border:1px solid rgba(255,255,255,.88);backdrop-filter:blur(22px);-webkit-backdrop-filter:blur(22px);box-shadow:0 28px 90px rgba(15,23,42,.22),0 0 90px rgba(124,58,237,.18);animation:tdv2CardPop 1.22s cubic-bezier(.16,1,.3,1) forwards;text-align:center}
.tdv2-card strong{display:block;font-size:clamp(40px,6vw,76px);line-height:.88;letter-spacing:-.085em;font-weight:1000;background:linear-gradient(100deg,#7C3AED 0%,#06B6D4 30%,#F97316 68%,#FACC15 100%);-webkit-background-clip:text;background-clip:text;color:transparent}
.tdv2-card span{display:block;margin-top:12px;color:#344054;font-size:15px;font-weight:900}
.tdv2-particle{position:fixed;z-index:100499;pointer-events:none;border-radius:999px;background:var(--tdv2-color);transform:translate(-50%,-50%) rotate(0deg);animation:tdv2Particle 1.25s cubic-bezier(.16,.9,.18,1) forwards}
.tdv2-completed{background:linear-gradient(90deg,rgba(236,253,245,.95),rgba(245,243,255,.8))!important;transition:opacity .42s ease,transform .42s ease}
.tdv2-completed b{text-decoration:line-through;opacity:.56}.tdv2-collapse{opacity:0;transform:translateX(12px) scale(.985)}
@keyframes tdv2CardPop{0%{transform:scale(.72) translateY(18px);opacity:0}22%{transform:scale(1.06);opacity:1}100%{transform:scale(.98) translateY(-4px);opacity:.98}}
@keyframes tdv2Particle{0%{opacity:0;transform:translate(-50%,-50%) scale(.5) rotate(0deg)}12%{opacity:1}100%{opacity:0;transform:translate(calc(-50% + var(--tdv2-x)),calc(-50% + var(--tdv2-y))) scale(.9) rotate(var(--tdv2-r))}}

</style>
<script>
window.openGlobalSearchOverlay=function(){
  var ov=document.getElementById('globalSearchOverlay');
  var input=document.getElementById('globalSearchInput');
  if(!ov)return;
  ov.classList.add('open');
  setTimeout(function(){ if(input) input.focus(); },60);
};
window.closeGlobalSearchOverlay=function(){
  var ov=document.getElementById('globalSearchOverlay');
  if(ov) ov.classList.remove('open');
};

(function(){
  function makeParticle(x,y,color,angle,velocity,size,rotate){
    var p=document.createElement('span');
    p.className='tdv2-particle';
    p.style.left=x+'px'; p.style.top=y+'px';
    p.style.setProperty('--tdv2-color',color);
    p.style.setProperty('--tdv2-x',Math.cos(angle)*velocity+'px');
    p.style.setProperty('--tdv2-y',Math.sin(angle)*velocity+'px');
    p.style.setProperty('--tdv2-r',rotate+'deg');
    p.style.width=size+'px'; p.style.height=(size*.42)+'px';
    document.body.appendChild(p);
    setTimeout(function(){p.remove();},1400);
  }

  window.showGoodJobDelight=function(originEl){
    var old=document.querySelector('.task-delight-v2'); if(old) old.remove();
    var r=originEl ? originEl.getBoundingClientRect() : {left:innerWidth/2,top:innerHeight/2,width:0,height:0};
    var cx=r.left+r.width/2, cy=r.top+r.height/2;
    var colors=['#7C3AED','#06B6D4','#F97316','#FACC15','#10B981','#FF6B4A'];
    for(var i=0;i<46;i++){
      makeParticle(cx,cy,colors[i%colors.length],-Math.PI+Math.random()*Math.PI*2,80+Math.random()*190,7+Math.random()*12,Math.random()*540);
    }
    var w=document.createElement('div');
    w.className='task-delight-v2';
    w.innerHTML='<div class="tdv2-card"><strong>GOOD JOB!</strong><span>Một việc nữa đã hoàn thành.</span></div>';
    document.body.appendChild(w);
    setTimeout(function(){w.classList.add('show');},20);
    setTimeout(function(){w.classList.add('hide');},1280);
    setTimeout(function(){w.remove();},1700);
  };

  function completeRowUI(tick){
    var row=tick.closest('tr')||tick.closest('.private-8e-item')||tick.closest('.private-strip-item')||tick.closest('.private-task-row')||tick.closest('.task-name-cell');
    tick.classList.add('done');
    tick.classList.remove('js-task-delight-done','js-quick-done');
    tick.innerHTML='✓';
    tick.removeAttribute('href');
    if(row){
      row.classList.add('tdv2-completed','task-is-done');
      setTimeout(function(){row.classList.add('tdv2-collapse');},850);
      setTimeout(function(){ if(row && row.parentNode) row.remove(); },1450);
    }
  }

  document.addEventListener('click',function(e){
    var tick=e.target.closest('.js-task-delight-done,.js-quick-done,.task-check[href*="advance="]');
    if(!tick)return;
    e.preventDefault();
    e.stopPropagation();
    if(tick.dataset.busy==='1')return;
    tick.dataset.busy='1';

    var taskId=tick.dataset.taskId || (tick.href && (tick.href.match(/advance=(\d+)/)||[])[1]);
    if(!taskId){ window.showGoodJobDelight(tick); completeRowUI(tick); return; }

    fetch('ajax_task_complete.php',{
      method:'POST',
      headers:{'Content-Type':'application/x-www-form-urlencoded'},
      body:'task_id='+encodeURIComponent(taskId)
    }).then(function(r){return r.json();}).then(function(data){
      if(data && data.ok){
        window.showGoodJobDelight(tick);
        completeRowUI(tick);
      }else{
        tick.dataset.busy='0';
        alert('Không thể hoàn thành task: '+(data && data.error ? data.error : 'unknown'));
      }
    }).catch(function(err){
      tick.dataset.busy='0';
      alert('AJAX lỗi. Vui lòng thử lại.');
      console.error(err);
    });
  },true);

  document.addEventListener('keydown',function(e){
    if(e.key==='Escape') closeGlobalSearchOverlay();
    if((e.metaKey||e.ctrlKey) && e.key.toLowerCase()==='k'){
      e.preventDefault();
      openGlobalSearchOverlay();
    }
  });
})();
</script>
<!-- /8E Stable Inline Search + Task Delight Safety Layer -->


<?php require_once __DIR__ . '/includes/footer.php'; ?>
