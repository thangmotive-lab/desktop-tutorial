<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';
header('Content-Type: application/json; charset=utf-8');
if(!is_logged_in()){ http_response_code(401); echo json_encode(['ok'=>false]); exit; }
$me=current_user();
$type=$_POST['type'] ?? $_GET['type'] ?? '';
$amount=0; $reason=''; $ref='';
if($type==='pomodoro'){
  $amount=(int)vcoin_get_setting($pdo,'pomodoro_complete',1200);
  $session=preg_replace('/[^a-zA-Z0-9_:\-]/','',($_POST['session'] ?? date('YmdHis')));
  $reason='Hoàn thành Pomodoro Focus';
  $ref='pomodoro:'.(int)$me['id'].':'.$session;
}
if(!$amount){ echo json_encode(['ok'=>false,'error'=>'invalid_type']); exit; }
$ok=vcoin_award($pdo,(int)$me['id'],$amount,$reason,$type,null,$ref,'Auto reward from UI');
echo json_encode(['ok'=>$ok,'amount'=>$amount,'balance'=>vcoin_balance($pdo,(int)$me['id'])]);
