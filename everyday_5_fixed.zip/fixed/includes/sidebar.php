<?php
// IA Refactor Sprint 8C — simplified navigation
$active = $_GET['page'] ?? 'dashboard';
$u = current_user();
$isDirector = is_director_role($u);
$isFinance = is_finance_role($u);
$isCtv = is_ctv_role($u);
$isFulltime = is_fulltime_role($u);
$isAdmin = user_is_admin() || $isFinance;

$groups = [];

$workItems = [
  'workspace' => 'Việc của tôi',
  'projects' => 'Projects',
  'tasks' => 'Tasks',
  'calendar' => 'Lịch',
  'need_help' => 'Need Help',
  'kudos' => 'Kudos'
];
if($isDirector){ $workItems['dashboard'] = 'CEO Dashboard'; }
$groups['WORK'] = $workItems;

$salesItems = [
  'clients' => 'Khách hàng',
  'quotation_list' => 'Báo giá',
  'quotation_create' => 'Tạo báo giá',
  'contracts' => 'Hợp đồng',
  'client_portal' => 'Client Portal'
];
$groups['SALES'] = $salesItems;

if($isFinance || $isDirector){
  $groups['FINANCE'] = [
    'business_finance' => 'Tổng quan tài chính',
    'payments' => 'Công nợ',
    'acceptances' => 'Nghiệm thu',
    'payroll_manager' => 'Bảng lương',
    'monthly_closing' => 'Chốt tháng',
    'internal_costs' => 'Internal Cost'
  ];
}

$peopleItems = [
  'okr' => 'OKR',
  'attendance' => 'Bảng công',
  'leave_requests' => 'Đơn từ'
];
if($isFulltime) $peopleItems['my_finance'] = 'My Finance';
if($isCtv) { $peopleItems['personal_rates'] = 'Personal Rate'; $peopleItems['ctv_payroll'] = 'CTV Payroll'; }
$groups['PEOPLE'] = $peopleItems;

if($isDirector || $isFinance){
  $groups['AI'] = [
    'ai_workspace' => 'AI Workspace',
    'ai_knowledge_base' => 'Knowledge Base',
    'ai_document_library' => 'Document Library',
    'ai_generate_center' => 'Generate Center',
    'ai_proposal_engine' => 'Proposal Engine',
    'ai_prompt_studio' => 'Prompt Studio'
  ];
}

// Admin modules are intentionally kept inside Admin Studio, not the workspace sidebar.

$navIcons = [
  'workspace'=>'layout-dashboard','projects'=>'folder-kanban','tasks'=>'square-check','calendar'=>'calendar-days','need_help'=>'circle-alert','kudos'=>'sparkles','dashboard'=>'chart-no-axes-combined',
  'clients'=>'users','quotation_list'=>'file-text','quotation_create'=>'file-plus-2','contracts'=>'file-signature','client_portal'=>'globe-2',
  'payments'=>'wallet','acceptances'=>'badge-check','cash_forecast'=>'trending-up','business_finance'=>'chart-line','finance_operations'=>'settings-2','payroll_manager'=>'badge-dollar-sign','monthly_closing'=>'lock-keyhole','internal_costs'=>'calculator',
  'okr'=>'target','leave_requests'=>'clipboard-pen-line','my_finance'=>'hand-coins','personal_rates'=>'star','ctv_payroll'=>'credit-card',
  'ai_workspace'=>'sparkles','ai_knowledge_base'=>'brain','ai_document_library'=>'library','ai_generate_center'=>'zap','ai_proposal_engine'=>'mail','ai_prompt_studio'=>'terminal-square',
  'users'=>'user-round','permissions'=>'shield-check','integrations'=>'folder-sync','activity'=>'history','approval_workflow'=>'badge-check',
  'quote_project_generator'=>'rocket','project_templates'=>'blocks'
];
$groupIcons = ['WORK'=>'briefcase-business','SALES'=>'handshake','FINANCE'=>'wallet','PEOPLE'=>'users','AI'=>'sparkles'];
function lucide_icon($name,$class=''){ return '<i class="m-icon '.htmlspecialchars($class).'" data-lucide="'.htmlspecialchars($name).'"></i>'; }
?>
<aside class="sidebar compact-sidebar sidebar-v2" id="sidebar">
  <button class="mobile-sidebar-close" type="button" onclick="closeMobileSidebar()">×</button>

  <div class="sidebar-brand-row">
    <a class="brand sidebar-brand-v2" href="app.php?page=workspace" title="Motive Everyday">
      <div class="brand-icon">M</div>
      <div class="brand-text">
        <strong>Motive Everyday</strong>
        <span>Agency Operating System</span>
      </div>
    </a>
    <button class="sidebar-toggle sidebar-toggle-v2" type="button" onclick="toggleSidebar()" aria-label="Thu gọn menu" title="Thu gọn / mở rộng menu">
      <?= lucide_icon('panel-left-close') ?>
    </button>
  </div>

  <nav class="nav-groups sidebar-scroll" aria-label="Main navigation">
    <?php foreach($groups as $groupName=>$items): ?>
      <div class="nav-group">
        <button class="nav-title nav-collapse-trigger" type="button" onclick="toggleNavGroup(this)" aria-expanded="true">
          <?= lucide_icon($groupIcons[$groupName] ?? 'circle', 'group-icon') ?>
          <span><?= e($groupName) ?></span>
          <b>⌄</b>
        </button>
        <div class="nav-group-items">
        <?php foreach($items as $key=>$label): ?>
          <a data-nav-link class="<?= $active===$key?'active':'' ?>" title="<?= e($label) ?>" href="<?= in_array($key,['users','permissions','integrations','activity']) ? 'admin.php?page='.$key : 'app.php?page='.$key ?>">
            <span class="nav-icon"><?= lucide_icon($navIcons[$key] ?? 'circle') ?></span>
            <span class="nav-text"><?= e($label) ?></span>
          </a>
        <?php endforeach; ?>
        </div>
      </div>
    <?php endforeach; ?>

    <div class="nav-group nav-group-extra">
      <div class="nav-group-items">
        <a href="app.php?page=quote_project_generator" title="Quote → Project"><span class="nav-icon"><?= lucide_icon('rocket') ?></span><span class="nav-text">Quote → Project</span></a>
        <a href="app.php?page=project_templates" title="Project Templates"><span class="nav-icon"><?= lucide_icon('blocks') ?></span><span class="nav-text">Project Templates</span></a>
      </div>
    </div>
  </nav>

  <div class="sidebar-footer-v2">
    <a class="side-user-v2" href="app.php?page=profile" title="Profile cá nhân">
      <?= avatar_html($u, true) ?>
      <span class="side-user-info">
        <b><?= e($u['name'] ?? 'Motive User') ?></b>
        <small><?= e($u['role'] ?? 'Team member') ?></small>
      </span>
    </a>
    <a class="sidebar-logout-v2" href="logout.php" title="Đăng xuất">
      <?= lucide_icon('log-out') ?>
      <span class="nav-text">Đăng xuất</span>
    </a>
  </div>
</aside>
