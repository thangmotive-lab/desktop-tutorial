<?php
/* MotiveEveryday Mailer — Gmail SMTP + mail() fallback */
if (!function_exists('motive_email_ensure_schema')) {
function motive_email_ensure_schema($pdo){
  try{
    $pdo->exec("CREATE TABLE IF NOT EXISTS email_logs (
      id INT AUTO_INCREMENT PRIMARY KEY,
      recipient_email VARCHAR(190) NOT NULL,
      recipient_name VARCHAR(190) DEFAULT NULL,
      subject VARCHAR(255) NOT NULL,
      template_key VARCHAR(80) DEFAULT NULL,
      status VARCHAR(30) DEFAULT 'pending',
      error_message TEXT,
      related_type VARCHAR(80) DEFAULT NULL,
      related_id INT DEFAULT NULL,
      created_by INT DEFAULT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      sent_at DATETIME DEFAULT NULL,
      KEY idx_email_logs_created (created_at),
      KEY idx_email_logs_recipient (recipient_email)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS password_resets (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      email VARCHAR(190) NOT NULL,
      token_hash VARCHAR(128) NOT NULL,
      expires_at DATETIME NOT NULL,
      used_at DATETIME DEFAULT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      KEY idx_password_resets_token (token_hash),
      KEY idx_password_resets_user (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  }catch(Throwable $e){}
}
function motive_get_setting($pdo,$key,$default=''){
  try{ if(function_exists('get_setting')) return get_setting($pdo,$key,$default); }catch(Throwable $e){}
  return $default;
}
function motive_set_setting($pdo,$key,$value){
  try{ if(function_exists('set_setting')) return set_setting($pdo,$key,$value); }catch(Throwable $e){}
  return false;
}
function motive_base_url(){
  $scheme=(!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
  $host=$_SERVER['HTTP_HOST'] ?? 'localhost';
  $dir=rtrim(str_replace('\\','/',dirname($_SERVER['SCRIPT_NAME'] ?? '/')),'/');
  return $scheme.'://'.$host.($dir && $dir!=='/' ? $dir : '');
}
function motive_email_template($title,$bodyHtml,$ctaText='',$ctaUrl=''){
  $cta = $ctaText && $ctaUrl ? '<p style="margin:26px 0"><a href="'.htmlspecialchars($ctaUrl).'" style="background:#111827;color:#fff;text-decoration:none;padding:14px 18px;border-radius:14px;font-weight:800;display:inline-block">'.htmlspecialchars($ctaText).'</a></p>' : '';
  return '<!doctype html><html><body style="margin:0;background:#fff7ed;font-family:Inter,Arial,sans-serif;color:#111827"><div style="max-width:640px;margin:0 auto;padding:28px"><div style="background:#fff;border-radius:28px;padding:28px;border:1px solid #f1f5f9;box-shadow:0 20px 60px rgba(15,23,42,.08)"><div style="font-weight:900;color:#ff6b4a;letter-spacing:.08em;text-transform:uppercase;font-size:12px">MotiveEveryday</div><h1 style="margin:8px 0 14px;font-size:30px;line-height:1.08;letter-spacing:-.04em">'.htmlspecialchars($title).'</h1><div style="font-size:15px;line-height:1.65;color:#475569">'.$bodyHtml.'</div>'.$cta.'<hr style="border:0;border-top:1px solid #e5e7eb;margin:28px 0"><p style="font-size:12px;color:#94a3b8;margin:0">Email tự động từ MotiveEveryday · Keep moving forward</p></div></div></body></html>';
}
function motive_smtp_send($host,$port,$secure,$username,$password,$fromEmail,$fromName,$to,$subject,$html,$replyTo=''){
  $port=(int)$port ?: 587;
  $remote = ($secure==='ssl' ? 'ssl://' : '').$host.':'.$port;
  $fp=@stream_socket_client($remote,$errno,$errstr,20,STREAM_CLIENT_CONNECT);
  if(!$fp) throw new Exception('SMTP connect failed: '.$errstr);
  stream_set_timeout($fp,20);
  $read=function() use($fp){ $data=''; while($line=fgets($fp,515)){ $data.=$line; if(isset($line[3]) && $line[3]===' ') break; } return $data; };
  $cmd=function($c,$expect=null) use($fp,$read){ fwrite($fp,$c."\r\n"); $r=$read(); if($expect && substr($r,0,3)!==$expect) throw new Exception('SMTP error after '.$c.': '.$r); return $r; };
  $read();
  $cmd('EHLO '.$_SERVER['HTTP_HOST'],'250');
  if($secure==='tls'){
    $cmd('STARTTLS','220');
    if(!stream_socket_enable_crypto($fp,true,STREAM_CRYPTO_METHOD_TLS_CLIENT)) throw new Exception('STARTTLS failed');
    $cmd('EHLO '.$_SERVER['HTTP_HOST'],'250');
  }
  if($username && $password){
    $cmd('AUTH LOGIN','334');
    $cmd(base64_encode($username),'334');
    $cmd(base64_encode($password),'235');
  }
  $cmd('MAIL FROM:<'.$fromEmail.'>','250');
  $cmd('RCPT TO:<'.$to.'>','250');
  $cmd('DATA','354');
  $headers=[];
  $headers[]='From: '.mb_encode_mimeheader($fromName ?: $fromEmail).' <'.$fromEmail.'>';
  if($replyTo) $headers[]='Reply-To: '.$replyTo;
  $headers[]='To: <'.$to.'>';
  $headers[]='Subject: '.mb_encode_mimeheader($subject);
  $headers[]='MIME-Version: 1.0';
  $headers[]='Content-Type: text/html; charset=UTF-8';
  $headers[]='Content-Transfer-Encoding: 8bit';
  $message=implode("\r\n",$headers)."\r\n\r\n".$html."\r\n.";
  fwrite($fp,$message."\r\n");
  $r=$read(); if(substr($r,0,3)!=='250') throw new Exception('SMTP DATA error: '.$r);
  $cmd('QUIT'); fclose($fp); return true;
}
function motive_send_email($pdo,$to,$subject,$html,$opts=[]){
  motive_email_ensure_schema($pdo);
  $to=trim((string)$to); if(!$to) return false;
  $me=function_exists('current_user') ? current_user() : null;
  $logId=0;
  try{
    $st=$pdo->prepare('INSERT INTO email_logs(recipient_email,recipient_name,subject,template_key,status,related_type,related_id,created_by) VALUES(?,?,?,?,?,?,?,?)');
    $st->execute([$to,$opts['recipient_name']??null,$subject,$opts['template_key']??null,'pending',$opts['related_type']??null,$opts['related_id']??null,(int)($me['id']??0)]);
    $logId=(int)$pdo->lastInsertId();
  }catch(Throwable $e){}
  $ok=false; $err='';
  try{
    $fromEmail=motive_get_setting($pdo,'email_from_email','hello.motivesocial@gmail.com');
    $fromName=motive_get_setting($pdo,'email_from_name','MotiveEveryday');
    $method=motive_get_setting($pdo,'email_method','smtp');
    if($method==='smtp'){
      motive_smtp_send(
        motive_get_setting($pdo,'email_smtp_host','smtp.gmail.com'),
        motive_get_setting($pdo,'email_smtp_port','587'),
        motive_get_setting($pdo,'email_smtp_secure','tls'),
        motive_get_setting($pdo,'email_smtp_username','hello.motivesocial@gmail.com'),
        motive_get_setting($pdo,'email_smtp_password',''),
        $fromEmail,$fromName,$to,$subject,$html
      );
      $ok=true;
    }else{
      $headers="MIME-Version: 1.0\r\nContent-Type: text/html; charset=UTF-8\r\nFrom: ".$fromName." <".$fromEmail.">\r\n";
      $ok=@mail($to,'=?UTF-8?B?'.base64_encode($subject).'?=',$html,$headers);
      if(!$ok) throw new Exception('PHP mail() failed');
    }
  }catch(Throwable $e){ $err=$e->getMessage(); }
  try{
    $pdo->prepare('UPDATE email_logs SET status=?, error_message=?, sent_at=? WHERE id=?')->execute([$ok?'sent':'failed',$err,$ok?date('Y-m-d H:i:s'):null,$logId]);
  }catch(Throwable $e){}
  return $ok;
}
function motive_email_welcome($pdo,$user,$plainPassword=''){
  $base=motive_base_url();
  $body='<p>Chào <b>'.htmlspecialchars($user['name'] ?? '').'</b>,</p><p>Tài khoản MotiveEveryday của bạn đã được tạo.</p><p><b>Email:</b> '.htmlspecialchars($user['email'] ?? '').'</p>'.($plainPassword?'<p><b>Mật khẩu tạm thời:</b> '.htmlspecialchars($plainPassword).'</p><p>Bạn nên đổi mật khẩu sau khi đăng nhập.</p>':'');
  return motive_send_email($pdo,$user['email'],'Chào mừng bạn đến với MotiveEveryday',motive_email_template('Tài khoản MotiveEveryday đã sẵn sàng',$body,'Đăng nhập',$base.'/login.php'),['template_key'=>'welcome','related_type'=>'user','related_id'=>$user['id']??null,'recipient_name'=>$user['name']??null]);
}
function motive_email_password_reset($pdo,$user,$resetLink){
  $body='<p>Chào <b>'.htmlspecialchars($user['name'] ?? '').'</b>,</p><p>Bạn vừa yêu cầu đặt lại mật khẩu cho MotiveEveryday. Link này có hiệu lực trong 30 phút.</p><p>Nếu không phải bạn yêu cầu, hãy bỏ qua email này.</p>';
  return motive_send_email($pdo,$user['email'],'Đặt lại mật khẩu MotiveEveryday',motive_email_template('Đặt lại mật khẩu',$body,'Đặt lại mật khẩu',$resetLink),['template_key'=>'password_reset','related_type'=>'user','related_id'=>$user['id']??null,'recipient_name'=>$user['name']??null]);
}
function motive_email_payroll($pdo,$user,$payroll,$event='notified'){
  $map=['notified'=>'Bảng lương đã được gửi','approved'=>'Bảng lương đã được duyệt','paid'=>'Bảng lương đã thanh toán'];
  $title=$map[$event] ?? 'Cập nhật bảng lương';
  $body='<p>Chào <b>'.htmlspecialchars($user['name'] ?? '').'</b>,</p><p>'.$title.' cho kỳ lương <b>'.htmlspecialchars($payroll['month'] ?? $payroll['salary_month'] ?? '').'</b>.</p><p><b>Tổng lương:</b> '.number_format((float)($payroll['total_salary'] ?? $payroll['net_salary'] ?? 0),0,',','.').'đ</p>';
  return motive_send_email($pdo,$user['email'],$title.' - MotiveEveryday',motive_email_template($title,$body,'Xem bảng lương',motive_base_url().'/app.php?page=payroll'),['template_key'=>'payroll_'.$event,'related_type'=>'payroll','related_id'=>$payroll['id']??null,'recipient_name'=>$user['name']??null]);
}
function motive_email_quote($pdo,$email,$name,$quote,$publicLink){
  $body='<p>Chào <b>'.htmlspecialchars($name ?: 'Quý khách').'</b>,</p><p>Motive Agency gửi bạn báo giá <b>'.htmlspecialchars($quote['quote_code'] ?? '').'</b>: '.htmlspecialchars($quote['title'] ?? '').'</p><p>Bạn có thể xem báo giá tại link bên dưới.</p>';
  return motive_send_email($pdo,$email,'Motive Agency gửi báo giá '.($quote['quote_code'] ?? ''),motive_email_template('Motive Agency gửi báo giá',$body,'Xem báo giá',$publicLink),['template_key'=>'quotation_send','related_type'=>'quotation','related_id'=>$quote['id']??null,'recipient_name'=>$name]);
}
function motive_email_contract($pdo,$email,$name,$title,$link=''){
  $body='<p>Chào <b>'.htmlspecialchars($name ?: 'Quý khách').'</b>,</p><p>Motive Agency gửi bạn hợp đồng dịch vụ. Vui lòng kiểm tra thông tin và phản hồi giúp team.</p>';
  return motive_send_email($pdo,$email,'Motive Agency gửi hợp đồng dịch vụ',motive_email_template('Motive Agency gửi hợp đồng',$body,$link?'Xem hợp đồng':'',$link),['template_key'=>'contract_send','related_type'=>'contract','recipient_name'=>$name]);
}
}
?>
