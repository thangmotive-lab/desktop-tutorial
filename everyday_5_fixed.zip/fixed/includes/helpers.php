<?php
if (!function_exists('str_contains')) {
    function str_contains($haystack, $needle) {
        return $needle === '' || strpos($haystack, $needle) !== false;
    }
}

function e($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function money($n) {
    return number_format((float)$n, 0, ',', '.') . ' VNĐ';
}

function num($n) {
    return number_format((float)$n, 0, ',', '.');
}

function gp_percent($revenue, $cost) {
    if ((float)$revenue <= 0) return 0;
    return round((((float)$revenue - (float)$cost) / (float)$revenue) * 100, 1);
}

function redirect($url) {
    if (!headers_sent()) {
        header('Location: ' . $url);
        exit;
    }
    $safeUrl = htmlspecialchars($url, ENT_QUOTES, 'UTF-8');
    echo '<script>window.location.href="'.$safeUrl.'";</script>';
    echo '<noscript><meta http-equiv="refresh" content="0;url='.$safeUrl.'"></noscript>';
    exit;
}

function public_token() {
    return bin2hex(random_bytes(12));
}


function priority_options() {
    return [
        'Khẩn cấp làm ngay' => '🔥 Khẩn cấp làm ngay',
        'Làm ngay' => '⚡ Làm ngay',
        'Quan trọng' => '⭐ Quan trọng',
        'Lúc nào làm cũng được' => '🌿 Lúc nào làm cũng được',
    ];
}

function normalize_priority($priority) {
    $p = trim((string)$priority);
    $map = [
        'Urgent' => 'Khẩn cấp làm ngay',
        'High' => 'Làm ngay',
        'Khẩn cấp' => 'Khẩn cấp làm ngay',
        'Khẩn cấp làm ngay' => 'Khẩn cấp làm ngay',
        'Làm ngay' => 'Làm ngay',
        'Quan trọng' => 'Quan trọng',
        'Normal' => 'Quan trọng',
        'Medium' => 'Quan trọng',
        'Low' => 'Lúc nào làm cũng được',
        'Không khẩn cấp' => 'Lúc nào làm cũng được',
        'Không quan trọng' => 'Lúc nào làm cũng được',
        'Lúc nào làm cũng được' => 'Lúc nào làm cũng được',
    ];
    return $map[$p] ?? ($p !== '' ? $p : 'Quan trọng');
}

function priority_rank($priority) {
    $p = normalize_priority($priority);
    return ['Khẩn cấp làm ngay'=>1,'Làm ngay'=>2,'Quan trọng'=>3,'Lúc nào làm cũng được'=>4][$p] ?? 3;
}

function badge_class($status) {
    $s = mb_strtolower((string)$status, 'UTF-8');
    if (str_contains($s,'khẩn cấp làm ngay') || str_contains($s,'urgent') || str_contains($s,'khẩn cấp')) return 'red priority-urgent-now';
    if (str_contains($s,'làm ngay') || str_contains($s,'high')) return 'orange priority-now';
    if (str_contains($s,'quan trọng') || str_contains($s,'normal') || str_contains($s,'medium')) return 'purple priority-important';
    if (str_contains($s,'lúc nào') || str_contains($s,'không khẩn') || str_contains($s,'low')) return 'green priority-anytime';
    if (str_contains($s,'done') || str_contains($s,'xong') || str_contains($s,'approved') || str_contains($s,'đã') || str_contains($s,'paid') || str_contains($s,'hoàn')) return 'green';
    if (str_contains($s,'pending') || str_contains($s,'draft') || str_contains($s,'chờ') || str_contains($s,'waiting')) return 'orange';
    if (str_contains($s,'trễ') || str_contains($s,'quá') || str_contains($s,'reject') || str_contains($s,'từ chối')) return 'red';
    return 'purple';
}

function initials($name) {
    $name = trim((string)$name);
    if (!$name) return 'ME';
    $parts = preg_split('/\s+/', $name);
    $a = mb_substr($parts[0],0,1,'UTF-8');
    $b = count($parts)>1 ? mb_substr(end($parts),0,1,'UTF-8') : '';
    return mb_strtoupper($a.$b,'UTF-8');
}

function avatar_html($user, $small=false) {
    $size = $small ? 'avatar small' : 'avatar';
    $name = $user['name'] ?? '';
    $avatar = $user['avatar'] ?? '';
    if ($avatar) {
        return '<span class="'.$size.'"><img src="'.e($avatar).'" alt="'.e($name).'"></span>';
    }
    return '<span class="'.$size.'">'.e(initials($name)).'</span>';
}

function log_activity($pdo, $action, $target_type='', $target_id=null, $description='') {
    $u = current_user();
    if (!$u) return;
    $stmt = $pdo->prepare('INSERT INTO activity_logs(user_id, action, target_type, target_id, description) VALUES(?,?,?,?,?)');
    $stmt->execute([$u['id'], $action, $target_type, $target_id, $description]);
}

function create_notification($pdo, $user_id, $title, $message, $type='general', $link='') {
    $stmt = $pdo->prepare('INSERT INTO notifications(user_id, title, message, type, link) VALUES(?,?,?,?,?)');
    $stmt->execute([$user_id, $title, $message, $type, $link]);
}

function quotation_totals($pdo, $quotation_id) {
    $stmt = $pdo->prepare('SELECT COALESCE(SUM(subtotal),0) subtotal, COALESCE(SUM(vat_amount),0) vat, COALESCE(SUM(total),0) total FROM quotation_items WHERE quotation_id=?');
    $stmt->execute([$quotation_id]);
    $q = $stmt->fetch();
    $stmt = $pdo->prepare('SELECT COALESCE(SUM(total),0) cost FROM internal_cost_items WHERE quotation_id=?');
    $stmt->execute([$quotation_id]);
    $c = $stmt->fetch();
    return [
        'subtotal'=>(float)$q['subtotal'],
        'vat'=>(float)$q['vat'],
        'total'=>(float)$q['total'],
        'cost'=>(float)$c['cost'],
        'profit'=>(float)$q['total']-(float)$c['cost'],
        'gp'=>gp_percent((float)$q['total'], (float)$c['cost'])
    ];
}




function money_short($n) {
    $n = (float)$n;
    if (abs($n) >= 1000000000) return rtrim(rtrim(number_format($n/1000000000, 1, ',', '.'), '0'), ',') . 'B';
    if (abs($n) >= 1000000) return rtrim(rtrim(number_format($n/1000000, 1, ',', '.'), '0'), ',') . 'M';
    if (abs($n) >= 1000) return rtrim(rtrim(number_format($n/1000, 1, ',', '.'), '0'), ',') . 'K';
    return number_format($n, 0, ',', '.');
}


function get_setting($pdo, $key, $default='') {
    try {
        $stmt = $pdo->prepare('SELECT setting_value FROM app_settings WHERE setting_key=? LIMIT 1');
        $stmt->execute([$key]);
        $row = $stmt->fetch();
        return $row ? $row['setting_value'] : $default;
    } catch (Exception $e) {
        return $default;
    }
}

function set_setting($pdo, $key, $value) {
    try {
        $stmt = $pdo->prepare('INSERT INTO app_settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)');
        $stmt->execute([$key,$value]);
    } catch (Exception $e) {
        return false;
    }
    return true;
}


function table_exists($pdo, $table) {
    try {
        $stmt = $pdo->prepare("SHOW TABLES LIKE ?");
        $stmt->execute([$table]);
        return (bool)$stmt->fetchColumn();
    } catch (Exception $e) {
        return false;
    }
}

function column_exists($pdo, $table, $column) {
    try {
        $stmt = $pdo->prepare("SHOW COLUMNS FROM `$table` LIKE ?");
        $stmt->execute([$column]);
        return (bool)$stmt->fetchColumn();
    } catch (Exception $e) {
        return false;
    }
}

function next_auto_code($pdo, $prefix, $table, $column) {
    $year = date('Y');
    $like = $prefix . '-' . $year . '-%';
    try {
        $stmt = $pdo->prepare("SELECT `$column` FROM `$table` WHERE `$column` LIKE ? ORDER BY id DESC LIMIT 1");
        $stmt->execute([$like]);
        $last = $stmt->fetchColumn();
        if ($last && preg_match('/-(\d+)$/', $last, $m)) {
            $num = (int)$m[1] + 1;
        } else {
            $num = 1;
        }
    } catch (Exception $e) {
        $num = 1;
    }
    return $prefix . '-' . $year . '-' . str_pad((string)$num, 4, '0', STR_PAD_LEFT);
}

function ensure_quotation_version($pdo, $quotation_id) {
    $stmt = $pdo->prepare('SELECT * FROM quotation_versions WHERE quotation_id=? ORDER BY version_no DESC LIMIT 1');
    $stmt->execute([$quotation_id]);
    $v = $stmt->fetch();
    if ($v) return $v;

    $qstmt = $pdo->prepare('SELECT * FROM quotations WHERE id=?');
    $qstmt->execute([$quotation_id]);
    $q = $qstmt->fetch();

    $pdo->prepare('INSERT INTO quotation_versions(quotation_id,version_no,title,note,created_by) VALUES(?,?,?,?,?)')
        ->execute([$quotation_id,1,$q['title'] ?? 'Quotation V1','Auto-created from legacy quotation',current_user()['id'] ?? null]);
    $vid = $pdo->lastInsertId();

    if (table_exists($pdo, 'quotation_items') && column_exists($pdo, 'quotation_items', 'quotation_version_id')) {
        $pdo->prepare('UPDATE quotation_items SET quotation_version_id=? WHERE quotation_id=? AND (quotation_version_id IS NULL OR quotation_version_id=0)')
            ->execute([$vid,$quotation_id]);
    }

    $stmt = $pdo->prepare('SELECT * FROM quotation_versions WHERE id=?');
    $stmt->execute([$vid]);
    return $stmt->fetch();
}

function quotation_version_totals($pdo, $version_id) {
    try {
        $stmt = $pdo->prepare('SELECT COALESCE(SUM(subtotal),0) subtotal, COALESCE(SUM(vat_amount),0) vat, COALESCE(SUM(total),0) total FROM quotation_items WHERE quotation_version_id=?');
        $stmt->execute([$version_id]);
        $t = $stmt->fetch();
        return ['subtotal'=>(float)$t['subtotal'],'vat'=>(float)$t['vat'],'total'=>(float)$t['total']];
    } catch (Exception $e) {
        return ['subtotal'=>0,'vat'=>0,'total'=>0];
    }
}

function sync_quotation_version_totals($pdo, $version_id) {
    $t = quotation_version_totals($pdo, $version_id);
    $stmt = $pdo->prepare('UPDATE quotation_versions SET subtotal=?,vat=?,total=? WHERE id=?');
    $stmt->execute([$t['subtotal'],$t['vat'],$t['total'],$version_id]);
}

function replace_docx_placeholders($templatePath, $outputPath, $data) {
    if (!class_exists('ZipArchive')) {
        throw new Exception('PHP ZipArchive extension chưa được bật trên hosting.');
    }
    if (!file_exists($templatePath)) {
        throw new Exception('Không tìm thấy template DOCX: '.$templatePath);
    }
    copy($templatePath, $outputPath);
    $zip = new ZipArchive();
    if ($zip->open($outputPath) !== true) {
        throw new Exception('Không mở được file DOCX output.');
    }
    $files = ['word/document.xml'];
    for ($i=0; $i<$zip->numFiles; $i++) {
        $name = $zip->getNameIndex($i);
        if (preg_match('/^word\\/(header|footer)\\d*\\.xml$/', $name)) $files[] = $name;
    }
    foreach ($files as $file) {
        $xml = $zip->getFromName($file);
        if ($xml === false) continue;
        foreach ($data as $key=>$value) {
            $xml = str_replace('{{'.$key.'}}', htmlspecialchars((string)$value, ENT_XML1 | ENT_COMPAT, 'UTF-8'), $xml);
            $xml = str_replace('['.$key.']', htmlspecialchars((string)$value, ENT_XML1 | ENT_COMPAT, 'UTF-8'), $xml);
        }
        $zip->addFromString($file, $xml);
    }
    $zip->close();
    return $outputPath;
}


function task_status_next($status) {
    $flow = ['Todo'=>'Doing','Doing'=>'Review','Review'=>'Waiting Approval','Waiting Approval'=>'Done','Done'=>'Done'];
    return $flow[$status] ?? 'Doing';
}

function project_progress_from_tasks($pdo, $project_id) {
    try {
        $stmt=$pdo->prepare("SELECT COUNT(*) total, SUM(CASE WHEN status='Done' THEN 1 ELSE 0 END) done FROM tasks WHERE project_id=?");
        $stmt->execute([$project_id]);
        $r=$stmt->fetch();
        $total=(int)($r['total']??0);
        $done=(int)($r['done']??0);
        return [$done,$total,$total>0?round($done/$total*100):0];
    } catch(Exception $e) {
        return [0,0,0];
    }
}

function task_need_support_cols() {
    return "COALESCE(t.need_support,t.help_requested,0) need_support_flag";
}


function workload_level($open_tasks) {
    $n = (int)$open_tasks;
    if ($n >= 11) return 'Red';
    if ($n >= 6) return 'Yellow';
    return 'Green';
}

function workload_badge_class($level) {
    if ($level === 'Red') return 'red';
    if ($level === 'Yellow') return 'orange';
    return 'green';
}

function deliverable_summary($pdo, $project_id) {
    $summary = [];
    try {
        $stmt = $pdo->prepare("SELECT deliverable_type, target_count FROM project_deliverables WHERE project_id=? ORDER BY deliverable_type");
        $stmt->execute([$project_id]);
        foreach ($stmt->fetchAll() as $r) {
            $type = $r['deliverable_type'] ?: 'Task';
            $summary[$type] = ['target'=>(int)$r['target_count'], 'done'=>0, 'total_task'=>0];
        }
    } catch(Exception $e) {}

    try {
        $stmt = $pdo->prepare("SELECT COALESCE(NULLIF(deliverable_type,''),'Task') type, 
            SUM(CASE WHEN status='Done' THEN COALESCE(deliverable_count,1) ELSE 0 END) done,
            SUM(COALESCE(deliverable_count,1)) total_task
            FROM tasks WHERE project_id=? GROUP BY COALESCE(NULLIF(deliverable_type,''),'Task')");
        $stmt->execute([$project_id]);
        foreach ($stmt->fetchAll() as $r) {
            $type = $r['type'];
            if (!isset($summary[$type])) $summary[$type] = ['target'=>0,'done'=>0,'total_task'=>0];
            $summary[$type]['done'] = (int)$r['done'];
            $summary[$type]['total_task'] = (int)$r['total_task'];
        }
    } catch(Exception $e) {}

    return $summary;
}

function mention_options_json($pdo) {
    try {
        $rows = $pdo->query("SELECT id,name,email,avatar FROM users WHERE status='active' OR status IS NULL ORDER BY name")->fetchAll();
        return json_encode($rows, JSON_UNESCAPED_UNICODE);
    } catch(Exception $e) {
        return '[]';
    }
}


function has_mood_today($pdo, $user_id) {
    try {
        $stmt=$pdo->prepare('SELECT id FROM mood_checkins WHERE user_id=? AND checkin_date=CURDATE() LIMIT 1');
        $stmt->execute([$user_id]);
        return (bool)$stmt->fetchColumn();
    } catch(Exception $e) {
        return true;
    }
}

function mood_label($mood) {
    $map = [
        'very_happy'=>'😄 Rất vui',
        'good'=>'🙂 Ổn',
        'normal'=>'😐 Bình thường',
        'overloaded'=>'😵 Hơi quá tải',
        'sad'=>'😔 Hơi buồn'
    ];
    return $map[$mood] ?? $mood;
}

function mood_score($mood) {
    $map = ['very_happy'=>5,'good'=>4,'normal'=>3,'overloaded'=>2,'sad'=>1];
    return $map[$mood] ?? 3;
}

function user_pref($pdo, $user_id) {
    try {
        $stmt=$pdo->prepare('SELECT * FROM user_preferences WHERE user_id=? LIMIT 1');
        $stmt->execute([$user_id]);
        $row=$stmt->fetch();
        if($row) return $row;
        $pdo->prepare('INSERT INTO user_preferences(user_id) VALUES(?)')->execute([$user_id]);
    } catch(Exception $e) {}
    return ['mute_notification'=>0,'mute_sound'=>0,'popup_position'=>'top-right'];
}


function can_view_business_finance() {
    $u = current_user();
    $role = $u['role'] ?? '';
    return user_is_admin() || in_array($role, ['CEO','Director','Accounting','Kế toán','Finance','HR']);
}

function finance_month_bounds($month) {
    if (!$month) $month = date('Y-m');
    return [$month.'-01', date('Y-m-t', strtotime($month.'-01'))];
}



function agency_money_flow_metrics($pdo, $month) {
    [$start,$end] = finance_month_bounds($month);
    $m = [
        // Sales funnel
        'pipeline_value'=>0,          // Quotation not rejected/lost/completed
        'approved_quote_value'=>0,    // Client agreed but no contract yet
        'approved_quote_count'=>0,
        // Contract accounting
        'booked_revenue'=>0,          // Signed contract value
        'contract_count'=>0,
        // Cash accounting
        'cash_collected'=>0,          // Paid payment schedules
        'receivable_due'=>0,          // Unpaid schedules due this month
        'overdue_receivable'=>0,      // Unpaid schedules before today
        // Cost/profit
        'internal_cost_total'=>0,
        'payroll_total'=>0,
        'expense_total'=>0,
        'gross_profit_booked'=>0,
        'cash_profit'=>0
    ];

    try {
        $stmt=$pdo->prepare("SELECT COALESCE(SUM(COALESCE(expected_revenue,0)),0)
          FROM quotations
          WHERE COALESCE(quote_month,DATE_FORMAT(COALESCE(quote_date,created_at),'%Y-%m'))=?
          AND COALESCE(contract_status,'none') NOT IN ('lost','completed','contract_signed')
          AND status NOT IN ('Reject','Lost','Completed')");
        $stmt->execute([$month]); $m['pipeline_value']=(float)$stmt->fetchColumn();
    } catch(Exception $e) {}

    try {
        $stmt=$pdo->prepare("SELECT COALESCE(SUM(COALESCE(expected_revenue,0)),0), COUNT(*)
          FROM quotations q
          WHERE COALESCE(q.contract_status,'none')='client_agreed'
          AND NOT EXISTS(SELECT 1 FROM contracts c WHERE c.quotation_id=q.id)
          AND COALESCE(q.quote_month,DATE_FORMAT(COALESCE(q.quote_date,q.created_at),'%Y-%m'))=?");
        $stmt->execute([$month]); $row=$stmt->fetch(PDO::FETCH_NUM);
        $m['approved_quote_value']=(float)($row[0]??0); $m['approved_quote_count']=(int)($row[1]??0);
    } catch(Exception $e) {}

    try {
        $stmt=$pdo->prepare("SELECT COALESCE(SUM(total_value),0), COUNT(*)
          FROM contracts
          WHERE DATE(COALESCE(signed_date,created_at)) BETWEEN ? AND ?
          AND status NOT IN ('Reject','Lost','Canceled','Cancelled','Đã hủy','Hủy')");
        $stmt->execute([$start,$end]); $row=$stmt->fetch(PDO::FETCH_NUM);
        $m['booked_revenue']=(float)($row[0]??0); $m['contract_count']=(int)($row[1]??0);
    } catch(Exception $e) {}

    try {
        $stmt=$pdo->prepare("SELECT COALESCE(SUM(amount),0)
          FROM payment_schedules
          WHERE status='paid'
          AND DATE(COALESCE(paid_date,due_date)) BETWEEN ? AND ?");
        $stmt->execute([$start,$end]); $m['cash_collected']=(float)$stmt->fetchColumn();
    } catch(Exception $e) {}

    try {
        $stmt=$pdo->prepare("SELECT COALESCE(SUM(amount),0)
          FROM payment_schedules
          WHERE status!='paid'
          AND DATE(due_date) BETWEEN ? AND ?");
        $stmt->execute([$start,$end]); $m['receivable_due']=(float)$stmt->fetchColumn();
    } catch(Exception $e) {}

    try {
        $m['overdue_receivable']=(float)$pdo->query("SELECT COALESCE(SUM(amount),0)
          FROM payment_schedules
          WHERE status!='paid' AND due_date < CURDATE()")->fetchColumn();
    } catch(Exception $e) {}

    try {
        $stmt=$pdo->prepare("SELECT COALESCE(SUM(ici.total),0)
          FROM internal_cost_items ici
          JOIN quotations q ON q.id=ici.quotation_id
          JOIN contracts c ON c.quotation_id=q.id
          WHERE DATE(COALESCE(c.signed_date,c.created_at)) BETWEEN ? AND ?");
        $stmt->execute([$start,$end]); $m['internal_cost_total']=(float)$stmt->fetchColumn();
    } catch(Exception $e) {}

    try {
        $stmt=$pdo->prepare("SELECT COALESCE(SUM(COALESCE(net_salary,total_salary,0)),0) FROM payroll WHERE COALESCE(salary_month,month)=?");
        $stmt->execute([$month]); $m['payroll_total']=(float)$stmt->fetchColumn();
    } catch(Exception $e) {}

    try {
        $stmt=$pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM business_expenses WHERE expense_month=?");
        $stmt->execute([$month]); $m['expense_total']=(float)$stmt->fetchColumn();
    } catch(Exception $e) {}

    $m['gross_profit_booked'] = $m['booked_revenue'] - $m['internal_cost_total'];
    $m['cash_profit'] = $m['cash_collected'] - $m['internal_cost_total'] - $m['payroll_total'] - $m['expense_total'];
    return $m;
}


function finance_metrics($pdo, $month) {
    $flow = agency_money_flow_metrics($pdo, $month);
    return [
        'revenue_total'=>$flow['booked_revenue'],
        'collected_total'=>$flow['cash_collected'],
        'receivable_total'=>$flow['receivable_due'],
        'internal_cost_total'=>$flow['internal_cost_total'],
        'payroll_total'=>$flow['payroll_total'],
        'expense_total'=>$flow['expense_total'],
        'gross_profit'=>$flow['gross_profit_booked'],
        'net_profit'=>$flow['cash_profit'],
        'pipeline_value'=>$flow['pipeline_value'],
        'approved_quote_value'=>$flow['approved_quote_value'],
        'approved_quote_count'=>$flow['approved_quote_count'],
        'overdue_receivable'=>$flow['overdue_receivable'],
        'contract_count'=>$flow['contract_count']
    ];
}


function is_collaborator_user($user) {
    $role = mb_strtolower((string)($user['role'] ?? ''), 'UTF-8');
    return str_contains($role,'collaborator') || str_contains($role,'cộng tác') || str_contains($role,'freelance') || str_contains($role,'ctv');
}

function get_personal_rate_for_task($pdo, $user_id, $deliverable_type) {
    try {
        $stmt=$pdo->prepare("SELECT * FROM personal_rates WHERE user_id=? AND status='active' AND (rate_status='approved' OR rate_status IS NULL) AND (item_name=? OR item_name LIKE ?) ORDER BY id DESC LIMIT 1");
        $stmt->execute([$user_id,$deliverable_type,'%'.$deliverable_type.'%']);
        $r=$stmt->fetch();
        return $r ? (float)$r['unit_price'] : 0;
    } catch(Exception $e) {
        return 0;
    }
}

function ensure_ctv_payroll($pdo, $user_id, $month) {
    $stmt=$pdo->prepare('SELECT id FROM ctv_payrolls WHERE user_id=? AND payroll_month=? LIMIT 1');
    $stmt->execute([$user_id,$month]);
    $id=$stmt->fetchColumn();
    if($id) return (int)$id;
    $pdo->prepare('INSERT INTO ctv_payrolls(user_id,payroll_month,status) VALUES(?,?,?)')->execute([$user_id,$month,'draft']);
    return (int)$pdo->lastInsertId();
}

function recalc_ctv_payroll($pdo, $payroll_id) {
    $stmt=$pdo->prepare('SELECT COALESCE(SUM(amount),0) FROM ctv_payroll_items WHERE payroll_id=?');
    $stmt->execute([$payroll_id]);
    $gross=(float)$stmt->fetchColumn();
    $stmt=$pdo->prepare('SELECT deduction FROM ctv_payrolls WHERE id=?');
    $stmt->execute([$payroll_id]);
    $deduction=(float)$stmt->fetchColumn();
    $net=max(0,$gross-$deduction);
    $pdo->prepare('UPDATE ctv_payrolls SET gross_amount=?, net_amount=? WHERE id=?')->execute([$gross,$net,$payroll_id]);
}

function generate_ctv_payroll_for_user_month($pdo, $user_id, $month) {
    [$start,$end]=finance_month_bounds($month);
    $payroll_id=ensure_ctv_payroll($pdo,$user_id,$month);
    $stmt=$pdo->prepare("SELECT t.*,p.id project_id FROM tasks t LEFT JOIN projects p ON p.id=t.project_id WHERE t.assignee_id=? AND t.status='Done' AND DATE(COALESCE(t.completed_at,t.deadline)) BETWEEN ? AND ?");
    $stmt->execute([$user_id,$start,$end]);
    foreach($stmt->fetchAll() as $t){
        $type=$t['deliverable_type'] ?: $t['deliverable'] ?: 'Task';
        $qty=(float)($t['deliverable_count'] ?: $t['product_quantity'] ?: 1);
        $unit=(float)($t['product_unit_price'] ?: get_personal_rate_for_task($pdo,$user_id,$type));
        $amount=$qty*$unit;
        if($amount<=0) continue;
        $pdo->prepare('INSERT INTO ctv_payroll_items(payroll_id,task_id,project_id,deliverable_type,qty,unit_price,amount,note) VALUES(?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE deliverable_type=VALUES(deliverable_type), qty=VALUES(qty), unit_price=VALUES(unit_price), amount=VALUES(amount)')
            ->execute([$payroll_id,$t['id'],$t['project_id'],$type,$qty,$unit,$amount,$t['title']]);
    }
    recalc_ctv_payroll($pdo,$payroll_id);
    return $payroll_id;
}

function generate_sales_commission_for_contract($pdo, $contract_id) {
    try {
        $stmt=$pdo->prepare('SELECT * FROM contracts WHERE id=?');
        $stmt->execute([$contract_id]);
        $c=$stmt->fetch();
        if(!$c) return false;
        $owner=(int)($c['sales_owner_id'] ?: $c['care_owner_id'] ?: $c['contract_owner_id'] ?: $c['quote_owner_id'] ?: 0);
        if(!$owner) return false;
        $rate=(float)($c['commission_rate'] ?: 2);
        $value=(float)($c['total_value'] ?: 0);
        $amount=$value*$rate/100;
        $month=date('Y-m', strtotime($c['signed_date'] ?: date('Y-m-d')));
        $pdo->prepare('INSERT INTO sales_commissions(user_id,contract_id,commission_month,contract_value,rate_percent,amount,status,note) VALUES(?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE contract_value=VALUES(contract_value), rate_percent=VALUES(rate_percent), amount=VALUES(amount)')
            ->execute([$owner,$contract_id,$month,$value,$rate,$amount,'pending','Auto-generated from signed contract']);
        $pdo->prepare('UPDATE contracts SET commission_generated=1 WHERE id=?')->execute([$contract_id]);
        return true;
    } catch(Exception $e) {
        return false;
    }
}


function approval_counts($pdo) {
    $counts=['tasks'=>0,'ctv'=>0,'commission'=>0,'payroll'=>0,'total'=>0];
    try { $counts['tasks']=(int)$pdo->query("SELECT COUNT(*) FROM tasks WHERE status='Waiting Approval'")->fetchColumn(); } catch(Exception $e){}
    try { $counts['ctv']=(int)$pdo->query("SELECT COUNT(*) FROM ctv_payrolls WHERE status IN ('draft','pending')")->fetchColumn(); } catch(Exception $e){}
    try { $counts['commission']=(int)$pdo->query("SELECT COUNT(*) FROM sales_commissions WHERE status='pending'")->fetchColumn(); } catch(Exception $e){}
    try { $counts['payroll']=(int)$pdo->query("SELECT COUNT(*) FROM payroll WHERE status='published' AND employee_approval_status='pending'")->fetchColumn(); } catch(Exception $e){}
    $counts['total']=$counts['tasks']+$counts['ctv']+$counts['commission']+$counts['payroll'];
    return $counts;
}

function recalc_okr_objective($pdo, $objective_id) {
    try {
        $stmt=$pdo->prepare("SELECT progress,weight FROM okr_key_results WHERE objective_id=?");
        $stmt->execute([$objective_id]);
        $rows=$stmt->fetchAll();
        $sum=0; $w=0;
        foreach($rows as $r){ $weight=(float)($r['weight'] ?: 1); $sum += (float)$r['progress']*$weight; $w += $weight; }
        $progress=$w>0?round($sum/$w,2):0;
        $pdo->prepare('UPDATE okr_objectives SET progress=? WHERE id=?')->execute([$progress,$objective_id]);
        return $progress;
    } catch(Exception $e) { return 0; }
}

function calc_kr_progress($current,$target,$start=0) {
    $current=(float)$current; $target=(float)$target; $start=(float)$start;
    if($target==$start) return $current>=$target?100:0;
    $p=($current-$start)/($target-$start)*100;
    return max(0,min(100,round($p,2)));
}

function current_quarter_period() {
    $q = ceil((int)date('n')/3);
    return date('Y').'-Q'.$q;
}


function safe_sum($pdo, $sql, $default=0) {
    try { return (float)$pdo->query($sql)->fetchColumn(); }
    catch (Exception $e) { return $default; }
}
function safe_rows($pdo, $sql) {
    try { return $pdo->query($sql)->fetchAll(); }
    catch (Exception $e) { return []; }
}
function is_director_role($user=null) {
    $u = $user ?: current_user();
    $role = mb_strtolower((string)($u['role'] ?? ''), 'UTF-8');
    $email = strtolower((string)($u['email'] ?? ''));
    return user_is_admin() || str_contains($role,'ceo') || str_contains($role,'giám đốc') || str_contains($role,'director') || $email==='admin@motive.vn';
}
function is_finance_role($user=null) {
    $u = $user ?: current_user();
    $role = mb_strtolower((string)($u['role'] ?? ''), 'UTF-8');
    return is_director_role($u) || str_contains($role,'finance') || str_contains($role,'accounting') || str_contains($role,'kế toán') || str_contains($role,'hr');
}
function is_ctv_role($user=null) {
    $u = $user ?: current_user();
    $role = mb_strtolower((string)($u['role'] ?? ''), 'UTF-8');
    return str_contains($role,'ctv') || str_contains($role,'cộng tác') || str_contains($role,'collaborator') || str_contains($role,'freelance');
}
function is_fulltime_role($user=null) {
    $u = $user ?: current_user();
    return !is_ctv_role($u);
}


function contract_cash_health($pdo, $contract_id, $total_value=0) {
    $stmt=$pdo->prepare("SELECT COALESCE(SUM(amount),0) total_schedule,
        COALESCE(SUM(CASE WHEN status='paid' THEN amount ELSE 0 END),0) paid,
        COALESCE(SUM(CASE WHEN status!='paid' THEN amount ELSE 0 END),0) unpaid,
        COALESCE(SUM(CASE WHEN status!='paid' AND due_date < CURDATE() THEN amount ELSE 0 END),0) overdue,
        MIN(CASE WHEN status!='paid' THEN due_date ELSE NULL END) next_due
      FROM payment_schedules WHERE contract_id=?");
    $stmt->execute([(int)$contract_id]);
    $r=$stmt->fetch(PDO::FETCH_ASSOC) ?: [];
    $paid=(float)($r['paid']??0);
    $unpaid=(float)($r['unpaid']??0);
    $overdue=(float)($r['overdue']??0);
    $totalSchedule=(float)($r['total_schedule']??0);
    $total=(float)$total_value;
    $remaining=max(0, ($total>0?$total:$totalSchedule) - $paid);
    if($overdue>0) { $label='Overdue'; $class='red'; $emoji='🔴'; }
    elseif($paid>0 && $remaining>0) { $label='Partial Paid'; $class='orange'; $emoji='🟠'; }
    elseif($unpaid>0 || $remaining>0) { $label='Waiting Payment'; $class='yellow'; $emoji='🟡'; }
    else { $label='Healthy'; $class='green'; $emoji='🟢'; }
    return [
      'paid'=>$paid,
      'unpaid'=>$unpaid,
      'overdue'=>$overdue,
      'remaining'=>$remaining,
      'total_schedule'=>$totalSchedule,
      'next_due'=>$r['next_due']??null,
      'label'=>$label,
      'class'=>$class,
      'emoji'=>$emoji
    ];
}

function cash_forecast_months($pdo, $start_month=null, $months=6) {
    $start_month=$start_month ?: date('Y-m');
    $out=[];
    for($i=0;$i<$months;$i++){
        $m=date('Y-m',strtotime($start_month.'-01 +'.$i.' month'));
        $expected=0;$collected=0;
        try{
          $st=$pdo->prepare("SELECT 
              COALESCE(SUM(CASE WHEN status!='paid' THEN amount ELSE 0 END),0) expected,
              COALESCE(SUM(CASE WHEN status='paid' THEN amount ELSE 0 END),0) collected
            FROM payment_schedules
            WHERE DATE_FORMAT(COALESCE(paid_date,due_date),'%Y-%m')=? OR COALESCE(carry_month,DATE_FORMAT(COALESCE(due_date,CURDATE()),'%Y-%m'))=?");
          $st->execute([$m,$m]);
          $r=$st->fetch(PDO::FETCH_ASSOC);
          $expected=(float)($r['expected']??0);
          $collected=(float)($r['collected']??0);
        }catch(Exception $e){}
        $out[]=['month'=>$m,'expected'=>$expected,'collected'=>$collected,'gap'=>max(0,$expected-$collected)];
    }
    return $out;
}

/* VCoin Reward Engine — added 2026-06-14 */
function vcoin_ensure_schema($pdo) {
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS app_settings (
          id INT AUTO_INCREMENT PRIMARY KEY,
          setting_key VARCHAR(120) UNIQUE,
          setting_value TEXT,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $pdo->exec("CREATE TABLE IF NOT EXISTS vcoin_transactions (
          id INT AUTO_INCREMENT PRIMARY KEY,
          user_id INT NOT NULL,
          amount INT NOT NULL DEFAULT 0,
          reason VARCHAR(255) NOT NULL,
          source_type VARCHAR(60) DEFAULT NULL,
          source_id INT DEFAULT NULL,
          reference_key VARCHAR(180) DEFAULT NULL,
          status VARCHAR(30) DEFAULT 'earned',
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          payroll_month VARCHAR(7) DEFAULT NULL,
          settled_at DATETIME DEFAULT NULL,
          created_by INT DEFAULT NULL,
          note TEXT,
          UNIQUE KEY uniq_vcoin_reference (reference_key),
          KEY idx_vcoin_user_month (user_id, payroll_month),
          KEY idx_vcoin_created (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $pdo->exec("CREATE TABLE IF NOT EXISTS vcoin_monthly_settlements (
          id INT AUTO_INCREMENT PRIMARY KEY,
          user_id INT NOT NULL,
          payroll_month VARCHAR(7) NOT NULL,
          vcoin_total INT NOT NULL DEFAULT 0,
          conversion_rate DECIMAL(12,2) NOT NULL DEFAULT 1,
          amount_vnd DECIMAL(15,2) NOT NULL DEFAULT 0,
          status VARCHAR(30) DEFAULT 'draft',
          note TEXT,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          settled_at DATETIME DEFAULT NULL,
          UNIQUE KEY uniq_vcoin_settlement (user_id, payroll_month)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Throwable $e) {}
}
function vcoin_get_setting($pdo, $key, $default) {
    vcoin_ensure_schema($pdo);
    try { return get_setting($pdo, 'vcoin_'.$key, $default); } catch(Throwable $e) { return $default; }
}
function vcoin_set_setting($pdo, $key, $value) {
    vcoin_ensure_schema($pdo);
    return set_setting($pdo, 'vcoin_'.$key, $value);
}
function vcoin_balance($pdo, $user_id) {
    vcoin_ensure_schema($pdo);
    try { $st=$pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM vcoin_transactions WHERE user_id=? AND status IN ('earned','settled')"); $st->execute([(int)$user_id]); return (int)$st->fetchColumn(); } catch(Throwable $e){ return 0; }
}
function vcoin_award($pdo, $user_id, $amount, $reason, $source_type='manual', $source_id=null, $reference_key=null, $note='') {
    vcoin_ensure_schema($pdo);
    $amount=(int)$amount; if($amount<=0) return false;
    $month=date('Y-m');
    if(!$reference_key) $reference_key=$source_type.':'.(int)$source_id.':'.(int)$user_id.':'.date('YmdHis').':'.bin2hex(random_bytes(3));
    try {
        $me = function_exists('current_user') ? current_user() : null;
        $stmt=$pdo->prepare("INSERT IGNORE INTO vcoin_transactions(user_id,amount,reason,source_type,source_id,reference_key,payroll_month,created_by,note) VALUES(?,?,?,?,?,?,?,?,?)");
        $stmt->execute([(int)$user_id,$amount,$reason,$source_type,$source_id,$reference_key,$month,(int)($me['id']??0),$note]);
        if($stmt->rowCount()>0) {
            try { create_notification($pdo,(int)$user_id,'Bạn vừa nhận thưởng!','+'.number_format($amount,0,',','.').' Mcoin · '.$reason,'vcoin','app.php?page=workspace'); } catch(Throwable $e) {}
            return true;
        }
    } catch(Throwable $e) {}
    return false;
}


/* Motive Rewards OS — Mcoin, Need Help, Kudos, Achievements */
function mcoin_ensure_schema($pdo){
    if(function_exists('vcoin_ensure_schema')) vcoin_ensure_schema($pdo);
    try{
        $pdo->exec("CREATE TABLE IF NOT EXISTS need_help_requests (
          id INT AUTO_INCREMENT PRIMARY KEY,
          task_id INT DEFAULT NULL,
          user_id INT NOT NULL,
          reason VARCHAR(120) NOT NULL,
          message TEXT,
          status VARCHAR(30) DEFAULT 'open',
          resolved_by INT DEFAULT NULL,
          resolved_at DATETIME DEFAULT NULL,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          KEY idx_need_help_user (user_id),
          KEY idx_need_help_task (task_id),
          KEY idx_need_help_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $pdo->exec("CREATE TABLE IF NOT EXISTS kudos (
          id INT AUTO_INCREMENT PRIMARY KEY,
          from_user_id INT NOT NULL,
          to_user_id INT NOT NULL,
          message TEXT NOT NULL,
          mcoin_amount INT NOT NULL DEFAULT 1000,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          KEY idx_kudos_to (to_user_id),
          KEY idx_kudos_from (from_user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $pdo->exec("CREATE TABLE IF NOT EXISTS achievements (
          id INT AUTO_INCREMENT PRIMARY KEY,
          code VARCHAR(80) UNIQUE NOT NULL,
          title VARCHAR(160) NOT NULL,
          description TEXT,
          icon VARCHAR(20) DEFAULT '🏅',
          mcoin_reward INT DEFAULT 0,
          is_active TINYINT(1) DEFAULT 1,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $pdo->exec("CREATE TABLE IF NOT EXISTS user_achievements (
          id INT AUTO_INCREMENT PRIMARY KEY,
          user_id INT NOT NULL,
          achievement_id INT NOT NULL,
          awarded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          UNIQUE KEY uniq_user_achievement (user_id, achievement_id),
          KEY idx_user_achievements_user (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $pdo->exec("CREATE TABLE IF NOT EXISTS focus_garden (
          id INT AUTO_INCREMENT PRIMARY KEY,
          user_id INT NOT NULL,
          focus_date DATE NOT NULL,
          sessions INT NOT NULL DEFAULT 0,
          garden_level INT NOT NULL DEFAULT 1,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          UNIQUE KEY uniq_focus_day (user_id, focus_date)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $defaults=[
          ['first_task','First Task','Hoàn thành task đầu tiên','🏅',3000],
          ['seven_day_streak','7 Day Streak','Chấm công đều 7 ngày','🔥',5000],
          ['focus_master','Focus Master','Hoàn thành 10 Pomodoro','🌳',5000],
          ['project_hero','Project Hero','Hoàn thành task quan trọng trong project','🚀',5000],
          ['agency_warrior','Agency Warrior','Đóng góp nổi bật cho team','⚡',8000],
        ];
        $st=$pdo->prepare("INSERT IGNORE INTO achievements(code,title,description,icon,mcoin_reward) VALUES(?,?,?,?,?)");
        foreach($defaults as $a) $st->execute($a);
    }catch(Throwable $e){}
}
function mcoin_get_setting($pdo,$key,$default){ return function_exists('vcoin_get_setting') ? vcoin_get_setting($pdo,$key,$default) : $default; }
function mcoin_set_setting($pdo,$key,$value){ return function_exists('vcoin_set_setting') ? vcoin_set_setting($pdo,$key,$value) : false; }
function mcoin_balance($pdo,$user_id){ return function_exists('vcoin_balance') ? vcoin_balance($pdo,$user_id) : 0; }
function mcoin_award($pdo,$user_id,$amount,$reason,$source_type='manual',$source_id=null,$reference_key=null,$note=''){
    $ok = function_exists('vcoin_award') ? vcoin_award($pdo,$user_id,$amount,$reason,$source_type,$source_id,$reference_key,$note) : false;
    if($ok){
      try{ create_notification($pdo,(int)$user_id,'Mcoin reward','+'.number_format((int)$amount,0,',','.').' Mcoin · '.$reason,'mcoin','app.php?page=workspace'); }catch(Throwable $e){}
    }
    return $ok;
}
function mcoin_garden_icon($sessions){
    $sessions=(int)$sessions;
    if($sessions>=100) return '🏕';
    if($sessions>=50) return '🌲';
    if($sessions>=10) return '🌳';
    if($sessions>=3) return '🌿';
    return '🌱';
}
function need_help_create($pdo,$task_id,$user_id,$reason,$message=''){
    mcoin_ensure_schema($pdo);
    try{
      $st=$pdo->prepare("INSERT INTO need_help_requests(task_id,user_id,reason,message) VALUES(?,?,?,?)");
      $st->execute([(int)$task_id,(int)$user_id,$reason,$message]);
      $id=(int)$pdo->lastInsertId();
      $admins=safe_rows($pdo,"SELECT id FROM users WHERE role IN ('Admin','CEO','Director','Giám đốc','Founder') OR is_admin=1 LIMIT 20");
      foreach($admins as $a){ create_notification($pdo,(int)$a['id'],'Có task cần hỗ trợ',$reason.($message?' · '.$message:''),'help','app.php?page=need_help'); }
      return $id;
    }catch(Throwable $e){ return 0; }
}
function achievement_award($pdo,$user_id,$code){
    mcoin_ensure_schema($pdo);
    try{
      $st=$pdo->prepare("SELECT * FROM achievements WHERE code=? AND is_active=1 LIMIT 1");$st->execute([$code]);$a=$st->fetch(); if(!$a) return false;
      $ins=$pdo->prepare("INSERT IGNORE INTO user_achievements(user_id,achievement_id) VALUES(?,?)");$ins->execute([(int)$user_id,(int)$a['id']]);
      if($ins->rowCount()>0){ if((int)$a['mcoin_reward']>0) mcoin_award($pdo,$user_id,(int)$a['mcoin_reward'],'Achievement: '.$a['title'],'achievement',(int)$a['id'],'achievement:'.$code.':'.$user_id); create_notification($pdo,$user_id,'Bạn mở khóa achievement!',($a['icon']?:'🏅').' '.$a['title'],'achievement','app.php?page=profile'); return true; }
    }catch(Throwable $e){}
    return false;
}

/* Sprint 31 — Workday Engine + CEO Dashboard helpers */
function sprint31_ensure_schema($pdo){
    try{
        $pdo->exec("CREATE TABLE IF NOT EXISTS workday_settings (
          id INT AUTO_INCREMENT PRIMARY KEY,
          setting_key VARCHAR(80) NOT NULL UNIQUE,
          setting_value VARCHAR(120) NOT NULL,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $defaults = [
          'full_day_minutes'=>'480',
          'three_quarter_day_minutes'=>'360',
          'half_day_minutes'=>'240',
          'quarter_day_minutes'=>'120',
          'standard_start_time'=>'09:00:00',
          'standard_end_time'=>'18:00:00',
          'late_grace_minutes'=>'10'
        ];
        $st=$pdo->prepare("INSERT IGNORE INTO workday_settings(setting_key,setting_value) VALUES(?,?)");
        foreach($defaults as $k=>$v){ $st->execute([$k,$v]); }
        try{ $pdo->exec("ALTER TABLE attendance ADD COLUMN approved_by INT NULL"); }catch(Throwable $e){}
        try{ $pdo->exec("ALTER TABLE attendance ADD COLUMN approved_at DATETIME NULL"); }catch(Throwable $e){}
        try{ $pdo->exec("ALTER TABLE attendance ADD COLUMN attendance_type VARCHAR(40) DEFAULT 'work'"); }catch(Throwable $e){}
    }catch(Throwable $e){}
}

function sprint31_workday_settings($pdo){
    sprint31_ensure_schema($pdo);
    $s = ['full_day_minutes'=>480,'three_quarter_day_minutes'=>360,'half_day_minutes'=>240,'quarter_day_minutes'=>120,'standard_start_time'=>'09:00:00','standard_end_time'=>'18:00:00','late_grace_minutes'=>10];
    try{
        foreach($pdo->query("SELECT setting_key,setting_value FROM workday_settings") as $r){
            $s[$r['setting_key']] = is_numeric($r['setting_value']) ? (int)$r['setting_value'] : $r['setting_value'];
        }
    }catch(Throwable $e){}
    return $s;
}

function sprint31_day_units_from_minutes($minutes,$settings=null){
    $s = $settings ?: ['full_day_minutes'=>480,'three_quarter_day_minutes'=>360,'half_day_minutes'=>240,'quarter_day_minutes'=>120];
    $m=(int)$minutes;
    if($m >= (int)$s['full_day_minutes']) return 1.0;
    if($m >= (int)$s['three_quarter_day_minutes']) return 0.75;
    if($m >= (int)$s['half_day_minutes']) return 0.5;
    if($m >= (int)$s['quarter_day_minutes']) return 0.25;
    return 0.0;
}

function sprint31_month_bounds($month){
    if(!$month) $month=date('Y-m');
    return [$month.'-01', date('Y-m-t', strtotime($month.'-01'))];
}

function sprint31_attendance_summary($pdo,$month){
    sprint31_ensure_schema($pdo);
    $settings=sprint31_workday_settings($pdo);
    [$start,$end]=sprint31_month_bounds($month);
    $users=safe_rows($pdo,"SELECT id,name,email,role,avatar,status FROM users WHERE COALESCE(status,'active')='active' ORDER BY name ASC");
    $rows=safe_rows($pdo,"SELECT a.*,u.name user_name,u.avatar user_avatar,u.role user_role FROM attendance a JOIN users u ON u.id=a.user_id WHERE DATE(a.work_date) BETWEEN '$start' AND '$end' ORDER BY a.work_date ASC,a.id ASC");
    $map=[];
    foreach($users as $u){
        $map[(int)$u['id']]=['user'=>$u,'days'=>0,'workdays'=>0,'hours'=>0,'minutes'=>0,'ot_minutes'=>0,'late'=>0,'early'=>0,'missing_checkout'=>0,'records'=>0,'leave'=>0,'wfh'=>0,'task_done'=>0,'task_ontime'=>0,'mcoin'=>0,'score'=>0];
    }
    $stdDay=(int)$settings['full_day_minutes'];
    $lateGrace=(int)$settings['late_grace_minutes'];
    foreach($rows as $r){
        $uid=(int)$r['user_id']; if(!isset($map[$uid])) continue;
        $mins=(int)($r['total_minutes'] ?? 0);
        if(!$mins && !empty($r['checkin_time']) && !empty($r['checkout_time'])){
            $mins=max(0,round((strtotime($r['work_date'].' '.$r['checkout_time'])-strtotime($r['work_date'].' '.$r['checkin_time']))/60));
        }
        $unit=sprint31_day_units_from_minutes($mins,$settings);
        $map[$uid]['days'] += $unit;
        if($unit>0) $map[$uid]['workdays'] += 1;
        $map[$uid]['minutes'] += $mins;
        $map[$uid]['ot_minutes'] += max(0,$mins-$stdDay);
        $map[$uid]['records']++;
        if(($r['work_mode'] ?? '')==='Remote') $map[$uid]['wfh']++;
        if(empty($r['checkout_time']) && ($r['status'] ?? '')!=='done') $map[$uid]['missing_checkout']++;
        if(!empty($r['checkin_time'])){
            $lateLimit=strtotime($r['work_date'].' '.$settings['standard_start_time']) + ($lateGrace*60);
            if(strtotime($r['work_date'].' '.$r['checkin_time']) > $lateLimit) $map[$uid]['late']++;
        }
        if(!empty($r['checkout_time']) && strtotime($r['work_date'].' '.$r['checkout_time']) < strtotime($r['work_date'].' '.$settings['standard_end_time'])) $map[$uid]['early']++;
    }
    $taskRows=safe_rows($pdo,"SELECT assignee_id, COUNT(*) done, SUM(CASE WHEN deadline IS NOT NULL AND DATE(COALESCE(completed_at,updated_at,deadline)) <= deadline THEN 1 ELSE 0 END) ontime FROM tasks WHERE status='Done' AND DATE(COALESCE(completed_at,updated_at,deadline,created_at)) BETWEEN '$start' AND '$end' GROUP BY assignee_id");
    foreach($taskRows as $t){ $uid=(int)$t['assignee_id']; if(isset($map[$uid])){ $map[$uid]['task_done']=(int)$t['done']; $map[$uid]['task_ontime']=(int)$t['ontime']; } }
    $mcoinRows=safe_rows($pdo,"SELECT user_id, SUM(amount) amount FROM vcoin_transactions WHERE amount>0 AND DATE(created_at) BETWEEN '$start' AND '$end' GROUP BY user_id");
    foreach($mcoinRows as $m){ $uid=(int)$m['user_id']; if(isset($map[$uid])) $map[$uid]['mcoin']=(int)$m['amount']; }
    foreach($map as &$x){
        $x['hours']=round($x['minutes']/60,1); $x['ot_hours']=round($x['ot_minutes']/60,1);
        $timeScore=min(40, ($x['days']/max(1,22))*40);
        $taskScore=min(40, ($x['task_done']/max(1,20))*30 + ($x['task_done']>0?($x['task_ontime']/$x['task_done'])*10:0));
        $contribScore=min(20, ($x['mcoin']/max(1,20000))*20);
        $penalty=min(18, ($x['late']*2)+($x['early']*2)+($x['missing_checkout']*3));
        $x['score']=max(0, min(100, round($timeScore+$taskScore+$contribScore-$penalty)));
    }
    unset($x);
    usort($map,function($a,$b){ return $b['score'] <=> $a['score']; });
    return array_values($map);
}
