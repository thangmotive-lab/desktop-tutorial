</div>
<div id="yayOverlay" class="yay-overlay">
  <div class="yay-box simple-yay">
    <div class="yay-icon">✓</div>
    <h2>Yay-me</h2>
    <p>Task đã hoàn thành.</p>
  </div>
</div>


<!-- Global Pomodoro — available on every page -->
<button class="focus-fab-v4 global-focus-fab" type="button" onclick="openFocusPopup()" aria-label="Mở Pomodoro Focus"><i data-lucide="timer"></i></button>
<div class="focus-popup-v4" id="focusPopupV4" aria-hidden="true">
  <button class="focus-popup-backdrop" type="button" onclick="closeFocusPopup()"></button>
  <div class="focus-popup-panel">
    <button class="modal-close" type="button" onclick="closeFocusPopup()">×</button>
    <span class="eyebrow"><i data-lucide="timer"></i> Focus Session</span>
    <h2>Pomodoro Timer</h2>
    <p class="focus-subtitle">Hoàn thành phiên Focus để trồng cây và nhận Mcoin.</p>
    <div class="focus-mode-tabs" role="tablist">
      <button class="active" type="button" data-focus-minutes="25"><i data-lucide="timer"></i> Pomodoro</button>
      <button type="button" data-focus-minutes="5"><i data-lucide="coffee"></i> Short Break</button>
      <button type="button" data-focus-minutes="15"><i data-lucide="moon"></i> Long Break</button>
    </div>
    <div class="focus-plant-v4" id="focusPlantV4"><i data-lucide="sprout"></i></div>
    <div class="focus-time-v4" id="focusTimeV4">25:00</div>
    <div class="focus-actions-v4 three">
      <button class="primary" type="button" onclick="startFocusV4()" id="focusStartBtnV4"><i data-lucide="play"></i> Bắt đầu</button>
      <button class="btn-soft" type="button" onclick="pauseFocusV4()">Tạm dừng</button>
      <button class="btn-soft" type="button" onclick="resetFocusV4()">Reset</button>
    </div>
  </div>
</div>
<!-- Pomodoro Mini Glass Bar V5.2 -->
<div class="focus-mini-glass-v5" id="focusMiniBarV5" aria-hidden="true">
  <button class="focus-mini-main-v5" type="button" onclick="openFocusPopup()" aria-label="Mở Pomodoro">
    <span class="focus-mini-dot-v5"></span>
    <span class="focus-mini-title-v5" id="focusMiniTitleV5">Focus</span>
    <strong class="focus-mini-time-v5" id="focusMiniTimeV5">25:00</strong>
  </button>
  <button class="focus-mini-btn-v5" type="button" onclick="pauseFocusV5(event)" id="focusMiniPauseV5" aria-label="Tạm dừng">Ⅱ</button>
  <button class="focus-mini-btn-v5 danger" type="button" onclick="resetFocusV5(event)" aria-label="Reset">×</button>
  <div class="focus-mini-progress-v5"><span id="focusMiniProgressV5"></span></div>
</div>

<!-- HF: legacy chatbot + notification v1 removed. Use Notification Center v2 only. -->
<div id="motiveToastStack" class="motive-toast-stack"></div>
<audio id="soundNotify" preload="auto"><source src="assets/sounds/notify.wav" type="audio/wav"></audio>
<audio id="soundDing" preload="auto"><source src="assets/sounds/ding.wav" type="audio/wav"></audio>
<audio id="soundSuccess" preload="auto"><source src="assets/sounds/success.wav" type="audio/wav"></audio>

<?php
$__me = current_user();
$__showMood = false; // disabled by HF Workspace Prairie UX
?>

<?php if($__showMood): ?>
<div class="daily-pulse-visual-backdrop active" id="dailyPulseModal">
  <div class="daily-pulse-visual-card animate__animated animate__zoomIn">
    <button class="daily-pulse-close" onclick="document.getElementById('dailyPulseModal').remove()" type="button">×</button>

    <div class="pulse-orbit">
      <span>✨</span><span>💜</span><span>🌙</span><span>⚡</span>
    </div>

    <div class="pulse-hero-art">
      <div class="pulse-blob one"></div>
      <div class="pulse-blob two"></div>
      <div class="pulse-face">💫</div>
    </div>

    <span class="pulse-kicker">Daily Pulse</span>
    <h2>Năng lượng hôm nay của bạn thế nào?</h2>
    <p>Check-in nhanh để Motive biết bạn đang ổn, rực rỡ hay cần được hỗ trợ.</p>

    <form method="post" action="app.php?page=mood_checkin" class="daily-pulse-form">
      <input type="hidden" name="redirect_to" value="<?= e($_SERVER['REQUEST_URI'] ?? 'app.php?page=workspace') ?>">

      <div class="pulse-mood-grid">
        <label class="pulse-mood-card">
          <input type="radio" name="mood" value="very_happy">
          <span class="emoji">😄</span>
          <b>Rất vui</b>
          <small>Full pin</small>
        </label>
        <label class="pulse-mood-card">
          <input type="radio" name="mood" value="good">
          <span class="emoji">🙂</span>
          <b>Ổn áp</b>
          <small>Ready</small>
        </label>
        <label class="pulse-mood-card">
          <input type="radio" name="mood" value="normal" checked>
          <span class="emoji">😐</span>
          <b>Bình thường</b>
          <small>Steady</small>
        </label>
        <label class="pulse-mood-card">
          <input type="radio" name="mood" value="overloaded">
          <span class="emoji">😵</span>
          <b>Quá tải</b>
          <small>Need space</small>
        </label>
        <label class="pulse-mood-card">
          <input type="radio" name="mood" value="sad">
          <span class="emoji">😔</span>
          <b>Hơi buồn</b>
          <small>Need care</small>
        </label>
      </div>

      <div class="pulse-location-row">
        <label><input type="radio" name="work_location" value="Office" checked><span>🏢 Office</span></label>
        <label><input type="radio" name="work_location" value="Remote"><span>🏠 Remote</span></label>
        <label><input type="radio" name="work_location" value="Onsite"><span>🎬 Onsite</span></label>
        <label><input type="radio" name="work_location" value="Business Trip"><span>✈️ Công tác</span></label>
      </div>

      <div class="pulse-focus-mini">
        <input name="focus_1" placeholder="Focus #1 hôm nay">
        <input name="focus_2" placeholder="Focus #2">
        <input name="focus_3" placeholder="Focus #3">
      </div>

      <label class="pulse-support-toggle">
        <input type="checkbox" name="need_support">
        <span>💌 Mình cần được hỗ trợ hôm nay</span>
      </label>

      <textarea name="note" placeholder="Một dòng tâm trạng hoặc điều team cần biết..."></textarea>

      <button class="pulse-submit">Gửi năng lượng hôm nay ✨</button>
    </form>
  </div>
</div>
<?php endif; ?>


<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script src="https://cdn.jsdelivr.net/npm/gsap@3.12.5/dist/gsap.min.js"></script>
<script src="https://unpkg.com/lucide@latest/dist/umd/lucide.min.js"></script>
<script>document.addEventListener("DOMContentLoaded",function(){ if(window.lucide){ lucide.createIcons({attrs:{"stroke-width":1.8}}); } });</script>
<script src="assets/js/app.js?v=8e-final-2-pomo-v6-priority" defer></script>
<?php if (!empty($_GET['yay'])): ?>
<script>setTimeout(showYay, 300);</script>
<?php endif; ?>
</body>
</html>
