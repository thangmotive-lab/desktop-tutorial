<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function is_logged_in() {
    return !empty($_SESSION['user']);
}

function current_user() {
    return $_SESSION['user'] ?? null;
}

function require_login() {
    if (!is_logged_in()) {
        header('Location: login.php');
        exit;
    }
}

function user_is_admin() {
    $u = current_user();
    $role = $u['role'] ?? '';
    $email = $u['email'] ?? '';

    return in_array($role, [
        'Founder',
        'CEO',
        'Giám đốc',
        'Admin',
        'HR',
        'Finance',
        'Kế toán'
    ], true) || $email === 'admin@motive.vn';
}

function user_can_see_finance() {
    $u = current_user();
    $role = $u['role'] ?? '';
    $email = $u['email'] ?? '';

    return user_is_admin() || in_array($role, [
        'BD',
        'Kế toán',
        'Finance'
    ], true) || $email === 'admin@motive.vn';
}
