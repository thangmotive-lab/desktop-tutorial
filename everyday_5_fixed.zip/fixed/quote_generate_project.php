<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/functions.php';

$quote_id = intval($_GET['quote_id'] ?? 0);

if ($quote_id <= 0) {
    die('Thiếu quote_id');
}

header('Location: app.php?page=quote_generate_project&quote_id=' . $quote_id);
exit;