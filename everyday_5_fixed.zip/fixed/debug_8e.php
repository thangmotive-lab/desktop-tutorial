<?php
date_default_timezone_set('Asia/Ho_Chi_Minh');

function file_info($path, $needles = []) {
    $exists = file_exists($path);
    $info = [
        'path' => $path,
        'exists' => $exists,
        'mtime' => $exists ? date('Y-m-d H:i:s', filemtime($path)) : '-',
        'size' => $exists ? filesize($path) : 0,
        'checks' => []
    ];
    if ($exists) {
        $content = file_get_contents($path);
        foreach ($needles as $label => $needle) {
            $info['checks'][$label] = strpos($content, $needle) !== false;
        }
    }
    return $info;
}

$base = __DIR__;

$files = [
    file_info($base.'/app.php', [
        'Search overlay HTML' => 'globalSearchOverlay',
        'Safe page title' => "ucwords(str_replace('_',' ', $page))"
    ]),
    file_info($base.'/assets/js/app.js', [
        'GOOD JOB text' => 'GOOD JOB',
        'Task Delight V2' => 'task_delight_v2',
        'AJAX endpoint call' => 'ajax_task_complete.php',
        'Search overlay JS' => 'openGlobalSearchOverlay'
    ]),
    file_info($base.'/assets/css/style.css', [
        'Task Delight CSS' => 'task-delight-v2',
        'Workspace 8E CSS' => 'workspace-8e',
        'Search overlay CSS' => 'global-search-overlay'
    ]),
    file_info($base.'/modules/workspace.php', [
        'Workspace 8E hero' => 'workspace-8e-hero',
        'Task Delight class' => 'js-task-delight-done',
        'Private 8E' => 'private-8e'
    ]),
    file_info($base.'/modules/tasks.php', [
        'Task Delight class' => 'js-task-delight-done',
        'Old advance link' => 'advance='
    ]),
    file_info($base.'/ajax_task_complete.php', [
        'AJAX complete endpoint' => 'task_delight_v2',
        'JSON response' => 'json_encode'
    ]),
];

$loaded = [
    'PHP version' => PHP_VERSION,
    'Current folder' => __DIR__,
    'Document root' => $_SERVER['DOCUMENT_ROOT'] ?? '-',
    'Script filename' => $_SERVER['SCRIPT_FILENAME'] ?? '-',
    'Server time' => date('Y-m-d H:i:s'),
    'OPcache enabled' => function_exists('opcache_get_status') ? (opcache_get_status(false) ? 'Yes' : 'No') : 'Unknown'
];

if (isset($_GET['reset_opcache']) && function_exists('opcache_reset')) {
    @opcache_reset();
    header('Location: debug_8e.php?opcache_reset_done=1');
    exit;
}
?>
<!doctype html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Everyday 8E Debug Check</title>
<style>
body{font-family:Inter,Arial,sans-serif;background:#f8fafc;color:#111827;margin:0;padding:24px}
.card{background:#fff;border:1px solid #e5e7eb;border-radius:18px;padding:18px;margin-bottom:14px;box-shadow:0 10px 30px rgba(15,23,42,.05)}
h1{margin:0 0 8px;font-size:32px;letter-spacing:-.04em}
table{width:100%;border-collapse:collapse;background:#fff;border-radius:14px;overflow:hidden}
th,td{padding:10px;border-bottom:1px solid #eef2f7;text-align:left;font-size:14px;vertical-align:top}
th{background:#f1f5f9}
.ok{color:#059669;font-weight:900}
.bad{color:#dc2626;font-weight:900}
.small{color:#64748b;font-size:13px}
.btn{display:inline-block;background:#111827;color:#fff;text-decoration:none;padding:10px 14px;border-radius:12px;font-weight:800;margin-right:8px}
pre{white-space:pre-wrap;background:#0f172a;color:#e2e8f0;padding:14px;border-radius:14px;overflow:auto}
</style>
</head>
<body>
<div class="card">
<h1>Everyday 8E Debug Check</h1>
<p class="small">Nếu file này chạy được, nghĩa là bạn đã upload đúng vào thư mục đang chạy. Dùng trang này để biết server có đang đọc đúng các file 8E hay không.</p>
<a class="btn" href="debug_8e.php?reset_opcache=1">Reset OPcache</a>
<a class="btn" href="app.php?page=workspace">Mở Workspace</a>
<?php if(isset($_GET['opcache_reset_done'])): ?><p class="ok">Đã gọi reset OPcache.</p><?php endif; ?>
</div>

<div class="card">
<h2>Thông tin server</h2>
<table>
<?php foreach($loaded as $k=>$v): ?>
<tr><th><?= htmlspecialchars($k) ?></th><td><?= htmlspecialchars((string)$v) ?></td></tr>
<?php endforeach; ?>
</table>
</div>

<div class="card">
<h2>Kiểm tra file 8E</h2>
<table>
<tr>
<th>File</th>
<th>Tồn tại</th>
<th>Modified</th>
<th>Size</th>
<th>Checks</th>
</tr>
<?php foreach($files as $f): ?>
<tr>
<td><code><?= htmlspecialchars(str_replace($base.'/', '', $f['path'])) ?></code></td>
<td><?= $f['exists'] ? '<span class="ok">YES</span>' : '<span class="bad">NO</span>' ?></td>
<td><?= htmlspecialchars($f['mtime']) ?></td>
<td><?= number_format($f['size']) ?> bytes</td>
<td>
<?php foreach($f['checks'] as $label=>$ok): ?>
<div><?= htmlspecialchars($label) ?>: <?= $ok ? '<span class="ok">OK</span>' : '<span class="bad">MISSING</span>' ?></div>
<?php endforeach; ?>
</td>
</tr>
<?php endforeach; ?>
</table>
</div>

<div class="card">
<h2>Kết luận nhanh</h2>
<ul>
<li>Nếu <b>Workspace 8E hero</b> hoặc <b>GOOD JOB text</b> là MISSING: file bạn upload chưa đúng hoặc bị ghi đè.</li>
<li>Nếu mọi thứ OK nhưng website vẫn không đổi: khả năng cao do server cache/CDN/OPcache hoặc app đang chạy từ thư mục khác.</li>
<li>Nếu <b>Current folder</b> không phải thư mục <code>/everyday</code> bạn đang upload: bạn đang upload sai chỗ.</li>
</ul>
</div>
</body>
</html>
