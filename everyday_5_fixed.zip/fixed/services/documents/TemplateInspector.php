<?php
class TemplateInspector {
    public static function inspect(string $docxPath): array {
        if(!file_exists($docxPath)) return ['ok'=>false,'message'=>'Template không tồn tại.'];
        if(!class_exists('ZipArchive')) return ['ok'=>false,'message'=>'PHP ZIP extension chưa bật.'];

        $zip=new ZipArchive();
        if($zip->open($docxPath)!==true) return ['ok'=>false,'message'=>'Không mở được DOCX.'];

        $text='';
        for($i=0;$i<$zip->numFiles;$i++){
            $name=$zip->getNameIndex($i);
            if(preg_match('/^word\/.*\.xml$/',$name)){
                $xml=$zip->getFromName($name);
                $text .= self::xmlToText($xml)."\n";
            }
        }
        $zip->close();

        preg_match_all('/\{\{[A-Z0-9_]+\}\}/u',$text,$modern);
        preg_match_all('/\[[^\[\]]{2,80}\]/u',$text,$legacy);
        $placeholders=array_values(array_unique(array_merge($modern[0] ?? [], $legacy[0] ?? [])));
        sort($placeholders);

        $markers=[
          'has_table_items'=>str_contains($text,'{{TABLE_ITEMS}}') || str_contains($text,'{{ITEM_ROWS}}'),
          'has_payment_rows'=>str_contains($text,'{{PAYMENT_ROWS}}'),
          'has_items_text'=>str_contains($text,'{{ITEMS_TEXT}}') || str_contains($text,'[Gói hosting dựa vào ratecard]')
        ];

        return ['ok'=>true,'placeholders'=>$placeholders,'markers'=>$markers,'count'=>count($placeholders)];
    }

    private static function xmlToText($xml): string {
        if(!$xml) return '';
        $xml=preg_replace('/<w:tab\/>/', "\t", $xml);
        $xml=preg_replace('/<\/w:p>/', "\n", $xml);
        $xml=strip_tags($xml);
        return html_entity_decode($xml, ENT_QUOTES | ENT_XML1, 'UTF-8');
    }
}
