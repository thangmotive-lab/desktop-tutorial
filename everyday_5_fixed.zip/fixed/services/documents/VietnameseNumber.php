<?php
class VietnameseNumber {
    public static function moneyToWords($number): string {
        $number = (int)round((float)$number);
        if ($number === 0) return 'Không đồng chẵn';
        $words = self::numberToWords($number);
        return ucfirst(trim($words)) . ' đồng chẵn';
    }

    private static function numberToWords($number): string {
        $units = ['', 'nghìn', 'triệu', 'tỷ', 'nghìn tỷ', 'triệu tỷ'];
        $chunks = [];
        while ($number > 0) {
            $chunks[] = $number % 1000;
            $number = intdiv($number, 1000);
        }
        $parts = [];
        for ($i = count($chunks) - 1; $i >= 0; $i--) {
            if ($chunks[$i] == 0) continue;
            $parts[] = self::readThree($chunks[$i], $i < count($chunks)-1) . ' ' . $units[$i];
        }
        return preg_replace('/\s+/', ' ', trim(implode(' ', $parts)));
    }

    private static function readThree($num, $full=false): string {
        $digit = ['không','một','hai','ba','bốn','năm','sáu','bảy','tám','chín'];
        $hundred = intdiv($num, 100);
        $tens = intdiv($num % 100, 10);
        $ones = $num % 10;
        $s = '';

        if ($hundred > 0 || $full) {
            $s .= $digit[$hundred] . ' trăm';
            if ($tens == 0 && $ones > 0) $s .= ' lẻ';
        }
        if ($tens > 1) {
            $s .= ' ' . $digit[$tens] . ' mươi';
            if ($ones == 1) $s .= ' mốt';
            elseif ($ones == 5) $s .= ' lăm';
            elseif ($ones > 0) $s .= ' ' . $digit[$ones];
        } elseif ($tens == 1) {
            $s .= ' mười';
            if ($ones == 5) $s .= ' lăm';
            elseif ($ones > 0) $s .= ' ' . $digit[$ones];
        } elseif ($ones > 0) {
            $s .= ' ' . $digit[$ones];
        }
        return trim($s);
    }
}
