<?php
class DynamicTableEngine {
    public static function injectTablesInXml(string $xml, array $mapping): string {
        $itemRows = $mapping['_ITEM_ROWS'] ?? [];
        $paymentRows = $mapping['_PAYMENT_ROWS'] ?? [];

        if(!empty($itemRows)){
            $xml = self::cloneRowByAnyPlaceholder($xml, ['{{ITEM_NAME}}','{{ITEM_DESCRIPTION}}','{{ITEM_TOTAL}}','{{ITEM_UNIT_PRICE}}'], $itemRows);
            $xml = self::replaceBlockWithTextTable($xml, '{{TABLE_ITEMS}}', self::plainItemsTable($itemRows));
            $xml = self::replaceBlockWithTextTable($xml, '{{ITEM_ROWS}}', self::plainItemsTable($itemRows));
        }

        if(!empty($paymentRows)){
            $xml = self::cloneRowByAnyPlaceholder($xml, ['{{PAYMENT_MILESTONE}}','{{PAYMENT_AMOUNT}}','{{PAYMENT_DUE_DATE}}'], $paymentRows);
            $xml = self::replaceBlockWithTextTable($xml, '{{PAYMENT_ROWS}}', self::plainPaymentTable($paymentRows));
        }

        return $xml;
    }

    private static function cloneRowByAnyPlaceholder(string $xml, array $placeholders, array $rows): string {
        foreach($placeholders as $ph){
            $safePh = htmlspecialchars($ph, ENT_XML1 | ENT_COMPAT, 'UTF-8');
            if(strpos($xml,$safePh)===false && strpos($xml,$ph)===false) continue;

            $pattern = '/<w:tr\b[^>]*>.*?(?:'.preg_quote($safePh,'/').'|'.preg_quote($ph,'/').').*?<\/w:tr>/s';
            if(!preg_match($pattern,$xml,$m)) continue;

            $templateRow=$m[0];
            $newRows='';
            foreach($rows as $row){
                $r=$templateRow;
                foreach($row as $k=>$v){
                    $value=htmlspecialchars((string)$v, ENT_XML1 | ENT_COMPAT, 'UTF-8');
                    $r=str_replace('{{'.$k.'}}',$value,$r);
                    $r=str_replace(htmlspecialchars('{{'.$k.'}}', ENT_XML1 | ENT_COMPAT, 'UTF-8'),$value,$r);
                }
                $newRows.=$r;
            }
            return str_replace($templateRow,$newRows,$xml);
        }
        return $xml;
    }

    private static function replaceBlockWithTextTable(string $xml, string $placeholder, string $tableText): string {
        $safePh=htmlspecialchars($placeholder, ENT_XML1 | ENT_COMPAT, 'UTF-8');
        $safeText=htmlspecialchars($tableText, ENT_XML1 | ENT_COMPAT, 'UTF-8');
        $safeText=str_replace("\n", '<w:br/>', $safeText);
        $xml=str_replace($safePh,$safeText,$xml);
        $xml=str_replace($placeholder,$safeText,$xml);
        return $xml;
    }

    private static function plainItemsTable(array $rows): string {
        $lines=[];
        foreach($rows as $r){
            $lines[]=$r['STT'].'. '.$r['ITEM_NAME'].' | SL: '.$r['ITEM_QUANTITY'].' '.$r['ITEM_UNIT'].' | Đơn giá: '.$r['ITEM_UNIT_PRICE'].' | Thành tiền: '.$r['ITEM_TOTAL'];
            if(!empty($r['ITEM_DETAIL'])) $lines[]='   '.$r['ITEM_DETAIL'];
        }
        return implode("\n",$lines);
    }

    private static function plainPaymentTable(array $rows): string {
        $lines=[];
        foreach($rows as $r){
            $lines[]=$r['PAYMENT_NO'].'. '.$r['PAYMENT_MILESTONE'].' '.$r['PAYMENT_PERCENT'].' | '.$r['PAYMENT_AMOUNT'].' | Hạn: '.$r['PAYMENT_DUE_DATE'];
        }
        return implode("\n",$lines);
    }
}
