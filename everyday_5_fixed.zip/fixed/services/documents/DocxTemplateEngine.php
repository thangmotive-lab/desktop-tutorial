<?php
require_once __DIR__ . '/DynamicTableEngine.php';
class DocxTemplateEngine {
    public static function render(string $templatePath, string $outputPath, array $mapping): array {
        if (!file_exists($templatePath)) {
            return ['ok'=>false,'message'=>'Template không tồn tại: '.$templatePath];
        }

        $outDir = dirname($outputPath);
        if(!is_dir($outDir)) mkdir($outDir,0775,true);
        copy($templatePath, $outputPath);

        $zip = new ZipArchive();
        if ($zip->open($outputPath) !== true) {
            return ['ok'=>false,'message'=>'Không mở được DOCX output.'];
        }

        for($i=0; $i<$zip->numFiles; $i++){
            $name=$zip->getNameIndex($i);
            if(!preg_match('/^word\/.*\.xml$/',$name)) continue;
            $xml=$zip->getFromName($name);
            if($xml===false) continue;

            // Make split placeholders easier to replace by removing tag boundaries between text runs only.
            $xml = DynamicTableEngine::injectTablesInXml($xml, $mapping);
            $xml = self::replaceInXml($xml, $mapping);
            $zip->addFromString($name,$xml);
        }
        $zip->close();
        return ['ok'=>true,'path'=>$outputPath];
    }

    private static function replaceInXml(string $xml, array $mapping): string {
        foreach($mapping as $key=>$value){
            // Skip internal keys (_ITEM_ROWS, _PAYMENT_ROWS) and array values
            if(str_starts_with((string)$key, '_') || is_array($value)) continue;
            $value = self::xmlSafe((string)$value);
            $variants = [
                '{{'.$key.'}}',
                '['.$key.']',
                '['.self::legacyLabel($key).']'
            ];
            foreach($variants as $ph){
                $xml = str_replace(self::xmlSafe($ph), $value, $xml);
                $xml = str_replace($ph, $value, $xml);
            }
        }

        // Common legacy placeholders from Motive docs
        $legacy = [
            '[Mã hợp đồng]' => 'CONTRACT_CODE',
            '[Mã số hợp đồng]' => 'CONTRACT_CODE',
            '[Mã nghiệm thu]' => 'ACCEPTANCE_CODE',
            '[Tên công ty]' => 'CLIENT_NAME',
            '[Tên doanh nghiệp/công ty/tổ chức]' => 'CLIENT_NAME',
            '[Tên công ty bên A]' => 'CLIENT_NAME',
            '[công ty A]' => 'CLIENT_NAME',
            '[Tên khách hàng]' => 'CLIENT_NAME',
            '[Tên giám đốc/người đại diện bên A]' => 'CLIENT_REPRESENTATIVE',
            '[Tên người đại diện ông/bà]' => 'CLIENT_REPRESENTATIVE',
            '[Người đại diện bên A - Viết hoa]' => 'CLIENT_REPRESENTATIVE_UPPER',
            '[Chức vụ]' => 'CLIENT_POSITION',
            '[Chức vụ người đại diện]' => 'CLIENT_POSITION',
            '[Địa chỉ]' => 'CLIENT_ADDRESS',
            '[Địa chỉ cơ quan]' => 'CLIENT_ADDRESS',
            '[Địa chỉ công ty bên A]' => 'CLIENT_ADDRESS',
            '[Số điện thoại]' => 'CLIENT_PHONE',
            '[Mã số thuế]' => 'CLIENT_TAX',
            '[Mã số thuế bên A]' => 'CLIENT_TAX',
            '[Tên ngân hàng]' => 'CLIENT_BANK',
            '[Số tài khoản]' => 'CLIENT_BANK_ACCOUNT',
            '[Email xuất hoá đơn]' => 'CLIENT_EMAIL',
            '[Tổng số tiền]' => 'TOTAL_AMOUNT',
            '[Số tiền bằng chữ]' => 'TOTAL_AMOUNT_TEXT',
            '[Tổng số tiền ghi bằng số]' => 'TOTAL_BEFORE_VAT',
            '[Nhân với 10%  của tổng số tiền]' => 'VAT_AMOUNT',
            '[Thành số tiền cần thanh toán]' => 'TOTAL_AMOUNT',
            '[Thành tiền]' => 'TOTAL_AMOUNT',
            '[Tổng số tiền tạm ứng bằng chữ và bằng số]' => 'DEPOSIT_AMOUNT_WITH_TEXT',
            '[Thời hạn hợp đồng hiệu lực từ ngày bắt đầu tới ngày kết thúc]' => 'CONTRACT_PERIOD',
            '[ngày ký hợp đồng]' => 'SIGN_DATE',
            '[ngày nghiệm thu]' => 'ACCEPTANCE_DATE',
            '[dịch vụ hợp đồng cung cấp]' => 'SERVICE_NAME',
            '[Gói hosting dựa vào ratecard]' => 'ITEMS_TEXT',
            '[Ngày bắt đầu triển khai dịch vụ hosting và ngày kết thúc gói hosting]' => 'CONTRACT_PERIOD',
            '[Tổng giá trị hợp đồng đã ký - bằng số và bằng chữ]' => 'TOTAL_AMOUNT_WITH_TEXT',
            '[Số tiền đã tạm ứng đợt I]' => 'DEPOSIT_AMOUNT_WITH_TEXT',
            '[Số tiền sau khi nghiệm thu - bằng số và bằng chữ]' => 'REMAINING_AMOUNT_WITH_TEXT',
            '[Số hợp đồng]' => 'CONTRACT_CODE'
        ];

        foreach($legacy as $placeholder=>$key){
            if(isset($mapping[$key])){
                $xml=str_replace(self::xmlSafe($placeholder), self::xmlSafe((string)$mapping[$key]), $xml);
                $xml=str_replace($placeholder, self::xmlSafe((string)$mapping[$key]), $xml);
            }
        }

        return $xml;
    }

    private static function xmlSafe(string $value): string {
        return htmlspecialchars($value, ENT_XML1 | ENT_COMPAT, 'UTF-8');
    }

    private static function legacyLabel(string $key): string {
        $map=[
            'CLIENT_NAME'=>'Tên công ty',
            'CONTRACT_CODE'=>'Mã hợp đồng',
            'TOTAL_AMOUNT'=>'Tổng số tiền',
            'TOTAL_AMOUNT_TEXT'=>'Số tiền bằng chữ'
        ];
        return $map[$key] ?? $key;
    }
}
