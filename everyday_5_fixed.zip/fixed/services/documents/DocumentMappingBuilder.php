<?php
require_once __DIR__ . '/VietnameseNumber.php';

class DocumentMappingBuilder {
    public static function fromQuotation(PDO $pdo, int $quotationId, string $documentType='contract'): array {
        $stmt=$pdo->prepare('SELECT q.*,u.name owner_name FROM quotations q LEFT JOIN users u ON u.id=q.owner_id WHERE q.id=? LIMIT 1');
        $stmt->execute([$quotationId]);
        $q=$stmt->fetch(PDO::FETCH_ASSOC) ?: [];

        $itemsStmt=$pdo->prepare('SELECT * FROM quotation_items WHERE quotation_id=? ORDER BY sort_order,id');
        $itemsStmt->execute([$quotationId]);
        $items=$itemsStmt->fetchAll(PDO::FETCH_ASSOC);

        $paymentsStmt=$pdo->prepare('SELECT * FROM payment_schedules WHERE quotation_id=? ORDER BY due_date,id');
        $paymentsStmt->execute([$quotationId]);
        $payments=$paymentsStmt->fetchAll(PDO::FETCH_ASSOC);

        $totals=function_exists('quotation_totals') ? quotation_totals($pdo,$quotationId) : self::simpleTotals($items);

        $contractCode = self::documentCode($documentType, $q['quote_code'] ?? '', $quotationId);
        $clientName = $q['client_name'] ?? '';
        $clientRep = $q['client_contact'] ?? '';
        $total = (float)($totals['total'] ?? 0);
        $subtotal = (float)($totals['subtotal'] ?? 0);
        $vat = (float)($totals['vat'] ?? 0);
        $vatRate = self::detectVatRate($items);

        $deposit = self::firstPaymentAmount($payments);
        $remaining = max(0,$total-$deposit);

        $mapping=[
            'QUOTE_CODE' => $q['quote_code'] ?? '',
            'PUBLIC_TOKEN' => $q['public_token'] ?? '',
            'CONTRACT_CODE' => $contractCode,
            'ACCEPTANCE_CODE' => str_replace(['MKT','MH','HD'],'NT',$contractCode),
            'PAYMENT_CODE' => str_replace(['MKT','MH','HD'],'TT',$contractCode),
            'SIGN_DATE' => date('d/m/Y'),
            'SIGN_DAY' => date('d'),
            'SIGN_MONTH' => date('m'),
            'SIGN_YEAR' => date('Y'),
            'ACCEPTANCE_DATE' => date('d/m/Y'),
            'CLIENT_NAME' => $clientName,
            'CLIENT_REPRESENTATIVE' => $clientRep,
            'CLIENT_REPRESENTATIVE_UPPER' => mb_strtoupper($clientRep ?: '[Người đại diện bên A]', 'UTF-8'),
            'CLIENT_POSITION' => $q['client_position'] ?? 'Giám đốc',
            'CLIENT_ADDRESS' => $q['client_address'] ?? '',
            'CLIENT_PHONE' => $q['client_phone'] ?? '',
            'CLIENT_TAX' => $q['client_tax'] ?? '',
            'CLIENT_BANK' => $q['client_bank'] ?? '',
            'CLIENT_BANK_ACCOUNT' => $q['client_bank_account'] ?? '',
            'CLIENT_EMAIL' => $q['client_email'] ?? '',
            'INVOICE_COMPANY' => $clientName,
            'INVOICE_ADDRESS' => $q['client_address'] ?? '',
            'INVOICE_TAX' => $q['client_tax'] ?? '',
            'SERVICE_NAME' => $q['title'] ?? ($items[0]['service_name'] ?? 'Dịch vụ truyền thông'),
            'OBJECTIVE' => $q['objective'] ?? '',
            'INDUSTRY' => $q['industry'] ?? '',
            'CONTRACT_START' => $q['start_date'] ?? '',
            'CONTRACT_END' => $q['end_date'] ?? '',
            'CONTRACT_PERIOD' => self::periodText($q),
            'TOTAL_BEFORE_VAT' => self::money($subtotal),
            'VAT_RATE' => $vatRate.'%',
            'VAT_AMOUNT' => self::money($vat),
            'TOTAL_AMOUNT' => self::money($total),
            'TOTAL_AMOUNT_RAW' => $total,
            'TOTAL_AMOUNT_TEXT' => VietnameseNumber::moneyToWords($total),
            'TOTAL_AMOUNT_WITH_TEXT' => self::money($total).' ('.VietnameseNumber::moneyToWords($total).')',
            'DEPOSIT_AMOUNT' => self::money($deposit),
            'DEPOSIT_AMOUNT_WITH_TEXT' => self::money($deposit).' ('.VietnameseNumber::moneyToWords($deposit).')',
            'REMAINING_AMOUNT' => self::money($remaining),
            'REMAINING_AMOUNT_WITH_TEXT' => self::money($remaining).' ('.VietnameseNumber::moneyToWords($remaining).')',
            'PAYMENT_TERMS' => self::paymentTermsText($payments, $q),
            'ITEMS_TEXT' => self::itemsText($items),
            'ITEMS_TABLE_TEXT' => self::itemsTableText($items),
            'TABLE_ITEMS' => self::itemsTableText($items),
            '_ITEM_ROWS' => self::itemRows($items),
            '_PAYMENT_ROWS' => self::paymentRows($payments),
            'MOTIVE_COMPANY' => 'CÔNG TY TNHH TRUYỀN THÔNG MOTIVE',
            'MOTIVE_REPRESENTATIVE' => 'Ông Vũ Ngọc Thắng',
            'MOTIVE_POSITION' => 'Giám đốc',
            'MOTIVE_ADDRESS' => '05, ngách 15 ngõ 82 Yên Lãng, Phường Đống Đa, TP Hà Nội, Việt Nam.',
            'MOTIVE_PHONE' => '0965 980 886',
            'MOTIVE_TAX' => '0110212832',
            'MOTIVE_BANK_ACCOUNT' => '199938888',
            'MOTIVE_BANK' => 'Ngân hàng MBBank – Chi nhánh Sở Giao dịch 3'
        ];

        return $mapping;
    }


    public static function itemRows(array $items): array {
        $rows=[];
        foreach($items as $idx=>$i){
            $subtotal=(float)($i['subtotal'] ?? (($i['quantity']??1)*($i['unit_price']??0)));
            $total=(float)($i['total'] ?? $subtotal);
            $rows[]=[
                'STT'=>$idx+1,
                'ITEM_NO'=>$idx+1,
                'ITEM_NAME'=>$i['service_name'] ?? '',
                'ITEM_DESCRIPTION'=>$i['description'] ?? '',
                'ITEM_NOTE'=>$i['note'] ?? '',
                'ITEM_DETAIL'=>trim(($i['description'] ?? '')."\n".($i['note'] ?? '')),
                'ITEM_QUANTITY'=>$i['quantity'] ?? 1,
                'ITEM_UNIT'=>$i['unit'] ?? '',
                'ITEM_WORKING_TIME'=>$i['working_time'] ?? '',
                'ITEM_UNIT_PRICE'=>self::money($i['unit_price'] ?? 0),
                'ITEM_SUBTOTAL'=>self::money($subtotal),
                'ITEM_VAT_RATE'=>isset($i['vat_rate']) ? rtrim(rtrim((string)$i['vat_rate'],'0'),'.').'%' : '',
                'ITEM_TOTAL'=>self::money($total)
            ];
        }
        return $rows;
    }

    public static function paymentRows(array $payments): array {
        $rows=[];
        foreach($payments as $idx=>$p){
            $rows[]=[
                'PAYMENT_NO'=>$idx+1,
                'PAYMENT_MILESTONE'=>$p['milestone'] ?? ($p['title'] ?? 'Đợt '.($idx+1)),
                'PAYMENT_PERCENT'=>isset($p['percent']) ? rtrim(rtrim((string)$p['percent'],'0'),'.').'%' : '',
                'PAYMENT_AMOUNT'=>self::money($p['amount'] ?? 0),
                'PAYMENT_DUE_DATE'=>$p['due_date'] ?? '',
                'PAYMENT_STATUS'=>$p['status'] ?? '',
                'PAYMENT_NOTE'=>$p['note'] ?? ''
            ];
        }
        return $rows;
    }

    private static function simpleTotals(array $items): array {
        $subtotal=0;$vat=0;$total=0;
        foreach($items as $i){
            $subtotal+=(float)($i['subtotal']??0);
            $total+=(float)($i['total']??0);
        }
        $vat=max(0,$total-$subtotal);
        return ['subtotal'=>$subtotal,'vat'=>$vat,'total'=>$total];
    }

    private static function detectVatRate(array $items): string {
        foreach($items as $i){
            if(isset($i['vat_rate'])) return rtrim(rtrim((string)$i['vat_rate'],'0'),'.');
        }
        return '10';
    }

    public static function money($amount): string {
        return number_format((float)$amount,0,',','.') . ' VNĐ';
    }

    private static function firstPaymentAmount(array $payments): float {
        foreach($payments as $p){
            if((float)($p['amount']??0)>0) return (float)$p['amount'];
        }
        return 0;
    }

    private static function periodText(array $q): string {
        $start=$q['start_date'] ?? '';
        $end=$q['end_date'] ?? '';
        if($start || $end) return trim($start.' - '.$end,' -');
        return '[Thời gian thực hiện theo báo giá/hợp đồng]';
    }

    private static function paymentTermsText(array $payments, array $q): string {
        if(!empty($payments)){
            $lines=[];
            foreach($payments as $p){
                $name=$p['milestone'] ?? ($p['title'] ?? 'Đợt thanh toán');
                $amount=self::money($p['amount'] ?? 0);
                $percent=isset($p['percent']) && $p['percent']!=='' ? ' ('.rtrim(rtrim((string)$p['percent'],'0'),'.').'%)' : '';
                $due=!empty($p['due_date']) ? ' - Hạn thanh toán: '.$p['due_date'] : '';
                $lines[]=$name.$percent.': '.$amount.$due;
            }
            return implode("\n",$lines);
        }
        return $q['payment_terms'] ?? 'Thanh toán theo thỏa thuận giữa hai bên.';
    }

    private static function itemsText(array $items): string {
        $lines=[];
        foreach($items as $idx=>$i){
            $lines[] = ($idx+1).'. '.($i['service_name'] ?? 'Dịch vụ').' — '.($i['description'] ?? '').' — '.self::money($i['total'] ?? $i['subtotal'] ?? 0);
        }
        return implode("\n",$lines);
    }

    private static function itemsTableText(array $items): string {
        $lines=[];
        foreach($items as $idx=>$i){
            $lines[] = ($idx+1).' | '.($i['service_name'] ?? '').' | SL: '.($i['quantity'] ?? 1).' '.($i['unit'] ?? '').' | Đơn giá: '.self::money($i['unit_price'] ?? 0).' | Thành tiền: '.self::money($i['total'] ?? $i['subtotal'] ?? 0);
        }
        return implode("\n",$lines);
    }

    private static function documentCode(string $type, string $quoteCode, int $id): string {
        $year=date('Y');
        $prefix='DOC';
        if($type==='contract') $prefix='MKT';
        if($type==='hosting' || stripos($quoteCode,'MH')!==false) $prefix='MH';
        if($type==='acceptance') $prefix='NT';
        if($type==='quotation') $prefix='BG';
        if($type==='payment_request') $prefix='TT';
        return $prefix.'-'.$year.'-'.str_pad((string)$id,4,'0',STR_PAD_LEFT);
    }
}
