<?php
class CostBuilder {
    public static function applyInternalCostJson(PDO $pdo, int $quotationId, string $jsonText): array {
        $data = json_decode($jsonText, true);
        if (!$data || empty($data['items']) || !is_array($data['items'])) {
            return ['ok'=>false,'message'=>'AI output không phải JSON cost hợp lệ.'];
        }

        $pdo->prepare('DELETE FROM internal_cost_items WHERE quotation_id=?')->execute([$quotationId]);

        foreach($data['items'] as $item){
            $amount=(float)($item['amount'] ?? 0);
            if($amount<=0) continue;
            $name=trim($item['name'] ?? 'AI Cost Item');
            $desc=trim($item['description'] ?? '');
            $pdo->prepare('INSERT INTO internal_cost_items(quotation_id,item_name,description,unit,quantity,unit_cost,total) VALUES(?,?,?,?,?,?,?)')
                ->execute([$quotationId,$name,$desc,'gói',1,$amount,$amount]);
        }
        return ['ok'=>true,'message'=>'Đã apply internal cost từ AI.'];
    }
}
