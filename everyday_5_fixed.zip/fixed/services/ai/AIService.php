<?php
require_once __DIR__ . '/Env.php';

class AIService {
    private PDO $pdo;
    private string $provider;
    private string $apiKey;
    private string $model;
    private int $timeout;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
        Env::load();
        $this->provider = Env::get('OPENAI_PROVIDER', 'openai');
        $this->apiKey = Env::get('OPENAI_API_KEY', '');
        $this->model = Env::get('OPENAI_MODEL', $this->getDefaultModelFromDb());
        $this->timeout = (int)Env::get('OPENAI_TIMEOUT', '45');
    }

    private function getDefaultModelFromDb(): string {
        try {
            $stmt = $this->pdo->prepare("SELECT default_model FROM ai_settings WHERE provider='openai' AND is_active=1 ORDER BY id DESC LIMIT 1");
            $stmt->execute();
            return $stmt->fetchColumn() ?: 'gpt-4.1-mini';
        } catch (Exception $e) {
            return 'gpt-4.1-mini';
        }
    }

    public function isConfigured(): bool {
        return trim($this->apiKey) !== '';
    }

    public function maskKey(): string {
        if (!$this->apiKey) return '';
        return substr($this->apiKey, 0, 10) . '...' . substr($this->apiKey, -4);
    }

    public function getModel(): string {
        return $this->model;
    }

    public function testConnection(): array {
        if (!$this->isConfigured()) {
            return ['ok'=>false, 'message'=>'OPENAI_API_KEY chưa được cấu hình trong file .env'];
        }
        return $this->generateRaw(
            'Bạn là AI test connection. Chỉ trả lời đúng một câu: Motive AI connected.',
            ['type'=>'test_connection', 'template_code'=>'TEST_CONNECTION']
        );
    }

    public function generateFromTemplate(string $templateCode, array $payload, array $meta = []): array {
        $template = $this->getPromptTemplate($templateCode);
        if (!$template) {
            return ['ok'=>false, 'message'=>'Không tìm thấy prompt template: '.$templateCode];
        }
        $prompt = $template['prompt'] . "\n\nDỮ LIỆU JSON:\n" . json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        $meta['template_code'] = $templateCode;
        $meta['type'] = $meta['type'] ?? $template['category'] ?? 'general';
        return $this->generateRaw($prompt, $meta);
    }

    public function generateRaw(string $prompt, array $meta = []): array {
        if (!$this->isConfigured()) {
            $this->logGeneration($prompt, '', $meta, 'error', 'Missing OPENAI_API_KEY');
            return ['ok'=>false, 'message'=>'OPENAI_API_KEY chưa được cấu hình trong file .env'];
        }

        $payload = [
            'model' => $this->model,
            'messages' => [
                ['role'=>'system', 'content'=>'Bạn là Motive AI, trợ lý vận hành agency. Trả lời chính xác, ngắn gọn, có cấu trúc, bằng tiếng Việt.'],
                ['role'=>'user', 'content'=>$prompt]
            ],
            'temperature' => 0.4
        ];

        $ch = curl_init('https://api.openai.com/v1/chat/completions');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $this->apiKey
            ],
            CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE),
            CURLOPT_TIMEOUT => $this->timeout
        ]);

        $raw = curl_exec($ch);
        $curlError = curl_error($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);

        if ($raw === false || $curlError) {
            $this->logGeneration($prompt, '', $meta, 'error', $curlError ?: 'cURL error');
            return ['ok'=>false, 'message'=>'Không gọi được OpenAI API: '.$curlError];
        }

        $json = json_decode($raw, true);
        if ($httpCode >= 400 || isset($json['error'])) {
            $message = $json['error']['message'] ?? ('HTTP '.$httpCode);
            $this->logGeneration($prompt, $raw, $meta, 'error', $message);
            return ['ok'=>false, 'message'=>$message, 'http_code'=>$httpCode, 'raw'=>$json];
        }

        $content = $json['choices'][0]['message']['content'] ?? '';
        $usage = $json['usage'] ?? [];
        $this->logGeneration($prompt, $content, $meta, 'success', '', $usage);

        return [
            'ok'=>true,
            'content'=>$content,
            'model'=>$json['model'] ?? $this->model,
            'usage'=>$usage
        ];
    }

    private function getPromptTemplate(string $code): ?array {
        try {
            $stmt = $this->pdo->prepare('SELECT * FROM ai_prompt_templates WHERE code=? AND is_active=1 LIMIT 1');
            $stmt->execute([$code]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            return $row ?: null;
        } catch (Exception $e) {
            return null;
        }
    }

    private function logGeneration(string $prompt, string $response, array $meta, string $status='success', string $error='', array $usage=[]): void {
        try {
            $input = (int)($usage['prompt_tokens'] ?? 0);
            $output = (int)($usage['completion_tokens'] ?? 0);
            $estimated = $this->estimateCost($input, $output);
            $stmt = $this->pdo->prepare('INSERT INTO ai_generations(user_id,type,template_code,source_type,source_id,prompt,response,provider,model_name,input_tokens,output_tokens,estimated_cost,status,error_message) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
            $stmt->execute([
                $meta['user_id'] ?? (function_exists('current_user') && current_user() ? current_user()['id'] : null),
                $meta['type'] ?? 'general',
                $meta['template_code'] ?? null,
                $meta['source_type'] ?? null,
                $meta['source_id'] ?? null,
                $prompt,
                $response,
                $this->provider,
                $this->model,
                $input,
                $output,
                $estimated,
                $status,
                $error
            ]);
        } catch (Exception $e) {}
    }

    private function estimateCost(int $inputTokens, int $outputTokens): float {
        // Conservative placeholder estimate. Real pricing can be updated in Sprint 7B cost dashboard.
        return round(($inputTokens * 0.0000002) + ($outputTokens * 0.0000006), 6);
    }
}
