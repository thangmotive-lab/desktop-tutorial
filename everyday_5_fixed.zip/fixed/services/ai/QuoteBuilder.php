<?php
class QuoteBuilder {
    public static function nextDraftVersion(PDO $pdo, int $quotationId): int {
        $stmt=$pdo->prepare('SELECT COALESCE(MAX(version_no),0)+1 FROM quotation_ai_drafts WHERE quotation_id=?');
        $stmt->execute([$quotationId]);
        return (int)$stmt->fetchColumn();
    }

    public static function saveDraft(PDO $pdo, int $quotationId, string $type, string $content, int $userId): int {
        $version=self::nextDraftVersion($pdo,$quotationId);
        $stmt=$pdo->prepare('INSERT INTO quotation_ai_drafts(quotation_id,version_no,draft_type,generated_content,created_by) VALUES(?,?,?,?,?)');
        $stmt->execute([$quotationId,$version,$type,$content,$userId]);
        return (int)$pdo->lastInsertId();
    }

    public static function applyDraftToQuotation(PDO $pdo, int $draftId): array {
        $stmt=$pdo->prepare('SELECT * FROM quotation_ai_drafts WHERE id=? LIMIT 1');
        $stmt->execute([$draftId]);
        $draft=$stmt->fetch(PDO::FETCH_ASSOC);
        if(!$draft) return ['ok'=>false,'message'=>'Không tìm thấy AI draft.'];

        // Apply draft safely into intro_text only to avoid overwriting pricing/scope details.
        $stmt=$pdo->prepare('UPDATE quotations SET intro_text=? WHERE id=?');
        $stmt->execute([$draft['generated_content'],$draft['quotation_id']]);
        return ['ok'=>true,'message'=>'Đã apply AI draft vào phần intro/summary của báo giá.'];
    }
}
