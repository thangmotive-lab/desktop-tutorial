<?php
class ContractBuilder {
    public static function saveGeneratedContract(PDO $pdo, int $quotationId, string $html, string $contractType='marketing'): array {
        $dir = __DIR__ . '/../../uploads/ai_contracts';
        if(!is_dir($dir)) mkdir($dir,0775,true);

        $filename = 'contract_quote_'.$quotationId.'_'.date('Ymd_His').'.html';
        $path = $dir . '/' . $filename;
        $publicPath = 'uploads/ai_contracts/' . $filename;

        $doc = '<!DOCTYPE html><html lang="vi"><head><meta charset="UTF-8"><title>Generated Contract</title><style>body{font-family:Arial,sans-serif;line-height:1.55;padding:40px;max-width:900px;margin:auto}h1,h2,h3{color:#111827}table{width:100%;border-collapse:collapse}td,th{border:1px solid #ddd;padding:8px}</style></head><body>'.$html.'</body></html>';
        file_put_contents($path, $doc);

        return ['ok'=>true,'path'=>$publicPath,'filename'=>$filename,'type'=>$contractType];
    }
}
