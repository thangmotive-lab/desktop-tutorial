<?php
class KnowledgeBuilder {
    public static function relevant(PDO $pdo, array $categories = [], int $limit = 5): array {
        try {
            if(empty($categories)){
                return $pdo->query("SELECT title,category,content FROM ai_knowledge_base WHERE is_active=1 ORDER BY id DESC LIMIT ".(int)$limit)->fetchAll(PDO::FETCH_ASSOC);
            }
            $placeholders = implode(',', array_fill(0,count($categories),'?'));
            $stmt=$pdo->prepare("SELECT title,category,content FROM ai_knowledge_base WHERE is_active=1 AND category IN ($placeholders) ORDER BY id DESC LIMIT ".(int)$limit);
            $stmt->execute($categories);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(Exception $e) {
            return [];
        }
    }

    public static function appendToPayload(PDO $pdo, array $payload, array $categories = []): array {
        $payload['knowledge_base'] = self::relevant($pdo, $categories, 8);
        return $payload;
    }
}
