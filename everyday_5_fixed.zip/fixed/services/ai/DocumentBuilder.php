<?php
class DocumentBuilder {
    public static function saveHtml(PDO $pdo, string $sourceType, int $sourceId, string $documentType, string $title, string $html, int $userId): array {
        $dir = __DIR__ . '/../../uploads/ai_documents';
        if(!is_dir($dir)) mkdir($dir,0775,true);
        $safeTitle = preg_replace('/[^a-zA-Z0-9_-]+/', '_', strtolower($documentType.'_'.$sourceType.'_'.$sourceId));
        $filename = $safeTitle.'_'.date('Ymd_His').'.html';
        $publicPath = 'uploads/ai_documents/'.$filename;

        $doc = self::wrapHtml($title,$html);
        file_put_contents($dir.'/'.$filename, $doc);

        $stmt=$pdo->prepare('INSERT INTO ai_document_outputs(source_type,source_id,document_type,title,html_content,file_path,created_by) VALUES(?,?,?,?,?,?,?)');
        $stmt->execute([$sourceType,$sourceId,$documentType,$title,$html,$publicPath,$userId]);
        return ['ok'=>true,'id'=>(int)$pdo->lastInsertId(),'path'=>$publicPath];
    }

    public static function wrapHtml(string $title, string $html): string {
        return '<!DOCTYPE html><html lang="vi"><head><meta charset="UTF-8"><title>'.htmlspecialchars($title).'</title><style>
        body{font-family:Arial,Helvetica,sans-serif;line-height:1.55;color:#111827;max-width:900px;margin:40px auto;padding:0 24px}
        h1,h2,h3{text-align:left;letter-spacing:-.03em} h1{text-align:center;text-transform:uppercase;font-size:24px}
        table{width:100%;border-collapse:collapse;margin:14px 0}td,th{border:1px solid #d1d5db;padding:8px;vertical-align:top}th{background:#f3f4f6}
        .signature{display:grid;grid-template-columns:1fr 1fr;gap:40px;text-align:center;margin-top:40px}
        @media print{@page{size:A4;margin:14mm}body{margin:0;padding:0;max-width:none;font-size:12px}}
        </style></head><body>'.$html.'</body></html>';
    }
}
