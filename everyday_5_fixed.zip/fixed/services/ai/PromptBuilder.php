<?php
class PromptBuilder {
    public static function quotationPayload(PDO $pdo, int $quotationId): array {
        $stmt=$pdo->prepare('SELECT q.*,u.name owner_name FROM quotations q LEFT JOIN users u ON u.id=q.owner_id WHERE q.id=? LIMIT 1');
        $stmt->execute([$quotationId]);
        $q=$stmt->fetch(PDO::FETCH_ASSOC);
        if(!$q) return [];

        $itemsStmt=$pdo->prepare('SELECT * FROM quotation_items WHERE quotation_id=? ORDER BY sort_order,id');
        $itemsStmt->execute([$quotationId]);
        $items=$itemsStmt->fetchAll(PDO::FETCH_ASSOC);

        $paymentsStmt=$pdo->prepare('SELECT * FROM payment_schedules WHERE quotation_id=? ORDER BY due_date,id');
        $paymentsStmt->execute([$quotationId]);
        $payments=$paymentsStmt->fetchAll(PDO::FETCH_ASSOC);

        $totals=function_exists('quotation_totals') ? quotation_totals($pdo,$quotationId) : [];

        return [
            'quotation'=>$q,
            'items'=>$items,
            'payments'=>$payments,
            'totals'=>$totals
        ];
    }

    public static function paymentPayload(PDO $pdo, int $paymentId): array {
        $stmt=$pdo->prepare('SELECT ps.*,q.quote_code,q.client_name quote_client,q.title quote_title,c.contract_code,c.client_name contract_client,c.total_value contract_value FROM payment_schedules ps LEFT JOIN quotations q ON q.id=ps.quotation_id LEFT JOIN contracts c ON c.id=ps.contract_id WHERE ps.id=? LIMIT 1');
        $stmt->execute([$paymentId]);
        $p=$stmt->fetch(PDO::FETCH_ASSOC);
        return ['payment'=>$p ?: []];
    }

    public static function contractPayloadFromQuotation(PDO $pdo, int $quotationId): array {
        $payload=self::quotationPayload($pdo,$quotationId);
        try {
            $stmt=$pdo->prepare('SELECT * FROM contracts WHERE quotation_id=? ORDER BY id DESC LIMIT 1');
            $stmt->execute([$quotationId]);
            $payload['contract']=$stmt->fetch(PDO::FETCH_ASSOC) ?: [];
        } catch(Exception $e) {
            $payload['contract']=[];
        }
        return $payload;
    }
}
