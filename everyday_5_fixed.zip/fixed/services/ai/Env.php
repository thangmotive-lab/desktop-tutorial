<?php
class Env {
    private static $loaded = false;

    public static function load($path = null) {
        if (self::$loaded) return;
        self::$loaded = true;
        $path = $path ?: __DIR__ . '/../../.env';
        if (!file_exists($path)) return;

        $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || str_starts_with($line, '#') || !str_contains($line, '=')) continue;
            [$key, $value] = explode('=', $line, 2);
            $key = trim($key);
            $value = trim($value);
            $value = trim($value, "\"'");
            if ($key !== '' && getenv($key) === false) {
                putenv($key . '=' . $value);
                $_ENV[$key] = $value;
            }
        }
    }

    public static function get($key, $default = '') {
        self::load();
        $value = getenv($key);
        return $value === false || $value === '' ? $default : $value;
    }
}
