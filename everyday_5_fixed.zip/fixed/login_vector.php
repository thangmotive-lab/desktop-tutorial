<?php
$error = $error ?? '';
$quoteToday = $quoteToday ?? 'Keep moving forward.';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <title>Motive Everyday — Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
  <meta name="theme-color" content="#f7fbff">
  <style>
    *{box-sizing:border-box}
    html,body{margin:0;min-height:100%;font-family:Inter,Arial,sans-serif}
    body{background:#f7fbff;color:#101828;overflow:hidden}
    input,button{font-family:inherit}
    .login-vector-page{
      position:relative;min-height:100vh;display:flex;align-items:center;justify-content:center;
      padding:34px;overflow:hidden;color:#101828;
    }
    .vector-prairie{position:absolute;inset:0;overflow:hidden;background:
      radial-gradient(circle at var(--glow-x,18%) var(--glow-y,28%),rgba(255,240,190,.9) 0 8%,rgba(255,214,128,.22) 9% 26%,transparent 46%),
      linear-gradient(180deg,var(--sky-1,#bfeefe) 0%,var(--sky-2,#f5fbff) 56%,var(--ground-1,#daf7db) 57%,var(--ground-2,#86d98a) 100%);
      transition:background 1.2s ease}
    .vector-prairie *{position:absolute;pointer-events:none}
    .sun{width:92px;height:92px;border-radius:50%;left:var(--sun-left,16%);top:var(--sun-top,21%);
      background:radial-gradient(circle,#fff8c7 0 42%,#fbbf24 43% 70%,rgba(251,191,36,.08) 71% 100%);
      box-shadow:0 0 55px rgba(251,191,36,.38),0 0 120px rgba(251,146,60,.18);animation:float 7s ease-in-out infinite;transition:.8s ease}
    .moon{width:72px;height:72px;border-radius:50%;right:14%;top:16%;background:#f8fafc;box-shadow:inset -14px -8px 0 #cbd5e1,0 0 55px rgba(226,232,240,.3);opacity:0;transition:.8s ease}
    .cloud{width:116px;height:34px;border-radius:999px;background:rgba(255,255,255,.68);filter:drop-shadow(0 8px 18px rgba(15,23,42,.04));animation:cloud 34s ease-in-out infinite}
    .cloud:before,.cloud:after{content:"";position:absolute;border-radius:50%;background:inherit}
    .cloud:before{width:44px;height:44px;left:20px;bottom:8px}.cloud:after{width:58px;height:58px;left:50px;bottom:4px}
    .c1{left:13%;top:23%}.c2{left:58%;top:16%;transform:scale(.72);animation-delay:-14s}.c3{left:76%;top:34%;transform:scale(.55);animation-delay:-23s}
    .landscape{position:absolute;inset:0;width:100%;height:100%;bottom:0}
    .mountains{fill:var(--mountain,#d8ecf0);opacity:.52}
    .path-line{fill:none;stroke:rgba(255,255,255,.44);stroke-width:18;stroke-linecap:round;opacity:.42}
    .particles span{width:8px;height:8px;border-radius:50%;background:rgba(255,255,255,.75);animation:particle 8s ease-in-out infinite}
    .particles span:nth-child(1){left:12%;bottom:18%}.particles span:nth-child(2){left:34%;bottom:14%;animation-delay:-2s}.particles span:nth-child(3){left:56%;bottom:20%;animation-delay:-4s}.particles span:nth-child(4){left:78%;bottom:16%;animation-delay:-1s}.particles span:nth-child(5){left:88%;bottom:24%;animation-delay:-5s}
    .grass{left:0;right:0;bottom:0;height:22%;opacity:.18;background:repeating-linear-gradient(82deg,transparent 0 13px,rgba(255,255,255,.55) 14px 16px,transparent 17px 28px),repeating-linear-gradient(102deg,transparent 0 16px,rgba(14,86,55,.34) 17px 18px,transparent 19px 31px);animation:grass 4s ease-in-out infinite}
    .login-vector-shell{position:relative;z-index:4;width:min(1120px,100%);display:grid;grid-template-columns:1fr .82fr;gap:24px;align-items:stretch}
    .copy,.card{border:1px solid rgba(255,255,255,.58);background:rgba(255,255,255,.52);backdrop-filter:blur(22px);-webkit-backdrop-filter:blur(22px);border-radius:36px;box-shadow:0 28px 80px rgba(15,23,42,.10)}
    .copy{padding:50px;min-height:620px;display:flex;flex-direction:column;justify-content:center}
    .kicker{display:inline-flex;color:#2e8b57;font-size:12px;font-weight:950;letter-spacing:.08em;text-transform:uppercase}
    h1{margin:14px 0 20px;max-width:580px;color:#101828;font-size:72px;line-height:.92;letter-spacing:-.08em}
    .subcopy{max-width:560px;color:rgba(16,24,40,.68);font-size:17px;line-height:1.65;font-weight:300}
    .pillars{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin:34px 0}
    .pillars div{padding:18px 16px;border-radius:24px;background:rgba(255,255,255,.56);border:1px solid rgba(255,255,255,.62)}
    .pillars span{display:block;color:#2e8b57;font-size:11px;font-weight:950;margin-bottom:8px}.pillars b{display:block;color:#101828;font-size:18px;letter-spacing:-.04em}
    .quote{margin-top:6px;padding:20px 22px;border-radius:26px;background:rgba(255,255,255,.54);border:1px solid rgba(255,255,255,.65)}
    .quote small{display:block;color:#2e8b57;font-size:11px;font-weight:950;text-transform:uppercase;letter-spacing:.08em;margin-bottom:8px}
    .quote blockquote{margin:0;color:#245c43;font-family:"Comic Sans MS","Segoe Print",cursive;font-style:italic;font-size:24px;line-height:1.35;transform:rotate(-1deg)}
    .card{padding:46px;align-self:center}
    .card h2{margin:8px 0 6px;font-size:44px;color:#101828;letter-spacing:-.07em}.card p{margin:0 0 28px;color:rgba(16,24,40,.66);font-weight:500}
    label{font-size:13px;font-weight:850;color:#101828;margin:16px 0 7px;display:block}
    input{width:100%;min-height:56px;border-radius:20px;border:1px solid rgba(255,255,255,.68);background:rgba(255,255,255,.72);padding:12px 14px;font-size:15px;outline:none}
    input:focus{border-color:#2e8b57;box-shadow:0 0 0 5px rgba(46,139,87,.14)}
    .submit{width:100%;margin-top:24px;min-height:58px;border:0;border-radius:22px;background:linear-gradient(135deg,#2e8b57,#39b6d8);box-shadow:0 18px 38px rgba(46,139,87,.18);font-size:16px;color:#fff;font-weight:900;cursor:pointer}
    .foot{display:flex;justify-content:space-between;gap:12px;margin-top:18px;color:rgba(16,24,40,.52);font-size:12px;font-weight:850}
    .flash{padding:12px 14px;border-radius:16px;background:#fff1f2;border:1px solid #fecdd3;color:#be123c;font-weight:800;margin-bottom:14px}
    [data-time-phase="morning"] .vector-prairie{--sky-1:#bfeefe;--sky-2:#fff5d4;--ground-1:#d9f8d8;--ground-2:#78d184;--glow-x:16%;--glow-y:28%;--sun-left:15%;--sun-top:22%;--mountain:#d8ecf0;--hill-a1:#c9f4c8;--hill-a2:#86d98a;--hill-b1:#9fe5a6;--hill-b2:#5fbd70;--hill-c1:#75d184;--hill-c2:#2f8b5a}
    [data-time-phase="noon"] .vector-prairie{--sky-1:#9bdcff;--sky-2:#eefcff;--ground-1:#d7f8dc;--ground-2:#65c978;--glow-x:50%;--glow-y:14%;--sun-left:48%;--sun-top:10%;--mountain:#cfe7ef;--hill-a1:#c8f5cf;--hill-a2:#7bd286;--hill-b1:#98e2a1;--hill-b2:#58b968;--hill-c1:#70cd7e;--hill-c2:#2c8556}
    [data-time-phase="sunset"] .vector-prairie{--sky-1:#ffc3a3;--sky-2:#ffe9be;--ground-1:#dfe5a9;--ground-2:#5fa56b;--glow-x:78%;--glow-y:35%;--sun-left:76%;--sun-top:32%;--mountain:#dcc8bd;--hill-a1:#d7dda2;--hill-a2:#95bd70;--hill-b1:#b8cd83;--hill-b2:#689b61;--hill-c1:#83aa63;--hill-c2:#356b49}
    [data-time-phase="night"] .vector-prairie{--sky-1:#111b3b;--sky-2:#2f3b63;--ground-1:#315f48;--ground-2:#143f33;--glow-x:88%;--glow-y:20%;--mountain:#293857;--hill-a1:#315f48;--hill-a2:#214b3b;--hill-b1:#24533f;--hill-b2:#163b32;--hill-c1:#1e4637;--hill-c2:#102d28}
    [data-time-phase="night"] .sun{opacity:0}[data-time-phase="night"] .moon{opacity:1}
    [data-time-phase="night"] .copy,[data-time-phase="night"] .card{background:rgba(17,24,39,.48);border-color:rgba(255,255,255,.16);color:#fff}
    [data-time-phase="night"] h1,[data-time-phase="night"] h2,[data-time-phase="night"] label,[data-time-phase="night"] .pillars b{color:#fff}
    [data-time-phase="night"] .subcopy,[data-time-phase="night"] .card p,[data-time-phase="night"] .foot{color:rgba(255,255,255,.72)}
    [data-time-phase="night"] .pillars div,[data-time-phase="night"] .quote{background:rgba(255,255,255,.12);border-color:rgba(255,255,255,.16)}
    [data-time-phase="night"] .quote blockquote{color:#d8fff0}
    @keyframes float{0%,100%{transform:translateY(0)}50%{transform:translateY(-8px)}}@keyframes cloud{0%,100%{margin-left:-14px}50%{margin-left:28px}}@keyframes particle{0%{transform:translateY(0);opacity:0}25%{opacity:.8}100%{transform:translateY(-80px);opacity:0}}@keyframes grass{0%,100%{transform:skewX(0) translateX(0)}50%{transform:skewX(-2deg) translateX(-6px)}}
    @media(max-width:900px){body{overflow:auto}.login-vector-page{padding:18px;align-items:flex-start}.login-vector-shell{grid-template-columns:1fr;gap:14px}.copy{min-height:420px;padding:30px;border-radius:30px}h1{font-size:48px}.subcopy{font-size:15px}.pillars{grid-template-columns:1fr;gap:10px;margin:22px 0}.card{padding:28px;border-radius:30px}.card h2{font-size:36px}.quote blockquote{font-size:20px}}
  </style>
</head>
<body>
  <main class="login-vector-page" id="loginVectorPage">
    <section class="vector-prairie" aria-hidden="true">
      <div class="sun"></div><div class="moon"></div>
      <div class="cloud c1"></div><div class="cloud c2"></div><div class="cloud c3"></div>
      <svg class="landscape" viewBox="0 0 1440 900" preserveAspectRatio="none">
        <defs>
          <linearGradient id="hillA" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stop-color="var(--hill-a1)"/><stop offset="100%" stop-color="var(--hill-a2)"/></linearGradient>
          <linearGradient id="hillB" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stop-color="var(--hill-b1)"/><stop offset="100%" stop-color="var(--hill-b2)"/></linearGradient>
          <linearGradient id="hillC" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stop-color="var(--hill-c1)"/><stop offset="100%" stop-color="var(--hill-c2)"/></linearGradient>
        </defs>
        <path class="mountains" d="M0,430 C170,330 270,420 430,320 C610,205 760,355 930,250 C1110,140 1270,330 1440,210 L1440,900 L0,900 Z"/>
        <path fill="url(#hillA)" d="M0,525 C180,440 310,490 500,420 C720,338 890,470 1080,385 C1230,320 1340,390 1440,330 L1440,900 L0,900 Z"/>
        <path fill="url(#hillB)" d="M0,610 C210,500 380,595 580,500 C780,410 930,560 1120,470 C1290,392 1370,465 1440,430 L1440,900 L0,900 Z"/>
        <path fill="url(#hillC)" d="M0,720 C190,610 360,700 570,615 C790,525 940,690 1160,590 C1320,520 1400,585 1440,560 L1440,900 L0,900 Z"/>
        <path class="path-line" d="M690,900 C680,820 720,760 700,695 C680,628 620,590 640,540 C660,490 730,470 750,420"/>
      </svg>
      <div class="particles"><span></span><span></span><span></span><span></span><span></span></div><div class="grass"></div>
    </section>

    <section class="login-vector-shell">
      <div class="copy">
        <span class="kicker">MOTIVE EVERYDAY</span>
        <h1>Keep moving forward.</h1>
        <p class="subcopy">Everyday là phần mềm quản lý công việc, dự án, đầu việc, khách hàng, hợp đồng, dòng tiền và AI Workspace trong một nơi duy nhất.</p>
        <div class="pillars"><div><span>01</span><b>Deep work</b></div><div><span>02</span><b>Keep track</b></div><div><span>03</span><b>Clear everything</b></div></div>
        <div class="quote"><small>Quote of the day</small><blockquote>“<?= e($quoteToday) ?>”</blockquote></div>
      </div>

      <div class="card">
        <div><span class="kicker">WELCOME BACK</span><h2>Đăng nhập</h2><p>Vào workspace để tiếp tục vận hành Motive hôm nay.</p></div>
        <?php if($error): ?><div class="flash"><?= e($error) ?></div><?php endif; ?>
        <form method="post" autocomplete="on">
          <label>Email</label><input type="email" name="email" placeholder="you@motive.vn" required autofocus>
          <label>Mật khẩu</label><input type="password" name="password" placeholder="••••••••" required>
          <button class="submit" type="submit">Vào workspace →</button>
        </form>
        <div class="foot"><span>Secure workspace</span><span>Made for Motive Agency</span></div>
      </div>
    </section>
  </main>

<script>
function applyLoginVectorTime(){
  const page=document.getElementById('loginVectorPage');
  if(!page) return;
  const h=new Date().getHours();
  let phase='morning';
  if(h>=5&&h<11) phase='morning'; else if(h>=11&&h<16) phase='noon'; else if(h>=16&&h<19) phase='sunset'; else phase='night';
  page.dataset.timePhase=phase;
}
document.addEventListener('DOMContentLoaded', applyLoginVectorTime);
setInterval(applyLoginVectorTime, 60000);
</script>
</body>
</html>
