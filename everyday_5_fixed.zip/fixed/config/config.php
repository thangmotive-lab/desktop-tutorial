<?php

// Tắt hiển thị lỗi ra màn hình trên production. Bật lại khi debug local.
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(E_ALL);
ini_set('log_errors', 1);

define('DB_HOST', 'localhost');
define('DB_NAME', 'motive_everyday');
define('DB_USER', 'motive_everyday');
define('DB_PASS', 'everyday///123');

define('APP_NAME', 'Motiveeveryday');
define('APP_VERSION', 'MVP 3A Final Stabilized');

date_default_timezone_set('Asia/Ho_Chi_Minh');
