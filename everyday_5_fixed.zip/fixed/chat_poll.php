<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';
require_login();
header('Content-Type: application/json; charset=utf-8');

$since=(int)($_GET['since']??0);
$stmt=$pdo->prepare('SELECT gm.id,gm.message,gm.created_at,u.name,u.avatar,u.id user_id FROM group_messages gm JOIN users u ON u.id=gm.user_id WHERE gm.id>? ORDER BY gm.id ASC LIMIT 30');
$stmt->execute([$since]);
echo json_encode(['messages'=>$stmt->fetchAll(),'me'=>current_user()['id']], JSON_UNESCAPED_UNICODE);
