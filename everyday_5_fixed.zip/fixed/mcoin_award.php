<?php
ob_start();
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';
header('Content-Type: application/json; charset=utf-8');
try {
    if (!function_exists('is_logged_in') || !is_logged_in()) {
        http_response_code(401);
        echo json_encode(['ok'=>false,'error'=>'not_logged_in']);
        exit;
    }
    $me = current_user();
    $uid = (int)($me['id'] ?? 0);
    if ($uid <= 0) throw new Exception('invalid_user');
    if (function_exists('mcoin_ensure_schema')) mcoin_ensure_schema($pdo);

    $type = $_POST['type'] ?? $_GET['type'] ?? 'manual';
    $session = trim($_POST['session'] ?? $_GET['session'] ?? '');
    $amount = 0;
    $reason = '';
    $gardenIcon = '🌱';
    $sessions = 0;

    if ($type === 'pomodoro') {
        $amount = (int)(function_exists('mcoin_get_setting') ? mcoin_get_setting($pdo, 'pomodoro_done', 1200) : 1200);
        if ($amount <= 0) $amount = 1200;
        $reason = 'Hoàn thành Pomodoro';
        $ref = 'pomodoro:'.$uid.':'.($session ?: date('YmdHis'));
        if (function_exists('mcoin_award')) {
            mcoin_award($pdo, $uid, $amount, $reason, 'pomodoro', null, $ref, 'Focus Garden');
        }
        try {
            $today = date('Y-m-d');
            $pdo->prepare("INSERT INTO focus_garden(user_id, focus_date, sessions, garden_level) VALUES(?,?,1,1) ON DUPLICATE KEY UPDATE sessions=sessions+1, garden_level=LEAST(5,garden_level+1), updated_at=NOW()")->execute([$uid,$today]);
            $st=$pdo->prepare("SELECT sessions FROM focus_garden WHERE user_id=? AND focus_date=? LIMIT 1");
            $st->execute([$uid,$today]);
            $sessions=(int)$st->fetchColumn();
            if (function_exists('mcoin_garden_icon')) $gardenIcon = mcoin_garden_icon($sessions);
            if ($sessions >= 10 && function_exists('achievement_award')) achievement_award($pdo,$uid,'focus_master');
        } catch(Throwable $e) {}
    } else {
        $amount = (int)($_POST['amount'] ?? $_GET['amount'] ?? 0);
        $reason = trim($_POST['reason'] ?? $_GET['reason'] ?? 'Mcoin reward');
        if ($amount > 0 && function_exists('mcoin_award')) {
            mcoin_award($pdo,$uid,$amount,$reason,'manual',null,null,'Manual reward endpoint');
        }
    }

    echo json_encode(['ok'=>true,'amount'=>$amount,'reason'=>$reason,'garden_icon'=>$gardenIcon,'sessions'=>$sessions]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok'=>false,'error'=>$e->getMessage()]);
}
