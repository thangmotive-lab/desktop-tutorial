let seconds = 0;
let timer = null;

const timerText = document.getElementById('workTimerText');
const startBtn = document.getElementById('btnStartWork');

startBtn?.addEventListener('click', function(){

    if(timer) return;

    startBtn.innerText = 'Đang làm';

    timer = setInterval(() => {

        seconds++;

        const h = String(Math.floor(seconds/3600)).padStart(2,'0');
        const m = String(Math.floor((seconds%3600)/60)).padStart(2,'0');
        const s = String(seconds%60).padStart(2,'0');

        timerText.innerHTML =
            `${h}:${m}:${s} • Đang làm việc`;

    },1000);

});