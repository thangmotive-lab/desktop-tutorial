function toggleSidebar(){
  const shell = document.getElementById('appShell');
  shell.classList.toggle('collapsed');
  localStorage.setItem('sidebarCollapsed', shell.classList.contains('collapsed') ? '1' : '0');
}
document.addEventListener('DOMContentLoaded', function(){
  const shell = document.getElementById('appShell');
  if(shell && localStorage.getItem('sidebarCollapsed') === '1') shell.classList.add('collapsed');
  startTimer();
});
function showYay(){
  const overlay = document.getElementById('yayOverlay');
  overlay.classList.add('active');
  launchConfetti();
  setTimeout(()=>overlay.classList.remove('active'), 2300);
}
function launchConfetti(){
  for(let i=0;i<24;i++){
    const el=document.createElement('div');
    el.textContent = ['💖','🎉','💗','✨'][Math.floor(Math.random()*4)];
    el.style.position='fixed';
    el.style.left=Math.random()*100+'vw';
    el.style.top='-30px';
    el.style.fontSize=(20+Math.random()*16)+'px';
    el.style.zIndex=120;
    el.style.transition='transform 2s ease, opacity 2s ease';
    document.body.appendChild(el);
    setTimeout(()=>{el.style.transform='translateY('+(window.innerHeight+80)+'px) rotate('+(Math.random()*360)+'deg)';el.style.opacity='0';},20);
    setTimeout(()=>el.remove(),2200);
  }
}

function startTimer(){
  const timers = [
    {wrap: document.getElementById('workTimer'), target: document.getElementById('timerTime')},
    {wrap: document.getElementById('headerWorkTimer'), target: document.getElementById('headerTimerTime')}
  ];
  timers.forEach(({wrap,target})=>{
    if(!wrap || !target) return;
    if(wrap.classList && wrap.classList.contains('idle')) return;
    const start = wrap.dataset.start;
    const baseMinutes = parseInt(wrap.dataset.baseMinutes || '0', 10);
    if(!start){
      const h = Math.floor(baseMinutes/60);
      const m = baseMinutes%60;
      target.textContent = String(h).padStart(2,'0')+':'+String(m).padStart(2,'0')+':00';
      return;
    }
    const startTime = new Date(start.replace(' ', 'T')).getTime();
    setInterval(()=>{
      const diff = Math.max(0, Date.now()-startTime) + baseMinutes*60000;
      const h = Math.floor(diff/3600000);
      const m = Math.floor((diff%3600000)/60000);
      const s = Math.floor((diff%60000)/1000);
      target.textContent = String(h).padStart(2,'0')+':'+String(m).padStart(2,'0')+':'+String(s).padStart(2,'0');
    },1000);
  });
}

function recalcQuotationRow(row){
  const qty = parseFloat(row.querySelector('[name*="[quantity]"]').value || 0);
  const unit = parseFloat(row.querySelector('[name*="[unit_price]"]').value || 0);
  const vat = parseFloat(row.querySelector('[name*="[vat_rate]"]').value || 0);
  const subtotal = qty * unit;
  const vatAmount = subtotal * vat / 100;
  const total = subtotal + vatAmount;
  row.querySelector('.js-subtotal').textContent = subtotal.toLocaleString('vi-VN') + 'đ';
  row.querySelector('.js-vat').textContent = vatAmount.toLocaleString('vi-VN') + 'đ';
  row.querySelector('.js-total').textContent = total.toLocaleString('vi-VN') + 'đ';
}
function recalcCostRow(row){
  const qty = parseFloat(row.querySelector('[name*="[quantity]"]').value || 0);
  const unit = parseFloat(row.querySelector('[name*="[unit_cost]"]').value || 0);
  row.querySelector('.js-cost-total').textContent = (qty*unit).toLocaleString('vi-VN') + 'đ';
}
document.addEventListener('input', function(e){
  const qRow = e.target.closest('.quotation-row'); if(qRow) recalcQuotationRow(qRow);
  const cRow = e.target.closest('.cost-row'); if(cRow) recalcCostRow(cRow);
});


function toggleAdminMenu(){
  const menu=document.getElementById('adminMenu');
  if(menu) menu.classList.toggle('open');
}
function openModal(id){
  const el=document.getElementById(id);
  if(el) el.classList.add('active');
}
function closeModal(id){
  const el=document.getElementById(id);
  if(el) el.classList.remove('active');
}
document.addEventListener('click', function(e){
  if(e.target.classList.contains('modal-backdrop')) e.target.classList.remove('active');
});
function showToast(title,msg,link){
  let stack=document.getElementById('toastStack');
  if(!stack){
    stack=document.createElement('div');
    stack.id='toastStack';
    stack.className='toast-stack';
    document.body.appendChild(stack);
  }
  const t=document.createElement('div');
  t.className='toast';
  t.innerHTML='<b>'+title+'</b><span>'+msg+'</span>'+(link?'<br><a href="'+link+'">Mở ngay</a>':'');
  stack.appendChild(t);
  setTimeout(()=>{t.style.opacity='0';t.style.transform='translateX(20px)';},6500);
  setTimeout(()=>t.remove(),7200);
}
function addQuotationRow(){
  const tbody=document.querySelector('#quotationItemsBody');
  if(!tbody) return;
  const idx=tbody.querySelectorAll('tr').length;
  const tr=document.createElement('tr');
  tr.className='quotation-row';
  tr.innerHTML=`<td>${idx+1}</td>
<td><input name="items[${idx}][service_name]"></td>
<td><textarea name="items[${idx}][description]"></textarea></td>
<td><input name="items[${idx}][quantity]" type="number" step="0.1" value="1"></td>
<td><input name="items[${idx}][unit]" value="gói"></td>
<td><input name="items[${idx}][working_time]"></td>
<td><input name="items[${idx}][unit_price]" type="number" value="0"></td>
<td><input name="items[${idx}][vat_rate]" type="number" step="0.1" value="10"></td>
<td class="js-subtotal">0đ</td><td class="js-vat">0đ</td><td class="js-total">0đ</td>
<td><input name="items[${idx}][note]"></td><td><button type="button" class="row-remove" onclick="removeTableRow(this)">Xoá</button></td>`;
  tbody.appendChild(tr);
}
function removeTableRow(btn){
  const tr=btn.closest('tr');
  if(tr) tr.remove();
}


function openTaskDrawer(id){ 
  const d=document.getElementById('taskDrawer'+id);
  const b=document.getElementById('drawerBackdrop');
  if(d){d.classList.add('active');}
  if(b){b.classList.add('active');}
}
function closeTaskDrawers(){
  document.querySelectorAll('.task-drawer').forEach(d=>d.classList.remove('active'));
  const b=document.getElementById('drawerBackdrop');
  if(b){b.classList.remove('active');}
}
function startTaskTimer(taskId, taskName){
  let popup=document.getElementById('activeTaskTimer');
  if(!popup){
    popup=document.createElement('div');
    popup.id='activeTaskTimer';
    popup.className='timer-popup';
    document.body.appendChild(popup);
  }
  const start=Date.now();
  popup.innerHTML=`<h3>Đang làm việc</h3><div><b>${taskName}</b></div><div class="timer-time" id="activeTaskTimerTime">00:00:00</div><div class="actions"><button onclick="pauseTaskTimer()" class="btn-orange">Pause</button><button onclick="stopTaskTimer()" class="btn-red">Stop</button></div>`;
  if(window.taskTimerInterval) clearInterval(window.taskTimerInterval);
  window.taskTimerInterval=setInterval(()=>{
    const diff=Date.now()-start;
    const h=Math.floor(diff/3600000), m=Math.floor((diff%3600000)/60000), s=Math.floor((diff%60000)/1000);
    const target=document.getElementById('activeTaskTimerTime');
    if(target) target.textContent=String(h).padStart(2,'0')+':'+String(m).padStart(2,'0')+':'+String(s).padStart(2,'0');
  },1000);
}
function pauseTaskTimer(){
  if(window.taskTimerInterval) clearInterval(window.taskTimerInterval);
}
function stopTaskTimer(){
  if(window.taskTimerInterval) clearInterval(window.taskTimerInterval);
  const popup=document.getElementById('activeTaskTimer');
  if(popup) popup.remove();
}


function startHeaderTimer(){
  const timer=document.getElementById('headerWorkTimer');
  if(!timer) return;
  const target=document.getElementById('headerTimerTime');
  const start=new Date(timer.dataset.start.replace(' ','T')).getTime();
  function tick(){
    const diff=Math.max(0,Date.now()-start);
    const h=Math.floor(diff/3600000);
    const m=Math.floor((diff%3600000)/60000);
    const s=Math.floor((diff%60000)/1000);
    if(target) target.textContent=String(h).padStart(2,'0')+':'+String(m).padStart(2,'0')+':'+String(s).padStart(2,'0');
  }
  tick(); setInterval(tick,1000);
}
document.addEventListener('DOMContentLoaded', startHeaderTimer);

function openSlideDrawer(id){
  const el=document.getElementById(id);
  const b=document.getElementById('drawerBackdrop');
  if(el) el.classList.add('active');
  if(b) b.classList.add('active');
}
function closeSlideDrawer(id){
  const el=document.getElementById(id);
  if(el) el.classList.remove('active');
  const b=document.getElementById('drawerBackdrop');
  if(b) b.classList.remove('active');
}

document.addEventListener('DOMContentLoaded', function(){
  if(window.AOS){ AOS.init({duration:520, easing:'ease-out-cubic', once:true}); }
  if(window.gsap){
    gsap.from('.card', {opacity:0, y:18, duration:.45, stagger:.035, ease:'power2.out'});
    gsap.from('.stat', {opacity:0, scale:.96, duration:.35, stagger:.045, ease:'back.out(1.4)'});
  }
});


/* HOTFIX 3A.4.1 Drawer robustness */
function openSlideDrawer(id){
  const el=document.getElementById(id);
  let b=document.getElementById('drawerBackdrop');
  if(!b){
    b=document.createElement('div');
    b.id='drawerBackdrop';
    b.className='drawer-backdrop';
    b.onclick=function(){ closeSlideDrawer(id); };
    document.body.appendChild(b);
  }
  if(el){
    el.classList.add('active');
    b.classList.add('active');
    if(window.gsap){
      gsap.fromTo(el,{x:60,opacity:0},{x:0,opacity:1,duration:.32,ease:'power3.out'});
    }
  }
}
function closeSlideDrawer(id){
  const el=document.getElementById(id);
  const b=document.getElementById('drawerBackdrop');
  if(el) el.classList.remove('active');
  if(b) b.classList.remove('active');
}
function openModal(id){
  const el=document.getElementById(id);
  if(el){
    el.classList.add('active');
    if(window.gsap){
      const panel=el.querySelector('.modal-panel');
      if(panel) gsap.fromTo(panel,{y:30,opacity:0,scale:.97},{y:0,opacity:1,scale:1,duration:.28,ease:'power3.out'});
    }
  }
}
function closeModal(id){
  const el=document.getElementById(id);
  if(el) el.classList.remove('active');
}


/* MVP 3A.5.2 live countdown */
function updateCountdownPills(){
  document.querySelectorAll('.countdown-pill[data-deadline]').forEach(function(el){
    const raw = el.dataset.deadline || '';
    if(!raw){ el.textContent='-'; return; }
    const deadline = new Date(raw.replace(' ', 'T')).getTime();
    if(!deadline){ el.textContent='-'; return; }
    const diff = deadline - Date.now();
    el.classList.remove('green','orange','red');
    if(diff <= 0){ el.textContent='Quá hạn'; el.classList.add('red'); return; }
    if(diff < 86400000){
      const hours = Math.max(1, Math.ceil(diff / 3600000));
      el.textContent = 'Còn ' + hours + ' giờ';
      el.classList.add(hours <= 8 ? 'red' : 'orange');
      return;
    }
    const days = Math.max(1, Math.ceil(diff / 86400000));
    el.textContent = 'Còn ' + days + ' ngày';
    el.classList.add(days <= 2 ? 'red' : (days <= 4 ? 'orange' : 'green'));
  });
}
document.addEventListener('DOMContentLoaded', function(){
  updateCountdownPills();
  setInterval(updateCountdownPills, 60000);
  if(window.gsap){
    gsap.set('.card,.stat',{opacity:1, clearProps:'filter'});
  }
});


/* MVP 3A.5.3 Sound cues */
function playTone(type){
  try{
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.frequency.value = type === 'checkin' ? 660 : 880;
    gain.gain.setValueAtTime(0.0001, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.08, ctx.currentTime + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.22);
    osc.start(ctx.currentTime);
    osc.stop(ctx.currentTime + 0.24);
  }catch(e){}
}
/* Sound hotfix: do not play sound for generic clicks/toasts. Notification V2 and Pomodoro handle sound explicitly. */


/* MVP 3A.5.4 robust sound unlock */
window.__audioUnlocked = false;
function unlockAudio(){
  if(window.__audioUnlocked) return;
  try{
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    gain.gain.value = 0.00001;
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(); osc.stop(ctx.currentTime + 0.01);
    window.__audioUnlocked = true;
  }catch(e){}
}
document.addEventListener('click', unlockAudio, {once:true});
document.addEventListener('touchstart', unlockAudio, {once:true});





/* MVP 3A.5.5 background notification polling */
let lastNotificationId = Number(localStorage.getItem('lastNotificationId') || '0');
function pollNotifications(){
  fetch('notification_poll.php?since=' + lastNotificationId, {credentials:'same-origin'})
    .then(r=>r.json())
    .then(data=>{
      if(!data.notifications) return;
      data.notifications.reverse().forEach(n=>{
        if(Number(n.id) > lastNotificationId) lastNotificationId = Number(n.id);
        if(window.showToast) showToast(n.title, n.message, n.link);
      });
      localStorage.setItem('lastNotificationId', String(lastNotificationId));
    })
    .catch(()=>{});
}
/* Legacy notification poll disabled: using Notification V2 only. */


/* MVP 3A.5.5.2 floating chatbox + notification windows */
let floatingChatLastId = Number(localStorage.getItem('floatingChatLastId') || '0');
let floatingNotificationLastId = Number(localStorage.getItem('floatingNotificationLastId') || '0');

function toggleFloatingChat(){
  const el=document.getElementById('floatingChatWindow');
  if(!el) return;
  el.classList.toggle('active');
  if(el.classList.contains('active')) {
    pollFloatingChat(true);
    if(window.gsap) gsap.fromTo(el,{y:18,scale:.96,opacity:0},{y:0,scale:1,opacity:1,duration:.25,ease:'power3.out'});
  }
}

function toggleNotificationPanel(){
  const el=document.getElementById('notificationPanel');
  if(!el) return;
  el.classList.toggle('active');
  if(el.classList.contains('active')) {
    const dot=document.getElementById('floatingNotifyDot');
    if(dot) dot.classList.remove('active');
    if(window.gsap) gsap.fromTo(el,{y:18,scale:.96,opacity:0},{y:0,scale:1,opacity:1,duration:.25,ease:'power3.out'});
  }
}

function appendFloatingChatMessage(m, me){
  const box=document.getElementById('floatingChatMessages');
  if(!box) return;
  const item=document.createElement('div');
  item.className='floating-chat-message ' + (Number(m.user_id)===Number(me) ? 'mine' : '');
  item.innerHTML='<div class="bubble"><b>'+escapeHtml(m.name)+'</b><p>'+escapeHtml(m.message)+'</p><span>'+escapeHtml(m.created_at)+'</span></div>';
  box.appendChild(item);
  box.scrollTop=box.scrollHeight;
}

function pollFloatingChat(force=false){
  fetch('chat_poll.php?since=' + (force ? 0 : floatingChatLastId), {credentials:'same-origin'})
    .then(r=>r.json())
    .then(data=>{
      if(!data.messages) return;
      const box=document.getElementById('floatingChatMessages');
      if(force && box) box.innerHTML='';
      data.messages.forEach(m=>{
        floatingChatLastId=Math.max(floatingChatLastId, Number(m.id));
        appendFloatingChatMessage(m, data.me);
      });
      localStorage.setItem('floatingChatLastId', String(floatingChatLastId));
    }).catch(()=>{});
}

function appendNotificationPanelItem(n){
  const list=document.getElementById('notificationPanelList');
  if(!list) return;
  const empty=list.querySelector('.muted');
  if(empty) empty.remove();
  const icon = n.type==='chat' ? '💬' : (n.type==='payroll' ? '💵' : (n.type==='help' ? '🆘' : '🔔'));
  const item=document.createElement('div');
  item.className='notification-pop-item';
  item.innerHTML='<div class="notification-pop-icon">'+icon+'</div><div><b>'+escapeHtml(n.title)+'</b><p>'+escapeHtml(n.message)+'</p>'+(n.link?'<a href="'+escapeHtml(n.link)+'">Mở ngay</a>':'')+'</div>';
  list.prepend(item);
}

function pollFloatingNotifications(){
  fetch('notification_poll.php?since=' + floatingNotificationLastId, {credentials:'same-origin'})
    .then(r=>r.json())
    .then(data=>{
      if(!data.notifications) return;
      data.notifications.forEach(n=>{
        floatingNotificationLastId=Math.max(floatingNotificationLastId, Number(n.id));
        appendNotificationPanelItem(n);
        const dot=document.getElementById('floatingNotifyDot');
        if(dot) dot.classList.add('active');
        const panel=document.getElementById('notificationPanel');
        if(panel && !panel.classList.contains('active')) panel.classList.add('active');
        if(window.showToast) showToast(n.title,n.message,n.link);
        if(window.playTone) playTone('notification');
      });
      localStorage.setItem('floatingNotificationLastId', String(floatingNotificationLastId));
    }).catch(()=>{});
}

function escapeHtml(str){
  return String(str || '').replace(/[&<>"']/g, function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m];});
}

document.addEventListener('DOMContentLoaded', function(){
  pollFloatingChat(true);
  // pollFloatingNotifications disabled: header notification popover + V2 toast only.
  setInterval(function(){ pollFloatingChat(false); }, 12000);

  const form=document.getElementById('floatingChatForm');
  if(form){
    form.addEventListener('submit', function(e){
      e.preventDefault();
      const input=document.getElementById('floatingChatInput');
      const message=(input.value || '').trim();
      if(!message) return;
      const fd=new FormData();
      fd.append('message', message);
      fetch('chat_send.php',{method:'POST',body:fd,credentials:'same-origin'})
        .then(r=>r.json())
        .then(data=>{
          if(data.ok){
            input.value='';
            setTimeout(function(){ pollFloatingChat(false); }, 250);
            if(window.playTone) playTone('notification');
          }
        }).catch(()=>{});
    });
  }
});


/* Sprint 3V-A Notification Popup V2 */
function motivePlaySound(type){
  try{
    if(window.__motiveMuteSound) return;
    const map={notify:'soundNotify',ding:'soundDing',success:'soundSuccess',mention:'soundNotify',approval:'soundSuccess',help:'soundDing'};
    const id=map[type] || 'soundNotify';
    const el=document.getElementById(id);
    if(el){ el.currentTime=0; el.play().catch(()=>{}); return; }
  }catch(e){}
  if(window.playTone) playTone(type==='ding'?'checkin':'notification');
}
function headerNotificationIcon(type){
  return type==='task' ? '✅' : (type==='chat' ? '💬' : (type==='help' ? '🆘' : (type==='payroll' ? '💸' : '🔔')));
}
function appendHeaderNotification(n){
  const list=document.getElementById('headerNotifyList');
  if(!list) return;
  const empty=list.querySelector('.muted'); if(empty) empty.remove();
  const a=document.createElement('a');
  a.className='notify-pop-card unread fresh';
  a.href=n.link || 'app.php?page=notifications';
  a.innerHTML='<span>'+headerNotificationIcon(n.type)+'</span><div><b>'+escapeHtml(n.title)+'</b><small>'+escapeHtml(n.message||n.content||'')+'</small></div>';
  list.prepend(a);
  Array.from(list.querySelectorAll('.notify-pop-card')).slice(6).forEach(x=>x.remove());
  const btn=document.querySelector('.header-notify-btn');
  if(btn && !btn.querySelector('em')) btn.insertAdjacentHTML('beforeend','<em>1</em>');
}
function motiveToast(n){
  const stack=document.getElementById('motiveToastStack') || document.getElementById('toastStack');
  if(!stack) return;
  const item=document.createElement('div');
  const level=n.level || n.type || 'info';
  item.className='motive-toast trendy '+level;
  const icon = headerNotificationIcon(n.type);
  item.innerHTML='<div class="motive-toast-icon">'+icon+'</div><div class="motive-toast-content"><b>'+escapeHtml(n.title)+'</b><p>'+escapeHtml(n.message||n.content||'')+'</p>'+(n.link?'<a href="'+escapeHtml(n.link)+'">Mở ngay</a>':'')+'</div><button type="button" aria-label="Đóng">×</button>';
  item.querySelector('button').onclick=()=>item.remove();
  stack.prepend(item);
  setTimeout(()=>item.classList.add('show'),30);
  setTimeout(()=>{item.classList.remove('show');setTimeout(()=>item.remove(),300)},6200);
}
let motiveLastPopupNotificationId = Number(localStorage.getItem('motiveLastPopupNotificationId') || '0');
function pollNotificationV2(){
  fetch('notification_poll.php?since='+motiveLastPopupNotificationId,{credentials:'same-origin'})
    .then(r=>r.json())
    .then(data=>{
      const pref=data.preferences || {};
      window.__motiveMuteSound = Number(pref.mute_sound||0)===1;
      if(!data.notifications) return;
      data.notifications.forEach(n=>{
        motiveLastPopupNotificationId=Math.max(motiveLastPopupNotificationId,Number(n.id));
        appendHeaderNotification(n);
        if(Number(pref.mute_notification||0)!==1) motiveToast(n);
        if(Number(pref.mute_sound||0)!==1) motivePlaySound(n.sound || n.type || 'notify');
      });
      localStorage.setItem('motiveLastPopupNotificationId',String(motiveLastPopupNotificationId));
    }).catch(()=>{});
}
document.addEventListener('DOMContentLoaded',function(){
  setTimeout(pollNotificationV2,1600);
  setInterval(pollNotificationV2,15000);
});

function toggleAccountMenu(){
  const el=document.getElementById('accountDropdown');
  if(el) el.classList.toggle('active');
}
document.addEventListener('click',function(e){
  const menu=document.querySelector('.account-menu');
  const dd=document.getElementById('accountDropdown');
  if(dd && menu && !menu.contains(e.target)) dd.classList.remove('active');
});

function formatMoneyInputs(){
  document.querySelectorAll('.money-input').forEach(input=>{
    const clean = v => String(v||'').replace(/[^\d]/g,'');
    const fmt = v => clean(v).replace(/\B(?=(\d{3})+(?!\d))/g,'.');
    input.value = fmt(input.value);
    input.addEventListener('input',()=>{ input.value = fmt(input.value); });
  });
}
document.addEventListener('DOMContentLoaded', formatMoneyInputs);

function toggleQuoteSelectAll(master){
  document.querySelectorAll('.quote-check').forEach(cb=>{ cb.checked = master.checked; });
  updateBulkCount();
}
function updateBulkCount(){
  const count = document.querySelectorAll('.quote-check:checked').length;
  const target = document.getElementById('bulkCount');
  if(target) target.textContent = count + ' đã chọn';
}
function confirmBulkQuote(){
  const count = document.querySelectorAll('.quote-check:checked').length;
  if(count <= 0){
    alert('Bạn chưa chọn báo giá nào.');
    return false;
  }
  const action = document.getElementById('bulkAction')?.value || '';
  if(action === 'delete') return confirm('Xóa ' + count + ' báo giá đã chọn? Hành động này không thể hoàn tác.');
  return confirm('Áp dụng thao tác cho ' + count + ' báo giá đã chọn?');
}

document.addEventListener('DOMContentLoaded', function(){
  document.querySelectorAll('.quote-check-wrap').forEach(label=>{
    label.addEventListener('click', function(e){
      e.stopPropagation();
      setTimeout(updateBulkCount, 20);
    });
  });
});


/* Project Operation Task Detail Drawer — Editable */
function openTaskDetailDrawer(data){
  const drawer=document.getElementById('taskDetailDrawer');
  const backdrop=document.getElementById('taskDetailBackdrop');
  if(!drawer || !backdrop) return;

  const setVal=(id,val)=>{ const el=document.getElementById(id); if(el) el.value=val || ''; };
  setVal('tdTaskId',data.id);
  setVal('tdCommentTaskId',data.id);
  setVal('tdTitleInput',data.title);
  setVal('tdBriefInput',data.brief);
  setVal('tdDescInput',data.desc);
  setVal('tdDeadlineInput',data.deadline);
  setVal('tdRefInput',data.reference);
  setVal('tdFileInput',data.file);

  const assignee=document.getElementById('tdAssigneeSelect');
  if(assignee) assignee.value=data.assigneeId || '';

  const status=document.getElementById('tdStatusSelect');
  if(status) status.value=data.status || 'Todo';

  const priority=document.getElementById('tdPrioritySelect');
  if(priority) priority.value=data.priority || 'Quan trọng';

  const full=document.getElementById('tdFull');
  if(full) full.href='app.php?page=task_detail&id='+data.id;

  drawer.classList.add('open');
  backdrop.classList.add('open');
  document.body.classList.add('dialog-lock');
  document.body.classList.add('task-drawer-open');
}
function closeTaskDetailDrawer(){
  const drawer=document.getElementById('taskDetailDrawer');
  const backdrop=document.getElementById('taskDetailBackdrop');
  if(drawer) drawer.classList.remove('open');
  if(backdrop) backdrop.classList.remove('open');
  document.body.classList.remove('dialog-lock');
  document.body.classList.remove('task-drawer-open');
}
document.addEventListener('click', function(e){
  const btn=e.target.closest('.task-detail-trigger');
  if(!btn) return;
  openTaskDetailDrawer({
    id:btn.dataset.taskId,
    title:btn.dataset.taskTitle,
    brief:btn.dataset.taskBrief,
    desc:btn.dataset.taskDesc,
    assignee:btn.dataset.taskAssignee,
    assigneeId:btn.dataset.taskAssigneeId,
    deadline:btn.dataset.taskDeadline,
    status:btn.dataset.taskStatus,
    priority:btn.dataset.taskPriority,
    reference:btn.dataset.taskReference,
    file:btn.dataset.taskFile
  });
});
document.addEventListener('keydown', function(e){
  if(e.key==='Escape') closeTaskDetailDrawer();
});


/* Amazing Gud Chop Delight + Drawer Comments/Avatar */
function updateDrawerAssigneePreview(){
  const sel=document.getElementById('tdAssigneeSelect');
  const box=document.getElementById('tdAssigneePreview');
  if(!sel || !box) return;
  const opt=sel.options[sel.selectedIndex];
  const name=(opt && (opt.dataset.name || opt.textContent)) || 'Chưa giao';
  const avatar=(opt && opt.dataset.avatar) || '';
  box.innerHTML = avatar
    ? '<span class="avatar small"><img src="'+avatar+'" alt=""></span><b>'+name+'</b>'
    : '<span class="avatar small">'+(name.trim().charAt(0)||'?')+'</span><b>'+name+'</b>';
}
document.addEventListener('change', function(e){
  if(e.target && e.target.id==='tdAssigneeSelect') updateDrawerAssigneePreview();
});
function renderDrawerComments(taskId){
  const target=document.getElementById('tdDrawerComments');
  const source=document.getElementById('taskComments'+taskId);
  if(target) target.innerHTML = source ? source.innerHTML : '<p class="muted">Chưa có bình luận.</p>';
}
function showAmazingGudChop(){
  const wrap=document.createElement('div');
  wrap.className='amazing-gudchop';
  wrap.innerHTML='<div class="confetti"></div><strong>Amazing Gúd chóp ✨</strong>';
  document.body.appendChild(wrap);
  setTimeout(()=>wrap.classList.add('show'),30);
  setTimeout(()=>wrap.remove(),2300);
}
document.addEventListener('DOMContentLoaded', function(){
  const params=new URLSearchParams(window.location.search);
  if(params.get('amazing')==='1') showAmazingGudChop();
});


/* Universal Amazing Gud Chop */
function showAmazingGudChop(){
  const wrap=document.createElement('div');
  wrap.className='amazing-gudchop';
  wrap.innerHTML='<div class="confetti"></div><strong>Amazing Gúd chóp ✨</strong>';
  document.body.appendChild(wrap);
  setTimeout(()=>wrap.classList.add('show'),30);
  setTimeout(()=>wrap.remove(),2300);
}
document.addEventListener('DOMContentLoaded', function(){
  const params=new URLSearchParams(window.location.search);
  if(params.get('amazing')==='1') showAmazingGudChop();
});


/* Restore Workspace Prairie Time */
function applyWorkspacePrairieTime(){
  const board=document.getElementById('workspacePrairie');
  if(!board) return;
  const h=new Date().getHours();
  let phase='morning';
  if(h>=5 && h<11) phase='morning';
  else if(h>=11 && h<16) phase='noon';
  else if(h>=16 && h<19) phase='sunset';
  else phase='night';
  board.dataset.timePhase=phase;
}
document.addEventListener('DOMContentLoaded', applyWorkspacePrairieTime);
setInterval(applyWorkspacePrairieTime, 60000);


/* Header Search Overlay + AJAX Quick Done */
function openGlobalSearchOverlay(){
  const ov=document.getElementById('globalSearchOverlay');
  const input=document.getElementById('globalSearchInput');
  if(!ov) return;
  ov.classList.add('open');
  document.body.classList.add('dialog-lock');
  setTimeout(()=>input && input.focus(),60);
}
function closeGlobalSearchOverlay(){
  const ov=document.getElementById('globalSearchOverlay');
  if(ov) ov.classList.remove('open');
  document.body.classList.remove('dialog-lock');
}
function showAmazingGudChop(){
  const old=document.querySelector('.amazing-gudchop');
  if(old) old.remove();
  const wrap=document.createElement('div');
  wrap.className='amazing-gudchop';
  wrap.innerHTML='<div class="confetti"></div><strong>Amazing Gúd chóp ✨</strong>';
  document.body.appendChild(wrap);
  setTimeout(()=>wrap.classList.add('show'),20);
  setTimeout(()=>wrap.remove(),1650);
}
document.addEventListener('keydown', function(e){
  if(e.key==='Escape') closeGlobalSearchOverlay();
  if((e.metaKey || e.ctrlKey) && e.key.toLowerCase()==='k'){
    e.preventDefault();
    openGlobalSearchOverlay();
  }
});
document.addEventListener('click', function(e){
  const tick=e.target.closest('.js-quick-done');
  if(!tick) return;
  e.preventDefault();
  const row=tick.closest('tr') || tick.closest('.private-strip-item') || tick.closest('.private-task-row');
  const taskId=tick.dataset.taskId;
  if(row) row.classList.add('task-completing');
  fetch('app.php?page=tasks', {
    method:'POST',
    headers:{'Content-Type':'application/x-www-form-urlencoded'},
    body:'quick_done_ajax=1&task_id='+encodeURIComponent(taskId)
  }).then(r=>r.json()).then(data=>{
    if(data && data.ok){
      tick.classList.add('done');
      tick.classList.remove('js-quick-done');
      tick.innerHTML='✓';
      if(row) row.classList.add('task-is-done');
      showAmazingGudChop();
      setTimeout(()=>{ if(row) row.remove(); },900);
    }else{
      window.location.href=tick.href;
    }
  }).catch(()=>{ window.location.href=tick.href; });
});

/* Quotation V3 Bulk Toolbar */
(function(){
  const oldUpdate=window.updateBulkCount;
  window.updateBulkCount=function(){
    const checks=document.querySelectorAll('.quote-check:checked');
    const count=document.getElementById('bulkCount');
    const toolbar=document.getElementById('quoteBulkToolbar');
    if(count) count.textContent=checks.length+' đã chọn';
    if(toolbar) toolbar.classList.toggle('active', checks.length>0);
    if(typeof oldUpdate==='function') try{ oldUpdate(); }catch(e){}
  }
  window.toggleQuoteSelectAll=function(el){
    document.querySelectorAll('.quote-check').forEach(c=>c.checked=el.checked);
    window.updateBulkCount();
  }
})();

/* UX patch 2026-06-13: collapsible category groups */
function toggleNavGroup(btn){
  const group = btn && btn.closest('.nav-group');
  if(!group) return;
  group.classList.toggle('collapsed');
  btn.setAttribute('aria-expanded', group.classList.contains('collapsed') ? 'false' : 'true');
  try{
    const shell = group.closest('.admin-sidebar') ? 'admin' : 'workspace';
    const label = (btn.querySelector('span')?.textContent || '').trim();
    localStorage.setItem('navGroupCollapsed:'+shell+':'+label, group.classList.contains('collapsed') ? '1' : '0');
  }catch(e){}
}
document.addEventListener('DOMContentLoaded',function(){
  document.querySelectorAll('.nav-collapse-trigger').forEach(function(btn){
    try{
      const group = btn.closest('.nav-group');
      const shell = group.closest('.admin-sidebar') ? 'admin' : 'workspace';
      const label = (btn.querySelector('span')?.textContent || '').trim();
      if(localStorage.getItem('navGroupCollapsed:'+shell+':'+label)==='1'){
        group.classList.add('collapsed');
        btn.setAttribute('aria-expanded','false');
      }
    }catch(e){}
    function toggleMobileMenu() {
  const drawer = document.getElementById('mobileDrawer');
  if (drawer) drawer.classList.toggle('active');
}
  });
});

/* Workspace V4 — focus popup + notification hard guard */
window.__shownToastKeys = window.__shownToastKeys || new Set();
(function(){
  const originalShowToast = window.showToast;
  window.showToast = function(title,msg,link){
    const key = String(title||'')+'|'+String(msg||'')+'|'+String(link||'');
    if(window.__shownToastKeys.has(key)) return;
    window.__shownToastKeys.add(key);
    const current = document.querySelectorAll('.toast,.motive-toast').length;
    if(current >= 3) return;
    if(typeof originalShowToast === 'function') originalShowToast(title,msg,link);
  };
  const originalMotiveToast = window.motiveToast;
  window.motiveToast = function(n){
    const key = String(n && n.id ? n.id : '')+'|'+String(n && n.title ? n.title : '')+'|'+String(n && (n.message||n.content) ? (n.message||n.content) : '');
    if(window.__shownToastKeys.has(key)) return;
    window.__shownToastKeys.add(key);
    const current = document.querySelectorAll('.toast,.motive-toast').length;
    if(current >= 3) return;
    if(typeof originalMotiveToast === 'function') originalMotiveToast(n);
  };
})();
function focusTickTock(){
  try{
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    let t = ctx.currentTime;
    [0, .18, .36].forEach(function(offset, i){
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type='square';
      osc.frequency.value = i % 2 ? 980 : 760;
      gain.gain.setValueAtTime(0.0001, t + offset);
      gain.gain.exponentialRampToValueAtTime(0.045, t + offset + .01);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + offset + .085);
      osc.connect(gain); gain.connect(ctx.destination);
      osc.start(t + offset); osc.stop(t + offset + .09);
    });
  }catch(e){}
}
function loadFocusStateV4(){
  let state={mode:25,left:25*60,running:false,endAt:0};
  try{ state=Object.assign(state, JSON.parse(localStorage.getItem('focusV4State')||'{}')); }catch(e){}
  if(state.running && state.endAt){
    state.left=Math.max(0, Math.round((Number(state.endAt)-Date.now())/1000));
    if(state.left<=0){ state.running=false; state.endAt=0; }
  }
  window.__focusV4Mode=Number(state.mode||25);
  window.__focusV4Left=Number(state.left||window.__focusV4Mode*60);
  window.__focusV4Running=!!state.running;
  window.__focusV4EndAt=Number(state.endAt||0);
}
function saveFocusStateV4(){
  try{ localStorage.setItem('focusV4State', JSON.stringify({mode:window.__focusV4Mode||25,left:window.__focusV4Left||0,running:!!window.__focusV4Running,endAt:window.__focusV4EndAt||0})); }catch(e){}
}
function openFocusPopup(){
  loadFocusStateV4();
  renderFocusV4();
  focusTickTock();
  const el=document.getElementById('focusPopupV4');
  if(el){ el.classList.add('active'); el.setAttribute('aria-hidden','false'); }
}
function closeFocusPopup(){
  const el=document.getElementById('focusPopupV4');
  if(el){ el.classList.remove('active'); el.setAttribute('aria-hidden','true'); }
}
window.__focusV4Interval = null;
loadFocusStateV4();
function renderFocusV4(){
  const el=document.getElementById('focusTimeV4');
  if(!el) return;
  if(window.__focusV4Running && window.__focusV4EndAt){
    window.__focusV4Left=Math.max(0, Math.round((window.__focusV4EndAt-Date.now())/1000));
  }
  const m=Math.floor(window.__focusV4Left/60), s=window.__focusV4Left%60;
  el.textContent=String(m).padStart(2,'0')+':'+String(s).padStart(2,'0');
  document.querySelectorAll('[data-focus-minutes]').forEach(function(btn){btn.classList.toggle('active', Number(btn.dataset.focusMinutes)===Number(window.__focusV4Mode||25));});
  const startBtn=document.getElementById('focusStartBtnV4');
  if(startBtn) startBtn.textContent=window.__focusV4Running ? 'Đang chạy' : '▶ Bắt đầu';
  saveFocusStateV4();
}
function startFocusV4(){
  focusTickTock();
  if(window.__focusV4Running) return;
  window.__focusV4Running=true;
  window.__focusV4EndAt=Date.now()+(window.__focusV4Left||((window.__focusV4Mode||25)*60))*1000;
  if(window.__focusV4Interval) clearInterval(window.__focusV4Interval);
  window.__focusV4Interval=setInterval(function(){
    renderFocusV4();
    if(window.__focusV4Left<=0){
      clearInterval(window.__focusV4Interval); window.__focusV4Interval=null; window.__focusV4Running=false; window.__focusV4EndAt=0; saveFocusStateV4();
      if(window.showToast) showToast('Focus hoàn thành','Pomodoro đã xong.','');
    }
  },1000);
  renderFocusV4();
}
function pauseFocusV4(){
  if(window.__focusV4Interval) clearInterval(window.__focusV4Interval);
  window.__focusV4Interval=null; window.__focusV4Running=false; window.__focusV4EndAt=0; renderFocusV4();
}
function resetFocusV4(){
  if(window.__focusV4Interval) clearInterval(window.__focusV4Interval);
  window.__focusV4Interval=null; window.__focusV4Running=false; window.__focusV4EndAt=0; window.__focusV4Left=(window.__focusV4Mode||25)*60; renderFocusV4();
}
document.addEventListener('click', function(e){
  const btn=e.target.closest('[data-focus-minutes]');
  if(!btn) return;
  const minutes=Number(btn.dataset.focusMinutes||25);
  window.__focusV4Mode=minutes;
  if(!window.__focusV4Running) window.__focusV4Left=minutes*60;
  renderFocusV4();
});
if(window.__focusV4Running){ window.__focusV4Running=false; startFocusV4(); }

function initCommandTabs(){
  document.querySelectorAll('[data-command-tab]').forEach(function(btn){
    btn.addEventListener('click', function(){
      const key=btn.dataset.commandTab;
      document.querySelectorAll('[data-command-tab]').forEach(function(b){ b.classList.toggle('active', b===btn); });
      document.querySelectorAll('[data-command-panel]').forEach(function(p){ p.classList.toggle('active', p.dataset.commandPanel===key); });
      try{ localStorage.setItem('workspaceCommandTab', key); }catch(e){}
      if(typeof updateCountdownPills==='function') updateCountdownPills();
    });
  });
  try{
    const key=localStorage.getItem('workspaceCommandTab');
    const btn=key && document.querySelector('[data-command-tab="'+key+'"]');
    if(btn) btn.click();
  }catch(e){}
}
document.addEventListener('DOMContentLoaded', initCommandTabs);

function openMobileSidebar(){ const shell=document.getElementById('appShell'); const ov=document.querySelector('.mobile-sidebar-overlay'); if(shell) shell.classList.add('mobile-open'); if(ov) ov.classList.add('active'); document.body.classList.add('mobile-menu-lock'); }
function closeMobileSidebar(){ const shell=document.getElementById('appShell'); const ov=document.querySelector('.mobile-sidebar-overlay'); if(shell) shell.classList.remove('mobile-open'); if(ov) ov.classList.remove('active'); document.body.classList.remove('mobile-menu-lock'); }
function toggleMobileMenu(){ const shell=document.getElementById('appShell'); if(shell && shell.classList.contains('mobile-open')) closeMobileSidebar(); else openMobileSidebar(); }
document.addEventListener('DOMContentLoaded',renderFocusV4);


/* Header Notification Popover + Workspace Task Edit Popup */
function toggleHeaderNotifications(){
  const pop=document.getElementById('headerNotifyPopover');
  if(pop) pop.classList.toggle('active');
}
document.addEventListener('click',function(e){
  const wrap=document.querySelector('.header-notify-menu');
  const pop=document.getElementById('headerNotifyPopover');
  if(wrap && pop && !wrap.contains(e.target)) pop.classList.remove('active');
});
function toDatetimeLocal(v){
  if(!v) return '';
  return String(v).replace(' ','T').slice(0,16);
}
function openWorkspaceTaskEdit(data){
  const set=(id,val)=>{ const el=document.getElementById(id); if(el) el.value=val || ''; };
  set('weTaskId',data.id);
  set('weTaskTitle',data.title);
  set('weTaskBrief',data.brief);
  set('weTaskDescription',data.description);
  set('weTaskDeadline',toDatetimeLocal(data.deadline));
  set('weTaskPriority',data.priority || 'Quan trọng');
  set('weTaskStatus',data.status || 'Todo');
  openModal('workspaceTaskEditModal');
}

/* V4.1 Pomodoro reward + plant + Mcoin */
function showFocusReward(amount){
  const plant=document.getElementById('focusPlantV4');
  if(plant){ plant.textContent='🌳'; plant.classList.add('grown'); }
  const old=document.querySelector('.focus-complete-toast'); if(old) old.remove();
  const t=document.createElement('div');
  t.className='focus-complete-toast';
  t.innerHTML='<span>🌳</span><div><b>Cây Focus đã lớn!</b><br><small>+'+(amount||1200).toLocaleString('vi-VN')+' Mcoin</small></div>';
  document.body.appendChild(t);
  setTimeout(()=>t.remove(),4200);
}
function awardPomodoroVcoin(){
  const session='pomo_'+Date.now()+'_'+Math.random().toString(36).slice(2,7);
  const fd=new FormData(); fd.append('type','pomodoro'); fd.append('session',session);
  fetch('mcoin_award.php',{method:'POST',body:fd,credentials:'same-origin'})
    .then(r=>r.json()).then(data=>{ showFocusReward(data && data.amount ? data.amount : 1200); })
    .catch(()=>showFocusReward(1200));
}
(function(){
  const oldStart=window.startFocusV4;
  if(typeof oldStart==='function'){
    window.startFocusV4=function(){
      focusTickTock();
      if(window.__focusV4Running) return;
      window.__focusV4Running=true;
      window.__focusV4EndAt=Date.now()+(window.__focusV4Left||((window.__focusV4Mode||25)*60))*1000;
      if(window.__focusV4Interval) clearInterval(window.__focusV4Interval);
      window.__focusV4Interval=setInterval(function(){
        renderFocusV4();
        if(window.__focusV4Left<=0){
          clearInterval(window.__focusV4Interval); window.__focusV4Interval=null; window.__focusV4Running=false; window.__focusV4EndAt=0; saveFocusStateV4();
          awardPomodoroVcoin();
          if(window.showToast) showToast('Focus hoàn thành','Bạn đã trồng được 1 cây Focus 🌳','');
        }
      },1000);
      renderFocusV4();
    }
  }
  const oldReset=window.resetFocusV4;
  window.resetFocusV4=function(){
    if(oldReset) oldReset();
    const plant=document.getElementById('focusPlantV4'); if(plant){ plant.textContent='🌱'; plant.classList.remove('grown'); }
  }
})();


/* Motive Rewards OS helpers */
function openNeedHelpModalFromTask(){
  const id = document.getElementById('weTaskId')?.value || 0;
  const target = document.getElementById('needHelpTaskId');
  if(target) target.value = id;
  openModal('workspaceNeedHelpModal');
}
function showMcoinReward(amount, reason){
  const box=document.createElement('div');
  box.className='mcoin-reward-toast';
  box.innerHTML='<div class="coin-stack">🪙</div><div><b>+'+Number(amount||0).toLocaleString('vi-VN')+' Mcoin</b><span>'+escapeHtml(reason||'Bạn vừa nhận thưởng')+'</span></div>';
  document.body.appendChild(box);
  setTimeout(()=>box.classList.add('show'),20);
  setTimeout(()=>box.remove(),3600);
}

/* === Focus Mini Timer Bar v4 Patch === */
(function(){
  function fmt(sec){ sec=Math.max(0,Math.round(Number(sec)||0)); const m=Math.floor(sec/60), s=sec%60; return String(m).padStart(2,'0')+':'+String(s).padStart(2,'0'); }
  function getModeName(){ const m=Number(window.__focusV4Mode||25); return m===5?'Short Break':(m===15?'Long Break':'Focus Mode'); }
  function ensureState(){
    if(typeof loadFocusStateV4==='function') loadFocusStateV4();
    window.__focusV4Mode=Number(window.__focusV4Mode||25);
    window.__focusV4Left=Number(window.__focusV4Left||window.__focusV4Mode*60);
    if(window.__focusV4Running && window.__focusV4EndAt){ window.__focusV4Left=Math.max(0,Math.round((Number(window.__focusV4EndAt)-Date.now())/1000)); }
  }
  function notifyDone(){
    try{ if(window.showToast) showToast('Focus hoàn thành','Bạn đã hoàn thành một phiên Focus. Nghỉ một chút nhé.',''); }catch(e){}
    try{ const a=document.getElementById('soundDing')||document.getElementById('soundSuccess'); if(a){ a.currentTime=0; a.play().catch(function(){}); } }catch(e){}
    try{
      if('Notification' in window){
        if(Notification.permission==='granted') new Notification('Focus session completed',{body:'Take a break and keep moving forward.'});
        else if(Notification.permission!=='denied') Notification.requestPermission();
      }
    }catch(e){}
  }
  function renderMini(){
    ensureState();
    const mini=document.getElementById('focusMiniBarV4'); if(!mini) return;
    const total=Math.max(1,Number(window.__focusV4Mode||25)*60);
    const left=Math.max(0,Number(window.__focusV4Left||0));
    const active=!!window.__focusV4Running || left<total;
    mini.classList.toggle('active', active);
    document.body.classList.toggle('focus-mini-active', active);
    const t=fmt(left);
    const popupTime=document.getElementById('focusTimeV4'); if(popupTime) popupTime.textContent=t;
    const miniTime=document.getElementById('focusMiniTimeV4'); if(miniTime) miniTime.textContent=t;
    const title=document.getElementById('focusMiniTitleV4'); if(title) title.textContent=getModeName();
    const label=document.getElementById('focusMiniLabelV4'); if(label) label.textContent=(window.__focusV4Running?'Đang chạy · ':'Tạm dừng · ')+t+' remaining';
    const prog=document.getElementById('focusMiniProgressV4'); if(prog) prog.style.width=Math.min(100,Math.max(0,((total-left)/total)*100))+'%';
    document.querySelectorAll('[data-focus-minutes]').forEach(function(btn){btn.classList.toggle('active', Number(btn.dataset.focusMinutes)===Number(window.__focusV4Mode||25));});
    const startBtn=document.getElementById('focusStartBtnV4'); if(startBtn) startBtn.innerHTML=window.__focusV4Running?'<i data-lucide="timer"></i> Đang chạy':'<i data-lucide="play"></i> Bắt đầu';
    try{ if(typeof saveFocusStateV4==='function') saveFocusStateV4(); }catch(e){}
    try{ if(window.lucide) lucide.createIcons({attrs:{'stroke-width':1.8}}); }catch(e){}
  }
  function tick(){
    if(window.__focusV4TimerMini) clearInterval(window.__focusV4TimerMini);
    window.__focusV4TimerMini=setInterval(function(){
      renderMini();
      if(window.__focusV4Running && Number(window.__focusV4Left||0)<=0){
        window.__focusV4Running=false; window.__focusV4EndAt=0; window.__focusV4Left=0;
        try{ if(typeof saveFocusStateV4==='function') saveFocusStateV4(); }catch(e){}
        clearInterval(window.__focusV4TimerMini); window.__focusV4TimerMini=null;
        renderMini(); notifyDone();
      }
    },1000);
  }
  window.renderFocusV4=function(){ renderMini(); };
  window.startFocusV4=function(){
    ensureState();
    if(Number(window.__focusV4Left||0)<=0) window.__focusV4Left=Number(window.__focusV4Mode||25)*60;
    window.__focusV4Running=true;
    window.__focusV4EndAt=Date.now()+Number(window.__focusV4Left||0)*1000;
    try{ if(typeof focusTickTock==='function') focusTickTock(); }catch(e){}
    try{ if('Notification' in window && Notification.permission==='default') Notification.requestPermission(); }catch(e){}
    renderMini(); tick();
  };
  window.pauseFocusV4=function(){ ensureState(); window.__focusV4Running=false; window.__focusV4EndAt=0; renderMini(); };
  window.resetFocusV4=function(){ ensureState(); window.__focusV4Running=false; window.__focusV4EndAt=0; window.__focusV4Left=Number(window.__focusV4Mode||25)*60; renderMini(); };
  window.finishFocusV4=function(){ window.__focusV4Running=false; window.__focusV4EndAt=0; window.__focusV4Left=0; renderMini(); notifyDone(); };
  document.addEventListener('visibilitychange',renderMini);
  window.addEventListener('storage',function(e){ if(e.key==='focusV4State') renderMini(); });
  document.addEventListener('click',function(e){
    const btn=e.target.closest('[data-focus-minutes]'); if(!btn) return;
    const minutes=Number(btn.dataset.focusMinutes||25); window.__focusV4Mode=minutes;
    if(!window.__focusV4Running) window.__focusV4Left=minutes*60;
    renderMini();
  },true);
  document.addEventListener('DOMContentLoaded',function(){ ensureState(); renderMini(); if(window.__focusV4Running) tick(); });
})();


/* === Pomodoro Glass Mini Bar V5.2 Final Override === */
(function(){
  const KEY='focusV4State';
  let timer=null;
  function $(id){ return document.getElementById(id); }
  function fmt(sec){ sec=Math.max(0, Math.ceil(Number(sec)||0)); const m=Math.floor(sec/60), s=sec%60; return String(m).padStart(2,'0')+':'+String(s).padStart(2,'0'); }
  function modeTitle(){ const m=Number(window.__focusV4Mode||25); return m===5?'Break':(m===15?'Long break':'Focus'); }
  function load(){
    let st={mode:25,left:1500,running:false,endAt:0};
    try{ st=Object.assign(st, JSON.parse(localStorage.getItem(KEY)||'{}')); }catch(e){}
    window.__focusV4Mode=Number(st.mode||25);
    window.__focusV4Left=Number(st.left||window.__focusV4Mode*60);
    window.__focusV4Running=!!st.running;
    window.__focusV4EndAt=Number(st.endAt||0);
    if(window.__focusV4Running && window.__focusV4EndAt){
      window.__focusV4Left=Math.max(0, Math.ceil((window.__focusV4EndAt-Date.now())/1000));
      if(window.__focusV4Left<=0){ window.__focusV4Running=false; window.__focusV4EndAt=0; }
    }
  }
  function save(){
    try{ localStorage.setItem(KEY, JSON.stringify({mode:window.__focusV4Mode||25,left:window.__focusV4Left||0,running:!!window.__focusV4Running,endAt:window.__focusV4EndAt||0})); }catch(e){}
  }
  function closePopup(){ const p=$('focusPopupV4'); if(p){ p.classList.remove('active'); p.setAttribute('aria-hidden','true'); } }
  function render(){
    load();
    const total=Math.max(1, Number(window.__focusV4Mode||25)*60);
    const left=Math.max(0, Number(window.__focusV4Left||0));
    const text=fmt(left);
    const popupTime=$('focusTimeV4'); if(popupTime) popupTime.textContent=text;
    const mini=$('focusMiniBarV5');
    if(mini){
      const show=!!window.__focusV4Running || left<total;
      mini.classList.toggle('active', show);
      mini.classList.toggle('paused', show && !window.__focusV4Running);
      mini.setAttribute('aria-hidden', show?'false':'true');
      document.body.classList.toggle('focus-mini-active', show);
    }
    const mt=$('focusMiniTimeV5'); if(mt) mt.textContent=text;
    const title=$('focusMiniTitleV5'); if(title) title.textContent=modeTitle();
    const prog=$('focusMiniProgressV5'); if(prog) prog.style.width=Math.min(100, Math.max(0, ((total-left)/total)*100))+'%';
    const start=$('focusStartBtnV4'); if(start) start.innerHTML=window.__focusV4Running?'<i data-lucide="timer"></i> Đang chạy':'<i data-lucide="play"></i> Bắt đầu';
    const pause=$('focusMiniPauseV5'); if(pause) pause.textContent=window.__focusV4Running?'Ⅱ':'▶';
    document.querySelectorAll('[data-focus-minutes]').forEach(function(btn){ btn.classList.toggle('active', Number(btn.dataset.focusMinutes)===Number(window.__focusV4Mode||25)); });
    try{ if(window.lucide) lucide.createIcons({attrs:{'stroke-width':1.8}}); }catch(e){}
    save();
  }
  function loop(){
    if(timer) clearInterval(timer);
    timer=setInterval(function(){
      load(); render();
      if(window.__focusV4Running && Number(window.__focusV4Left||0)<=0){
        window.__focusV4Running=false; window.__focusV4EndAt=0; window.__focusV4Left=0; save(); render(); clearInterval(timer); timer=null;
        try{ if(typeof awardPomodoroVcoin==='function') awardPomodoroVcoin(); }catch(e){}
        try{ if(window.showToast) showToast('Focus hoàn thành','Bạn đã hoàn thành một phiên Pomodoro 🌱',''); }catch(e){}
      }
    },1000);
  }
  window.renderFocusV4=render;
  window.startFocusV4=function(){
    load();
    if(Number(window.__focusV4Left||0)<=0) window.__focusV4Left=Number(window.__focusV4Mode||25)*60;
    window.__focusV4Running=true;
    window.__focusV4EndAt=Date.now()+Number(window.__focusV4Left||0)*1000;
    save(); render(); closePopup(); loop();
  };
  window.pauseFocusV4=function(){ load(); window.__focusV4Running=false; window.__focusV4EndAt=0; save(); render(); };
  window.resetFocusV4=function(){ load(); window.__focusV4Running=false; window.__focusV4EndAt=0; window.__focusV4Left=Number(window.__focusV4Mode||25)*60; save(); render(); };
  window.pauseFocusV5=function(e){ if(e) e.stopPropagation(); load(); if(window.__focusV4Running){ window.pauseFocusV4(); } else { window.startFocusV4(); } };
  window.resetFocusV5=function(e){ if(e) e.stopPropagation(); window.resetFocusV4(); };
  document.addEventListener('click',function(e){ const btn=e.target.closest('[data-focus-minutes]'); if(!btn) return; load(); window.__focusV4Mode=Number(btn.dataset.focusMinutes||25); if(!window.__focusV4Running) window.__focusV4Left=window.__focusV4Mode*60; save(); render(); },true);
  document.addEventListener('DOMContentLoaded',function(){ load(); render(); if(window.__focusV4Running) loop(); });
  window.addEventListener('storage',function(e){ if(e.key===KEY) render(); });
  document.addEventListener('visibilitychange',function(){ render(); if(window.__focusV4Running) loop(); });
})();

/* === Pomodoro Glass Mini Bar V5.3 Visibility Fix === */
(function(){
  const KEY='focusV4State';
  let timer=null;
  function $(id){ return document.getElementById(id); }
  function fmt(sec){ sec=Math.max(0,Math.ceil(Number(sec)||0)); const m=Math.floor(sec/60), s=sec%60; return String(m).padStart(2,'0')+':'+String(s).padStart(2,'0'); }
  function read(){
    let st={mode:25,left:1500,running:false,endAt:0};
    try{ st=Object.assign(st,JSON.parse(localStorage.getItem(KEY)||'{}')); }catch(e){}
    window.__focusV4Mode=Number(st.mode||window.__focusV4Mode||25);
    window.__focusV4Running=!!st.running;
    window.__focusV4EndAt=Number(st.endAt||0);
    window.__focusV4Left=Number(st.left||window.__focusV4Left||window.__focusV4Mode*60);
    if(window.__focusV4Running && window.__focusV4EndAt){
      window.__focusV4Left=Math.max(0,Math.ceil((window.__focusV4EndAt-Date.now())/1000));
      if(window.__focusV4Left<=0){ window.__focusV4Running=false; window.__focusV4EndAt=0; window.__focusV4Left=0; }
    }
  }
  function write(){ try{ localStorage.setItem(KEY,JSON.stringify({mode:window.__focusV4Mode||25,left:window.__focusV4Left||0,running:!!window.__focusV4Running,endAt:window.__focusV4EndAt||0})); }catch(e){} }
  function ensureMini(){
    let mini=$('focusMiniBarV5');
    if(!mini){
      mini=document.createElement('div');
      mini.className='focus-mini-glass-v5';
      mini.id='focusMiniBarV5';
      mini.setAttribute('aria-hidden','true');
      mini.innerHTML='<button class="focus-mini-main-v5" type="button" onclick="openFocusPopup()"><span class="focus-mini-dot-v5"></span><span class="focus-mini-title-v5" id="focusMiniTitleV5">Focus</span><strong class="focus-mini-time-v5" id="focusMiniTimeV5">25:00</strong></button><button class="focus-mini-btn-v5" type="button" onclick="pauseFocusV5(event)" id="focusMiniPauseV5">Ⅱ</button><button class="focus-mini-btn-v5 danger" type="button" onclick="resetFocusV5(event)">×</button><div class="focus-mini-progress-v5"><span id="focusMiniProgressV5"></span></div>';
      document.body.appendChild(mini);
    }
    return mini;
  }
  function closePopup(){
    ['focusPopupV4','pomodoroModal','focusModal'].forEach(function(id){ const p=$(id); if(p){ p.classList.remove('active','show','open'); p.setAttribute('aria-hidden','true'); p.style.display=''; } });
  }
  function render(){
    read();
    const total=Math.max(1,Number(window.__focusV4Mode||25)*60);
    const left=Math.max(0,Number(window.__focusV4Left||0));
    const show=!!window.__focusV4Running || left<total;
    const text=fmt(left);
    const mini=ensureMini();
    mini.classList.toggle('active',show);
    mini.classList.toggle('paused',show && !window.__focusV4Running);
    mini.setAttribute('aria-hidden',show?'false':'true');
    mini.style.display=show?'flex':'';
    mini.style.opacity=show?'1':'';
    mini.style.pointerEvents=show?'auto':'';
    mini.style.transform=show?'translate(-50%,0)':'';
    document.body.classList.toggle('focus-mini-active',show);
    const popupTime=$('focusTimeV4'); if(popupTime) popupTime.textContent=text;
    const mt=$('focusMiniTimeV5'); if(mt) mt.textContent=text;
    const title=$('focusMiniTitleV5'); if(title) title.textContent=Number(window.__focusV4Mode||25)===5?'Break':(Number(window.__focusV4Mode||25)===15?'Long break':'Focus');
    const prog=$('focusMiniProgressV5'); if(prog) prog.style.width=Math.min(100,Math.max(0,((total-left)/total)*100))+'%';
    const pause=$('focusMiniPauseV5'); if(pause) pause.textContent=window.__focusV4Running?'Ⅱ':'▶';
    const start=$('focusStartBtnV4'); if(start) start.innerHTML=window.__focusV4Running?'<i data-lucide="timer"></i> Đang chạy':'<i data-lucide="play"></i> Bắt đầu';
    write();
  }
  function loop(){
    if(timer) clearInterval(timer);
    timer=setInterval(function(){
      render();
      if(window.__focusV4Running && Number(window.__focusV4Left||0)<=0){
        window.__focusV4Running=false; window.__focusV4EndAt=0; window.__focusV4Left=0; write(); render(); clearInterval(timer); timer=null;
        try{ if(typeof awardPomodoroVcoin==='function') awardPomodoroVcoin(); }catch(e){}
      }
    },1000);
  }
  window.renderFocusV4=render;
  window.startFocusV4=function(){ read(); if(Number(window.__focusV4Left||0)<=0) window.__focusV4Left=Number(window.__focusV4Mode||25)*60; window.__focusV4Running=true; window.__focusV4EndAt=Date.now()+Number(window.__focusV4Left||0)*1000; write(); closePopup(); render(); loop(); };
  window.pauseFocusV4=function(){ read(); if(window.__focusV4Running){ window.__focusV4Left=Math.max(0,Math.ceil((window.__focusV4EndAt-Date.now())/1000)); } window.__focusV4Running=false; window.__focusV4EndAt=0; write(); render(); };
  window.resetFocusV4=function(){ read(); window.__focusV4Running=false; window.__focusV4EndAt=0; window.__focusV4Left=Number(window.__focusV4Mode||25)*60; write(); render(); };
  window.pauseFocusV5=function(e){ if(e) e.stopPropagation(); read(); if(window.__focusV4Running) window.pauseFocusV4(); else window.startFocusV4(); };
  window.resetFocusV5=function(e){ if(e) e.stopPropagation(); window.resetFocusV4(); };
  document.addEventListener('DOMContentLoaded',function(){ render(); if(window.__focusV4Running) loop(); });
  document.addEventListener('click',function(e){ const btn=e.target.closest('[data-focus-minutes]'); if(!btn) return; read(); window.__focusV4Mode=Number(btn.dataset.focusMinutes||25); if(!window.__focusV4Running) window.__focusV4Left=window.__focusV4Mode*60; write(); render(); },true);
})();


/* === Sprint 6 Pomodoro Mini Bar Lock === */
(function(){
  const KEY='focusV4State';
  let timer=null;
  function $(id){ return document.getElementById(id); }
  function fmt(sec){ sec=Math.max(0,Math.ceil(Number(sec)||0)); const m=Math.floor(sec/60), ss=sec%60; return String(m).padStart(2,'0')+':'+String(ss).padStart(2,'0'); }
  function read(){
    let st={mode:25,left:1500,running:false,endAt:0};
    try{ st=Object.assign(st,JSON.parse(localStorage.getItem(KEY)||'{}')); }catch(e){}
    window.__focusV4Mode=Number(st.mode||window.__focusV4Mode||25);
    window.__focusV4Running=!!st.running;
    window.__focusV4EndAt=Number(st.endAt||0);
    window.__focusV4Left=Number(st.left||window.__focusV4Left||window.__focusV4Mode*60);
    if(window.__focusV4Running && window.__focusV4EndAt){
      window.__focusV4Left=Math.max(0,Math.ceil((window.__focusV4EndAt-Date.now())/1000));
      if(window.__focusV4Left<=0){ window.__focusV4Running=false; window.__focusV4EndAt=0; window.__focusV4Left=0; }
    }
  }
  function write(){ try{ localStorage.setItem(KEY,JSON.stringify({mode:window.__focusV4Mode||25,left:window.__focusV4Left||0,running:!!window.__focusV4Running,endAt:window.__focusV4EndAt||0})); }catch(e){} }
  function ensureMini(){
    let mini=$('focusMiniBarV5');
    if(!mini){
      mini=document.createElement('div');
      mini.className='focus-mini-glass-v5';
      mini.id='focusMiniBarV5';
      mini.setAttribute('aria-hidden','true');
      mini.innerHTML='<button class="focus-mini-main-v5" type="button" onclick="openFocusPopup()"><span class="focus-mini-dot-v5"></span><span class="focus-mini-title-v5" id="focusMiniTitleV5">Focus</span><strong class="focus-mini-time-v5" id="focusMiniTimeV5">25:00</strong></button><button class="focus-mini-btn-v5" type="button" onclick="pauseFocusV5(event)" id="focusMiniPauseV5">Ⅱ</button><button class="focus-mini-btn-v5 danger" type="button" onclick="resetFocusV5(event)">×</button><div class="focus-mini-progress-v5"><span id="focusMiniProgressV5"></span></div>';
      document.body.appendChild(mini);
    }
    return mini;
  }
  function closePopup(){ const p=$('focusPopupV4'); if(p){ p.classList.remove('active'); p.setAttribute('aria-hidden','true'); } }
  function render(){
    read();
    const total=Math.max(1,Number(window.__focusV4Mode||25)*60);
    const left=Math.max(0,Number(window.__focusV4Left||0));
    const show=!!window.__focusV4Running || left<total;
    const text=fmt(left);
    const mini=ensureMini();
    mini.classList.toggle('active',show);
    mini.classList.toggle('paused',show && !window.__focusV4Running);
    mini.setAttribute('aria-hidden',show?'false':'true');
    mini.style.left='50%'; mini.style.right='auto'; mini.style.top='auto';
    mini.style.display='flex'; mini.style.flexDirection='row'; mini.style.alignItems='center';
    mini.style.transform=show?'translate(-50%,0)':'translate(-50%,120px)';
    mini.style.opacity=show?'1':'0'; mini.style.visibility=show?'visible':'hidden'; mini.style.pointerEvents=show?'auto':'none';
    document.body.classList.toggle('focus-mini-active',show);
    const popupTime=$('focusTimeV4'); if(popupTime) popupTime.textContent=text;
    const mt=$('focusMiniTimeV5'); if(mt) mt.textContent=text;
    const title=$('focusMiniTitleV5'); if(title) title.textContent=Number(window.__focusV4Mode||25)===5?'Break':(Number(window.__focusV4Mode||25)===15?'Long break':'Focus');
    const prog=$('focusMiniProgressV5'); if(prog) prog.style.width=Math.min(100,Math.max(0,((total-left)/total)*100))+'%';
    const pause=$('focusMiniPauseV5'); if(pause) pause.textContent=window.__focusV4Running?'Ⅱ':'▶';
    const start=$('focusStartBtnV4'); if(start) start.innerHTML=window.__focusV4Running?'<i data-lucide="timer"></i> Đang chạy':'<i data-lucide="play"></i> Bắt đầu';
    write();
  }
  function loop(){
    if(timer) clearInterval(timer);
    timer=setInterval(function(){ render(); if(window.__focusV4Running && Number(window.__focusV4Left||0)<=0){ window.__focusV4Running=false; window.__focusV4EndAt=0; window.__focusV4Left=0; write(); render(); clearInterval(timer); timer=null; try{ if(typeof awardPomodoroVcoin==='function') awardPomodoroVcoin(); }catch(e){} } },1000);
  }
  window.renderFocusV4=render;
  window.startFocusV4=function(){ read(); if(Number(window.__focusV4Left||0)<=0) window.__focusV4Left=Number(window.__focusV4Mode||25)*60; window.__focusV4Running=true; window.__focusV4EndAt=Date.now()+Number(window.__focusV4Left||0)*1000; write(); closePopup(); render(); loop(); };
  window.pauseFocusV4=function(){ read(); if(window.__focusV4Running){ window.__focusV4Left=Math.max(0,Math.ceil((window.__focusV4EndAt-Date.now())/1000)); } window.__focusV4Running=false; window.__focusV4EndAt=0; write(); render(); };
  window.resetFocusV4=function(){ read(); window.__focusV4Running=false; window.__focusV4EndAt=0; window.__focusV4Left=Number(window.__focusV4Mode||25)*60; write(); render(); };
  window.pauseFocusV5=function(e){ if(e) e.stopPropagation(); read(); if(window.__focusV4Running) window.pauseFocusV4(); else window.startFocusV4(); };
  window.resetFocusV5=function(e){ if(e) e.stopPropagation(); window.resetFocusV4(); };
  document.addEventListener('DOMContentLoaded',function(){ render(); if(window.__focusV4Running) loop(); });
  document.addEventListener('click',function(e){ const btn=e.target.closest('[data-focus-minutes]'); if(!btn) return; read(); window.__focusV4Mode=Number(btn.dataset.focusMinutes||25); if(!window.__focusV4Running) window.__focusV4Left=window.__focusV4Mode*60; write(); render(); },true);
})();
