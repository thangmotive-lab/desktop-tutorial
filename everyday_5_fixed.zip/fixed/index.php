<?php
// Trang mặc định khi người dùng truy cập domain.
require_once __DIR__ . '/login.php';
