<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';
require_login();
header('Content-Type: application/json; charset=utf-8');

$since=(int)($_GET['since']??0);
$pref=user_pref($pdo,current_user()['id']);

$stmt=$pdo->prepare("SELECT id,title,message,type,link,created_at,COALESCE(level,'info') level,COALESCE(sound,'notify') sound 
  FROM notifications 
  WHERE user_id=? AND is_read=0 AND id>? 
  ORDER BY id ASC LIMIT 10");
$stmt->execute([current_user()['id'],$since]);
echo json_encode([
  'notifications'=>$stmt->fetchAll(),
  'preferences'=>[
    'mute_notification'=>(int)($pref['mute_notification']??0),
    'mute_sound'=>(int)($pref['mute_sound']??0),
    'popup_position'=>$pref['popup_position']??'top-right'
  ]
], JSON_UNESCAPED_UNICODE);
