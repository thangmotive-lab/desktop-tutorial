<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';
require_login();
header('Content-Type: application/json; charset=utf-8');

$message=trim($_POST['message']??'');
if($message===''){
  echo json_encode(['ok'=>false,'error'=>'empty']);
  exit;
}
$me=current_user();
$stmt=$pdo->prepare('INSERT INTO group_messages(user_id,message) VALUES(?,?)');
$stmt->execute([$me['id'],$message]);
$id=$pdo->lastInsertId();

foreach($pdo->query("SELECT id FROM users WHERE status='active' AND id!=".(int)$me['id']) as $u){
  create_notification($pdo,$u['id'],'Tin nhắn nhóm mới',$me['name'].': '.mb_substr($message,0,80,'UTF-8'),'chat','app.php?page=chat');
}

echo json_encode(['ok'=>true,'id'=>$id], JSON_UNESCAPED_UNICODE);
