<?php
$error = $error ?? '';
$quoteToday = $quoteToday ?? 'Keep Moving Forward.';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <title>Motive Everyday — Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
  <style>
    *{box-sizing:border-box}
    body{margin:0;min-height:100vh;font-family:Inter,Arial,sans-serif;color:#172033;background:linear-gradient(135deg,#fff7ed,#ecfeff,#f5f3ff);display:flex;align-items:center;justify-content:center;padding:26px}
    .login-card{max-width:1080px;width:100%;min-height:620px;background:rgba(255,255,255,.92);border-radius:36px;overflow:hidden;display:grid;grid-template-columns:1fr .86fr;box-shadow:0 28px 90px rgba(15,23,42,.13);border:1px solid rgba(255,255,255,.7)}
    .login-left{padding:48px;background:linear-gradient(135deg,#111827,#7c3aed);color:white;display:flex;flex-direction:column;justify-content:center}
    .brand-badge{width:58px;height:58px;border-radius:20px;background:#fff;color:#111827;display:flex;align-items:center;justify-content:center;font-weight:950;font-size:28px;margin-bottom:26px}
    .eyebrow{font-size:12px;letter-spacing:.08em;text-transform:uppercase;font-weight:950;opacity:.8}
    h1{font-size:58px;line-height:.96;letter-spacing:-.07em;margin:12px 0} h2{font-size:42px;letter-spacing:-.06em;margin:8px 0}
    .muted{opacity:.74;line-height:1.55}.login-quote{margin-top:32px;padding:18px;border-radius:22px;background:rgba(255,255,255,.12);font-weight:800}
    .login-right{padding:48px;display:flex;flex-direction:column;justify-content:center}
    label{font-size:13px;font-weight:850;margin:16px 0 7px;display:block}
    input{width:100%;min-height:54px;border:1px solid #e5e7eb;border-radius:18px;padding:12px 14px;font-size:15px}
    button{width:100%;min-height:56px;border:0;border-radius:20px;background:#ff6b4a;color:#fff;font-weight:900;margin-top:22px;cursor:pointer}
    .flash{padding:12px 14px;border-radius:16px;background:#fff1f2;border:1px solid #fecdd3;color:#be123c;font-weight:800;margin:12px 0}
    @media(max-width:900px){body{padding:16px;align-items:flex-start}.login-card{grid-template-columns:1fr;min-height:0}.login-left,.login-right{padding:28px}h1{font-size:42px}h2{font-size:34px}}
  </style>
</head>
<body>
  <main class="login-card">
    <section class="login-left">
      <div class="brand-badge">M</div>
      <span class="eyebrow">Motive Everyday</span>
      <h1>Keep Moving Forward.</h1>
      <p class="muted">Agency operating system for Motive team.</p>
      <div class="login-quote">“<?= e($quoteToday) ?>”</div>
    </section>
    <section class="login-right">
      <span class="eyebrow">Welcome back</span>
      <h2>Đăng nhập</h2>
      <p class="muted">Vào workspace để tiếp tục vận hành Motive hôm nay.</p>
      <?php if($error): ?><div class="flash"><?= e($error) ?></div><?php endif; ?>
      <form method="post" autocomplete="on">
        <label>Email</label><input type="email" name="email" placeholder="you@motive.vn" required autofocus>
        <label>Mật khẩu</label><input type="password" name="password" placeholder="••••••••" required>
        <button type="submit">Vào Motive Everyday →</button>
      </form>
    </section>
  </main>
</body>
</html>
