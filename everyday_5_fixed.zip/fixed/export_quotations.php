<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';
require_login();

$me=current_user();
if(!is_director_role($me) && !is_finance_role($me)) die('Bạn không có quyền export.');

$month=$_GET['month'] ?? date('Y-m');
$status=trim($_GET['status']??'');
$owner=(int)($_GET['owner_id']??0);
$qstr=trim($_GET['q']??'');

$where=[];$params=[];
if($month){ $where[]="COALESCE(q.quote_month, DATE_FORMAT(COALESCE(q.quote_date,q.created_at),'%Y-%m'))=?"; $params[]=$month; }
if($status){ $where[]='q.status=?'; $params[]=$status; }
if($owner){ $where[]='q.owner_id=?'; $params[]=$owner; }
if($qstr!==''){ $where[]='(q.client_name LIKE ? OR q.quote_code LIKE ? OR q.title LIKE ? OR q.objective LIKE ?)'; array_push($params,"%$qstr%","%$qstr%","%$qstr%","%$qstr%"); }

$sql="SELECT q.quote_code,q.client_name,q.title,q.industry,q.objective,q.quote_date,q.quote_month,q.expired_at,q.status,q.contract_status,q.expected_revenue,q.won_at,q.lost_at,q.completed_at,u.name owner_name,v.total version_total
      FROM quotations q
      LEFT JOIN users u ON u.id=q.owner_id
      LEFT JOIN quotation_versions v ON v.quotation_id=q.id AND v.version_no=q.current_version";
if($where) $sql.=" WHERE ".implode(" AND ",$where);
$sql.=" ORDER BY COALESCE(q.quote_date,q.created_at) DESC,q.id DESC";
$stmt=$pdo->prepare($sql);$stmt->execute($params);$rows=$stmt->fetchAll(PDO::FETCH_ASSOC);

$filename='quotation_pipeline_'.$month.'_'.date('Ymd_His').'.xls';
header('Content-Type: application/vnd.ms-excel; charset=utf-8');
header('Content-Disposition: attachment; filename="'.$filename.'"');
echo "\xEF\xBB\xBF";
echo "<table border='1'>";
$headers=['Mã báo giá','Khách hàng','Tiêu đề','Ngành','Mục tiêu','Ngày báo giá','Tháng','Ngày hết hạn','Trạng thái','Trạng thái HĐ','Giá trị báo giá','Khoản thu dự kiến','Owner','Ngày đồng ý','Ngày lost','Ngày hoàn thành'];
echo "<tr>";
foreach($headers as $h) echo "<th>".htmlspecialchars($h,ENT_QUOTES,'UTF-8')."</th>";
echo "</tr>";
foreach($rows as $r){
  echo "<tr>";
  echo "<td>".htmlspecialchars($r['quote_code']??'',ENT_QUOTES,'UTF-8')."</td>";
  echo "<td>".htmlspecialchars($r['client_name']??'',ENT_QUOTES,'UTF-8')."</td>";
  echo "<td>".htmlspecialchars($r['title']??'',ENT_QUOTES,'UTF-8')."</td>";
  echo "<td>".htmlspecialchars($r['industry']??'',ENT_QUOTES,'UTF-8')."</td>";
  echo "<td>".htmlspecialchars($r['objective']??'',ENT_QUOTES,'UTF-8')."</td>";
  echo "<td>".htmlspecialchars($r['quote_date']??'',ENT_QUOTES,'UTF-8')."</td>";
  echo "<td>".htmlspecialchars($r['quote_month']??'',ENT_QUOTES,'UTF-8')."</td>";
  echo "<td>".htmlspecialchars($r['expired_at']??'',ENT_QUOTES,'UTF-8')."</td>";
  echo "<td>".htmlspecialchars($r['status']??'',ENT_QUOTES,'UTF-8')."</td>";
  echo "<td>".htmlspecialchars($r['contract_status']??'',ENT_QUOTES,'UTF-8')."</td>";
  echo "<td>".(float)($r['version_total']??0)."</td>";
  echo "<td>".(float)($r['expected_revenue']??0)."</td>";
  echo "<td>".htmlspecialchars($r['owner_name']??'',ENT_QUOTES,'UTF-8')."</td>";
  echo "<td>".htmlspecialchars($r['won_at']??'',ENT_QUOTES,'UTF-8')."</td>";
  echo "<td>".htmlspecialchars($r['lost_at']??'',ENT_QUOTES,'UTF-8')."</td>";
  echo "<td>".htmlspecialchars($r['completed_at']??'',ENT_QUOTES,'UTF-8')."</td>";
  echo "</tr>";
}
echo "</table>";
exit;
