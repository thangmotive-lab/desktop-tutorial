
-- Sprint 4: Quote → Contract → Project Automation
ALTER TABLE quotations ADD COLUMN project_id INT NULL;
ALTER TABLE projects ADD COLUMN quotation_id INT NULL;
ALTER TABLE projects ADD COLUMN contract_id INT NULL;
ALTER TABLE tasks ADD COLUMN quotation_item_id INT NULL;

CREATE TABLE IF NOT EXISTS quotation_project_map(
  id INT AUTO_INCREMENT PRIMARY KEY,
  quotation_id INT NOT NULL,
  contract_id INT NULL,
  project_id INT NOT NULL,
  template_id INT NULL,
  created_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_quote_project (quotation_id, project_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS project_templates(
  id INT AUTO_INCREMENT PRIMARY KEY,
  template_name VARCHAR(190) NOT NULL,
  template_type VARCHAR(80) DEFAULT 'General',
  description TEXT NULL,
  is_active TINYINT DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS project_template_tasks(
  id INT AUTO_INCREMENT PRIMARY KEY,
  template_id INT NOT NULL,
  sort_order INT DEFAULT 0,
  title VARCHAR(255) NOT NULL,
  phase VARCHAR(120) NULL,
  priority VARCHAR(80) DEFAULT 'Quan trọng',
  due_offset_days INT DEFAULT 3,
  assignee_role VARCHAR(80) NULL,
  brief TEXT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
