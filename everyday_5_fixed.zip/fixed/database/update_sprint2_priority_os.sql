-- Sprint 2 — normalize task priorities to MotiveEveryday 4-level system
-- New levels:
-- 1) Khẩn cấp làm ngay
-- 2) Làm ngay
-- 3) Quan trọng
-- 4) Lúc nào làm cũng được

UPDATE tasks SET priority='Khẩn cấp làm ngay' WHERE priority IN ('Urgent','Khẩn cấp','Khẩn cấp làm ngay');
UPDATE tasks SET priority='Làm ngay' WHERE priority IN ('High','Làm ngay');
UPDATE tasks SET priority='Quan trọng' WHERE priority IN ('Normal','Medium','Quan trọng','');
UPDATE tasks SET priority='Lúc nào làm cũng được' WHERE priority IN ('Low','Không khẩn cấp','Không quan trọng','Lúc nào làm cũng được');
UPDATE tasks SET priority='Quan trọng' WHERE priority IS NULL;
