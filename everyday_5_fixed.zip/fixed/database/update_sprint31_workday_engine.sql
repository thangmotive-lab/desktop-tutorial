-- Sprint 31: Workday Engine + CEO Dashboard
CREATE TABLE IF NOT EXISTS workday_settings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  setting_key VARCHAR(80) NOT NULL UNIQUE,
  setting_value VARCHAR(120) NOT NULL,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO workday_settings(setting_key,setting_value) VALUES
('full_day_minutes','480'),
('three_quarter_day_minutes','360'),
('half_day_minutes','240'),
('quarter_day_minutes','120'),
('standard_start_time','09:00:00'),
('standard_end_time','18:00:00'),
('late_grace_minutes','10');

ALTER TABLE attendance ADD COLUMN approved_by INT NULL;
ALTER TABLE attendance ADD COLUMN approved_at DATETIME NULL;
ALTER TABLE attendance ADD COLUMN attendance_type VARCHAR(40) DEFAULT 'work';
