-- Sprint 3: Client Portal + Approval Workflow
CREATE TABLE IF NOT EXISTS client_portal_access (
  id INT AUTO_INCREMENT PRIMARY KEY,
  client_id INT NOT NULL,
  token VARCHAR(80) NOT NULL UNIQUE,
  is_active TINYINT(1) DEFAULT 1,
  note TEXT NULL,
  created_by INT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NULL,
  INDEX(client_id), INDEX(token)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS approval_requests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  item_type VARCHAR(50) NOT NULL,
  item_id INT NOT NULL,
  title VARCHAR(255) NOT NULL,
  requested_by INT NULL,
  approved_by INT NULL,
  status VARCHAR(30) DEFAULT 'pending',
  note TEXT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  decided_at DATETIME NULL,
  INDEX(item_type,item_id), INDEX(status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
