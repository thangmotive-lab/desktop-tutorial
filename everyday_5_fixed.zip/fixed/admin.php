<?php
ob_start();
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';
require_login();

$me = current_user();
$role = $me['role'] ?? '';
if (!user_is_admin()) {
  die('Bạn không có quyền truy cập Admin Studio.');
}

$page = $_GET['page'] ?? 'users';
$allowed = ['users','permissions','leave_requests','payroll','kpi','activity','ratecard','integrations','settings','okr','personal_rates','contract_templates','business_finance','monthly_closing','payroll_manager','ctv_approval','sales_commissions','contract_owners','ctv_payroll','finance_operations','approval_center','ai_center','ai_quote','ai_knowledge','ai_documents','ai_workspace','ai_knowledge_base','ai_document_library','ai_generate_center','ai_proposal_engine','ai_prompt_studio','document_templates','doc_templates','doc_generate','revenue_overview','document_generate','dashboard','quotation_list','internal_costs','cash_forecast','files','contract_generate','attendance','search','contract_detail','task_detail','quotation_edit','growth_os','payments','notifications','payroll_batch','quotation_create','team_productivity','task_mentions','contracts','project_detail','vcoin_manager','achievement_manager'];
if (!in_array($page, $allowed)) $page = 'users';

$titles = [
  'users'=>'Hồ sơ nhân sự',
  'permissions'=>'Phân quyền',
  'leave_requests'=>'Đơn từ',
  'payroll'=>'Bảng lương',
  'payroll_manager'=>'Payroll Manager',
  'kpi'=>'KPI',
  'activity'=>'Activity Log',
  'ratecard'=>'Ratecard',
  'integrations'=>'Google Drive',
  'settings'=>'Settings',
  'okr'=>'OKR',
  'ai_quote'=>'AI Quote',
  'ai_center'=>'AI Center',
  'ai_documents'=>'AI Documents',
  'doc_generate'=>'Generate DOCX',
  'document_generate'=>'Generate DOCX',
  'doc_templates'=>'Document Templates',
  'document_templates'=>'Document Templates',
  'ai_knowledge'=>'AI Knowledge',
  'ai_workspace'=>'AI Workspace',
  'ai_knowledge_base'=>'AI Knowledge Base',
  'ai_document_library'=>'AI Document Library',
  'ai_generate_center'=>'AI Generate Center',
  'ai_proposal_engine'=>'AI Proposal Engine',
  'ai_prompt_studio'=>'AI Prompt Studio',
  'approval_center'=>'Approval Center',
  'personal_rates'=>'Personal Rate',
  'contract_templates'=>'Contract Templates',
  'business_finance'=>'Business Finance',
  'finance_operations'=>'Finance Operations',
  'ctv_payroll'=>'CTV Payroll',
  'contract_owners'=>'Contract Owners',
  'sales_commissions'=>'Sales Commission',
  'ctv_approval'=>'CTV Approval',
  'monthly_closing'=>'Monthly Closing',
  'vcoin_manager'=>'Mcoin Manager','achievement_manager'=>'Achievement Manager'
];
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <title>Admin Studio - Motiveeveryday</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/animate.css@4.1.1/animate.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/style.css">
  <link rel="stylesheet" href="assets/css/admin.css">
</head>
<body class="admin-body">
<div class="admin-shell">
  <aside class="admin-sidebar">
    <div class="admin-brand">
      <div class="brand-icon">M</div>
      <div>
        <b>Admin Studio</b>
        <span>Motiveeveryday</span>
      </div>
    </div>
    <?php
    $adminGroups = [
      'PEOPLE' => ['users'=>'Hồ sơ nhân sự','permissions'=>'Phân quyền','leave_requests'=>'Đơn từ','personal_rates'=>'Personal Rate','kpi'=>'KPI','okr'=>'Agency OKR'],
      'FINANCE' => ['vcoin_manager'=>'Mcoin Manager','achievement_manager'=>'Achievement Manager','payroll'=>'Bảng lương','payroll_manager'=>'Payroll Manager','business_finance'=>'Business Finance','finance_operations'=>'Finance Operations','monthly_closing'=>'Monthly Closing','ctv_approval'=>'CTV Approval','ctv_payroll'=>'CTV Payroll','sales_commissions'=>'Sales Commission','contract_owners'=>'Contract Owners','approval_center'=>'Approval Center'],
      'AI STUDIO' => ['ai_workspace'=>'AI Workspace','ai_knowledge_base'=>'Knowledge Base','ai_document_library'=>'Document Library','ai_generate_center'=>'Generate Center','ai_proposal_engine'=>'Proposal Engine','ai_prompt_studio'=>'Prompt Studio','ai_center'=>'AI Center','ai_quote'=>'AI Quote','ai_knowledge'=>'AI Knowledge','ai_documents'=>'AI Documents','doc_generate'=>'Generate DOCX','doc_templates'=>'Document Templates'],
      'SYSTEM' => ['ratecard'=>'Ratecard','contract_templates'=>'Contract Templates','integrations'=>'Google Drive','settings'=>'Settings','activity'=>'Activity Log']
    ];
    ?>
    <nav class="admin-nav-groups">
      <?php foreach($adminGroups as $groupName=>$items): ?>
        <div class="nav-group">
          <button class="nav-title nav-collapse-trigger" type="button" onclick="toggleNavGroup(this)" aria-expanded="true"><span><?= e($groupName) ?></span><b>⌄</b></button>
          <div class="nav-group-items">
          <?php foreach($items as $key=>$label): ?>
            <a class="<?= $page===$key?'active':'' ?>" href="admin.php?page=<?= e($key) ?>"><?= e($label) ?></a>
          <?php endforeach; ?>
          </div>
        </div>
      <?php endforeach; ?>
    </nav>
    <div class="admin-bottom">
      <a href="app.php?page=workspace">← Back Workspace</a>
      <a href="logout.php">Log-out</a>
    </div>
  </aside>

  <main class="admin-main">
    <header class="admin-top">
      <a class="admin-back-top icon-btn" href="app.php?page=workspace" title="Quay lại Workspace">←</a>
      <div>
        <span class="eyebrow">Private Control Room</span>
        <h1><?= e($titles[$page] ?? ucwords(str_replace('_',' ',$page))) ?></h1>
      </div>
      <div class="user-chip"><?= avatar_html($me,true) ?><?= e($me['name']) ?></div>
    </header>
    <div class="admin-content" data-aos="fade-up">
      <?php require __DIR__ . '/modules/' . $page . '.php'; ?>
    </div>
  </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script src="https://cdn.jsdelivr.net/npm/gsap@3.12.5/dist/gsap.min.js"></script>
<script src="assets/js/app.js"></script>
</body>
</html>
