/* ================================
   Motive Everyday - Work Timer Header JS
   Chỉ dành cho TIMER CHẤM CÔNG
   Không đụng Pomodoro
   ================================ */
(function(){
  const STORAGE_KEY = 'motive_work_timer_state_v1';

  const defaultState = {
    status: 'idle', // idle | running | paused
    startedAt: null,
    pausedAt: null,
    elapsedBeforePause: 0
  };

  let state = loadState();
  let interval = null;

  function loadState(){
    try{
      return Object.assign({}, defaultState, JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}'));
    }catch(e){
      return Object.assign({}, defaultState);
    }
  }

  function saveState(){
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }

  function pad(num){ return String(num).padStart(2,'0'); }

  function formatDuration(ms){
    const totalSeconds = Math.max(0, Math.floor(ms / 1000));
    const h = Math.floor(totalSeconds / 3600);
    const m = Math.floor((totalSeconds % 3600) / 60);
    const s = totalSeconds % 60;
    return `${pad(h)}:${pad(m)}:${pad(s)}`;
  }

  function getElapsed(){
    if(state.status === 'running' && state.startedAt){
      return state.elapsedBeforePause + (Date.now() - Number(state.startedAt));
    }
    return state.elapsedBeforePause || 0;
  }

  function startWork(){
    if(state.status === 'paused'){
      state.status = 'running';
      state.startedAt = Date.now();
      state.pausedAt = null;
    }else{
      state = {
        status:'running',
        startedAt: Date.now(),
        pausedAt: null,
        elapsedBeforePause: 0
      };
    }
    saveState();
    render();
  }

  function pauseWork(){
    if(state.status !== 'running') return;
    state.elapsedBeforePause = getElapsed();
    state.status = 'paused';
    state.startedAt = null;
    state.pausedAt = Date.now();
    saveState();
    render();
  }

  function stopWork(){
    const total = getElapsed();
    const shouldStop = confirm(`Kết thúc ca làm việc?\nThời gian đã ghi nhận: ${formatDuration(total)}`);
    if(!shouldStop) return;

    state = Object.assign({}, defaultState);
    saveState();
    render();

    window.dispatchEvent(new CustomEvent('motive:workTimerStopped', {
      detail: { elapsedMs: total, elapsedText: formatDuration(total) }
    }));
  }

  function getEls(){
    return {
      bar: document.querySelector('[data-work-timer-bar]'),
      icon: document.querySelector('[data-work-timer-icon]'),
      time: document.querySelector('[data-work-timer-time]'),
      label: document.querySelector('[data-work-timer-label]'),
      actions: document.querySelector('[data-work-timer-actions]')
    };
  }

  function render(){
    const els = getEls();
    if(!els.bar) return;

    clearInterval(interval);
    interval = null;

    els.bar.classList.remove('is-idle','is-running','is-paused');
    els.bar.classList.add(`is-${state.status}`);

    if(state.status === 'idle'){
      els.icon.textContent = '⏱';
      els.time.textContent = 'Bắt đầu làm việc';
      els.label.textContent = '';
      els.actions.innerHTML = `<button type="button" class="work-timer-btn start" data-work-start><span>▶</span><span class="btn-text">Bắt đầu</span></button>`;
    }

    if(state.status === 'running'){
      els.icon.textContent = '⏱';
      els.time.textContent = formatDuration(getElapsed());
      els.label.textContent = 'Đang làm việc';
      els.actions.innerHTML = `
        <button type="button" class="work-timer-btn pause icon-only" data-work-pause aria-label="Tạm nghỉ">Ⅱ</button>
        <button type="button" class="work-timer-btn stop icon-only" data-work-stop aria-label="Kết thúc ca">■</button>
      `;
      interval = setInterval(() => {
        const nowEls = getEls();
        if(nowEls.time) nowEls.time.textContent = formatDuration(getElapsed());
      }, 1000);
    }

    if(state.status === 'paused'){
      els.icon.textContent = '⏸';
      els.time.textContent = formatDuration(getElapsed());
      els.label.textContent = 'Đang tạm nghỉ';
      els.actions.innerHTML = `
        <button type="button" class="work-timer-btn start icon-only" data-work-start aria-label="Tiếp tục">▶</button>
        <button type="button" class="work-timer-btn stop icon-only" data-work-stop aria-label="Kết thúc ca">■</button>
      `;
    }
  }

  document.addEventListener('click', function(e){
    if(e.target.closest('[data-work-start]')) startWork();
    if(e.target.closest('[data-work-pause]')) pauseWork();
    if(e.target.closest('[data-work-stop]')) stopWork();
  });

  document.addEventListener('DOMContentLoaded', render);
  window.MotiveWorkTimer = { startWork, pauseWork, stopWork, render, getElapsed };
})();
