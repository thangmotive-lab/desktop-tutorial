<?php
$tid=(int)($_GET['id']??0);
$stmt=$pdo->prepare("SELECT t.*,p.name project_name,p.id project_id,p.avatar project_avatar,u.name assignee_name,u.avatar assignee_avatar,c.name creator_name
  FROM tasks t
  LEFT JOIN projects p ON p.id=t.project_id
  LEFT JOIN users u ON u.id=t.assignee_id
  LEFT JOIN users c ON c.id=t.created_by
  WHERE t.id=? LIMIT 1");
$stmt->execute([$tid]);
$t=$stmt->fetch();
if(!$t) die('Không tìm thấy task.');

$me=current_user();
$canEdit = user_is_admin() || (int)$t['created_by']===(int)$me['id'] || (int)$t['assignee_id']===(int)$me['id'];

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['save_task_detail']) && $canEdit){
  $pdo->prepare("UPDATE tasks SET title=?, brief=?, description=?, assignee_id=?, priority=?, start_date=?, deadline=?, status=?, phase=?, reference_link=?, file_link=? WHERE id=?")
      ->execute([$_POST['title'],$_POST['brief']??'',$_POST['description']??'',$_POST['assignee_id']?:null,normalize_priority($_POST['priority'] ?? ''),$_POST['start_date']?:null,$_POST['deadline']?:null,$_POST['status'],$_POST['phase']?:'General',$_POST['reference_link']??'',$_POST['file_link']??'',$tid]);
  log_activity($pdo,'update','task',$tid,'Cập nhật task detail');
  redirect('app.php?page=task_detail&id='.$tid.'&saved=1');
}

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['add_task_comment'])){
  $comment=trim($_POST['comment']??'');
  if($comment!==''){
    $pdo->prepare("INSERT INTO task_comments(task_id,user_id,comment) VALUES(?,?,?)")->execute([$tid,$me['id'],$comment]);
    $cid=$pdo->lastInsertId();
    if(function_exists('create_task_mentions_from_comment')) create_task_mentions_from_comment($pdo,$tid,$cid,$comment,$me['id']);
    log_activity($pdo,'comment','task',$tid,'Comment task detail');
  }
  redirect('app.php?page=task_detail&id='.$tid.'#comments');
}

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['add_task_link'])){
  $url=trim($_POST['url']??'');
  if($url!==''){
    $pdo->prepare("INSERT INTO task_links(task_id,title,url,note,created_by) VALUES(?,?,?,?,?)")
      ->execute([$tid,$_POST['title']?:'Link',$url,$_POST['note']??'',$me['id']]);
  }
  redirect('app.php?page=task_detail&id='.$tid.'#links');
}

if(isset($_GET['delete_link']) && $canEdit){
  $pdo->prepare("DELETE FROM task_links WHERE id=? AND task_id=?")->execute([(int)$_GET['delete_link'],$tid]);
  redirect('app.php?page=task_detail&id='.$tid.'#links');
}

$users=safe_rows($pdo,"SELECT id,name,avatar FROM users ORDER BY name");
$comments=safe_rows($pdo,"SELECT c.*,u.name user_name,u.avatar user_avatar FROM task_comments c LEFT JOIN users u ON u.id=c.user_id WHERE c.task_id=$tid ORDER BY c.id ASC");
$links=safe_rows($pdo,"SELECT l.*,u.name user_name FROM task_links l LEFT JOIN users u ON u.id=l.created_by WHERE l.task_id=$tid ORDER BY l.id DESC");
$statuses=['Todo','Doing','Review','Waiting Approval','Done'];
$priorities=['Khẩn cấp làm ngay','Làm ngay','Quan trọng','Lúc nào làm cũng được'];
?>
<?php if(!empty($_GET['saved'])): ?><div class="alert success">Đã lưu task detail.</div><?php endif; ?>

<section class="workspace-hero task-detail-hero">
  <div>
    <span class="eyebrow">Task Detail</span>
    <h1><?= e($t['title']) ?></h1>
    <p class="muted">
      <?php if($t['project_id']): ?><a href="app.php?page=project_detail&id=<?= $t['project_id'] ?>"><?= e($t['project_name']) ?></a> · <?php endif; ?>
      <?= e($t['status']) ?> · Deadline: <?= e($t['deadline']) ?>
    </p>
  </div>
  <div class="actions">
    <?php if($canEdit): ?><a class="primary" href="#editTaskForm" onclick="document.getElementById('editTaskForm')?.classList.add('edit-focus-card')">✎ Sửa task</a><?php endif; ?>
    <?php if($t['project_id']): ?><a class="btn btn-soft" href="app.php?page=project_detail&id=<?= $t['project_id'] ?>">← Project</a><?php endif; ?>
    <a class="btn btn-soft" href="app.php?page=tasks">My Tasks</a>
  </div>
</section>

<div class="task-detail-layout">
  <section class="card" id="editTaskForm">
    <div class="card-head"><h2>Brief & yêu cầu task</h2><div class="actions"><?php if($canEdit): ?><span class="badge green">Có thể chỉnh sửa</span><?php endif; ?><span class="badge <?= badge_class($t['status']) ?>"><?= e($t['status']) ?></span></div></div>
    <form method="post">
      <input type="hidden" name="save_task_detail" value="1">
      <label>Title</label><input name="title" value="<?= e($t['title']) ?>" <?= $canEdit?'':'readonly' ?>>
      <label>Brief</label><textarea name="brief" rows="5" <?= $canEdit?'':'readonly' ?>><?= e($t['brief']??'') ?></textarea>
      <label>Chi tiết yêu cầu</label><textarea name="description" rows="8" <?= $canEdit?'':'readonly' ?>><?= e($t['description']??'') ?></textarea>
      <div class="form-row">
        <div><label>Người phụ trách</label><select name="assignee_id" <?= $canEdit?'':'disabled' ?>><option value="">Chưa giao</option><?php foreach($users as $u): ?><option value="<?= $u['id'] ?>" <?= (int)$t['assignee_id']===(int)$u['id']?'selected':'' ?>><?= e($u['name']) ?></option><?php endforeach; ?></select></div>
        <div><label>Priority</label><select name="priority" <?= $canEdit?'':'disabled' ?>><?php foreach(priority_options() as $pv=>$pl): ?><option value="<?= e($pv) ?>" <?= normalize_priority($t['priority']??'')===$pv?'selected':'' ?>><?= e($pl) ?></option><?php endforeach; ?></select></div>
      </div>
      <div class="form-row">
        <div><label>Start</label><input type="date" name="start_date" value="<?= e($t['start_date']??'') ?>" <?= $canEdit?'':'readonly' ?>></div>
        <div><label>Deadline</label><input type="date" name="deadline" value="<?= e($t['deadline']??'') ?>" <?= $canEdit?'':'readonly' ?>></div>
      </div>
      <div class="form-row">
        <div><label>Status</label><select name="status" <?= $canEdit?'':'disabled' ?>><?php foreach($statuses as $s): ?><option <?= ($t['status']??'Todo')===$s?'selected':'' ?>><?= e($s) ?></option><?php endforeach; ?></select></div>
        <div><label>Section / Phase</label><input name="phase" value="<?= e($t['phase'] ?: 'General') ?>" <?= $canEdit?'':'readonly' ?>></div>
      </div>
      <label>Reference link</label><input name="reference_link" value="<?= e($t['reference_link']??'') ?>" <?= $canEdit?'':'readonly' ?>>
      <label>File link</label><input name="file_link" value="<?= e($t['file_link']??'') ?>" <?= $canEdit?'':'readonly' ?>>
      <?php if($canEdit): ?><button class="primary">Lưu task detail</button><?php endif; ?>
    </form>
  </section>

  <aside class="card task-meta-card">
    <h2>Thông tin nhanh</h2>
    <p><b>Assignee</b><br><span class="user-chip"><?= avatar_html(['name'=>$t['assignee_name'],'avatar'=>$t['assignee_avatar']],true) ?><?= e($t['assignee_name'] ?: 'Chưa giao') ?></span></p>
    <p><b>Người tạo</b><br><?= e($t['creator_name'] ?: '-') ?></p>
    <p><b>Project</b><br><?php if($t['project_id']): ?><a href="app.php?page=project_detail&id=<?= $t['project_id'] ?>"><?= e($t['project_name']) ?></a><?php else: ?>Task cá nhân<?php endif; ?></p>
    <?php if(!empty($t['reference_link'])): ?><p><a class="btn btn-soft" target="_blank" href="<?= e($t['reference_link']) ?>">Mở reference</a></p><?php endif; ?>
    <?php if(!empty($t['file_link'])): ?><p><a class="btn btn-soft" target="_blank" href="<?= e($t['file_link']) ?>">Mở file</a></p><?php endif; ?>
  </aside>
</div>

<div class="two-col">
<section class="card" id="links">
  <div class="card-head"><h2>Link đính kèm</h2></div>
  <form method="post" class="compact-form">
    <input type="hidden" name="add_task_link" value="1">
    <input name="title" placeholder="Tên link">
    <input name="url" placeholder="https://..." required>
    <input name="note" placeholder="Ghi chú">
    <button class="btn btn-soft">+ Link</button>
  </form>
  <table class="dense-table"><tbody>
  <?php foreach($links as $l): ?><tr><td><b><?= e($l['title']) ?></b><br><span class="muted"><?= e($l['note']) ?></span></td><td><a target="_blank" href="<?= e($l['url']) ?>">Open</a></td><td><?= e($l['user_name']) ?></td><td><?php if($canEdit): ?><a class="btn btn-soft" href="app.php?page=task_detail&id=<?= $tid ?>&delete_link=<?= $l['id'] ?>">Xóa</a><?php endif; ?></td></tr><?php endforeach; ?>
  <?php if(empty($links)): ?><tr><td class="muted">Chưa có link đính kèm.</td></tr><?php endif; ?>
  </tbody></table>
</section>

<section class="card" id="comments">
  <div class="card-head"><h2>Bình luận & góp ý</h2></div>
  <div class="task-comment-list">
    <?php foreach($comments as $c): ?><div class="task-comment"><?= avatar_html(['name'=>$c['user_name'],'avatar'=>$c['user_avatar']],true) ?><div><b><?= e($c['user_name']) ?></b><span><?= e($c['created_at']) ?></span><p><?= nl2br(e($c['comment'])) ?></p></div></div><?php endforeach; ?>
    <?php if(empty($comments)): ?><p class="muted">Chưa có bình luận.</p><?php endif; ?>
  </div>
  <form method="post" class="comment-form">
    <input type="hidden" name="add_task_comment" value="1">
    <textarea name="comment" placeholder="Góp ý, comment, dùng @Tên để mention..." required></textarea>
    <button class="primary">Gửi bình luận</button>
  </form>
</section>
</div>
