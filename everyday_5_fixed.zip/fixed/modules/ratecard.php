<?php
$edit=null;
if(isset($_GET['edit'])){
  $stmt=$pdo->prepare('SELECT * FROM ratecard_items WHERE id=?');
  $stmt->execute([(int)$_GET['edit']]);
  $edit=$stmt->fetch();
}
if ($_SERVER['REQUEST_METHOD']==='POST') {
  if(!empty($_POST['ratecard_id'])){
    $stmt=$pdo->prepare('UPDATE ratecard_items SET category=?,service_name=?,description=?,unit=?,unit_price=?,default_quantity=?,working_time=?,vat_rate=?,internal_cost_hint=?,keywords=?,note=? WHERE id=?');
    $stmt->execute([$_POST['category'],$_POST['service_name'],$_POST['description'],$_POST['unit'],$_POST['unit_price'],$_POST['default_quantity'],$_POST['working_time'],$_POST['vat_rate'],$_POST['internal_cost_hint'],$_POST['keywords'],$_POST['note'],$_POST['ratecard_id']]);
  } else {
    $stmt=$pdo->prepare('INSERT INTO ratecard_items(category,service_name,description,unit,unit_price,default_quantity,working_time,vat_rate,internal_cost_hint,keywords,note) VALUES(?,?,?,?,?,?,?,?,?,?,?)');
    $stmt->execute([$_POST['category'],$_POST['service_name'],$_POST['description'],$_POST['unit'],$_POST['unit_price'],$_POST['default_quantity'],$_POST['working_time'],$_POST['vat_rate'],$_POST['internal_cost_hint'],$_POST['keywords'],$_POST['note']]);
  }
  redirect((strpos($_SERVER['HTTP_REFERER']??'', 'admin.php')!==false?'admin.php':'app.php').'?page=ratecard');
}
$items=$pdo->query('SELECT * FROM ratecard_items ORDER BY category, service_name')->fetchAll();
?>
<section class="card">
  <div class="card-head"><h2>Ratecard</h2><button class="primary" onclick="openSlideDrawer('ratecardDrawer')">+ Thêm ratecard</button></div>
  <table><thead><tr><th>Nhóm</th><th>Dịch vụ</th><th>Đơn vị</th><th>Giá bán</th><th>VAT</th><th>Cost hint</th><th>Keyword</th><th>Action</th></tr></thead><tbody>
  <?php foreach($items as $i): ?>
    <tr>
      <td><?= e($i['category']) ?></td>
      <td><b><?= e($i['service_name']) ?></b><br><span class="muted"><?= e($i['description']) ?></span></td>
      <td><?= e($i['unit']) ?></td><td><?= money($i['unit_price']) ?></td><td><?= (float)$i['vat_rate'] ?>%</td><td><?= money($i['internal_cost_hint']) ?></td><td><?= e($i['keywords']) ?></td>
      <td><a class="btn ratecard-edit-btn" href="<?= strpos($_SERVER['REQUEST_URI'],'admin.php')!==false?'admin.php':'app.php' ?>?page=ratecard&edit=<?= $i['id'] ?>">Edit</a></td>
    </tr>
  <?php endforeach; ?>
  </tbody></table>
</section>

<div id="drawerBackdrop" class="drawer-backdrop <?= $edit?'active':'' ?>" onclick="closeSlideDrawer('ratecardDrawer')"></div>
<div class="slide-drawer <?= $edit?'active':'' ?>" id="ratecardDrawer">
  <div class="drawer-form-header">
    <div><span class="eyebrow">Ratecard</span><h2><?= $edit?'Edit ratecard':'Thêm ratecard item' ?></h2></div>
    <button class="drawer-close-x" onclick="closeSlideDrawer('ratecardDrawer')" type="button">×</button>
  </div>
  <form method="post">
    <input type="hidden" name="ratecard_id" value="<?= e($edit['id']??'') ?>">
    <label>Nhóm</label><input name="category" required value="<?= e($edit['category']??'') ?>">
    <label>Dịch vụ</label><input name="service_name" required value="<?= e($edit['service_name']??'') ?>">
    <label>Mô tả</label><textarea name="description"><?= e($edit['description']??'') ?></textarea>
    <div class="form-row"><div><label>Đơn vị</label><input name="unit" value="<?= e($edit['unit']??'gói') ?>"></div><div><label>SL mặc định</label><input name="default_quantity" type="number" step="0.1" value="<?= e($edit['default_quantity']??1) ?>"></div></div>
    <div class="form-row"><div><label>Giá bán</label><input name="unit_price" type="number" required value="<?= e($edit['unit_price']??0) ?>"></div><div><label>VAT%</label><input name="vat_rate" type="number" value="<?= e($edit['vat_rate']??10) ?>"></div></div>
    <label>Thời gian</label><input name="working_time" value="<?= e($edit['working_time']??'') ?>">
    <label>Cost hint</label><input name="internal_cost_hint" type="number" value="<?= e($edit['internal_cost_hint']??0) ?>">
    <label>Keywords</label><input name="keywords" value="<?= e($edit['keywords']??'') ?>">
    <label>Note</label><textarea name="note"><?= e($edit['note']??'') ?></textarea>
    <button class="primary">Lưu</button>
  </form>
</div>
