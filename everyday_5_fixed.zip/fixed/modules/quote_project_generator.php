<?php
$me=current_user();
if(!is_director_role($me) && !is_finance_role($me) && !user_is_admin()){
  echo '<section class="card"><h2>Không có quyền truy cập</h2></section>'; return;
}
function qp_has_col($pdo,$table,$col){
  static $cache=[]; $k=$table.'.'.$col; if(isset($cache[$k])) return $cache[$k];
  try{ $st=$pdo->prepare("SHOW COLUMNS FROM `$table` LIKE ?"); $st->execute([$col]); return $cache[$k]=(bool)$st->fetch(); }catch(Exception $e){ return $cache[$k]=false; }
}
function qp_add_col($pdo,$table,$ddl){ try{ $pdo->exec("ALTER TABLE `$table` ADD COLUMN $ddl"); }catch(Exception $e){} }
try{
  qp_add_col($pdo,'quotations','project_id INT NULL');
  qp_add_col($pdo,'projects','quotation_id INT NULL');
  qp_add_col($pdo,'projects','contract_id INT NULL');
  qp_add_col($pdo,'tasks','quotation_item_id INT NULL');
  $pdo->exec("CREATE TABLE IF NOT EXISTS quotation_project_map(
    id INT AUTO_INCREMENT PRIMARY KEY,
    quotation_id INT NOT NULL,
    contract_id INT NULL,
    project_id INT NOT NULL,
    template_id INT NULL,
    created_by INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_quote_project (quotation_id,project_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  $pdo->exec("CREATE TABLE IF NOT EXISTS project_templates(
    id INT AUTO_INCREMENT PRIMARY KEY,
    template_name VARCHAR(190) NOT NULL,
    template_type VARCHAR(80) DEFAULT 'General',
    description TEXT NULL,
    is_active TINYINT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  $pdo->exec("CREATE TABLE IF NOT EXISTS project_template_tasks(
    id INT AUTO_INCREMENT PRIMARY KEY,
    template_id INT NOT NULL,
    sort_order INT DEFAULT 0,
    title VARCHAR(255) NOT NULL,
    phase VARCHAR(120) NULL,
    priority VARCHAR(80) DEFAULT 'Quan trọng',
    due_offset_days INT DEFAULT 3,
    assignee_role VARCHAR(80) NULL,
    brief TEXT NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}catch(Exception $e){}

try{
  $count=(int)$pdo->query("SELECT COUNT(*) FROM project_templates")->fetchColumn();
  if($count===0){
    $pdo->prepare("INSERT INTO project_templates(template_name,template_type,description) VALUES(?,?,?)")->execute(['Social Retainer','Social Media','Template mặc định cho quản trị social monthly retainer']);
    $tid=(int)$pdo->lastInsertId();
    $defaults=[
      ['Kickoff & nhận brief','Kickoff','Khẩn cấp làm ngay',1,'Chuẩn bị kickoff, nhận brief và xác nhận mục tiêu dự án.'],
      ['Content Plan','Planning','Làm ngay',3,'Lên content plan, angle, timeline và phân bổ nguồn lực.'],
      ['Production / Design','Production','Quan trọng',7,'Sản xuất nội dung theo từng hạng mục trong báo giá.'],
      ['Internal Review','Review','Quan trọng',10,'Review nội bộ trước khi gửi khách hàng.'],
      ['Client Approval','Client Approval','Làm ngay',12,'Gửi khách duyệt và xử lý feedback.'],
      ['Final Delivery & Report','Delivery','Quan trọng',30,'Bàn giao, tổng kết, báo cáo và nhắc payment.'],
    ];
    $i=1; foreach($defaults as $d){ $pdo->prepare("INSERT INTO project_template_tasks(template_id,sort_order,title,phase,priority,due_offset_days,brief) VALUES(?,?,?,?,?,?,?)")->execute([$tid,$i++,$d[0],$d[1],$d[2],$d[3],$d[4]]); }
  }
}catch(Exception $e){}

$selectedId=(int)($_GET['quotation_id'] ?? $_POST['quotation_id'] ?? 0);
$flash='';
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['generate_project'])){
  $qid=(int)$_POST['quotation_id'];
  $templateId=(int)($_POST['template_id'] ?? 0);
  $pmId=(int)($_POST['owner_id'] ?? 0) ?: null;
  $start=$_POST['start_date'] ?: date('Y-m-d');
  $end=$_POST['end_date'] ?: date('Y-m-d', strtotime($start.' +30 days'));
  $q=$pdo->prepare("SELECT * FROM quotations WHERE id=?"); $q->execute([$qid]); $quote=$q->fetch();
  if(!$quote){ $flash='Không tìm thấy báo giá.'; }
  else {
    $exists=null;
    try{ $st=$pdo->prepare("SELECT id FROM projects WHERE quotation_id=? LIMIT 1"); $st->execute([$qid]); $exists=$st->fetchColumn(); }catch(Exception $e){}
    if($exists){ redirect('app.php?page=project_detail&id='.$exists); }
    $name=trim($_POST['project_name'] ?: (($quote['client_name']??'Khách hàng').' | '.($quote['title']??($quote['quote_code']??'Project'))));
    $client=$quote['client_name'] ?? '';
    $objective=$quote['objective'] ?? ($quote['title'] ?? 'Dự án được khởi tạo từ báo giá');
    $desc='Tự động tạo từ báo giá '.($quote['quote_code']??('#'.$qid)).'.';
    $cols=['name','client_name','owner_id','project_type','health','start_date','end_date','progress','status','objective','deliverable_target','description'];
    $vals=[$name,$client,$pmId,$_POST['project_type'] ?? 'Production','On Track',$start,$end,0,'Planning',$objective,0,$desc];
    if(qp_has_col($pdo,'projects','quotation_id')){ $cols[]='quotation_id'; $vals[]=$qid; }
    if(qp_has_col($pdo,'projects','contract_id') && !empty($_POST['contract_id'])){ $cols[]='contract_id'; $vals[]=(int)$_POST['contract_id']; }
    $sql='INSERT INTO projects('.implode(',',$cols).') VALUES('.implode(',',array_fill(0,count($cols),'?')).')';
    $pdo->prepare($sql)->execute($vals);
    $pid=(int)$pdo->lastInsertId();
    try{ $pdo->prepare('UPDATE quotations SET project_id=?, status=CASE WHEN status IN ("Contract Signed","Completed") THEN status ELSE "Contract Signed" END WHERE id=?')->execute([$pid,$qid]); }catch(Exception $e){}
    try{ $pdo->prepare('INSERT IGNORE INTO quotation_project_map(quotation_id,contract_id,project_id,template_id,created_by) VALUES(?,?,?,?,?)')->execute([$qid,($_POST['contract_id']?:null),$pid,($templateId?:null),$me['id']]); }catch(Exception $e){}
    $items=[];
    try{ $st=$pdo->prepare('SELECT * FROM quotation_items WHERE quotation_id=? ORDER BY sort_order,id'); $st->execute([$qid]); $items=$st->fetchAll(); }catch(Exception $e){}
    $base=strtotime($start); $totalItems=max(1,count($items)); $i=0;
    foreach($items as $it){
      $i++; $offset=max(1,ceil(($i/$totalItems)*max(7,(strtotime($end)-$base)/86400)));
      $deadline=date('Y-m-d', strtotime($start.' +'.$offset.' days'));
      $title=$it['service_name'] ?? ($it['item_name'] ?? ('Hạng mục '.$i));
      $brief=trim(($it['description']??'')."\n\nSố lượng: ".($it['quantity']??1).' '.($it['unit']??''));
      $cols=['project_id','title','assignee_id','priority','start_date','deadline','status','phase','brief','deliverable','deliverable_type','deliverable_count','created_by'];
      $vals=[$pid,$title,$pmId,'Quan trọng',$start,$deadline,'Todo','Deliverable',$brief,1,$it['unit']??'item',(int)ceil((float)($it['quantity']??1)),$me['id']];
      if(qp_has_col($pdo,'tasks','quotation_item_id')){ $cols[]='quotation_item_id'; $vals[]=(int)$it['id']; }
      try{ $pdo->prepare('INSERT INTO tasks('.implode(',',$cols).') VALUES('.implode(',',array_fill(0,count($cols),'?')).')')->execute($vals); }catch(Exception $e){}
    }
    if($templateId){
      $ts=$pdo->prepare('SELECT * FROM project_template_tasks WHERE template_id=? ORDER BY sort_order,id'); $ts->execute([$templateId]);
      foreach($ts->fetchAll() as $tt){
        $deadline=date('Y-m-d', strtotime($start.' +'.(int)$tt['due_offset_days'].' days'));
        $cols=['project_id','title','assignee_id','priority','start_date','deadline','status','phase','brief','created_by'];
        $vals=[$pid,$tt['title'],$pmId,$tt['priority'] ?: 'Quan trọng',$start,$deadline,'Todo',$tt['phase'] ?: 'Milestone',$tt['brief'] ?: '',$me['id']];
        try{ $pdo->prepare('INSERT INTO tasks('.implode(',',$cols).') VALUES('.implode(',',array_fill(0,count($cols),'?')).')')->execute($vals); }catch(Exception $e){}
      }
    }
    log_activity($pdo,'generate','project',$pid,'Generate project từ báo giá #'.$qid);
    redirect('app.php?page=project_detail&id='.$pid.'&generated=1');
  }
}

$quotes=safe_rows($pdo,"SELECT q.*, (SELECT COUNT(*) FROM quotation_items qi WHERE qi.quotation_id=q.id) item_count FROM quotations q ORDER BY q.id DESC LIMIT 300");
$templates=safe_rows($pdo,"SELECT * FROM project_templates WHERE is_active=1 ORDER BY template_name");
$users=safe_rows($pdo,"SELECT id,name FROM users ORDER BY name");
$contracts=safe_rows($pdo,"SELECT id,contract_code,client_name FROM contracts ORDER BY id DESC LIMIT 200");
$selected=null; $items=[];
if($selectedId){
  $st=$pdo->prepare('SELECT * FROM quotations WHERE id=?'); $st->execute([$selectedId]); $selected=$st->fetch();
  $it=$pdo->prepare('SELECT * FROM quotation_items WHERE quotation_id=? ORDER BY sort_order,id'); $it->execute([$selectedId]); $items=$it->fetchAll();
}
?>
<section class="card quote-project-hero">
  <div class="card-head">
    <div><span class="eyebrow">Sprint 4</span><h2>Quote → Contract → Project Automation</h2><p class="muted">Tạo project và task tự động từ báo giá đã duyệt/ký hợp đồng. Không còn tạo project thủ công sau khi khách đồng ý.</p></div>
    <a class="btn btn-soft" href="app.php?page=project_templates">Quản lý template</a>
  </div>
  <?php if($flash): ?><div class="flash"><?= e($flash) ?></div><?php endif; ?>
  <form method="get" class="asana-toolbar">
    <input type="hidden" name="page" value="quote_project_generator">
    <select name="quotation_id" onchange="this.form.submit()">
      <option value="">Chọn báo giá để generate project</option>
      <?php foreach($quotes as $q): ?><option value="<?= $q['id'] ?>" <?= $selectedId===$q['id']?'selected':'' ?>><?= e(($q['quote_code']??('#'.$q['id'])).' · '.($q['client_name']??'').' · '.($q['title']??'').' · '.($q['item_count']??0).' items') ?></option><?php endforeach; ?>
    </select>
  </form>
</section>

<?php if($selected): ?>
<section class="two-col quote-project-grid">
  <div class="card">
    <div class="card-head"><div><span class="eyebrow">Preview</span><h2><?= e($selected['quote_code'] ?? ('Quotation #'.$selectedId)) ?></h2><p class="muted"><?= e($selected['client_name'] ?? '') ?> · <?= e($selected['status'] ?? '') ?></p></div></div>
    <table class="dense-table mobile-card-table"><thead><tr><th>#</th><th>Hạng mục</th><th>SL</th><th>Giá trị</th></tr></thead><tbody>
      <?php foreach($items as $i=>$it): ?><tr><td data-label="#"><?= $i+1 ?></td><td data-label="Hạng mục"><b><?= e($it['service_name'] ?? ($it['item_name'] ?? 'Hạng mục')) ?></b><br><span class="muted"><?= e(mb_substr($it['description']??'',0,110)) ?></span></td><td data-label="SL"><?= e(($it['quantity']??1).' '.($it['unit']??'')) ?></td><td data-label="Giá trị"><?= number_format((float)($it['total']??0),0,',','.') ?>đ</td></tr><?php endforeach; ?>
    </tbody></table>
  </div>
  <div class="card">
    <div class="card-head"><div><span class="eyebrow">Generate</span><h2>Khởi tạo dự án</h2></div></div>
    <form method="post">
      <input type="hidden" name="quotation_id" value="<?= (int)$selectedId ?>">
      <label>Tên project</label><input name="project_name" value="<?= e(($selected['client_name']??'').' | '.($selected['title']??($selected['quote_code']??''))) ?>">
      <label>Contract liên quan</label><select name="contract_id"><option value="">Chưa gắn hợp đồng</option><?php foreach($contracts as $c): ?><option value="<?= $c['id'] ?>"><?= e(($c['contract_code']??'#'.$c['id']).' · '.$c['client_name']) ?></option><?php endforeach; ?></select>
      <div class="form-row"><div><label>PM / Owner</label><select name="owner_id"><option value="">Chọn PM</option><?php foreach($users as $u): ?><option value="<?= $u['id'] ?>"><?= e($u['name']) ?></option><?php endforeach; ?></select></div><div><label>Project Type</label><select name="project_type"><option>Production</option><option>Social Media</option><option>Performance</option><option>Event</option><option>Website</option><option>Internal</option></select></div></div>
      <div class="form-row"><div><label>Start</label><input type="date" name="start_date" value="<?= date('Y-m-d') ?>"></div><div><label>End</label><input type="date" name="end_date" value="<?= date('Y-m-d',strtotime('+30 days')) ?>"></div></div>
      <label>Template milestone</label><select name="template_id"><option value="">Chỉ tạo task từ hạng mục báo giá</option><?php foreach($templates as $t): ?><option value="<?= $t['id'] ?>"><?= e($t['template_name'].' · '.$t['template_type']) ?></option><?php endforeach; ?></select>
      <button class="primary" name="generate_project" value="1">🚀 Generate Project + Tasks</button>
    </form>
  </div>
</section>
<?php endif; ?>
