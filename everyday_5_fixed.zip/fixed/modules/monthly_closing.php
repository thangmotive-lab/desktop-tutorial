<?php
if(!can_view_business_finance()) die('Bạn không có quyền xem Thángly Closing.');
$month=$_GET['month'] ?? date('Y-m');
$m=finance_metrics($pdo,$month);
function closing_num($n){ return number_format((float)$n,0,',','.'); }

if($_SERVER['REQUEST_METHOD']==='POST'){
  $status=$_POST['status'] ?? 'closed';
  $pdo->prepare('INSERT INTO monthly_closings(closing_month,revenue_total,collected_total,receivable_total,internal_cost_total,payroll_total,expense_total,gross_profit,net_profit,status,closed_by,closed_at,note)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
    ON DUPLICATE KEY UPDATE revenue_total=VALUES(revenue_total), collected_total=VALUES(collected_total), receivable_total=VALUES(receivable_total), internal_cost_total=VALUES(internal_cost_total), payroll_total=VALUES(payroll_total), expense_total=VALUES(expense_total), gross_profit=VALUES(gross_profit), net_profit=VALUES(net_profit), status=VALUES(status), closed_by=VALUES(closed_by), closed_at=VALUES(closed_at), note=VALUES(note)')
    ->execute([$month,$m['revenue_total'],$m['collected_total'],$m['receivable_total'],$m['internal_cost_total'],$m['payroll_total'],$m['expense_total'],$m['gross_profit'],$m['net_profit'],$status,current_user()['id'],date('Y-m-d H:i:s'),$_POST['note'] ?? '']);
  log_activity($pdo,'monthly_closing','finance',$month,'Chốt tháng '.$month);
  redirect('app.php?page=monthly_closing&month='.$month.'&saved=1');
}

$stmt=$pdo->prepare('SELECT mc.*,u.name closed_by_name FROM monthly_closings mc LEFT JOIN users u ON u.id=mc.closed_by WHERE mc.closing_month=? LIMIT 1');
$stmt->execute([$month]);
$closing=$stmt->fetch();

$history=$pdo->query('SELECT mc.*,u.name closed_by_name FROM monthly_closings mc LEFT JOIN users u ON u.id=mc.closed_by ORDER BY mc.closing_month DESC LIMIT 18')->fetchAll();
?>
<section class="workspace-hero finance-hero">
  <div>
    <span class="eyebrow">Thángly Closing</span>
    <h1>Chốt tháng <?= e($month) ?></h1>
    <p class="muted">Khóa snapshot doanh thu, đã thu, chờ thu, chi phí và profit vào ngày 30 hàng tháng.</p>
  </div>
  <form method="get"><input type="hidden" name="page" value="monthly_closing"><input type="month" name="month" value="<?= e($month) ?>"><button class="btn btn-soft">Xem</button></form>
</section>
<?php if(!empty($_GET['saved'])): ?><div class="alert success">Đã lưu closing tháng <?= e($month) ?>.</div><?php endif; ?>

<div class="stats-grid finance-stats">
  <div class="stat coral"><span>Doanh thu</span><strong><?= money_short($m['revenue_total']) ?></strong></div>
  <div class="stat mint"><span>Đã thu</span><strong><?= money_short($m['collected_total']) ?></strong></div>
  <div class="stat yellow"><span>Chờ thu</span><strong><?= money_short($m['receivable_total']) ?></strong></div>
  <div class="stat purple"><span>Chi phí nội bộ</span><strong><?= money_short($m['internal_cost_total']) ?></strong></div>
  <div class="stat coral"><span>Lương nhân sự</span><strong><?= money_short($m['payroll_total']) ?></strong></div>
  <div class="stat mint"><span>Lợi nhuận ròng</span><strong><?= money_short($m['net_profit']) ?></strong></div>
</div>

<div class="two-col">
<section class="card">
  <div class="card-head"><h2>Tổng hợp chốt tháng</h2></div>
  <form method="post">
    <div class="finance-waterfall">
      <div><span>Doanh thu</span><b><?= closing_num($m['revenue_total']) ?></b></div>
      <div><span>Đã thu</span><b><?= closing_num($m['collected_total']) ?></b></div>
      <div><span>Chờ thu</span><b><?= closing_num($m['receivable_total']) ?></b></div>
      <div><span>Chi phí nội bộ</span><b><?= closing_num($m['internal_cost_total']) ?></b></div>
      <div><span>Lương nhân sự</span><b><?= closing_num($m['payroll_total']) ?></b></div>
      <div><span>Chi phí doanh nghiệp</span><b><?= closing_num($m['expense_total']) ?></b></div>
      <div><span>Lợi nhuận gộp</span><b><?= closing_num($m['gross_profit']) ?></b></div>
      <div class="final"><span>Lợi nhuận ròng</span><b><?= closing_num($m['net_profit']) ?></b></div>
    </div>
    <label>Trạng thái</label><select name="status"><option value="draft">draft</option><option value="closed" selected>closed</option><option value="reopened">reopened</option></select>
    <label>Note</label><textarea name="note"><?= e($closing['note'] ?? '') ?></textarea>
    <button class="primary">Chốt / cập nhật tháng này</button>
  </form>
</section>

<section class="card">
  <div class="card-head"><h2>Trạng thái hiện tại</h2></div>
  <?php if($closing): ?>
    <table class="dense-table"><tbody>
      <tr><th>Tháng</th><td><?= e($closing['closing_month']) ?></td></tr>
      <tr><th>Trạng thái</th><td><span class="badge <?= badge_class($closing['status']) ?>"><?= e($closing['status']) ?></span></td></tr>
      <tr><th>Người chốt</th><td><?= e($closing['closed_by_name']) ?></td></tr>
      <tr><th>Thời gian chốt</th><td><?= e($closing['closed_at']) ?></td></tr>
      <tr><th>Lợi nhuận ròng</th><td><b><?= closing_num($closing['net_profit']) ?></b></td></tr>
    </tbody></table>
  <?php else: ?>
    <p class="muted">Tháng này chưa được chốt.</p>
  <?php endif; ?>
</section>
</div>

<section class="card">
  <div class="card-head"><h2>Lịch sử closing</h2></div>
  <table class="dense-table">
    <thead><tr><th>Tháng</th><th>Doanh thu</th><th>Đã thu</th><th>Chờ thu</th><th>Expense+Lương nhân sự</th><th>Lợi nhuận ròng</th><th>Trạng thái</th><th>Người chốt</th></tr></thead>
    <tbody>
    <?php foreach($history as $h): ?>
      <tr><td><b><?= e($h['closing_month']) ?></b></td><td><?= closing_num($h['revenue_total']) ?></td><td><?= closing_num($h['collected_total']) ?></td><td><?= closing_num($h['receivable_total']) ?></td><td><?= closing_num($h['expense_total']+$h['payroll_total']) ?></td><td><b><?= closing_num($h['net_profit']) ?></b></td><td><span class="badge <?= badge_class($h['status']) ?>"><?= e($h['status']) ?></span></td><td><?= e($h['closed_by_name']) ?></td></tr>
    <?php endforeach; ?>
    <?php if(empty($history)): ?><tr><td colspan="8" class="muted">Chưa có lịch sử closing.</td></tr><?php endif; ?>
    </tbody>
  </table>
</section>
