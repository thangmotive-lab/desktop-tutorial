<?php
$me=current_user();
if($_SERVER['REQUEST_METHOD']==='POST'){
  $message=trim($_POST['message']??'');
  if($message!==''){
    $stmt=$pdo->prepare('INSERT INTO group_messages(user_id,message) VALUES(?,?)');
    $stmt->execute([$me['id'],$message]);
    foreach($pdo->query("SELECT id FROM users WHERE status='active' AND id!=".(int)$me['id']) as $u){
      create_notification($pdo,$u['id'],'Tin nhắn nhóm mới',$me['name'].': '.mb_substr($message,0,80,'UTF-8'),'chat','app.php?page=chat');
    }
  }
  redirect('app.php?page=chat');
}
$messages=$pdo->query('SELECT gm.*,u.name,u.avatar FROM group_messages gm JOIN users u ON u.id=gm.user_id ORDER BY gm.id DESC LIMIT 80')->fetchAll();
$messages=array_reverse($messages);
?>
<section class="chat-shell" data-aos="fade-up"><div class="chat-bg-orb orb-one"></div><div class="chat-bg-orb orb-two"></div><div class="card chat-card glass-chat">
  <div class="card-head">
    <div><span class="eyebrow">Team Chat</span><h2>Chat nhóm Motive</h2></div>
  </div>
  <div class="chat-window">
    <?php foreach($messages as $m): ?>
      <div class="chat-message <?= $m['user_id']==$me['id']?'mine':'' ?>">
        <?= avatar_html($m,true) ?>
        <div class="chat-bubble">
          <b><?= e($m['name']) ?></b>
          <p><?= nl2br(e($m['message'])) ?></p>
          <span><?= e($m['created_at']) ?></span>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
  <form method="post" class="chat-form">
    <input name="message" placeholder="Nhắn gì đó cho team..." autocomplete="off">
    <button class="primary">Gửi</button>
  </form>
</div></section>
