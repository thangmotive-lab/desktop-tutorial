<?php
if(!is_director_role() && !is_finance_role()) die('Bạn không có quyền xem Revenue Overview.');
$month=$_GET['month'] ?? date('Y-m');

$paid=safe_sum($pdo,"SELECT COALESCE(SUM(amount),0) FROM payment_schedules WHERE status='paid' AND DATE_FORMAT(COALESCE(paid_date,updated_at,created_at),'%Y-%m')=".quote_sql($month));
$expectedSigned=safe_sum($pdo,"SELECT COALESCE(SUM(total_value),0) FROM contracts WHERE DATE_FORMAT(COALESCE(signed_date,created_at),'%Y-%m')=".quote_sql($month));
$agreedNotSigned=safe_sum($pdo,"SELECT COALESCE(SUM(expected_revenue),0) FROM quotations q WHERE q.contract_status='client_agreed' AND NOT EXISTS(SELECT 1 FROM contracts c WHERE c.quotation_id=q.id) AND DATE_FORMAT(COALESCE(q.won_at,q.quote_date,q.created_at),'%Y-%m')=".quote_sql($month));
$potential=safe_sum($pdo,"SELECT COALESCE(SUM(expected_revenue),0) FROM quotations q WHERE q.status IN ('Sent','Feedback','Pending') AND DATE_FORMAT(COALESCE(q.quote_date,q.created_at),'%Y-%m')=".quote_sql($month));
$overdue=safe_sum($pdo,"SELECT COALESCE(SUM(amount),0) FROM payment_schedules WHERE status!='paid' AND due_date < CURDATE()");

$contracts=safe_rows($pdo,"SELECT contract_code,client_name,total_value,signed_date,status FROM contracts WHERE DATE_FORMAT(COALESCE(signed_date,created_at),'%Y-%m')=".quote_sql($month)." ORDER BY total_value DESC LIMIT 20");
$agreed=safe_rows($pdo,"SELECT quote_code,client_name,title,expected_revenue,quote_date,expired_at,status FROM quotations q WHERE q.contract_status='client_agreed' AND NOT EXISTS(SELECT 1 FROM contracts c WHERE c.quotation_id=q.id) ORDER BY expected_revenue DESC LIMIT 20");
$openQuotes=safe_rows($pdo,"SELECT quote_code,client_name,title,expected_revenue,quote_date,expired_at,status FROM quotations WHERE status IN ('Sent','Feedback','Pending') ORDER BY expected_revenue DESC LIMIT 20");

function quote_sql($v){ return "'".str_replace("'","''",$v)."'"; }
?>
<section class="workspace-hero finance-hero">
  <div>
    <span class="eyebrow">Business Logic</span>
    <h1>Revenue Overview</h1>
    <p class="muted">Phân biệt rõ: báo giá khả quan → khách đồng ý → hợp đồng → thanh toán → doanh thu đã cầm về.</p>
  </div>
</section>

<form method="get" class="asana-toolbar">
  <input type="hidden" name="page" value="revenue_overview">
  <input type="month" name="month" value="<?= e($month) ?>">
  <button class="primary">Xem tháng</button>
</form>

<div class="stats-grid compact-stats">
  <div class="stat mint"><span>Đã cầm về</span><strong><?= money($paid) ?></strong></div>
  <div class="stat coral"><span>Hợp đồng đã ký</span><strong><?= money($expectedSigned) ?></strong></div>
  <div class="stat yellow"><span>Đã đồng ý, chưa ký</span><strong><?= money($agreedNotSigned) ?></strong></div>
  <div class="stat purple"><span>Báo giá khả quan</span><strong><?= money($potential) ?></strong></div>
  <div class="stat red"><span>Quá hạn thu</span><strong><?= money($overdue) ?></strong></div>
</div>

<div class="two-col">
<section class="card">
  <div class="card-head"><h2>Hợp đồng đã ký</h2></div>
  <table class="dense-table"><thead><tr><th>Mã</th><th>Khách</th><th>Giá trị</th><th>Ngày ký</th><th>Status</th></tr></thead><tbody>
  <?php foreach($contracts as $r): ?><tr><td><b><?= e($r['contract_code']) ?></b></td><td><?= e($r['client_name']) ?></td><td><?= money($r['total_value']) ?></td><td><?= e($r['signed_date']) ?></td><td><?= e($r['status']) ?></td></tr><?php endforeach; ?>
  <?php if(empty($contracts)): ?><tr><td colspan="5" class="muted">Chưa có hợp đồng.</td></tr><?php endif; ?>
  </tbody></table>
</section>

<section class="card">
  <div class="card-head"><h2>Khách đồng ý, chưa ký HĐ</h2></div>
  <table class="dense-table"><thead><tr><th>Mã BG</th><th>Khách</th><th>Giá trị dự kiến</th><th>Ngày BG</th><th>Hết hạn</th></tr></thead><tbody>
  <?php foreach($agreed as $r): ?><tr><td><b><?= e($r['quote_code']) ?></b></td><td><?= e($r['client_name']) ?></td><td><?= money($r['expected_revenue']) ?></td><td><?= e($r['quote_date']) ?></td><td><?= e($r['expired_at']) ?></td></tr><?php endforeach; ?>
  <?php if(empty($agreed)): ?><tr><td colspan="5" class="muted">Không có báo giá đang chờ ký.</td></tr><?php endif; ?>
  </tbody></table>
</section>
</div>

<section class="card">
  <div class="card-head"><h2>Báo giá khả quan / đang follow</h2></div>
  <table class="dense-table"><thead><tr><th>Mã BG</th><th>Khách</th><th>Tiêu đề</th><th>Giá trị dự kiến</th><th>Status</th><th>Hết hạn</th></tr></thead><tbody>
  <?php foreach($openQuotes as $r): ?><tr><td><b><?= e($r['quote_code']) ?></b></td><td><?= e($r['client_name']) ?></td><td><?= e($r['title']) ?></td><td><?= money($r['expected_revenue']) ?></td><td><?= e($r['status']) ?></td><td><?= e($r['expired_at']) ?></td></tr><?php endforeach; ?>
  <?php if(empty($openQuotes)): ?><tr><td colspan="6" class="muted">Không có báo giá khả quan.</td></tr><?php endif; ?>
  </tbody></table>
</section>
