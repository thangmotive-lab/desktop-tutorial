<?php
$months=(int)($_GET['months'] ?? 6);
if(!in_array($months,[3,6,12],true)) $months=6;

$startMonth=date('Y-m-01');
$endMonth=date('Y-m-t',strtotime("+".($months-1)." months",strtotime($startMonth)));

$expected=0;$collected=0;$gap=0;
$monthRows=[];

// Try to read payment_schedules with flexible columns.
try{
  $rows=safe_rows($pdo,"SELECT ps.*,q.code quotation_code,q.client_name q_client,c.contract_code,c.client_name c_client
    FROM payment_schedules ps
    LEFT JOIN quotations q ON q.id=ps.quotation_id
    LEFT JOIN contracts c ON c.id=ps.contract_id
    WHERE DATE(COALESCE(ps.due_date,ps.payment_date,ps.created_at)) BETWEEN '$startMonth' AND '$endMonth'
    ORDER BY COALESCE(ps.due_date,ps.payment_date,ps.created_at) ASC");
}catch(Exception $e){
  $rows=[];
}

$byMonth=[];
for($i=0;$i<$months;$i++){
  $m=date('Y-m',strtotime("+$i months",strtotime($startMonth)));
  $byMonth[$m]=['month'=>$m,'expected'=>0,'collected'=>0,'gap'=>0,'items'=>[]];
}

foreach($rows as $r){
  $date=$r['due_date'] ?? $r['payment_date'] ?? $r['created_at'] ?? date('Y-m-d');
  $m=date('Y-m',strtotime($date));
  if(!isset($byMonth[$m])) continue;
  $amount=(float)($r['amount'] ?? $r['payment_amount'] ?? $r['value'] ?? 0);
  $status=strtolower($r['status'] ?? $r['payment_status'] ?? '');
  $isPaid=in_array($status,['paid','collected','done','đã thu','da thu','completed','received'],true) || !empty($r['paid_at']);
  $byMonth[$m]['expected'] += $amount;
  if($isPaid) $byMonth[$m]['collected'] += $amount;
  $byMonth[$m]['items'][]=$r + ['_amount'=>$amount,'_paid'=>$isPaid,'_date'=>$date];
}
foreach($byMonth as $m=>$row){
  $byMonth[$m]['gap']=max(0,$row['expected']-$row['collected']);
  $expected += $row['expected'];
  $collected += $row['collected'];
}
$gap=max(0,$expected-$collected);
function money_m($v){ return round(((float)$v)/1000000).'M'; }
?>
<section class="workspace-hero finance-hero cash-forecast-hero">
  <div>
    <span class="eyebrow">Cash Forecast</span>
    <h1>Dự báo dòng tiền</h1>
    <p class="muted">Theo dõi tiền dự kiến thu, đã thu và khoảng gap còn lại trong các tháng tới.</p>
  </div>
  <form method="get" class="finance-month-form">
    <input type="hidden" name="page" value="cash_forecast">
    <select name="months">
      <option value="3" <?= $months===3?'selected':'' ?>>3 tháng</option>
      <option value="6" <?= $months===6?'selected':'' ?>>6 tháng</option>
      <option value="12" <?= $months===12?'selected':'' ?>>12 tháng</option>
    </select>
    <button class="btn btn-soft">Xem</button>
  </form>
</section>

<div class="stats-grid compact-stats">
  <div class="stat yellow"><span>Expected</span><strong><?= money_m($expected) ?></strong></div>
  <div class="stat mint"><span>Collected</span><strong><?= money_m($collected) ?></strong></div>
  <div class="stat coral"><span>Gap</span><strong><?= money_m($gap) ?></strong></div>
</div>

<section class="card">
  <div class="card-head">
    <div><h2>Forecast theo tháng</h2><p class="muted">Tổng hợp payment schedule theo tháng.</p></div>
    <a class="btn btn-soft" href="app.php?page=payments">Payment Schedule</a>
  </div>
  <div class="cash-month-grid">
    <?php foreach($byMonth as $m=>$row): ?>
      <div class="cash-month-card">
        <span><?= date('m/Y',strtotime($m.'-01')) ?></span>
        <strong><?= money_m($row['expected']) ?></strong>
        <small>Đã thu <?= money_m($row['collected']) ?> · Gap <?= money_m($row['gap']) ?></small>
      </div>
    <?php endforeach; ?>
  </div>
</section>

<section class="card">
  <div class="card-head"><h2>Khoản thu sắp tới</h2></div>
  <table class="dense-table">
    <thead><tr><th>Ngày</th><th>Client / HĐ</th><th>Giá trị</th><th>Status</th></tr></thead>
    <tbody>
    <?php foreach($rows as $r): ?>
      <tr>
        <td><?= e($r['_date']) ?></td>
        <td><b><?= e($r['q_client'] ?? $r['c_client'] ?? $r['client_name'] ?? '-') ?></b><br><span class="muted"><?= e($r['quotation_code'] ?? $r['contract_code'] ?? $r['note'] ?? '') ?></span></td>
        <td><b><?= money_m($r['_amount']) ?></b></td>
        <td><span class="badge <?= $r['_paid']?'green':'orange' ?>"><?= $r['_paid']?'Đã thu':'Chờ thu' ?></span></td>
      </tr>
    <?php endforeach; ?>
    <?php if(empty($rows)): ?><tr><td colspan="4" class="muted">Chưa có payment schedule trong kỳ này.</td></tr><?php endif; ?>
    </tbody>
  </table>
</section>
