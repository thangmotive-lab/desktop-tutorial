<section class="card">
  <div class="card-head"><h2>Google Drive Integration</h2></div>
  <p class="muted">Có thể liên kết Google Drive bằng API, nhưng cần cấu hình OAuth từ Google Cloud của tài khoản Motive.</p>
  <div class="summary-box">
    <div class="row"><span>Trạng thái MVP</span><b>Link-based</b></div>
    <div class="row"><span>Bước cần có</span><b>Google OAuth Client ID / Secret</b></div>
    <div class="row"><span>Quyền cần xin</span><b>Drive file picker / readonly hoặc file create</b></div>
  </div>
</section>
<section class="card">
  <h2>Roadmap kết nối Drive</h2>
  <table>
    <thead><tr><th>Bước</th><th>Mô tả</th><th>Trạng thái</th></tr></thead>
    <tbody>
      <tr><td>1</td><td>Tạo Google Cloud Project và OAuth Consent Screen</td><td><span class="badge orange">Cần bạn cấp</span></td></tr>
      <tr><td>2</td><td>Lấy Client ID / Client Secret</td><td><span class="badge orange">Cần config</span></td></tr>
      <tr><td>3</td><td>Cho phép user chọn file/folder Drive ngay trong task/project</td><td><span class="badge purple">Phase sau</span></td></tr>
      <tr><td>4</td><td>Tự tạo folder project từ quotation/contract</td><td><span class="badge purple">Phase sau</span></td></tr>
    </tbody>
  </table>
</section>
