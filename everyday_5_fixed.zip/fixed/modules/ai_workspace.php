<?php
if(!is_director_role() && !is_finance_role()) die('Bạn không có quyền xem AI Workspace.');

$knowledgeCount=(int)safe_sum($pdo,"SELECT COUNT(*) FROM ai_knowledge_base WHERE is_active=1");
$templateCount=(int)safe_sum($pdo,"SELECT COUNT(*) FROM document_templates WHERE is_active=1");
$generatedCount=(int)safe_sum($pdo,"SELECT COUNT(*) FROM generated_documents");
$promptCount=(int)safe_sum($pdo,"SELECT COUNT(*) FROM ai_prompt_studio WHERE is_active=1");

$recentDocs=safe_rows($pdo,"SELECT gd.*,dt.template_name,u.name user_name FROM generated_documents gd LEFT JOIN document_templates dt ON dt.id=gd.template_id LEFT JOIN users u ON u.id=gd.created_by ORDER BY gd.id DESC LIMIT 8");
$recentKb=safe_rows($pdo,"SELECT kb.*,u.name user_name FROM ai_knowledge_base kb LEFT JOIN users u ON u.id=kb.updated_by ORDER BY kb.updated_at DESC LIMIT 8");
$prompts=safe_rows($pdo,"SELECT * FROM ai_prompt_studio WHERE is_active=1 ORDER BY usage_count DESC, updated_at DESC LIMIT 8");
$templates=safe_rows($pdo,"SELECT * FROM document_templates WHERE is_active=1 ORDER BY updated_at DESC, id DESC LIMIT 8");
?>
<section class="workspace-hero ai-workspace-hero">
  <div>
    <span class="eyebrow">AI Workspace</span>
    <h1>AI Operating System</h1>
    <p class="muted">Một nơi duy nhất cho Knowledge Base, Document Library, Generate Center và Prompt Studio.</p>
  </div>
  <div class="actions">
    <a class="btn btn-soft" href="app.php?page=ai_generate_center">Generate</a>
    <a class="primary" href="app.php?page=ai_knowledge_base">+ Knowledge</a>
  </div>
</section>

<div class="stats-grid compact-stats ai-kpi-grid">
  <a class="stat purple" href="app.php?page=ai_knowledge_base"><span>Knowledge Records</span><strong><?= $knowledgeCount ?></strong></a>
  <a class="stat mint" href="app.php?page=ai_document_library"><span>Document Templates</span><strong><?= $templateCount ?></strong></a>
  <a class="stat coral" href="app.php?page=ai_generate_center"><span>Generated Files</span><strong><?= $generatedCount ?></strong></a>
  <a class="stat yellow" href="app.php?page=ai_prompt_studio"><span>Prompts</span><strong><?= $promptCount ?></strong></a>
</div>

<div class="ai-workspace-grid">
  <section class="card">
    <div class="card-head"><h2>Recent Generated Documents</h2><a class="btn btn-soft" href="app.php?page=doc_generate">Generate DOCX</a></div>
    <table class="dense-table"><thead><tr><th>Document</th><th>Type</th><th>By</th><th>Action</th></tr></thead><tbody>
      <?php foreach($recentDocs as $d): ?>
        <tr><td><b><?= e($d['document_code']) ?></b><br><span class="muted"><?= e($d['title']) ?></span></td><td><?= e($d['document_type']) ?></td><td><?= e($d['user_name']) ?></td><td><?php if($d['docx_path']): ?><a class="btn btn-soft" href="<?= e($d['docx_path']) ?>" target="_blank">DOCX</a><?php endif; ?></td></tr>
      <?php endforeach; ?>
      <?php if(empty($recentDocs)): ?><tr><td colspan="4" class="muted">Chưa có document.</td></tr><?php endif; ?>
    </tbody></table>
  </section>

  <section class="card">
    <div class="card-head"><h2>Recent Knowledge</h2><a class="btn btn-soft" href="app.php?page=ai_knowledge_base">Knowledge Base</a></div>
    <table class="dense-table"><thead><tr><th>Title</th><th>Category</th><th>Version</th></tr></thead><tbody>
      <?php foreach($recentKb as $k): ?>
        <tr><td><b><?= e($k['title']) ?></b><br><span class="muted"><?= e($k['tags']) ?></span></td><td><?= e($k['category']) ?></td><td><?= e($k['version']) ?></td></tr>
      <?php endforeach; ?>
      <?php if(empty($recentKb)): ?><tr><td colspan="3" class="muted">Chưa có knowledge.</td></tr><?php endif; ?>
    </tbody></table>
  </section>

  <section class="card">
    <div class="card-head"><h2>Top Prompts</h2><a class="btn btn-soft" href="app.php?page=ai_prompt_studio">Prompt Studio</a></div>
    <table class="dense-table"><thead><tr><th>Prompt</th><th>Category</th><th>Version</th></tr></thead><tbody>
      <?php foreach($prompts as $p): ?>
        <tr><td><b><?= e($p['prompt_name']) ?></b></td><td><?= e($p['category']) ?></td><td><?= e($p['version']) ?></td></tr>
      <?php endforeach; ?>
      <?php if(empty($prompts)): ?><tr><td colspan="3" class="muted">Chưa có prompt.</td></tr><?php endif; ?>
    </tbody></table>
  </section>

  <section class="card">
    <div class="card-head"><h2>Document Library</h2><a class="btn btn-soft" href="app.php?page=ai_document_library">Open Library</a></div>
    <table class="dense-table"><thead><tr><th>Template</th><th>Type</th><th>Code</th></tr></thead><tbody>
      <?php foreach($templates as $t): ?>
        <tr><td><b><?= e($t['template_name']) ?></b></td><td><?= e($t['library_type'] ?: $t['document_type']) ?></td><td><?= e($t['template_code']) ?></td></tr>
      <?php endforeach; ?>
      <?php if(empty($templates)): ?><tr><td colspan="3" class="muted">Chưa có template.</td></tr><?php endif; ?>
    </tbody></table>
  </section>
</div>
