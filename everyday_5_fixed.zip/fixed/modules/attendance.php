<?php
$me=current_user();
sprint31_ensure_schema($pdo);
$settings=sprint31_workday_settings($pdo);
$month=$_GET['month'] ?? date('Y-m');
[$start,$end]=sprint31_month_bounds($month);

if($_SERVER['REQUEST_METHOD']==='POST'){
  if(isset($_POST['save_settings']) && (user_is_admin() || is_finance_role($me))){
    $keys=['full_day_minutes','three_quarter_day_minutes','half_day_minutes','quarter_day_minutes','standard_start_time','standard_end_time','late_grace_minutes'];
    $st=$pdo->prepare("INSERT INTO workday_settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)");
    foreach($keys as $k){ $st->execute([$k, trim((string)($_POST[$k] ?? ''))]); }
    redirect('app.php?page=attendance&month='.urlencode($month));
  }

  $today=date('Y-m-d'); $now=date('H:i:s');
  $stmt=$pdo->prepare('SELECT * FROM attendance WHERE user_id=? AND work_date=? LIMIT 1'); $stmt->execute([$me['id'],$today]); $row=$stmt->fetch();
  $mode=$_POST['work_mode'] ?? 'Office'; $note=$_POST['note'] ?? '';
  if(($_POST['type'] ?? '')==='in'){
    if(!$row) $pdo->prepare('INSERT INTO attendance(user_id,work_date,checkin_time,work_mode,status,note,attendance_type) VALUES(?,?,?,?,?,?,?)')->execute([$me['id'],$today,$now,$mode,'working',$note,'work']);
    else $pdo->prepare("UPDATE attendance SET checkin_time=?, checkout_time=NULL, work_mode=?, status='working', note=? WHERE id=?")->execute([$now,$mode,$note,$row['id']]);
  } elseif(($_POST['type'] ?? '')==='out') {
    if($row){
      $mins=(int)($row['total_minutes'] ?? 0);
      if(!empty($row['checkin_time']) && ($row['status'] ?? '')==='working'){
        $startTs=strtotime($row['work_date'].' '.$row['checkin_time']); $mins += max(0,round((time()-$startTs)/60));
      } elseif(!empty($row['checkin_time'])) {
        $startTs=strtotime($row['work_date'].' '.$row['checkin_time']); $mins=max($mins,max(0,round((time()-$startTs)/60)));
      }
      $pdo->prepare("UPDATE attendance SET checkout_time=?, total_minutes=?, status='done', note=? WHERE id=?")->execute([$now,$mins,$note,$row['id']]);
    }
  }
  log_activity($pdo,($_POST['type']??'')==='in'?'checkin':'checkout','attendance',$me['id'],'Chấm công');
  redirect('app.php?page=attendance&month='.urlencode($month));
}

$where=user_is_admin()||is_finance_role($me)?"DATE(a.work_date) BETWEEN '$start' AND '$end'":"a.user_id=".(int)$me['id']." AND DATE(a.work_date) BETWEEN '$start' AND '$end'";
$rows=safe_rows($pdo,"SELECT a.*, u.name user_name, u.avatar user_avatar FROM attendance a JOIN users u ON u.id=a.user_id WHERE $where ORDER BY a.work_date DESC,a.id DESC LIMIT 120");
$summary=sprint31_attendance_summary($pdo,$month);
if(!user_is_admin() && !is_finance_role($me)) $summary=array_values(array_filter($summary, fn($x)=>(int)$x['user']['id']===(int)$me['id']));
$totalDays=array_sum(array_column($summary,'days')); $totalHours=array_sum(array_column($summary,'hours')); $totalOt=array_sum(array_column($summary,'ot_hours')); $avgScore=count($summary)?round(array_sum(array_column($summary,'score'))/count($summary)):0;
?>
<section class="card sprint31-hero">
  <div class="card-head">
    <div><span class="eyebrow">SPRINT 31</span><h2>Workday Engine</h2><p class="muted">Đếm ngày công, giờ làm, OT, đi muộn và Work Score theo tháng để nối sang Payroll.</p></div>
    <form class="month-switch" method="get"><input type="hidden" name="page" value="attendance"><input type="month" name="month" value="<?= e($month) ?>"><button class="btn btn-soft">Xem tháng</button></form>
  </div>
  <div class="workday-kpis">
    <div><span>Ngày công</span><b><?= number_format($totalDays,2,',','.') ?></b><small>Tổng team</small></div>
    <div><span>Giờ làm</span><b><?= number_format($totalHours,1,',','.') ?>h</b><small>Đã ghi nhận</small></div>
    <div><span>OT</span><b><?= number_format($totalOt,1,',','.') ?>h</b><small>Vượt chuẩn ngày</small></div>
    <div><span>Work Score</span><b><?= $avgScore ?></b><small>Trung bình team</small></div>
  </div>
</section>

<div class="two-col sprint31-two">
  <section class="card check-card">
    <h2>Check-in / Check-out</h2>
    <form method="post">
      <label>Work mode</label><select name="work_mode"><option>Office</option><option>Remote</option><option>Meeting Client</option></select>
      <label>Ghi chú</label><textarea name="note" rows="3" placeholder="Hôm nay tôi tập trung vào..."></textarea>
      <div class="actions"><button class="primary" name="type" value="in">Check-in</button><button class="btn btn-soft" name="type" value="out">Check-out</button></div>
    </form>
  </section>

  <?php if(user_is_admin() || is_finance_role($me)): ?>
  <section class="card settings-card">
    <h2>Quy tắc tính công</h2>
    <form method="post" class="compact-form">
      <input type="hidden" name="save_settings" value="1">
      <div class="form-row-3"><div><label>1 công</label><input name="full_day_minutes" type="number" value="<?= e($settings['full_day_minutes']) ?>"></div><div><label>0.75 công</label><input name="three_quarter_day_minutes" type="number" value="<?= e($settings['three_quarter_day_minutes']) ?>"></div><div><label>0.5 công</label><input name="half_day_minutes" type="number" value="<?= e($settings['half_day_minutes']) ?>"></div></div>
      <div class="form-row-3"><div><label>0.25 công</label><input name="quarter_day_minutes" type="number" value="<?= e($settings['quarter_day_minutes']) ?>"></div><div><label>Giờ vào chuẩn</label><input name="standard_start_time" type="time" value="<?= e(substr($settings['standard_start_time'],0,5)) ?>"></div><div><label>Grace muộn</label><input name="late_grace_minutes" type="number" value="<?= e($settings['late_grace_minutes']) ?>"></div></div>
      <label>Giờ ra chuẩn</label><input name="standard_end_time" type="time" value="<?= e(substr($settings['standard_end_time'],0,5)) ?>">
      <button class="primary">Lưu quy tắc</button>
    </form>
  </section>
  <?php endif; ?>
</div>

<section class="card">
  <div class="card-head"><div><h2>Bảng công tháng <?= e($month) ?></h2><p class="muted">Ngày công được quy đổi theo ngưỡng giờ làm. Work Score = thời gian + task đúng hạn + Mcoin - lỗi chấm công.</p></div></div>
  <table class="dense-table mobile-card-table workday-table"><thead><tr><th>Nhân sự</th><th>Công</th><th>Giờ</th><th>OT</th><th>Muộn</th><th>Task</th><th>Mcoin</th><th>Score</th></tr></thead><tbody>
    <?php foreach($summary as $s): ?><tr><td data-label="Nhân sự"><span class="user-chip"><?= avatar_html(['name'=>$s['user']['name'],'avatar'=>$s['user']['avatar']],true) ?><b><?= e($s['user']['name']) ?></b></span><small><?= e($s['user']['role'] ?? '') ?></small></td><td data-label="Công"><b><?= number_format($s['days'],2,',','.') ?></b></td><td data-label="Giờ"><?= number_format($s['hours'],1,',','.') ?>h</td><td data-label="OT"><?= number_format($s['ot_hours'],1,',','.') ?>h</td><td data-label="Muộn"><?= (int)$s['late'] ?></td><td data-label="Task"><?= (int)$s['task_done'] ?> / <?= (int)$s['task_ontime'] ?> đúng hạn</td><td data-label="Mcoin"><?= number_format((int)$s['mcoin'],0,',','.') ?></td><td data-label="Score"><span class="score-pill <?= $s['score']>=85?'good':($s['score']>=60?'ok':'risk') ?>"><?= (int)$s['score'] ?></span></td></tr><?php endforeach; ?>
  </tbody></table>
</section>

<section class="card">
  <div class="card-head"><h2>Log chấm công</h2></div>
  <table class="dense-table mobile-card-table"><thead><tr><th>Nhân sự</th><th>Ngày</th><th>Check-in</th><th>Check-out</th><th>Tổng giờ</th><th>Mode</th><th>Status</th></tr></thead><tbody>
  <?php foreach($rows as $r): ?><tr><td data-label="Nhân sự"><span class="user-chip"><?= avatar_html(['name'=>$r['user_name'],'avatar'=>$r['user_avatar']],true) ?><?= e($r['user_name']) ?></span></td><td data-label="Ngày"><?= e($r['work_date']) ?></td><td data-label="Check-in"><?= e($r['checkin_time']) ?></td><td data-label="Check-out"><?= e($r['checkout_time']) ?></td><td data-label="Tổng giờ"><?= round(((int)$r['total_minutes'])/60,2) ?>h</td><td data-label="Mode"><?= e($r['work_mode']) ?></td><td data-label="Status"><span class="badge <?= badge_class($r['status']) ?>"><?= e($r['status']) ?></span></td></tr><?php endforeach; ?>
  <?php if(empty($rows)): ?><tr><td colspan="7" class="muted">Chưa có dữ liệu chấm công trong tháng.</td></tr><?php endif; ?>
  </tbody></table>
</section>
