<?php
$id=(int)($_GET['id']??0);
if(isset($_GET['mark_paid'])){
  $pid=(int)$_GET['mark_paid'];
  $pdo->prepare("UPDATE payment_schedules SET status='paid', paid_date=CURDATE() WHERE id=?")->execute([$pid]);
  redirect('app.php?page=contract_detail&id='.$id);
}
$stmt=$pdo->prepare('SELECT c.*,q.quote_code,q.title quote_title,t.template_name,u1.name quote_owner_name,u2.name account_manager_name 
  FROM contracts c
  LEFT JOIN quotations q ON q.id=c.quotation_id
  LEFT JOIN contract_templates t ON t.id=c.template_id
  LEFT JOIN users u1 ON u1.id=c.quote_owner_id
  LEFT JOIN users u2 ON u2.id=COALESCE(c.account_manager_id,c.contract_owner_id)
  WHERE c.id=?');
$stmt->execute([$id]);
$c=$stmt->fetch();
if(!$c) die('Không tìm thấy hợp đồng.');
$payments=$pdo->prepare('SELECT * FROM payment_schedules WHERE contract_id=? ORDER BY due_date,id');
$payments->execute([$id]);
$payments=$payments->fetchAll();
$paid=0;$pending=0;foreach($payments as $p){ if($p['status']==='paid') $paid+=(float)$p['amount']; else $pending+=(float)$p['amount'];}
$contractHealth=contract_cash_health($pdo,$id,$c['total_value']);
?>
<section class="workspace-hero">
  <div><span class="eyebrow">Contract Detail</span><h1><?= e($c['contract_code']) ?></h1><p class="muted"><?= e($c['client_name']) ?> · <?= e($c['quote_code']) ?> · <?= e($c['template_name']) ?></p></div>
  <div class="actions"><a class="btn btn-soft" href="app.php?page=contracts">← Contracts</a><?php if($c['generated_file']): ?><a class="btn btn-coral" href="<?= e($c['generated_file']) ?>" target="_blank">Download DOCX</a><?php endif; ?></div>
</section>
<div class="stats-grid compact-stats">
  <div class="stat coral"><span>Giá trị HĐ</span><strong><?= money_short($c['total_value']) ?></strong></div>
  <div class="stat mint"><span>Đã thu</span><strong><?= money_short($paid) ?></strong></div>
  <div class="stat yellow"><span>Chờ thu</span><strong><?= money_short($pending) ?></strong></div>
  <div class="stat purple"><span>Status</span><strong style="font-size:20px"><?= e($c['status']) ?></strong></div>
  <div class="stat <?= e($contractHealth['class']) ?>"><span>Cash Health</span><strong style="font-size:20px"><?= e($contractHealth['emoji'].' '.$contractHealth['label']) ?></strong></div>
</div>

<section class="card contract-timeline-card">
  <div class="card-head"><h2>Contract → Cash Timeline</h2></div>
  <div class="contract-timeline">
    <div class="timeline-step done"><b>Ký hợp đồng</b><span><?= e($c['signed_date'] ?: $c['created_at']) ?></span></div>
    <?php foreach($payments as $idx=>$p): ?>
      <div class="timeline-step <?= $p['status']==='paid'?'done':(($p['due_date']<date('Y-m-d'))?'late':'pending') ?>">
        <b>Payment #<?= $idx+1 ?> · <?= money_short($p['amount']) ?></b>
        <span><?= $p['status']==='paid'?'Paid '.e($p['paid_date'] ?: $p['due_date']):'Due '.e($p['due_date']) ?></span>
      </div>
    <?php endforeach; ?>
    <div class="timeline-step <?= $pending<=0?'done':'pending' ?>"><b>Completed</b><span><?= $pending<=0?'Đã thu đủ':'Còn '.money_short($pending) ?></span></div>
  </div>
</section>

<div class="two-col">
<section class="card"><div class="card-head"><h2>Thông tin hợp đồng</h2></div>
  <table class="dense-table"><tbody>
    <tr><th>Khách hàng</th><td><?= e($c['client_name']) ?></td></tr>
    <tr><th>Báo giá</th><td><?= e($c['quote_code']) ?> — <?= e($c['quote_title']) ?></td></tr>
    <tr><th>Người báo giá</th><td><?= e($c['quote_owner_name']) ?></td></tr>
    <tr><th>Account Manager</th><td><?= e($c['account_manager_name']) ?></td></tr>
    <tr><th>Ngày ký</th><td><?= e($c['signed_date']) ?></td></tr>
    <tr><th>Thời gian</th><td><?= e($c['start_date']) ?> → <?= e($c['end_date']) ?></td></tr>
    <tr><th>Nghiệm thu</th><td><?= e($c['acceptance_date']) ?></td></tr>
    <tr><th>Thanh lý</th><td><?= e($c['liquidation_date']) ?></td></tr>
  </tbody></table>
</section>
<section class="card"><div class="card-head"><h2>Tài liệu</h2></div>
  <p><?php if($c['generated_file']): ?><a class="btn btn-soft" href="<?= e($c['generated_file']) ?>" target="_blank">Contract DOCX</a><?php else: ?><span class="muted">Chưa có file generated.</span><?php endif; ?></p>
  <p><?php if($c['acceptance_link']): ?><a class="btn btn-soft" href="<?= e($c['acceptance_link']) ?>" target="_blank">Nghiệm thu</a><?php endif; ?></p>
  <p><?php if($c['liquidation_link']): ?><a class="btn btn-soft" href="<?= e($c['liquidation_link']) ?>" target="_blank">Thanh lý</a><?php endif; ?></p>
</section>
</div>
<section class="card"><div class="card-head"><h2>Payment Schedule</h2></div>
<table><thead><tr><th>Mã</th><th>Đợt</th><th>Số tiền</th><th>Due</th><th>Paid date</th><th>Status</th><th>Action</th></tr></thead><tbody>
<?php foreach($payments as $p): ?><tr><td><?= e($p['payment_code']) ?></td><td><?= e($p['title'] ?: $p['milestone']) ?></td><td><b><?= money($p['amount']) ?></b></td><td><?= e($p['due_date']) ?></td><td><?= e($p['paid_date']) ?></td><td><span class="badge <?= badge_class($p['status']) ?>"><?= e($p['status']) ?></span></td><td><?php if($p['status']!=='paid'): ?><a class="btn btn-soft" href="app.php?page=contract_detail&id=<?= $id ?>&mark_paid=<?= $p['id'] ?>">Mark paid</a><?php endif; ?></td></tr><?php endforeach; ?>
<?php if(empty($payments)): ?><tr><td colspan="7" class="muted">Chưa có lịch thanh toán.</td></tr><?php endif; ?>
</tbody></table>
</section>
