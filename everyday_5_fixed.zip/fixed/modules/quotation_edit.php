<?php
$id=(int)($_GET['id']??0);
$stmt=$pdo->prepare('SELECT q.*,u.name owner_name FROM quotations q LEFT JOIN users u ON u.id=q.owner_id WHERE q.id=?');
$stmt->execute([$id]);
$q=$stmt->fetch();
if(!$q) die('Không tìm thấy báo giá.');

$currentVersion = ensure_quotation_version($pdo,$id);

if(isset($_GET['new_version'])){
  $old=$currentVersion;
  $newNo=((int)$old['version_no'])+1;
  $pdo->prepare('INSERT INTO quotation_versions(quotation_id,version_no,title,subtotal,vat,total,note,created_by) VALUES(?,?,?,?,?,?,?,?)')
    ->execute([$id,$newNo,$q['title'].' V'.$newNo,$old['subtotal'],$old['vat'],$old['total'],'Created from V'.$old['version_no'],current_user()['id']]);
  $newVid=$pdo->lastInsertId();
  $items=$pdo->prepare('SELECT * FROM quotation_items WHERE quotation_version_id=? ORDER BY sort_order,id');
  $items->execute([$old['id']]);
  foreach($items->fetchAll() as $it){
    $pdo->prepare('INSERT INTO quotation_items(quotation_id,quotation_version_id,sort_order,service_name,description,quantity,unit,working_time,duration,unit_price,subtotal,vat_rate,vat_percent,vat_amount,total,note) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
      ->execute([$id,$newVid,$it['sort_order'],$it['service_name'],$it['description'],$it['quantity'],$it['unit'],$it['working_time'],$it['duration'],$it['unit_price'],$it['subtotal'],$it['vat_rate'],$it['vat_percent'],$it['vat_amount'],$it['total'],$it['note']]);
  }
  $pdo->prepare('UPDATE quotations SET current_version=? WHERE id=?')->execute([$newNo,$id]);
  log_activity($pdo,'create','quotation_version',$newVid,'Tạo version V'.$newNo.' cho '.$q['quote_code']);
  redirect('app.php?page=quotation_edit&id='.$id);
}

$currentVersion = ensure_quotation_version($pdo,$id);
$versionId=(int)$currentVersion['id'];

if($_SERVER['REQUEST_METHOD']==='POST'){
  if(($_POST['form_type'] ?? '')==='meta'){
    $owner = $_POST['owner_id'] ?: current_user()['id'];
    $signed = $_POST['status']==='Contract Signed' ? 1 : 0;
    $signedAt = $_POST['status']==='Contract Signed' ? date('Y-m-d H:i:s') : null;
    $pdo->prepare('UPDATE quotations SET client_name=?,client_contact=?,title=?,industry=?,objective=?,intro_text=?,valid_until=?,payment_terms=?,status=?,owner_id=?,signed_contract=?,signed_at=? WHERE id=?')
      ->execute([$_POST['client_name'],$_POST['client_contact'],$_POST['title'],$_POST['industry'],$_POST['objective'],$_POST['intro_text'],$_POST['valid_until'],$_POST['payment_terms'],$_POST['status'],$owner,$signed,$signedAt,$id]);
    $pdo->prepare('UPDATE quotation_versions SET title=?,note=? WHERE id=?')->execute([$_POST['version_title'],$_POST['version_note'],$versionId]);
  } else {
    $pdo->prepare('DELETE FROM quotation_items WHERE quotation_version_id=?')->execute([$versionId]);
    $sortOrder = 1;
    foreach($_POST['items']??[] as $it){
      $serviceName = trim($it['service_name'] ?? '');
      $description = trim($it['description'] ?? '');
      $note = trim($it['note'] ?? '');
      if($serviceName==='' && $description==='' && $note==='') continue;

      $qty=(float)($it['quantity']??0);
      $price=(float)($it['unit_price']??0);
      $vatRate=(float)($it['vat_rate']??($it['vat_percent']??0));
      $duration=trim($it['duration'] ?? ($it['working_time'] ?? ''));
      $workingTime=trim(($it['working_time'] ?? '') ?: $duration);
      $unit=trim($it['unit'] ?? '');
      $sub=$qty*$price;
      $vat=$sub*$vatRate/100;
      $total=$sub+$vat;
      $pdo->prepare('INSERT INTO quotation_items(quotation_id,quotation_version_id,sort_order,service_name,description,quantity,unit,working_time,duration,unit_price,subtotal,vat_rate,vat_percent,vat_amount,total,note) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
        ->execute([$id,$versionId,$sortOrder++,$serviceName,$description,$qty,$unit,$workingTime,$duration,$price,$sub,$vatRate,$vatRate,$vat,$total,$note]);
    }
    sync_quotation_version_totals($pdo,$versionId);
  }
  log_activity($pdo,'update','quotation',$id,'Cập nhật báo giá '.$q['quote_code']);
  redirect('app.php?page=quotation_edit&id='.$id);
}

$stmt=$pdo->prepare('SELECT * FROM quotation_items WHERE quotation_version_id=? ORDER BY sort_order,id');
$stmt->execute([$versionId]);
$items=$stmt->fetchAll();
if(!$items){
  $items[]=['service_name'=>'','description'=>'','quantity'=>1,'unit'=>'gói','working_time'=>'','duration'=>'','unit_price'=>0,'vat_rate'=>10,'note'=>'','subtotal'=>0,'vat_amount'=>0,'total'=>0];
}

$versions=$pdo->prepare('SELECT * FROM quotation_versions WHERE quotation_id=? ORDER BY version_no DESC');
$versions->execute([$id]);
$versions=$versions->fetchAll();
$t=quotation_version_totals($pdo,$versionId);
$users=$pdo->query('SELECT id,name FROM users ORDER BY name')->fetchAll();
$statuses=['Draft','Sent','Feedback','Pending','Reject','Contract Signed'];
?>
<div class="tabs">
  <a class="active" href="app.php?page=quotation_edit&id=<?= $id ?>">Builder V<?= (int)$currentVersion['version_no'] ?></a>
  <a href="public_quote.php?token=<?= e($q['public_token']) ?>" target="_blank">Client Landing Page</a>
  <a href="app.php?page=internal_costs&id=<?= $id ?>">Internal Cost</a>
  <a href="app.php?page=payments&id=<?= $id ?>">Payment</a>
  <?php if($q['status']==='Contract Signed'): ?><a href="app.php?page=contract_generate&amp;quotation_id=<?= $id ?>">Generate Contract</a><?php endif; ?>
</div>

<div class="two-col">
<section class="card">
  <div class="card-head">
    <div><span class="eyebrow"><?= e($q['quote_code']) ?> · V<?= (int)$currentVersion['version_no'] ?></span><h2>Thông tin báo giá</h2></div>
    <span class="badge <?= badge_class($q['status']) ?>"><?= e($q['status']) ?></span>
  </div>
  <form method="post">
    <input type="hidden" name="form_type" value="meta">
    <div class="form-row"><div><label>Khách hàng</label><input name="client_name" value="<?= e($q['client_name']) ?>"></div><div><label>Người liên hệ</label><input name="client_contact" value="<?= e($q['client_contact']) ?>"></div></div>
    <label>Tiêu đề báo giá</label><input name="title" value="<?= e($q['title']) ?>">
    <label>Version title</label><input name="version_title" value="<?= e($currentVersion['title']) ?>">
    <div class="form-row"><div><label>Ngành</label><input name="industry" value="<?= e($q['industry']) ?>"></div><div><label>Valid until</label><input name="valid_until" type="date" value="<?= e($q['valid_until']) ?>"></div></div>
    <label>Owner</label><select name="owner_id"><option value="">Chọn owner</option><?php foreach($users as $u): ?><option value="<?= $u['id'] ?>" <?= (int)$q['owner_id']===(int)$u['id']?'selected':'' ?>><?= e($u['name']) ?></option><?php endforeach; ?></select>
    <label>Status</label><select name="status"><?php foreach($statuses as $s): ?><option value="<?= e($s) ?>" <?= $q['status']===$s?'selected':'' ?>><?= e($s) ?></option><?php endforeach; ?></select>
    <label>Objective</label><textarea name="objective"><?= e($q['objective']) ?></textarea>
    <label>Intro text</label><textarea name="intro_text"><?= e($q['intro_text']) ?></textarea>
    <label>Payment terms</label><textarea name="payment_terms"><?= e($q['payment_terms']) ?></textarea>
    <label>Version note</label><textarea name="version_note"><?= e($currentVersion['note']) ?></textarea>
    <button class="primary">Lưu thông tin</button>
  </form>
</section>

<section class="card">
  <div class="card-head"><h2>Version History</h2><a class="btn btn-soft" href="app.php?page=quotation_edit&id=<?= $id ?>&new_version=1">+ New Version</a></div>
  <table class="dense-table"><thead><tr><th>Version</th><th>Total</th><th>Created</th><th>Note</th></tr></thead><tbody>
  <?php foreach($versions as $v): ?><tr class="<?= $v['id']==$versionId?'active-row':'' ?>"><td><b>V<?= (int)$v['version_no'] ?></b></td><td><?= money($v['total']) ?></td><td><?= e($v['created_at']) ?></td><td><?= e($v['note']) ?></td></tr><?php endforeach; ?>
  </tbody></table>
  <div class="quote-total-box"><span>Current total</span><strong><?= money($t['total']) ?></strong><small>Subtotal <?= money($t['subtotal']) ?> · VAT <?= money($t['vat']) ?></small></div>
</section>
</div>

<section class="card quote-builder-card">
  <div class="card-head quote-builder-head">
    <div>
      <span class="eyebrow">Quotation Builder</span>
      <h2>Hạng mục báo giá — V<?= (int)$currentVersion['version_no'] ?></h2>
      <p class="muted">Danh sách được thu gọn để dễ nhìn hơn. Chỉ khi bấm <strong>Edit</strong> thì khung soạn thảo mới mở ra.</p>
    </div>
    <button class="btn btn-soft" type="button" onclick="addQuoteRow()">+ Thêm dòng</button>
  </div>
  <form method="post" id="quoteItemsForm">
    <input type="hidden" name="form_type" value="items">
    <div class="quote-builder" id="quoteItemsBuilder">
      <?php foreach($items as $idx=>$it):
        $durationValue = $it['duration'] ?: ($it['working_time'] ?? '');
        $vatValue = $it['vat_rate'] ?? $it['vat_percent'] ?? 10;
        $hasContent = trim((string)($it['service_name'] ?? '')) !== '' || trim((string)($it['description'] ?? '')) !== '' || trim((string)($it['note'] ?? '')) !== '';
      ?>
      <article class="quote-item-row<?= $hasContent ? '' : ' is-open' ?>" data-row-index="<?= $idx ?>">
        <div class="quote-item-summary">
          <div class="quote-row-number">#<span><?= $idx+1 ?></span></div>
          <div class="quote-summary-main">
            <div class="quote-summary-label">Tiêu đề hạng mục</div>
            <div class="quote-summary-title" data-summary="service_name"><?= e($it['service_name'] ?: 'Hạng mục chưa đặt tên') ?></div>
            <div class="quote-summary-desc" data-summary="description"><?= e($it['description'] ?: 'Chưa có mô tả chi tiết.') ?></div>
          </div>
          <div class="quote-summary-meta"><span class="quote-summary-meta-label">SL</span><span class="quote-summary-meta-value" data-summary="quantity"><?= e($it['quantity']) ?></span></div>
          <div class="quote-summary-meta"><span class="quote-summary-meta-label">Đơn vị</span><span class="quote-summary-meta-value" data-summary="unit"><?= e($it['unit'] ?: '-') ?></span></div>
          <div class="quote-summary-meta"><span class="quote-summary-meta-label">Thời gian</span><span class="quote-summary-meta-value" data-summary="duration"><?= e($durationValue ?: '-') ?></span></div>
          <div class="quote-summary-meta"><span class="quote-summary-meta-label">Đơn giá</span><span class="quote-summary-meta-value" data-summary="unit_price"><?= e(number_format((float)($it['unit_price'] ?? 0), 0, ',', '.')) ?> VND</span></div>
          <div class="quote-summary-meta"><span class="quote-summary-meta-label">VAT</span><span class="quote-summary-meta-value" data-summary="vat_rate"><?= e(rtrim(rtrim(number_format((float)$vatValue,2,'.',''),'0'),'.')) ?>%</span></div>
          <div class="quote-summary-actions">
            <button class="btn-toggle-row" type="button" onclick="toggleQuoteRow(this)"><?= $hasContent ? 'Edit' : 'Thu gọn' ?></button>
            <button class="btn-delete-row" type="button" onclick="deleteQuoteRow(this)" title="Xoá dòng này">Xoá</button>
          </div>
        </div>
        <div class="quote-item-editor">
          <div class="quote-row-top">
            <div class="quote-field quote-service-field">
              <label>Dịch vụ</label>
              <textarea class="quote-input quote-service-input auto-grow" name="items[<?= $idx ?>][service_name]" rows="2" placeholder="Tên hạng mục/dịch vụ"><?= e($it['service_name']) ?></textarea>
            </div>
            <div class="quote-field quote-small-field">
              <label>SL</label>
              <input class="quote-input" name="items[<?= $idx ?>][quantity]" type="number" step="0.01" value="<?= e($it['quantity']) ?>">
            </div>
            <div class="quote-field quote-small-field">
              <label>Đơn vị</label>
              <input class="quote-input" name="items[<?= $idx ?>][unit]" value="<?= e($it['unit']) ?>" placeholder="tháng/gói/video">
            </div>
            <div class="quote-field quote-small-field">
              <label>Thời gian</label>
              <input class="quote-input" name="items[<?= $idx ?>][duration]" value="<?= e($durationValue) ?>" placeholder="30 ngày">
              <input type="hidden" name="items[<?= $idx ?>][working_time]" value="<?= e($durationValue) ?>">
            </div>
            <div class="quote-field quote-price-field">
              <label>Đơn giá</label>
              <input class="quote-input" name="items[<?= $idx ?>][unit_price]" type="number" step="1000" value="<?= e($it['unit_price']) ?>">
            </div>
            <div class="quote-field quote-vat-field">
              <label>VAT%</label>
              <input class="quote-input" name="items[<?= $idx ?>][vat_rate]" type="number" step="0.01" value="<?= e($vatValue) ?>">
            </div>
          </div>
          <div class="quote-row-description">
            <div class="quote-field">
              <label>Mô tả chi tiết</label>
              <textarea class="quote-input quote-description-input auto-grow" name="items[<?= $idx ?>][description]" rows="4" placeholder="Mô tả phạm vi công việc, deliverables, ghi chú triển khai..."><?= e($it['description']) ?></textarea>
            </div>
            <div class="quote-field quote-note-field">
              <label>Note</label>
              <textarea class="quote-input quote-note-input auto-grow" name="items[<?= $idx ?>][note]" rows="4" placeholder="Ghi chú nội bộ hoặc ghi chú hiển thị trên báo giá"><?= e($it['note']) ?></textarea>
            </div>
          </div>
        </div>
      </article>
      <?php endforeach; ?>
    </div>
    <div class="quote-form-actions">
      <button class="primary">Lưu hạng mục</button>
      <button class="btn btn-soft" type="button" onclick="addQuoteRow()">+ Thêm dòng mới</button>
    </div>
  </form>
</section>

<script>
function autoGrowTextarea(el){
  if(!el || !el.classList || !el.classList.contains('auto-grow')) return;
  el.style.height='auto';
  el.style.height=Math.max(el.scrollHeight, el.classList.contains('quote-description-input') ? 110 : 46)+'px';
}

function formatQuoteMoney(value){
  const num = Number(value || 0);
  if(Number.isNaN(num)) return '0 VND';
  return num.toLocaleString('vi-VN') + ' VND';
}

function updateQuoteSummary(row){
  if(!row) return;
  const service = row.querySelector('[name$="[service_name]"]')?.value?.trim() || 'Hạng mục chưa đặt tên';
  const description = row.querySelector('[name$="[description]"]')?.value?.trim() || 'Chưa có mô tả chi tiết.';
  const quantity = row.querySelector('[name$="[quantity]"]')?.value?.trim() || '0';
  const unit = row.querySelector('[name$="[unit]"]')?.value?.trim() || '-';
  const duration = row.querySelector('[name$="[duration]"]')?.value?.trim() || '-';
  const unitPrice = row.querySelector('[name$="[unit_price]"]')?.value || 0;
  const vatRate = row.querySelector('[name$="[vat_rate]"]')?.value?.trim() || '0';

  const map = {
    service_name: service,
    description: description,
    quantity: quantity,
    unit: unit,
    duration: duration,
    unit_price: formatQuoteMoney(unitPrice),
    vat_rate: `${vatRate}%`
  };

  row.querySelectorAll('[data-summary]').forEach(el => {
    const key = el.getAttribute('data-summary');
    if(map[key] !== undefined) el.textContent = map[key];
  });
}

function syncWorkingTime(row){
  if(!row) return;
  const duration = row.querySelector('[name$="[duration]"]');
  const hidden = row.querySelector('[name$="[working_time]"]');
  if(duration && hidden) hidden.value = duration.value;
}

function reindexQuoteRows(){
  const rows=document.querySelectorAll('#quoteItemsBuilder .quote-item-row');
  rows.forEach((row,index)=>{
    row.dataset.rowIndex=index;
    const number=row.querySelector('.quote-row-number span');
    if(number) number.textContent=index+1;
    row.querySelectorAll('[name]').forEach(input=>{
      input.name=input.name.replace(/items\[\d+\]/,'items['+index+']');
    });
  });
}

function setQuoteRowOpen(row, shouldOpen){
  if(!row) return;
  row.classList.toggle('is-open', !!shouldOpen);
  const btn = row.querySelector('.btn-toggle-row');
  if(btn) btn.textContent = shouldOpen ? 'Thu gọn' : 'Edit';
  if(shouldOpen){
    row.querySelectorAll('.auto-grow').forEach(autoGrowTextarea);
  }
}

function toggleQuoteRow(button){
  const row = button.closest('.quote-item-row');
  setQuoteRowOpen(row, !row.classList.contains('is-open'));
}

function clearQuoteRow(row){
  if(!row) return;
  row.querySelectorAll('input, textarea').forEach(input=>{
    if(input.type==='hidden'){
      input.value='';
      return;
    }
    if(input.name.includes('[quantity]')) input.value='1';
    else if(input.name.includes('[unit]')) input.value='gói';
    else if(input.name.includes('[vat_rate]')) input.value='10';
    else if(input.name.includes('[unit_price]')) input.value='0';
    else input.value='';
    autoGrowTextarea(input);
  });
  syncWorkingTime(row);
  updateQuoteSummary(row);
}

function deleteQuoteRow(button){
  const row=button.closest('.quote-item-row');
  if(!row) return;
  const rows=document.querySelectorAll('#quoteItemsBuilder .quote-item-row');
  if(rows.length<=1){
    clearQuoteRow(row);
    setQuoteRowOpen(row, true);
    return;
  }
  if(!confirm('Bạn có chắc muốn xoá hạng mục này không?')) return;
  row.remove();
  reindexQuoteRows();
}

function addQuoteRow(){
  const builder=document.getElementById('quoteItemsBuilder');
  const i=builder.querySelectorAll('.quote-item-row').length;
  const row=document.createElement('article');
  row.className='quote-item-row is-open';
  row.dataset.rowIndex=i;
  row.innerHTML=`
    <div class="quote-item-summary">
      <div class="quote-row-number">#<span>${i+1}</span></div>
      <div class="quote-summary-main">
        <div class="quote-summary-label">Tiêu đề hạng mục</div>
        <div class="quote-summary-title" data-summary="service_name">Hạng mục chưa đặt tên</div>
        <div class="quote-summary-desc" data-summary="description">Chưa có mô tả chi tiết.</div>
      </div>
      <div class="quote-summary-meta"><span class="quote-summary-meta-label">SL</span><span class="quote-summary-meta-value" data-summary="quantity">1</span></div>
      <div class="quote-summary-meta"><span class="quote-summary-meta-label">Đơn vị</span><span class="quote-summary-meta-value" data-summary="unit">gói</span></div>
      <div class="quote-summary-meta"><span class="quote-summary-meta-label">Thời gian</span><span class="quote-summary-meta-value" data-summary="duration">-</span></div>
      <div class="quote-summary-meta"><span class="quote-summary-meta-label">Đơn giá</span><span class="quote-summary-meta-value" data-summary="unit_price">0 VND</span></div>
      <div class="quote-summary-meta"><span class="quote-summary-meta-label">VAT</span><span class="quote-summary-meta-value" data-summary="vat_rate">10%</span></div>
      <div class="quote-summary-actions">
        <button class="btn-toggle-row" type="button" onclick="toggleQuoteRow(this)">Thu gọn</button>
        <button class="btn-delete-row" type="button" onclick="deleteQuoteRow(this)" title="Xoá dòng này">Xoá</button>
      </div>
    </div>
    <div class="quote-item-editor">
      <div class="quote-row-top">
        <div class="quote-field quote-service-field">
          <label>Dịch vụ</label>
          <textarea class="quote-input quote-service-input auto-grow" name="items[${i}][service_name]" rows="2" placeholder="Tên hạng mục/dịch vụ"></textarea>
        </div>
        <div class="quote-field quote-small-field">
          <label>SL</label>
          <input class="quote-input" name="items[${i}][quantity]" type="number" step="0.01" value="1">
        </div>
        <div class="quote-field quote-small-field">
          <label>Đơn vị</label>
          <input class="quote-input" name="items[${i}][unit]" value="gói" placeholder="tháng/gói/video">
        </div>
        <div class="quote-field quote-small-field">
          <label>Thời gian</label>
          <input class="quote-input" name="items[${i}][duration]" placeholder="30 ngày">
          <input type="hidden" name="items[${i}][working_time]" value="">
        </div>
        <div class="quote-field quote-price-field">
          <label>Đơn giá</label>
          <input class="quote-input" name="items[${i}][unit_price]" type="number" step="1000" value="0">
        </div>
        <div class="quote-field quote-vat-field">
          <label>VAT%</label>
          <input class="quote-input" name="items[${i}][vat_rate]" type="number" step="0.01" value="10">
        </div>
      </div>
      <div class="quote-row-description">
        <div class="quote-field">
          <label>Mô tả chi tiết</label>
          <textarea class="quote-input quote-description-input auto-grow" name="items[${i}][description]" rows="4" placeholder="Mô tả phạm vi công việc, deliverables, ghi chú triển khai..."></textarea>
        </div>
        <div class="quote-field quote-note-field">
          <label>Note</label>
          <textarea class="quote-input quote-note-input auto-grow" name="items[${i}][note]" rows="4" placeholder="Ghi chú nội bộ hoặc ghi chú hiển thị trên báo giá"></textarea>
        </div>
      </div>
    </div>`;
  builder.appendChild(row);
  row.querySelectorAll('.auto-grow').forEach(autoGrowTextarea);
  updateQuoteSummary(row);
  row.scrollIntoView({behavior:'smooth',block:'center'});
}

document.addEventListener('input', function(event){
  autoGrowTextarea(event.target);
  const row = event.target.closest ? event.target.closest('.quote-item-row') : null;
  if(row){
    if(event.target.name && event.target.name.includes('[duration]')) syncWorkingTime(row);
    updateQuoteSummary(row);
  }
});

document.addEventListener('change', function(event){
  const row = event.target.closest ? event.target.closest('.quote-item-row') : null;
  if(row){
    if(event.target.name && event.target.name.includes('[duration]')) syncWorkingTime(row);
    updateQuoteSummary(row);
  }
});

document.addEventListener('DOMContentLoaded', function(){
  document.querySelectorAll('.quote-item-row').forEach(row => {
    row.querySelectorAll('.auto-grow').forEach(autoGrowTextarea);
    syncWorkingTime(row);
    updateQuoteSummary(row);
  });
});
</script>
