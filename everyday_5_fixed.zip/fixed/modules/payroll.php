<?php
$me = current_user();

if(isset($_GET['approve_salary'])){
  $pid=(int)$_GET['approve_salary'];
  $stmt=$pdo->prepare("UPDATE payroll SET employee_approval_status='approved', employee_approved_at=NOW() WHERE id=? AND user_id=?");
  $stmt->execute([$pid,$me['id']]);
  log_activity($pdo,'approve','payroll',$pid,'Nhân viên xác nhận bảng lương');
  redirect('app.php?page=payroll');
}

if($_SERVER['REQUEST_METHOD']==='POST' && user_is_admin()){
  $uid=(int)$_POST['user_id'];
  $month=$_POST['month'];
  $base=(float)$_POST['base_salary'];
  $standard=(float)$_POST['standard_hours'];
  $actual=(float)$_POST['actual_hours'];
  $actualDays=(int)($_POST['actual_days'] ?? 0);
  $kpi=(float)$_POST['kpi_percent'];
  $projectDone=(int)$_POST['project_completed'];
  $commission=(float)$_POST['commission'];
  $bhxh=(float)$_POST['bhxh'];
  $tncn=(float)$_POST['tncn'];
  $other=(float)$_POST['other_deduction'];

  $workRatio=$standard>0?min(1,$actual/$standard):0;
  $workPay=$base*0.8*$workRatio;
  $kpiPay=$base*0.2*($kpi/100);
  $total=$workPay+$kpiPay+$commission-$bhxh-$tncn-$other;

  $stmt=$pdo->prepare('INSERT INTO payroll(user_id,month,base_salary,standard_hours,actual_hours,actual_days,kpi_percent,project_completed,commission,bhxh,tncn,other_deduction,total_salary,note,status,employee_approval_status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
  $stmt->execute([$uid,$month,$base,$standard,$actual,$actualDays,$kpi,$projectDone,$commission,$bhxh,$tncn,$other,$total,$_POST['note'],'published','pending']);

  create_notification($pdo,$uid,'Lương tháng này đã được cập nhật','HR đã tính lương tháng '.$month.'. KPI: '.$kpi.'%, ngày làm: '.$actualDays.', giờ làm: '.$actual.'h, thực nhận: '.money($total),'payroll','app.php?page=payroll');
  log_activity($pdo,'create','payroll',$pdo->lastInsertId(),'Tính lương');
  redirect('app.php?page=payroll');
}

$users=$pdo->query('SELECT * FROM users ORDER BY name')->fetchAll();
$where=user_is_admin()?'1=1':'pr.user_id='.(int)$me['id'];
$rows=$pdo->query("SELECT pr.*,u.name user_name,u.avatar user_avatar FROM payroll pr JOIN users u ON u.id=pr.user_id WHERE $where ORDER BY pr.month DESC,pr.id DESC")->fetchAll();
?>
<div class="two-col">
<section class="card">
  <div class="card-head"><h2>Bảng lương</h2>
<section class="card">
  <div class="card-head"><h2>Gợi ý payroll mồng 1</h2></div>
  <p class="muted">Phase này đã có nền dữ liệu để tính tự động: Fulltime theo ngày/giờ làm việc, CTV theo số lượng sản phẩm task Done × đơn giá.</p>
</section>
</div>
  <table>
    <thead>
      <tr>
        <th>Tháng</th>
        <th>Nhân sự</th>
        <th>Lương cứng</th>
        <th>Ngày / giờ làm</th>
        <th>KPI</th>
        <th>Project</th>
        <th>BHXH</th>
        <th>TNCN</th>
        <th>Thực nhận</th>
        <th>Xác nhận</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach($rows as $r): ?>
      <tr>
        <td><?= e($r['month']) ?></td>
        <td><span class="user-chip"><?= avatar_html(['name'=>$r['user_name'],'avatar'=>$r['user_avatar']],true) ?><?= e($r['user_name']) ?></span><br><span class="muted"><?= e($r['note']) ?></span></td>
        <td><?= money($r['base_salary']) ?></td>
        <td><?= e($r['actual_days'] ?? 0) ?> ngày<br><?= e($r['actual_hours']) ?>/<?= e($r['standard_hours']) ?>h</td>
        <td><?= e($r['kpi_percent']) ?>%</td>
        <td><?= e($r['project_completed']) ?></td>
        <td><?= money($r['bhxh']) ?></td>
        <td><?= money($r['tncn']) ?></td>
        <td><b><?= money($r['total_salary']) ?></b></td>
        <td>
          <?php if(($r['employee_approval_status'] ?? 'pending') === 'approved'): ?>
            <span class="approval-pill approved">Đã đồng ý</span>
          <?php elseif((int)$r['user_id']===(int)$me['id'] && $r['status']==='published'): ?>
            <a class="btn btn-green" href="app.php?page=payroll&approve_salary=<?= $r['id'] ?>">Tôi đồng ý</a>
          <?php else: ?>
            <span class="approval-pill pending"><?= e($r['employee_approval_status'] ?? 'pending') ?></span>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</section>

<?php if(user_is_admin()): ?>
<section class="card">
  <h2>Tính lương thủ công</h2>
  <form method="post">
    <label>Nhân sự</label>
    <select name="user_id">
      <?php foreach($users as $u): ?><option value="<?= $u['id'] ?>"><?= e($u['name']) ?></option><?php endforeach; ?>
    </select>
    <label>Tháng</label><input name="month" type="month" value="<?= date('Y-m') ?>">
    <label>Lương cứng</label><input name="base_salary" type="number" value="<?= e($users[0]['base_salary']??0) ?>">
    <div class="form-row">
      <div><label>Giờ chuẩn</label><input name="standard_hours" type="number" value="176"></div>
      <div><label>Giờ thực tế</label><input name="actual_hours" type="number" value="176"></div>
    </div>
    <div class="form-row">
      <div><label>Ngày làm</label><input name="actual_days" type="number" value="22"></div>
      <div><label>KPI %</label><input name="kpi_percent" type="number" value="100"></div>
    </div>
    <div class="form-row">
      <div><label>Project hoàn thành</label><input name="project_completed" type="number" value="0"></div>
      <div><label>Hoa hồng</label><input name="commission" type="number" value="0"></div>
    </div>
    <div class="form-row-3">
      <div><label>BHXH</label><input name="bhxh" type="number" value="0"></div>
      <div><label>TNCN</label><input name="tncn" type="number" value="0"></div>
      <div><label>Khấu trừ khác</label><input name="other_deduction" type="number" value="0"></div>
    </div>
    <label>Note</label><textarea name="note"></textarea>
    <button class="primary">Tính & publish lương</button>
  </form>
</section>
<?php endif; ?>
</div>
