<?php
if(!can_view_business_finance()) die('Bạn không có quyền xem Sales Commission.');
$month=$_GET['month'] ?? date('Y-m');

if(isset($_GET['generate_contract'])){
  $cid=(int)$_GET['generate_contract'];
  generate_sales_commission_for_contract($pdo,$cid);
  redirect('app.php?page=sales_commissions&month='.$month);
}
if(isset($_GET['approve'])){
  $id=(int)$_GET['approve'];
  $pdo->prepare("UPDATE sales_commissions SET status='approved', approved_by=?, approved_at=NOW() WHERE id=?")->execute([current_user()['id'],$id]);
  redirect('app.php?page=sales_commissions&month='.$month);
}
if(isset($_GET['paid'])){
  $id=(int)$_GET['paid'];
  $pdo->prepare("UPDATE sales_commissions SET status='paid', paid_at=NOW() WHERE id=?")->execute([$id]);
  redirect('app.php?page=sales_commissions&month='.$month);
}
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['bulk_generate'])){
  $contracts=$pdo->prepare("SELECT id FROM contracts WHERE DATE_FORMAT(COALESCE(signed_date,created_at),'%Y-%m')=? AND status IN ('Đã ký','Ký hợp đồng','Contract Signed','Hoàn thành','Đang thực hiện')");
  $contracts->execute([$month]);
  foreach($contracts->fetchAll() as $c){ generate_sales_commission_for_contract($pdo,$c['id']); }
  redirect('app.php?page=sales_commissions&month='.$month);
}

$rows=$pdo->prepare('SELECT sc.*,u.name user_name,u.avatar user_avatar,c.contract_code,c.client_name 
  FROM sales_commissions sc 
  LEFT JOIN users u ON u.id=sc.user_id 
  LEFT JOIN contracts c ON c.id=sc.contract_id 
  WHERE sc.commission_month=? 
  ORDER BY FIELD(sc.status,"pending","approved","paid"), sc.amount DESC');
$rows->execute([$month]);$rows=$rows->fetchAll();

$contracts=$pdo->prepare("SELECT c.*,u.name owner_name FROM contracts c LEFT JOIN users u ON u.id=COALESCE(c.sales_owner_id,c.care_owner_id,c.contract_owner_id,c.quote_owner_id) WHERE DATE_FORMAT(COALESCE(c.signed_date,c.created_at),'%Y-%m')=? ORDER BY c.id DESC");
$contracts->execute([$month]);$contracts=$contracts->fetchAll();
$total=0;foreach($rows as $r)$total+=(float)$r['amount'];
?>
<section class="workspace-hero finance-hero">
  <div><span class="eyebrow">Sales Commission</span><h1>Commission tháng <?= e($month) ?></h1><p class="muted">Tự tính 2% khi hợp đồng đã ký và có owner phụ trách.</p></div>
  <form method="get"><input type="hidden" name="page" value="sales_commissions"><input type="month" name="month" value="<?= e($month) ?>"><button class="btn btn-soft">Xem</button></form>
</section>
<div class="stats-grid compact-stats"><div class="stat coral"><span>Total Commission</span><strong><?= money_short($total) ?></strong></div><div class="stat yellow"><span>Số khoản</span><strong><?= count($rows) ?></strong></div></div>
<section class="card">
  <div class="card-head"><h2>Commission List</h2><form method="post"><button class="btn btn-coral" name="bulk_generate" value="1">Generate tháng này</button></form></div>
  <table class="dense-table"><thead><tr><th>Owner</th><th>Contract</th><th>Client</th><th>Value</th><th>Rate</th><th>Amount</th><th>Status</th><th>Action</th></tr></thead><tbody>
  <?php foreach($rows as $r): ?>
    <tr>
      <td><span class="user-chip"><?= avatar_html(['name'=>$r['user_name'],'avatar'=>$r['user_avatar']],true) ?><?= e($r['user_name']) ?></span></td>
      <td><?= e($r['contract_code']) ?></td><td><?= e($r['client_name']) ?></td><td><?= money($r['contract_value']) ?></td><td><?= e($r['rate_percent']) ?>%</td><td><b><?= money($r['amount']) ?></b></td>
      <td><span class="badge <?= badge_class($r['status']) ?>"><?= e($r['status']) ?></span></td>
      <td><?php if($r['status']==='pending'): ?><a class="btn btn-coral" href="app.php?page=sales_commissions&month=<?= e($month) ?>&approve=<?= $r['id'] ?>">Approve</a><?php endif; ?> <?php if($r['status']==='approved'): ?><a class="btn btn-soft" href="app.php?page=sales_commissions&month=<?= e($month) ?>&paid=<?= $r['id'] ?>">Paid</a><?php endif; ?></td>
    </tr>
  <?php endforeach; ?>
  <?php if(empty($rows)): ?><tr><td colspan="8" class="muted">Chưa có commission. Bấm Generate tháng này.</td></tr><?php endif; ?>
  </tbody></table>
</section>
<section class="card">
  <div class="card-head"><h2>Contracts tháng <?= e($month) ?></h2></div>
  <table class="dense-table"><thead><tr><th>Contract</th><th>Client</th><th>Owner</th><th>Value</th><th>Status</th><th>Action</th></tr></thead><tbody>
  <?php foreach($contracts as $c): ?>
    <tr><td><b><?= e($c['contract_code']) ?></b></td><td><?= e($c['client_name']) ?></td><td><?= e($c['owner_name']) ?></td><td><?= money($c['total_value']) ?></td><td><span class="badge <?= badge_class($c['status']) ?>"><?= e($c['status']) ?></span></td><td><a class="btn btn-soft" href="app.php?page=sales_commissions&month=<?= e($month) ?>&generate_contract=<?= $c['id'] ?>">Generate</a></td></tr>
  <?php endforeach; ?>
  </tbody></table>
</section>
