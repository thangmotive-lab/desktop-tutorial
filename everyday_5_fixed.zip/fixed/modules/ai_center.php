<?php
// Sprint 8C.4A redirect note: old AI Center route preserved for backward compatibility.
redirect('app.php?page=ai_workspace');
