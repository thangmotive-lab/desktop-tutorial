<?php
if(!can_view_business_finance()) die('Bạn không có quyền xem Approval Center.');
$tab=$_GET['tab'] ?? 'all';

if(isset($_GET['approve_task'])){
  $id=(int)$_GET['approve_task'];
  $pdo->prepare("UPDATE tasks SET status='Done', approved_by=?, approved_at=NOW(), completed_at=NOW() WHERE id=?")->execute([current_user()['id'],$id]);
  redirect('app.php?page=approval_center&tab=tasks&yay=1');
}
if(isset($_GET['approve_ctv'])){
  $id=(int)$_GET['approve_ctv'];
  $pdo->prepare("UPDATE ctv_payrolls SET status='approved', approved_by=?, approved_at=NOW() WHERE id=?")->execute([current_user()['id'],$id]);
  redirect('app.php?page=approval_center&tab=ctv');
}
if(isset($_GET['approve_commission'])){
  $id=(int)$_GET['approve_commission'];
  $pdo->prepare("UPDATE sales_commissions SET status='approved', approved_by=?, approved_at=NOW() WHERE id=?")->execute([current_user()['id'],$id]);
  redirect('app.php?page=approval_center&tab=commission');
}
if(isset($_GET['reject_task'])){
  $id=(int)$_GET['reject_task'];
  $pdo->prepare("UPDATE tasks SET status='Review' WHERE id=?")->execute([$id]);
  redirect('app.php?page=approval_center&tab=tasks');
}
if(isset($_GET['reject_ctv'])){
  $id=(int)$_GET['reject_ctv'];
  $pdo->prepare("UPDATE ctv_payrolls SET status='draft' WHERE id=?")->execute([$id]);
  redirect('app.php?page=approval_center&tab=ctv');
}
if(isset($_GET['reject_commission'])){
  $id=(int)$_GET['reject_commission'];
  $pdo->prepare("UPDATE sales_commissions SET status='pending', note=CONCAT(COALESCE(note,''),' | Returned by approval center') WHERE id=?")->execute([$id]);
  redirect('app.php?page=approval_center&tab=commission');
}

$counts=approval_counts($pdo);

$tasks=safe_rows($pdo,"SELECT t.*,p.name project_name,u.name assignee_name,u.avatar assignee_avatar FROM tasks t LEFT JOIN projects p ON p.id=t.project_id LEFT JOIN users u ON u.id=t.assignee_id WHERE t.status='Waiting Approval' ORDER BY t.submitted_at DESC,t.deadline ASC LIMIT 50");
$ctv=safe_rows($pdo,"SELECT cp.*,u.name user_name,u.avatar user_avatar FROM ctv_payrolls cp JOIN users u ON u.id=cp.user_id WHERE cp.status IN ('draft','pending') ORDER BY cp.net_amount DESC LIMIT 50");
$comm=safe_rows($pdo,"SELECT sc.*,u.name user_name,u.avatar user_avatar,c.contract_code,c.client_name FROM sales_commissions sc LEFT JOIN users u ON u.id=sc.user_id LEFT JOIN contracts c ON c.id=sc.contract_id WHERE sc.status='pending' ORDER BY sc.amount DESC LIMIT 50");
$payroll=safe_rows($pdo,"SELECT pr.*,u.name user_name,u.avatar user_avatar FROM payroll pr JOIN users u ON u.id=pr.user_id WHERE pr.status='published' AND pr.employee_approval_status='pending' ORDER BY pr.month DESC LIMIT 50");
?>
<?php if(!empty($_GET['yay'])): ?><div class="yay-toast">YAY-ME ✨</div><?php endif; ?>
<section class="workspace-hero finance-hero">
  <div>
    <span class="eyebrow">Sprint 5</span>
    <h1>Approval Center</h1>
    <p class="muted">Một nơi duy nhất để CEO/Manager duyệt task, CTV payroll, commission và payroll.</p>
  </div>
</section>

<div class="stats-grid compact-stats">
  <div class="stat coral"><span>Total waiting</span><strong><?= (int)$counts['total'] ?></strong></div>
  <div class="stat yellow"><span>Tasks</span><strong><?= (int)$counts['tasks'] ?></strong></div>
  <div class="stat purple"><span>CTV Payroll</span><strong><?= (int)$counts['ctv'] ?></strong></div>
  <div class="stat mint"><span>Commission</span><strong><?= (int)$counts['commission'] ?></strong></div>
</div>

<div class="tabs">
  <a class="<?= $tab==='all'?'active':'' ?>" href="app.php?page=approval_center&tab=all">All</a>
  <a class="<?= $tab==='tasks'?'active':'' ?>" href="app.php?page=approval_center&tab=tasks">Tasks</a>
  <a class="<?= $tab==='ctv'?'active':'' ?>" href="app.php?page=approval_center&tab=ctv">CTV Payroll</a>
  <a class="<?= $tab==='commission'?'active':'' ?>" href="app.php?page=approval_center&tab=commission">Commission</a>
  <a class="<?= $tab==='payroll'?'active':'' ?>" href="app.php?page=approval_center&tab=payroll">Salary</a>
</div>

<?php if($tab==='all' || $tab==='tasks'): ?>
<section class="card">
  <div class="card-head"><h2>Task chờ duyệt</h2></div>
  <table class="dense-table"><thead><tr><th>Task</th><th>Project</th><th>Assignee</th><th>Deadline</th><th>Action</th></tr></thead><tbody>
    <?php foreach($tasks as $t): ?><tr><td><b><?= e($t['title']) ?></b><br><span class="muted"><?= e($t['brief']) ?></span></td><td><?= e($t['project_name']) ?></td><td><span class="user-chip"><?= avatar_html(['name'=>$t['assignee_name'],'avatar'=>$t['assignee_avatar']],true) ?><?= e($t['assignee_name']) ?></span></td><td><?= e($t['deadline']) ?></td><td><a class="btn btn-coral" href="app.php?page=approval_center&approve_task=<?= $t['id'] ?>">Approve</a> <a class="btn btn-soft" href="app.php?page=approval_center&reject_task=<?= $t['id'] ?>">Return</a></td></tr><?php endforeach; ?>
    <?php if(empty($tasks)): ?><tr><td colspan="5" class="muted">Không có task chờ duyệt.</td></tr><?php endif; ?>
  </tbody></table>
</section>
<?php endif; ?>

<?php if($tab==='all' || $tab==='ctv'): ?>
<section class="card">
  <div class="card-head"><h2>CTV Payroll chờ duyệt</h2></div>
  <table class="dense-table"><thead><tr><th>CTV</th><th>Month</th><th>Gross</th><th>Deduction</th><th>Net</th><th>Status</th><th>Action</th></tr></thead><tbody>
    <?php foreach($ctv as $r): ?><tr><td><span class="user-chip"><?= avatar_html(['name'=>$r['user_name'],'avatar'=>$r['user_avatar']],true) ?><?= e($r['user_name']) ?></span></td><td><?= e($r['payroll_month']) ?></td><td><?= money($r['gross_amount']) ?></td><td><?= money($r['deduction']) ?></td><td><b><?= money($r['net_amount']) ?></b></td><td><span class="badge <?= badge_class($r['status']) ?>"><?= e($r['status']) ?></span></td><td><a class="btn btn-coral" href="app.php?page=approval_center&approve_ctv=<?= $r['id'] ?>">Approve</a> <a class="btn btn-soft" href="app.php?page=approval_center&reject_ctv=<?= $r['id'] ?>">Return</a></td></tr><?php endforeach; ?>
    <?php if(empty($ctv)): ?><tr><td colspan="7" class="muted">Không có CTV payroll chờ duyệt.</td></tr><?php endif; ?>
  </tbody></table>
</section>
<?php endif; ?>

<?php if($tab==='all' || $tab==='commission'): ?>
<section class="card">
  <div class="card-head"><h2>Commission chờ duyệt</h2></div>
  <table class="dense-table"><thead><tr><th>Owner</th><th>Contract</th><th>Client</th><th>Value</th><th>Rate</th><th>Amount</th><th>Action</th></tr></thead><tbody>
    <?php foreach($comm as $r): ?><tr><td><span class="user-chip"><?= avatar_html(['name'=>$r['user_name'],'avatar'=>$r['user_avatar']],true) ?><?= e($r['user_name']) ?></span></td><td><?= e($r['contract_code']) ?></td><td><?= e($r['client_name']) ?></td><td><?= money($r['contract_value']) ?></td><td><?= e($r['rate_percent']) ?>%</td><td><b><?= money($r['amount']) ?></b></td><td><a class="btn btn-coral" href="app.php?page=approval_center&approve_commission=<?= $r['id'] ?>">Approve</a> <a class="btn btn-soft" href="app.php?page=approval_center&reject_commission=<?= $r['id'] ?>">Return</a></td></tr><?php endforeach; ?>
    <?php if(empty($comm)): ?><tr><td colspan="7" class="muted">Không có commission chờ duyệt.</td></tr><?php endif; ?>
  </tbody></table>
</section>
<?php endif; ?>

<?php if($tab==='all' || $tab==='payroll'): ?>
<section class="card">
  <div class="card-head"><h2>Salary chờ nhân sự xác nhận</h2></div>
  <table class="dense-table"><thead><tr><th>Nhân sự</th><th>Month</th><th>KPI</th><th>Net</th><th>Status</th></tr></thead><tbody>
    <?php foreach($payroll as $r): ?><tr><td><span class="user-chip"><?= avatar_html(['name'=>$r['user_name'],'avatar'=>$r['user_avatar']],true) ?><?= e($r['user_name']) ?></span></td><td><?= e($r['month']) ?></td><td><?= e($r['kpi_percent']) ?>%</td><td><b><?= money($r['net_salary'] ?: $r['total_salary']) ?></b></td><td><span class="badge <?= badge_class($r['employee_approval_status']) ?>"><?= e($r['employee_approval_status']) ?></span></td></tr><?php endforeach; ?>
    <?php if(empty($payroll)): ?><tr><td colspan="5" class="muted">Không có salary chờ xác nhận.</td></tr><?php endif; ?>
  </tbody></table>
</section>
<?php endif; ?>
