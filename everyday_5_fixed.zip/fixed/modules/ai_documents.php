<?php
if(!is_director_role() && !is_finance_role()) die('Bạn không có quyền xem AI Documents.');
$type=$_GET['type'] ?? '';
$where=[];$params=[];
if($type){$where[]='document_type=?';$params[]=$type;}
$sql="SELECT d.*,u.name user_name,dt.template_name FROM ai_document_outputs d LEFT JOIN users u ON u.id=d.created_by LEFT JOIN document_templates dt ON dt.id=d.template_id";
if($where)$sql.=" WHERE ".implode(' AND ',$where);
$sql.=" ORDER BY d.id DESC LIMIT 100";
$st=$pdo->prepare($sql);$st->execute($params);$rows=$st->fetchAll();
$types=safe_rows($pdo,"SELECT document_type,COUNT(*) c FROM ai_document_outputs GROUP BY document_type ORDER BY c DESC");
?>
<section class="workspace-hero finance-hero ai-hero">
  <div><span class="eyebrow">AI Documents</span><h1>Generated Documents</h1><p class="muted">Hợp đồng, nghiệm thu, yêu cầu thanh toán do AI tạo.</p></div>
  <a class="btn btn-soft" href="app.php?page=ai_quote">Generate mới</a>
</section>
<div class="tabs"><a class="<?= !$type?'active':'' ?>" href="app.php?page=ai_documents">All</a><?php foreach($types as $t): ?><a class="<?= $type===$t['document_type']?'active':'' ?>" href="app.php?page=ai_documents&type=<?= e($t['document_type']) ?>"><?= e($t['document_type']) ?> (<?= $t['c'] ?>)</a><?php endforeach; ?></div>
<section class="card">
<table class="dense-table"><thead><tr><th>Date</th><th>Type</th><th>Title</th><th>Template</th><th>Source</th><th>By</th><th>Status</th><th>Action</th></tr></thead><tbody>
<?php foreach($rows as $r): ?><tr><td><?= e($r['created_at']) ?></td><td><span class="badge purple"><?= e($r['document_type']) ?></span></td><td><b><?= e($r['title']) ?></b></td><td><?= e($r['template_name']) ?></td><td><?= e($r['source_type']) ?> #<?= e($r['source_id']) ?></td><td><?= e($r['user_name']) ?></td><td><?= e($r['status']) ?></td><td><?php if($r['docx_path']): ?><a class="btn btn-soft" href="<?= e($r['docx_path']) ?>" target="_blank">DOCX</a><?php endif; ?> <?php if($r['file_path'] && !$r['docx_path']): ?><a class="btn btn-soft" href="<?= e($r['file_path']) ?>" target="_blank">Open/Print</a><?php endif; ?></td></tr><?php endforeach; ?>
<?php if(empty($rows)): ?><tr><td colspan="8" class="muted">Chưa có document AI.</td></tr><?php endif; ?>
</tbody></table>
</section>
