<?php
$me=current_user();
$period=$_GET['period'] ?? current_quarter_period();
$editObjective=null;
$editKr=null;

// Runtime schema guard for older OKR tables
try {
  $pdo->exec("ALTER TABLE okr_objectives ADD COLUMN IF NOT EXISTS objective_title VARCHAR(255) NULL");
  $pdo->exec("ALTER TABLE okr_objectives ADD COLUMN IF NOT EXISTS owner_id INT NULL");
  $pdo->exec("ALTER TABLE okr_objectives ADD COLUMN IF NOT EXISTS okr_scope VARCHAR(80) DEFAULT 'Company'");
  $pdo->exec("ALTER TABLE okr_objectives ADD COLUMN IF NOT EXISTS period VARCHAR(20) NULL");
  $pdo->exec("ALTER TABLE okr_objectives ADD COLUMN IF NOT EXISTS status VARCHAR(50) DEFAULT 'active'");
  $pdo->exec("ALTER TABLE okr_objectives ADD COLUMN IF NOT EXISTS progress DECIMAL(5,2) DEFAULT 0");
  $pdo->exec("ALTER TABLE okr_objectives ADD COLUMN IF NOT EXISTS description TEXT");
  $pdo->exec("ALTER TABLE okr_objectives ADD COLUMN IF NOT EXISTS created_by INT NULL");
  $pdo->exec("ALTER TABLE okr_key_results ADD COLUMN IF NOT EXISTS kr_title VARCHAR(255) NULL");
  $pdo->exec("ALTER TABLE okr_key_results ADD COLUMN IF NOT EXISTS metric_type VARCHAR(80) DEFAULT 'number'");
  $pdo->exec("ALTER TABLE okr_key_results ADD COLUMN IF NOT EXISTS start_value DECIMAL(15,2) DEFAULT 0");
  $pdo->exec("ALTER TABLE okr_key_results ADD COLUMN IF NOT EXISTS target_value DECIMAL(15,2) DEFAULT 100");
  $pdo->exec("ALTER TABLE okr_key_results ADD COLUMN IF NOT EXISTS current_value DECIMAL(15,2) DEFAULT 0");
  $pdo->exec("ALTER TABLE okr_key_results ADD COLUMN IF NOT EXISTS weight DECIMAL(5,2) DEFAULT 1.00");
  $pdo->exec("ALTER TABLE okr_key_results ADD COLUMN IF NOT EXISTS progress DECIMAL(5,2) DEFAULT 0");
  $pdo->exec("ALTER TABLE okr_key_results ADD COLUMN IF NOT EXISTS status VARCHAR(50) DEFAULT 'active'");
  $pdo->exec("ALTER TABLE okr_key_results ADD COLUMN IF NOT EXISTS linked_module VARCHAR(80) NULL");
  $pdo->exec("ALTER TABLE okr_key_results ADD COLUMN IF NOT EXISTS linked_query VARCHAR(255) NULL");
} catch(Exception $e) {}


if(isset($_GET['delete_obj']) && user_is_admin()){
  $oid=(int)$_GET['delete_obj'];
  $pdo->prepare('DELETE FROM okr_updates WHERE objective_id=?')->execute([$oid]);
  $pdo->prepare('DELETE FROM okr_key_results WHERE objective_id=?')->execute([$oid]);
  $pdo->prepare('DELETE FROM okr_objectives WHERE id=?')->execute([$oid]);
  redirect('app.php?page=okr&period='.$period);
}

if(isset($_GET['edit_obj'])){
  $st=$pdo->prepare('SELECT * FROM okr_objectives WHERE id=?');
  $st->execute([(int)$_GET['edit_obj']]);
  $editObjective=$st->fetch();
}

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['save_objective'])){
  if(!empty($_POST['objective_id'])){
    $pdo->prepare('UPDATE okr_objectives SET objective_title=?, owner_id=?, okr_scope=?, period=?, status=?, description=? WHERE id=?')
      ->execute([$_POST['objective_title'],$_POST['owner_id']?:null,$_POST['okr_scope'],$_POST['period'],$_POST['status'],$_POST['description'],$_POST['objective_id']]);
    $oid=(int)$_POST['objective_id'];
  } else {
    $pdo->prepare('INSERT INTO okr_objectives(objective_title,owner_id,okr_scope,period,status,description,created_by) VALUES(?,?,?,?,?,?,?)')
      ->execute([$_POST['objective_title'],$_POST['owner_id']?:null,$_POST['okr_scope'],$_POST['period'],'active',$_POST['description'],$me['id']]);
    $oid=(int)$pdo->lastInsertId();
  }
  redirect('app.php?page=okr&period='.$_POST['period'].'&edit_obj='.$oid);
}

if(isset($_GET['edit_kr'])){ $kst=$pdo->prepare('SELECT * FROM okr_key_results WHERE id=?'); $kst->execute([(int)$_GET['edit_kr']]); $editKr=$kst->fetch(); }

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['save_kr'])){
  $current=(float)$_POST['current_value'];
  $target=(float)$_POST['target_value'];
  $start=(float)$_POST['start_value'];
  $progress=calc_kr_progress($current,$target,$start);
  if(!empty($_POST['kr_id'])){
    $old=$pdo->prepare('SELECT current_value FROM okr_key_results WHERE id=?');$old->execute([$_POST['kr_id']]);$oldValue=$old->fetchColumn();
    $pdo->prepare('UPDATE okr_key_results SET kr_title=?,metric_type=?,start_value=?,target_value=?,current_value=?,weight=?,progress=?,status=?,linked_module=?,linked_query=? WHERE id=?')
      ->execute([$_POST['kr_title'],$_POST['metric_type'],$start,$target,$current,$_POST['weight']?:1,$progress,$_POST['status'],$_POST['linked_module'],$_POST['linked_query'],$_POST['kr_id']]);
    $kid=(int)$_POST['kr_id'];
    $oid=(int)$_POST['objective_id'];
    $pdo->prepare('INSERT INTO okr_updates(objective_id,key_result_id,user_id,update_note,old_value,new_value) VALUES(?,?,?,?,?,?)')
      ->execute([$oid,$kid,$me['id'],$_POST['update_note']??'Update KR',$oldValue,$current]);
  } else {
    $oid=(int)$_POST['objective_id'];
    $pdo->prepare('INSERT INTO okr_key_results(objective_id,kr_title,metric_type,start_value,target_value,current_value,weight,progress,status,linked_module,linked_query) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
      ->execute([$oid,$_POST['kr_title'],$_POST['metric_type'],$start,$target,$current,$_POST['weight']?:1,$progress,'active',$_POST['linked_module'],$_POST['linked_query']]);
  }
  recalc_okr_objective($pdo,$oid);
  redirect('app.php?page=okr&period='.$period.'&edit_obj='.$oid);
}

if(isset($_GET['sync'])){
  $oid=(int)$_GET['sync'];
  $krs=$pdo->prepare('SELECT * FROM okr_key_results WHERE objective_id=?');
  $krs->execute([$oid]);
  foreach($krs->fetchAll() as $kr){
    $value=null;
    if($kr['linked_module']==='revenue'){
      $value=safe_sum($pdo,"SELECT COALESCE(SUM(total_value),0) FROM contracts WHERE DATE_FORMAT(COALESCE(signed_date,created_at),'%Y-%m')='".date('Y-m')."'");
    } elseif($kr['linked_module']==='contracts'){
      $value=safe_sum($pdo,"SELECT COUNT(*) FROM contracts WHERE DATE_FORMAT(COALESCE(signed_date,created_at),'%Y-%m')='".date('Y-m')."'");
    } elseif($kr['linked_module']==='quotations'){
      $value=safe_sum($pdo,"SELECT COUNT(*) FROM quotations WHERE DATE_FORMAT(created_at,'%Y-%m')='".date('Y-m')."'");
    } elseif($kr['linked_module']==='tasks_done'){
      $value=safe_sum($pdo,"SELECT COUNT(*) FROM tasks WHERE status='Done' AND DATE_FORMAT(COALESCE(completed_at,deadline),'%Y-%m')='".date('Y-m')."'");
    }
    if($value!==null){
      $progress=calc_kr_progress($value,$kr['target_value'],$kr['start_value']);
      $pdo->prepare('UPDATE okr_key_results SET current_value=?,progress=? WHERE id=?')->execute([$value,$progress,$kr['id']]);
    }
  }
  recalc_okr_objective($pdo,$oid);
  redirect('app.php?page=okr&period='.$period.'&edit_obj='.$oid);
}

$users=$pdo->query('SELECT id,name,avatar FROM users ORDER BY name')->fetchAll();
$objectives=$pdo->prepare('SELECT o.*,u.name owner_name,u.avatar owner_avatar FROM okr_objectives o LEFT JOIN users u ON u.id=o.owner_id WHERE o.period=? ORDER BY o.id DESC');
$objectives->execute([$period]);$objectives=$objectives->fetchAll();

$selected=$editObjective ?: ($objectives[0] ?? null);
$krs=[];
if($selected){
  $st=$pdo->prepare('SELECT * FROM okr_key_results WHERE objective_id=? ORDER BY id ASC');
  $st->execute([$selected['id']]);$krs=$st->fetchAll();
}
?>
<section class="workspace-hero finance-hero">
  <div>
    <span class="eyebrow">Sprint 6</span>
    <h1>Agency OKR</h1>
    <p class="muted">Quản trị mục tiêu công ty, team và cá nhân theo quý/tháng.</p>
  </div>
  <form method="get"><input type="hidden" name="page" value="okr"><input name="period" value="<?= e($period) ?>" placeholder="2026-Q2 hoặc 2026-06"><button class="btn btn-soft">Xem</button></form>
</section>

<div class="two-col">
<section class="card">
  <div class="card-head"><h2>Objectives</h2><button class="primary" onclick="openModal('objectiveModal')">+ Objective</button></div>
  <div class="okr-list">
    <?php foreach($objectives as $o): ?>
      <a class="okr-objective-card <?= $selected && $selected['id']==$o['id']?'active':'' ?>" href="app.php?page=okr&period=<?= e($period) ?>&edit_obj=<?= $o['id'] ?>">
        <div><b><?= e($o['objective_title']) ?></b><span><?= e($o['okr_scope']) ?> · <?= e($o['owner_name']) ?></span></div>
        <strong><?= num($o['progress']) ?>%</strong>
        <div class="progress"><span style="width:<?= min(100,(float)$o['progress']) ?>%"></span></div>
      </a>
    <?php endforeach; ?>
    <?php if(empty($objectives)): ?><p class="muted">Chưa có Objective trong period này.</p><?php endif; ?>
  </div>
</section>

<section class="card">
  <div class="card-head">
    <div><h2><?= $selected?e($selected['objective_title']):'Chọn Objective' ?></h2><?php if($selected): ?><p class="muted"><?= e($selected['description']) ?></p><?php endif; ?></div>
    <?php if($selected): ?><div><button class="btn btn-soft" onclick="openModal('objectiveModal')">Sửa Objective</button> <a class="btn btn-soft" href="app.php?page=okr&period=<?= e($period) ?>&sync=<?= $selected['id'] ?>">Sync data</a> <button class="btn btn-coral" onclick="openModal('krModal')">+ KR</button></div><?php endif; ?>
  </div>
  <?php if($selected): ?>
  <div class="okr-hero-progress"><strong><?= num($selected['progress']) ?>%</strong><div class="progress"><span style="width:<?= min(100,(float)$selected['progress']) ?>%"></span></div></div>
  <table class="dense-table"><thead><tr><th>Key Result</th><th>Current</th><th>Target</th><th>Progress</th><th>Linked</th></tr></thead><tbody>
    <?php foreach($krs as $kr): ?><tr><td><b><?= e($kr['kr_title']) ?></b></td><td><?= num($kr['current_value']) ?></td><td><?= num($kr['target_value']) ?></td><td><div class="progress"><span style="width:<?= min(100,(float)$kr['progress']) ?>%"></span></div><?= num($kr['progress']) ?>%</td><td><?= e($kr['linked_module']) ?></td></tr><?php endforeach; ?>
    <?php if(empty($krs)): ?><tr><td colspan="5" class="muted">Chưa có Key Result.</td></tr><?php endif; ?>
  </tbody></table>
  <?php endif; ?>
</section>
</div>

<div class="modal-backdrop" id="objectiveModal">
  <div class="modal-panel">
    <button class="modal-close" onclick="closeModal('objectiveModal')">×</button>
    <h2>Tạo Objective</h2>
    <form method="post">
      <input type="hidden" name="save_objective" value="1">
      <label>Objective</label><input name="objective_title" required>
      <label>Owner</label><select name="owner_id"><option value="">Company</option><?php foreach($users as $u): ?><option value="<?= $u['id'] ?>"><?= e($u['name']) ?></option><?php endforeach; ?></select>
      <div class="form-row"><div><label>Scope</label><select name="okr_scope"><option>Company</option><option>Team</option><option>Personal</option></select></div><div><label>Period</label><input name="period" value="<?= e($period) ?>"></div></div>
      <input type="hidden" name="status" value="active">
      <label>Description</label><textarea name="description"></textarea>
      <button class="primary">Lưu Objective</button>
    </form>
  </div>
</div>

<?php if($selected): ?>
<div class="modal-backdrop" id="krModal">
  <div class="modal-panel">
    <button class="modal-close" onclick="closeModal('krModal')">×</button>
    <h2>Thêm Key Result</h2>
    <form method="post">
      <input type="hidden" name="save_kr" value="1">
      <input type="hidden" name="objective_id" value="<?= (int)$selected['id'] ?>">
      <label>Key Result</label><input name="kr_title" required value="<?= e($editKr['kr_title']??'') ?>">
      <div class="form-row-3"><div><label>Start</label><input type="number" step="0.01" name="start_value" value="<?= e($editKr['start_value']??0) ?>"></div><div><label>Current</label><input type="number" step="0.01" name="current_value" value="<?= e($editKr['current_value']??0) ?>"></div><div><label>Target</label><input type="number" step="0.01" name="target_value" value="<?= e($editKr['target_value']??100) ?>"></div></div>
      <div class="form-row"><div><label>Metric</label><select name="metric_type"><option>number</option><option>money</option><option>percent</option></select></div><div><label>Weight</label><input type="number" step="0.1" name="weight" value="<?= e($editKr['weight']??1) ?>"></div></div>
      <label>Linked module</label><select name="linked_module"><option value="">Không sync</option><option value="revenue">Revenue tháng hiện tại</option><option value="contracts">Số hợp đồng tháng hiện tại</option><option value="quotations">Số báo giá tháng hiện tại</option><option value="tasks_done">Task Done tháng hiện tại</option></select>
      <input type="hidden" name="linked_query" value="">
      <input type="hidden" name="status" value="active">
      <label>Update note</label><textarea name="update_note"></textarea>
      <button class="primary">Lưu KR</button>
    </form>
  </div>
</div>
<?php endif; ?>
