<?php
if(!is_director_role() && !is_finance_role()) die('Bạn không có quyền xem Knowledge Base.');

$categories=['Agency Profile','Case Study','Pricing','Services','Workflow','Client Information','Proposal Assets','General'];
$category=$_GET['category'] ?? '';
$q=trim($_GET['q']??'');
$edit=null;

if(isset($_GET['delete']) && user_is_admin()){
  $pdo->prepare("UPDATE ai_knowledge_base SET is_active=0, updated_by=? WHERE id=?")->execute([current_user()['id'],(int)$_GET['delete']]);
  redirect('app.php?page=ai_knowledge_base');
}
if(isset($_GET['duplicate'])){
  $id=(int)$_GET['duplicate'];
  $st=$pdo->prepare("SELECT * FROM ai_knowledge_base WHERE id=?");$st->execute([$id]);$r=$st->fetch();
  if($r){
    $pdo->prepare("INSERT INTO ai_knowledge_base(title,category,content,tags,version,is_active,created_by,updated_by) VALUES(?,?,?,?,?,?,?,?)")
      ->execute([$r['title'].' Copy',$r['category'],$r['content'],$r['tags'],$r['version'],1,current_user()['id'],current_user()['id']]);
  }
  redirect('app.php?page=ai_knowledge_base');
}
if(isset($_GET['edit'])){
  $st=$pdo->prepare("SELECT * FROM ai_knowledge_base WHERE id=?");$st->execute([(int)$_GET['edit']]);$edit=$st->fetch();
}
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['save_kb'])){
  if(!empty($_POST['kb_id'])){
    $pdo->prepare("UPDATE ai_knowledge_base SET title=?,category=?,content=?,tags=?,version=?,is_active=?,updated_by=? WHERE id=?")
      ->execute([$_POST['title'],$_POST['category'],$_POST['content'],$_POST['tags'],$_POST['version'],isset($_POST['is_active'])?1:0,current_user()['id'],$_POST['kb_id']]);
  } else {
    $pdo->prepare("INSERT INTO ai_knowledge_base(title,category,content,tags,version,is_active,created_by,updated_by) VALUES(?,?,?,?,?,?,?,?)")
      ->execute([$_POST['title'],$_POST['category'],$_POST['content'],$_POST['tags'],$_POST['version']?:'1.0',isset($_POST['is_active'])?1:0,current_user()['id'],current_user()['id']]);
  }
  redirect('app.php?page=ai_knowledge_base');
}

$where=["is_active=1"];$params=[];
if($category){$where[]="category=?";$params[]=$category;}
if($q!==''){$where[]="(title LIKE ? OR content LIKE ? OR tags LIKE ?)";array_push($params,"%$q%","%$q%","%$q%");}
$sql="SELECT kb.*,u.name user_name FROM ai_knowledge_base kb LEFT JOIN users u ON u.id=kb.updated_by WHERE ".implode(" AND ",$where)." ORDER BY kb.updated_at DESC,kb.id DESC";
$stmt=$pdo->prepare($sql);$stmt->execute($params);$rows=$stmt->fetchAll();
?>
<section class="workspace-hero ai-workspace-hero">
  <div><span class="eyebrow">AI Workspace</span><h1>Knowledge Base</h1><p class="muted">Nguồn dữ liệu AI dùng để viết proposal, báo giá, hợp đồng và nội dung.</p></div>
  <button class="primary" onclick="openModal('kbModal')">+ Knowledge</button>
</section>

<form class="asana-toolbar" method="get">
  <input type="hidden" name="page" value="ai_knowledge_base">
  <input name="q" value="<?= e($q) ?>" placeholder="Tìm knowledge...">
  <select name="category"><option value="">Tất cả category</option><?php foreach($categories as $c): ?><option value="<?= e($c) ?>" <?= $category===$c?'selected':'' ?>><?= e($c) ?></option><?php endforeach; ?></select>
  <button class="btn btn-soft">Filter</button>
</form>

<section class="card">
  <div class="card-head"><h2>Knowledge Records</h2></div>
  <table class="dense-table">
    <thead><tr><th>Title</th><th>Category</th><th>Tags</th><th>Version</th><th>Updated</th><th>Action</th></tr></thead>
    <tbody>
      <?php foreach($rows as $r): ?>
        <tr>
          <td><b><?= e($r['title']) ?></b><br><span class="muted"><?= e(mb_substr(strip_tags($r['content']),0,120)) ?></span></td>
          <td><span class="badge purple"><?= e($r['category']) ?></span></td>
          <td><?= e($r['tags']) ?></td>
          <td><?= e($r['version']) ?></td>
          <td><?= e($r['updated_at']) ?><br><span class="muted"><?= e($r['user_name']) ?></span></td>
          <td class="actions"><a class="btn btn-soft" href="app.php?page=ai_knowledge_base&edit=<?= $r['id'] ?>">Edit</a><a class="btn btn-soft" href="app.php?page=ai_knowledge_base&duplicate=<?= $r['id'] ?>">Duplicate</a><?php if(user_is_admin()): ?><a class="btn btn-soft" onclick="return confirm('Archive knowledge?')" href="app.php?page=ai_knowledge_base&delete=<?= $r['id'] ?>">Archive</a><?php endif; ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if(empty($rows)): ?><tr><td colspan="6" class="muted">Chưa có knowledge.</td></tr><?php endif; ?>
    </tbody>
  </table>
</section>

<div class="modal-backdrop <?= $edit?'active':'' ?>" id="kbModal">
  <div class="modal-panel large-modal">
    <button class="modal-close" onclick="closeModal('kbModal')">×</button>
    <h2><?= $edit?'Edit Knowledge':'Create Knowledge' ?></h2>
    <form method="post">
      <input type="hidden" name="save_kb" value="1">
      <input type="hidden" name="kb_id" value="<?= e($edit['id']??'') ?>">
      <label>Title</label><input name="title" required value="<?= e($edit['title']??'') ?>">
      <div class="form-row"><div><label>Category</label><select name="category"><?php foreach($categories as $c): ?><option value="<?= e($c) ?>" <?= ($edit['category']??'')===$c?'selected':'' ?>><?= e($c) ?></option><?php endforeach; ?></select></div><div><label>Version</label><input name="version" value="<?= e($edit['version']??'1.0') ?>"></div></div>
      <label>Tags</label><input name="tags" value="<?= e($edit['tags']??'') ?>" placeholder="pricing, motive, case-study...">
      <label>Content</label><textarea name="content" rows="12" required><?= e($edit['content']??'') ?></textarea>
      <label class="check-row"><input type="checkbox" name="is_active" value="1" <?= !isset($edit['is_active']) || $edit['is_active']?'checked':'' ?>> Active</label>
      <button class="primary">Save Knowledge</button>
    </form>
  </div>
</div>
<?php if($edit): ?><script>document.addEventListener('DOMContentLoaded',()=>openModal('kbModal'));</script><?php endif; ?>
