<?php
function workspace_table_exists($pdo,$table){
  try{$st=$pdo->prepare("SHOW TABLES LIKE ?");$st->execute([$table]);return (bool)$st->fetchColumn();}catch(Exception $e){return false;}
}
function workspace_column_exists($pdo,$table,$column){
  try{$st=$pdo->prepare("SHOW COLUMNS FROM `$table` LIKE ?");$st->execute([$column]);return (bool)$st->fetch();}catch(Exception $e){return false;}
}

$me=current_user();
$uid=(int)$me['id'];

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['update_workspace_task'])){
  $taskId=(int)($_POST['task_id'] ?? 0);
  $title=trim($_POST['task_title'] ?? '');
  if($taskId>0 && $title!==''){
    $deadline=trim($_POST['task_deadline'] ?? '');
    if($deadline && strlen($deadline)===16){ $deadline=str_replace('T',' ',$deadline).':00'; }
    $priority=normalize_priority($_POST['task_priority'] ?? '');
    $status=$_POST['task_status'] ?? 'Todo';
    $brief=trim($_POST['task_brief'] ?? '');
    $desc=trim($_POST['task_description'] ?? '');
    $sets=['title=?','priority=?','status=?','deadline=?'];
    $vals=[$title,$priority,$status,$deadline ?: null];
    foreach(['brief'=>$brief,'description'=>$desc] as $col=>$val){ if(workspace_column_exists($pdo,'tasks',$col)){ $sets[]="$col=?"; $vals[]=$val; } }
    $vals[]=$taskId; $vals[]=$uid;
    $pdo->prepare('UPDATE tasks SET '.implode(',',$sets).' WHERE id=? AND (assignee_id=? OR created_by=?)')->execute($vals);
    log_activity($pdo,'update','task',$taskId,'Sửa task từ workspace popup');
  }
  redirect('app.php?page=workspace');
}

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['create_private_task'])){
  $title=trim($_POST['private_task_title'] ?? '');
  if($title!==''){
    $due=($_POST['private_due_datetime'] ?? '') ?: ($_POST['private_due_date'] ?? null);
    if($due && strlen($due)===16){ $due=str_replace('T',' ',$due).':00'; }
    $desc=trim($_POST['private_description'] ?? '');
    $cols=['title','assignee_id','created_by','status','priority','deadline','created_at'];
    $vals=[$title,$uid,$uid,'todo',normalize_priority($_POST['private_priority'] ?? ''),$due,date('Y-m-d H:i:s')];
    foreach(['description'=>$desc,'due_date'=>$due,'is_private'=>1,'task_scope'=>'personal'] as $col=>$val){
      if(workspace_column_exists($pdo,'tasks',$col)){ $cols[]=$col; $vals[]=$val; }
    }
    $pdo->prepare('INSERT INTO tasks('.implode(',',$cols).') VALUES('.implode(',',array_fill(0,count($cols),'?')).')')->execute($vals);
    log_activity($pdo,'create','task',$pdo->lastInsertId(),'Tạo task cá nhân private');
  }
  redirect('app.php?page=workspace');
}

$quotesOfToday = [
  'Tập trung vào việc quan trọng nhất, phần còn lại sẽ nhẹ hơn.',
  'Mỗi task hoàn thành là một bước tiến của cả team.',
  'Không cần hoàn hảo ngay, chỉ cần tiến lên mỗi ngày.',
  'Làm tốt việc nhỏ, agency sẽ thắng ở việc lớn.',
  'Team mạnh là team biết hỗ trợ nhau đúng lúc.'
];
$quoteToday = $quotesOfToday[(int)date('z') % count($quotesOfToday)];
function workspace_deadline_label($date){
  $ts=strtotime((string)$date); if(!$ts) return '-';
  $diff=$ts-time(); if($diff<=0) return 'Quá hạn';
  if($diff < 86400) return max(1,(int)ceil($diff/3600)).' giờ';
  return max(1,(int)ceil($diff/86400)).' ngày';
}

$tab='priority';
$privateCondition="(COALESCE(t.is_private,0)=1 OR COALESCE(t.task_scope,'')='personal' OR t.project_id IS NULL)";
$baseTaskWhere="(t.assignee_id=$uid OR t.created_by=$uid) AND NOT $privateCondition";
$taskQueries=[
  'priority'=>"$baseTaskWhere AND t.status!='Done' AND (t.priority IN ('Khẩn cấp làm ngay','Làm ngay','Quan trọng') OR t.deadline <= DATE_ADD(CURDATE(), INTERVAL 5 DAY) OR t.deadline IS NULL)",
  'week'=>"$baseTaskWhere AND t.status!='Done' AND t.deadline BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)",
  'late'=>"$baseTaskWhere AND t.status!='Done' AND t.deadline < CURDATE()",
  'done'=>"$baseTaskWhere AND t.status='Done'"
];
$taskGroups=[];
foreach($taskQueries as $k=>$where){
  $taskGroups[$k]=safe_rows($pdo,"SELECT t.*,p.name project_name,p.client_name,u.name assignee_name,u.avatar assignee_avatar FROM tasks t LEFT JOIN projects p ON p.id=t.project_id LEFT JOIN users u ON u.id=t.assignee_id WHERE $where ORDER BY CASE WHEN t.deadline IS NULL THEN 1 ELSE 0 END,t.deadline ASC,t.id DESC LIMIT 5");
}

$privateTasks=safe_rows($pdo,"SELECT t.*,p.name project_name FROM tasks t LEFT JOIN projects p ON p.id=t.project_id WHERE (t.assignee_id=$uid OR t.created_by=$uid) AND t.status!='Done' AND $privateCondition ORDER BY CASE WHEN t.deadline IS NULL THEN 1 ELSE 0 END,t.deadline ASC,t.id DESC LIMIT 24");
$privateByHour=[];
foreach($privateTasks as $pt){
  $key='unscheduled'; $label='Chưa xếp giờ';
  if(!empty($pt['deadline'])){ $ts=strtotime($pt['deadline']); if($ts){ $key=date('H',$ts); $label=date('H:00',$ts); } }
  $privateByHour[$key]['label']=$label;
  $privateByHour[$key]['items'][]=$pt;
}
uksort($privateByHour,function($a,$b){ if($a==='unscheduled') return 1; if($b==='unscheduled') return -1; return (int)$a <=> (int)$b; });

$dueProjects=safe_rows($pdo,"SELECT p.*,u.name owner_name,u.avatar owner_avatar FROM projects p LEFT JOIN users u ON u.id=p.owner_id WHERE p.end_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 14 DAY) AND p.status NOT IN ('Completed','Hoàn tất','Đã nghiệm thu') ORDER BY p.end_date ASC LIMIT 6");

$working=safe_rows($pdo,"SELECT u.name,u.avatar,a.checkin_time FROM attendance a JOIN users u ON u.id=a.user_id WHERE a.work_date=CURDATE() AND a.checkin_time IS NOT NULL AND a.checkout_time IS NULL ORDER BY a.checkin_time DESC LIMIT 8");

$taskStatsRow = safe_rows($pdo, "SELECT 
  COUNT(*) total_tasks,
  SUM(CASE WHEN status='Done' THEN 1 ELSE 0 END) done_tasks,
  SUM(CASE WHEN status NOT IN ('Done') AND status IN ('Doing','Review','In Progress') THEN 1 ELSE 0 END) doing_tasks,
  SUM(CASE WHEN status!='Done' AND deadline BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY) THEN 1 ELSE 0 END) near_deadlines
  FROM tasks WHERE assignee_id=$uid OR created_by=$uid");
$taskStats = $taskStatsRow[0] ?? [];
$totalTasks = (int)($taskStats['total_tasks'] ?? 0);
$doneTasks = (int)($taskStats['done_tasks'] ?? 0);
$doingTasks = (int)($taskStats['doing_tasks'] ?? 0);
$nearDeadlines = (int)($taskStats['near_deadlines'] ?? 0);
$mcoinBalance = function_exists('mcoin_balance') ? mcoin_balance($pdo,$uid) : 0;
?>
<section class="workspace-v4-hero prairie-8e" id="workspacePrairie">
  <div class="prairie-8e-scene" aria-hidden="true">
    <span class="prairie-8e-sun"></span>
    <span class="prairie-8e-moon"></span>
    <span class="prairie-8e-stars"></span>
    <span class="prairie-8e-cloud cloud-a"></span>
    <span class="prairie-8e-cloud cloud-b"></span>
    <span class="prairie-8e-hill hill-a"></span>
    <span class="prairie-8e-hill hill-b"></span>
    <span class="prairie-8e-grass"></span>
  </div>
  <div class="workspace-v4-welcome">
    <div class="workspace-v4-copy">
      <span class="eyebrow">Welcome back, <?= e($me['name']) ?> 👋</span>
      <h1>Chào <?= e($me['name']) ?>!</h1>
      <p>“<?= e($quoteToday) ?>”</p>
    </div>
    <div class="workspace-v4-stats" aria-label="Tổng quan công việc">
      <div class="workspace-v4-stat purple"><span>▣</span><small>Tổng task</small><b><?= $totalTasks ?></b></div>
      <div class="workspace-v4-stat green"><span>✓</span><small>Đã hoàn thành</small><b><?= $doneTasks ?></b></div>
      <div class="workspace-v4-stat yellow"><span>◷</span><small>Đang làm</small><b><?= $doingTasks ?></b></div>
      <div class="workspace-v4-stat red"><span>⚑</span><small>Deadline gần</small><b><?= $nearDeadlines ?></b></div>
      <div class="workspace-v4-stat coin"><span>🪙</span><small>Mcoin</small><b><?= number_format((int)$mcoinBalance,0,',','.') ?></b></div>
    </div>
  </div>
</section>

<div class="workspace-v4-grid">
  <section class="card priority-8e-board workspace-v4-priority">
    <div class="card-head">
      <div><span class="eyebrow">Command Center</span><h2>Task ưu tiên</h2><p class="muted">5 việc quan trọng nhất cần xử lý ngay.</p></div>
      <a class="btn btn-soft" href="app.php?page=tasks">Mở tất cả tasks →</a>
    </div>
    <div class="tabs compact-tabs command-tabs" role="tablist">
      <button class="active" type="button" data-command-tab="priority">Ưu tiên</button>
      <button type="button" data-command-tab="week">7 ngày tới</button>
      <button type="button" data-command-tab="late">Quá hạn</button>
      <button type="button" data-command-tab="done">Đã xong</button>
    </div>
    <!-- MOTIVE_TASKLIST_V4_ACTIVE -->
    <?php foreach(['priority'=>'Không có task ưu tiên.','week'=>'Không có task trong 7 ngày tới.','late'=>'Không có task quá hạn.','done'=>'Chưa có task đã xong.'] as $panelKey=>$emptyText): $panelTasks=$taskGroups[$panelKey] ?? []; ?>
    <div class="command-panel <?= $panelKey==='priority'?'active':'' ?>" data-command-panel="<?= e($panelKey) ?>">
      <div class="priority-task-list-v4">
        <?php foreach($panelTasks as $t):
          $taskPayload = json_encode(["id"=>$t["id"],"title"=>$t["title"],"brief"=>$t["brief"]??"","description"=>$t["description"]??"","deadline"=>$t["deadline"]??"","priority"=>normalize_priority($t["priority"]??""),"status"=>$t["status"]??"Todo"], JSON_UNESCAPED_UNICODE);
          $isDone = ($t['status'] ?? '') === 'Done';
        ?>
          <article class="priority-task-item-v4 <?= $isDone?'is-done':'' ?>">
            <div class="priority-task-check-v4">
              <?php if(!$isDone): ?>
                <a class="task-check js-task-delight-done" title="Hoàn thành" href="app.php?page=tasks&advance=<?= $t['id'] ?>&from_workspace=1" data-task-id="<?= $t['id'] ?>">✓</a>
              <?php else: ?>
                <span class="task-check done">✓</span>
              <?php endif; ?>
            </div>

            <button type="button" class="priority-task-main-v4 task-popup-open" onclick='openWorkspaceTaskEdit(<?= $taskPayload ?>)'>
              <b><?= e($t['title']) ?></b>
              <small>
                <?php if($t['project_id']): ?><?= e($t['project_name'] ?: 'Project') ?><?php else: ?>Private task<?php endif; ?>
                <?php if(!empty($t['client_name'])): ?> · <?= e($t['client_name']) ?><?php endif; ?>
                <?php if(!empty($t['brief'])): ?> · <?= e(mb_substr($t['brief'],0,72)) ?><?php endif; ?>
              </small>
            </button>

            <div class="priority-task-meta-v4">
              <span class="badge <?= badge_class($t['priority']) ?>"><?= e($t['priority']) ?></span>
              <span class="countdown-pill" data-deadline="<?= e($t['deadline']) ?>"></span>
              <span class="badge <?= badge_class($t['status']) ?>"><?= e($t['status']) ?></span>
            </div>

            <button class="icon-action priority-task-edit-v4" title="Sửa task" type="button" onclick='openWorkspaceTaskEdit(<?= $taskPayload ?>)'>✎</button>
          </article>
        <?php endforeach; ?>
        <?php if(empty($panelTasks)): ?>
          <div class="priority-task-empty-v4"><?= e($emptyText) ?></div>
        <?php endif; ?>
      </div>
    </div>
    <?php endforeach; ?>
  </section>

  <aside class="workspace-v4-side">
    <section class="card personal-v4-card">
      <div class="card-head compact-head"><div><span class="eyebrow">Private</span><h2>Task cá nhân</h2><p class="muted"><?= count($privateTasks) ?> việc cá nhân hôm nay</p></div><button class="primary small-btn" onclick="openModal('privateTaskModal')">+ Task cá nhân</button></div>
      <div class="personal-v4-list">
        <?php foreach(array_slice($privateTasks,0,3) as $t): ?>
          <div class="personal-v4-item">
            <?php if($t['status']!=='Done'): ?><a class="task-check js-task-delight-done" href="app.php?page=tasks&advance=<?= $t['id'] ?>&from_workspace=1" data-task-id="<?= $t['id'] ?>">✓</a><?php else: ?><span class="task-check done">✓</span><?php endif; ?>
            <a href="app.php?page=tasks&focus=<?= $t['id'] ?>"><b><?= e($t['title']) ?></b></a>
          </div>
        <?php endforeach; ?>
        <?php if(empty($privateTasks)): ?><p class="muted">Chưa có task cá nhân.</p><?php endif; ?>
      </div>
      <a class="see-all-v4" href="app.php?page=tasks">Xem tất cả →</a>
    </section>

    <section class="card ending-8e-card">
      <div class="card-head compact-head"><div><span class="eyebrow">Deadline</span><h2>Project sắp kết thúc</h2></div><a class="btn btn-soft" href="app.php?page=projects">All</a></div>
      <div class="ending-8e-list">
        <?php foreach($dueProjects as $p): $leftLabel=workspace_deadline_label($p['end_date']); $danger=(strtotime($p['end_date'])-time()) <= 3*86400; ?>
          <a class="ending-8e-item" href="app.php?page=project_detail&id=<?= $p['id'] ?>">
            <div><b><?= e($p['name']) ?></b><small><?= e($p['client_name']) ?> · PM: <?= e($p['owner_name']) ?></small></div>
            <span class="<?= $danger?'danger':'' ?>"><?= e($leftLabel) ?></span>
          </a>
        <?php endforeach; ?>
        <?php if(empty($dueProjects)): ?><p class="muted">Không có project sắp kết thúc.</p><?php endif; ?>
      </div>
    </section>

    <section class="card team-8e-card">
      <div class="card-head compact-head"><div><span class="eyebrow">Team Pulse</span><h2>Đang chấm công</h2><p class="muted"><?= count($working) ?> thành viên đang làm việc</p></div><a class="btn btn-soft" href="app.php?page=attendance">Xem tất cả →</a></div>
      <div class="team-v4-avatars">
        <?php foreach(array_slice($working,0,6) as $w): ?>
          <div><?= avatar_html($w,true) ?><b><?= e($w['name']) ?></b><small><?= e(substr($w['checkin_time'],0,5)) ?></small></div>
        <?php endforeach; ?>
        <?php if(empty($working)): ?><p class="muted">Chưa có ai check-in đang làm.</p><?php endif; ?>
      </div>
    </section>
  </aside>
</div>



<div class="modal-backdrop" id="workspaceTaskEditModal">
  <div class="modal-panel task-edit-popup-panel">
    <button class="modal-close" type="button" onclick="closeModal('workspaceTaskEditModal')">×</button>
    <span class="eyebrow">Edit task</span>
    <h2>Sửa task</h2>
    <form method="post">
      <input type="hidden" name="update_workspace_task" value="1">
      <input type="hidden" name="task_id" id="weTaskId">
      <label>Tên task</label><input name="task_title" id="weTaskTitle" required>
      <label>Brief</label><textarea name="task_brief" id="weTaskBrief"></textarea>
      <label>Mô tả</label><textarea name="task_description" id="weTaskDescription"></textarea>
      <div class="form-row-3">
        <div><label>Deadline</label><input type="datetime-local" name="task_deadline" id="weTaskDeadline"></div>
        <div><label>Priority</label><select name="task_priority" id="weTaskPriority"><option>Khẩn cấp làm ngay</option><option>Làm ngay</option><option>Quan trọng</option><option>Lúc nào làm cũng được</option></select></div>
        <div><label>Status</label><select name="task_status" id="weTaskStatus"><option>Todo</option><option>To-do</option><option>Doing</option><option>Review</option><option>Waiting Approval</option><option>Done</option></select></div>
      </div>
      <div class="task-popup-actions">
        <button class="btn-soft" type="button" onclick="closeModal('workspaceTaskEditModal'); openNeedHelpModalFromTask()">🚨 Cần hỗ trợ</button>
        <button class="primary">Lưu thay đổi</button>
      </div>
    </form>
  </div>
</div>


<div class="modal-backdrop" id="workspaceNeedHelpModal">
  <div class="modal-panel">
    <button class="modal-close" type="button" onclick="closeModal('workspaceNeedHelpModal')">×</button>
    <span class="eyebrow">Need Help</span>
    <h2>Gửi yêu cầu hỗ trợ</h2>
    <form method="post" action="app.php?page=need_help">
      <input type="hidden" name="create_need_help" value="1">
      <input type="hidden" name="task_id" id="needHelpTaskId" value="0">
      <label>Lý do</label>
      <select name="reason"><option>Thiếu thông tin</option><option>Thiếu nguồn lực</option><option>Khách hàng chậm phản hồi</option><option>Deadline gấp</option><option>Khác</option></select>
      <label>Chi tiết</label><textarea name="message" placeholder="Mình đang cần hỗ trợ điều gì?"></textarea>
      <button class="primary">Gửi hỗ trợ</button>
    </form>
  </div>
</div>

<div class="modal-backdrop" id="privateTaskModal">
  <div class="modal-panel">
    <button class="modal-close" onclick="closeModal('privateTaskModal')">×</button>
    <h2>Tạo task cá nhân private</h2>
    <form method="post">
      <input type="hidden" name="create_private_task" value="1">
      <label>Tên task</label><input name="private_task_title" required placeholder="Ví dụ: Gọi lại khách, chuẩn bị tài liệu...">
      <label>Mô tả</label><textarea name="private_description"></textarea>
      <div class="form-row"><div><label>Deadline theo giờ</label><input type="datetime-local" name="private_due_datetime"><input type="hidden" name="private_due_date"></div><div><label>Priority</label><select name="private_priority"><option>Khẩn cấp làm ngay</option><option>Làm ngay</option><option selected>Quan trọng</option><option>Lúc nào làm cũng được</option></select></div></div>
      <button class="primary">Lưu task private</button>
    </form>
  </div>
</div>
