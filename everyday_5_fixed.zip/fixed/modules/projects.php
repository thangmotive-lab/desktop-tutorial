<?php
$types=['Production','Performance','Social Media','Event','Website','Internal'];
$healths=['On Track','Risk','Delayed'];
$statuses=['Planning','In Progress','Review','Completed','Paused'];

if(isset($_GET['delete_project']) && user_is_admin()){
  $pid=(int)$_GET['delete_project'];
  $pdo->prepare('DELETE FROM task_comments WHERE task_id IN (SELECT id FROM tasks WHERE project_id=?)')->execute([$pid]);
  try{ $pdo->prepare('DELETE FROM task_links WHERE task_id IN (SELECT id FROM tasks WHERE project_id=?)')->execute([$pid]); }catch(Exception $e){}
  $pdo->prepare('DELETE FROM tasks WHERE project_id=?')->execute([$pid]);
  $pdo->prepare('DELETE FROM project_members WHERE project_id=?')->execute([$pid]);
  try{ $pdo->prepare('DELETE FROM project_deliverables WHERE project_id=?')->execute([$pid]); }catch(Exception $e){}
  $pdo->prepare('DELETE FROM projects WHERE id=?')->execute([$pid]);
  log_activity($pdo,'delete','project',$pid,'Xóa project');
  redirect('app.php?page=projects');
}



function handle_project_avatar_upload($current=''){
  if(!empty($_FILES['project_avatar']['name'])){
    $ext=strtolower(pathinfo($_FILES['project_avatar']['name'],PATHINFO_EXTENSION));
    if(!in_array($ext,['jpg','jpeg','png','webp','gif'])) return $current;
    $dir=__DIR__.'/../uploads/projects';
    if(!is_dir($dir)) mkdir($dir,0775,true);
    $filename='uploads/projects/project_'.time().'_'.rand(1000,9999).'.'.$ext;
    move_uploaded_file($_FILES['project_avatar']['tmp_name'],__DIR__.'/../'.$filename);
    return $filename;
  }
  return $current;
}


if($_SERVER['REQUEST_METHOD']==='POST'){
  if(!empty($_POST['project_id'])){
    $stmt=$pdo->prepare('UPDATE projects SET name=?, client_name=?, quotation_id=?, contract_id=?, owner_id=?, project_type=?, health=?, start_date=?, end_date=?, progress=?, status=?, objective=?, deliverable_target=?, description=?, avatar=? WHERE id=?');
    $stmt->execute([$_POST['name'],$_POST['client_name'],$_POST['quotation_id']?:null,$_POST['contract_id']?:null,$_POST['owner_id']?:null,$_POST['project_type'],$_POST['health'],$_POST['start_date'],$_POST['end_date'],$_POST['progress']?:0,$_POST['status'],$_POST['objective'],$_POST['deliverable_target']?:0,$_POST['description']??'',handle_project_avatar_upload($_POST['current_avatar']??''),$_POST['project_id']]);
    $pid=(int)$_POST['project_id'];
  } else {
    $stmt=$pdo->prepare('INSERT INTO projects(name, client_name, quotation_id, contract_id, owner_id, project_type, health, start_date, end_date, progress, status, objective, deliverable_target, description, avatar) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
    $stmt->execute([$_POST['name'],$_POST['client_name'],$_POST['quotation_id']?:null,$_POST['contract_id']?:null,$_POST['owner_id']?:null,$_POST['project_type'],$_POST['health'],$_POST['start_date'],$_POST['end_date'],$_POST['progress']?:0,$_POST['status'],$_POST['objective'],$_POST['deliverable_target']?:0,$_POST['description']??'',handle_project_avatar_upload('')]);
    $pid=$pdo->lastInsertId();
  }
  $pdo->prepare('DELETE FROM project_members WHERE project_id=?')->execute([$pid]);
  foreach($_POST['members']??[] as $uid){ $pdo->prepare('INSERT INTO project_members(project_id,user_id) VALUES(?,?)')->execute([$pid,$uid]); }
  log_activity($pdo,'save','project',$pid,'Lưu project '.$_POST['name']);
  redirect('app.php?page=projects');
}

$users=$pdo->query('SELECT id,name,avatar FROM users ORDER BY name')->fetchAll();
$quotes=$pdo->query('SELECT id,quote_code,client_name FROM quotations ORDER BY id DESC')->fetchAll();
$contracts=$pdo->query('SELECT id,contract_code,client_name FROM contracts ORDER BY id DESC')->fetchAll();

$month=$_GET['month'] ?? '';
$type=$_GET['type'] ?? '';
$health=$_GET['health'] ?? '';
$q=trim($_GET['q']??'');
$where=[];$params=[];
if($month){$where[]="(DATE_FORMAT(p.start_date,'%Y-%m')=? OR DATE_FORMAT(p.end_date,'%Y-%m')=?)";$params[]=$month;$params[]=$month;}
if($type){$where[]='p.project_type=?';$params[]=$type;}
if($health){$where[]='p.health=?';$params[]=$health;}
if($q!==''){$where[]='(p.name LIKE ? OR p.client_name LIKE ? OR p.objective LIKE ?)';array_push($params,"%$q%","%$q%","%$q%");}
$sql='SELECT p.*, u.name owner_name, u.avatar owner_avatar,
  (SELECT COUNT(*) FROM tasks t WHERE t.project_id=p.id) task_total,
  (SELECT COUNT(*) FROM tasks t WHERE t.project_id=p.id AND t.status="Done") task_done,
  (SELECT COUNT(*) FROM tasks t WHERE t.project_id=p.id AND (t.need_support=1 OR t.help_requested=1) AND t.status!="Done") need_support_count,
  (SELECT COUNT(*) FROM tasks t WHERE t.project_id=p.id AND t.status="Waiting Approval") waiting_approval_count
  FROM projects p LEFT JOIN users u ON u.id=p.owner_id';
if($where)$sql.=' WHERE '.implode(' AND ',$where);
$sql.=' ORDER BY p.end_date ASC,p.id DESC';
$stmt=$pdo->prepare($sql);$stmt->execute($params);$rows=$stmt->fetchAll();

$editProject=null;
if(isset($_GET['edit'])){
  $st=$pdo->prepare('SELECT * FROM projects WHERE id=?');$st->execute([(int)$_GET['edit']]);$editProject=$st->fetch();
}
?>
<section class="card">
  <div class="card-head">
    <div><span class="eyebrow">Projects V2</span><h2>Projects</h2><p class="muted">Bảng ngang tối giản: Project, PM, thời gian, progress, health, status.</p></div>
    <button class="primary" onclick="openSlideDrawer('projectDrawer')">+ Tạo project</button>
  </div>
<table class="dense-table">
    <thead><tr><th>Project</th><th>Type</th><th>PM</th><th>End</th><th>Progress</th><th>Health</th><th>Status</th><th>Action</th></tr></thead>
    <tbody>
    <?php foreach($rows as $p): $pct=$p['task_total']>0?round($p['task_done']/$p['task_total']*100):(int)$p['progress']; ?>
      <tr>
        <td><div class="project-title-cell"><?php if(!empty($p['avatar'])): ?><span class="project-avatar"><img src="<?= e($p['avatar']) ?>" alt=""></span><?php else: ?><span class="project-avatar"><?= e(mb_substr($p['name'],0,1)) ?></span><?php endif; ?><div><a class="project-link" href="app.php?page=project_detail&id=<?= $p['id'] ?>"><b><?= e($p['name']) ?></b></a><br><span class="muted"><?= e($p['client_name']) ?></span><?php if(!empty($p['description'])): ?><br><small class="muted"><?= e(mb_substr($p['description'],0,70)) ?></small><?php endif; ?></div></div></td>
        <td><span class="badge purple"><?= e($p['project_type'] ?: 'Production') ?></span></td>
        <td><span class="user-chip"><?= avatar_html(['name'=>$p['owner_name'],'avatar'=>$p['owner_avatar']],true) ?><?= e($p['owner_name']) ?></span></td>
        <td><?= e($p['end_date']) ?></td>
        <td><div class="progress"><span style="width:<?= $pct ?>%"></span></div><?= (int)$p['task_done'] ?>/<?= (int)$p['task_total'] ?> · <?= $pct ?>%</td>
        <td><span class="badge <?= $p['health']==='Delayed'?'red':($p['health']==='Risk'?'orange':'green') ?>"><?= e($p['health'] ?: 'On Track') ?></span></td>
        <td><span class="badge <?= badge_class($p['status']) ?>"><?= e($p['status']) ?></span></td>
        <td class="actions"><a class="btn btn-soft" href="app.php?page=projects&edit=<?= $p['id'] ?>">Edit</a><?php if(user_is_admin()): ?><a class="btn btn-soft danger-link" onclick="return confirm('Xóa project?')" href="app.php?page=projects&delete_project=<?= $p['id'] ?>">Xóa</a><?php endif; ?></td>
      </tr>
    <?php endforeach; ?>
    <?php if(empty($rows)): ?><tr><td colspan="8" class="muted">Chưa có project.</td></tr><?php endif; ?>
    </tbody>
  </table>
</section>

<div id="drawerBackdrop" class="drawer-backdrop" onclick="closeSlideDrawer('projectDrawer')"></div>
<div class="slide-drawer <?= $editProject?'active':'' ?>" id="projectDrawer">
  <div class="drawer-form-header">
    <div><span class="eyebrow">Project V2</span><h2><?= $editProject?'Edit project':'Tạo project' ?></h2></div>
    <button class="drawer-close-x" onclick="closeSlideDrawer('projectDrawer')" type="button">×</button>
  </div>
  <form method="post" enctype="multipart/form-data">
    <input type="hidden" name="project_id" value="<?= e($editProject['id'] ?? '') ?>">
    <label>Tên project</label><input name="name" required value="<?= e($editProject['name'] ?? '') ?>">
    <input type="hidden" name="current_avatar" value="<?= e($editProject['avatar'] ?? '') ?>">
    <label>Avatar project</label>
    <?php if(!empty($editProject['avatar'])): ?><p><img src="<?= e($editProject['avatar']) ?>" style="width:64px;height:64px;object-fit:cover;border-radius:18px"></p><?php endif; ?>
    <input type="file" name="project_avatar" accept="image/*">
    <label>Client</label><input name="client_name" value="<?= e($editProject['client_name'] ?? '') ?>">
    <div class="form-row"><div><label>Quotation</label><select name="quotation_id"><option value="">Không gắn</option><?php foreach($quotes as $qrow): ?><option value="<?= $qrow['id'] ?>" <?= (($editProject['quotation_id']??'')==$qrow['id'])?'selected':'' ?>><?= e($qrow['quote_code'].' - '.$qrow['client_name']) ?></option><?php endforeach; ?></select></div><div><label>Contract</label><select name="contract_id"><option value="">Không gắn</option><?php foreach($contracts as $c): ?><option value="<?= $c['id'] ?>" <?= (($editProject['contract_id']??'')==$c['id'])?'selected':'' ?>><?= e($c['contract_code'].' - '.$c['client_name']) ?></option><?php endforeach; ?></select></div></div>
    <div class="form-row"><div><label>Project Type</label><select name="project_type"><?php foreach($types as $t): ?><option <?= (($editProject['project_type']??'Production')===$t)?'selected':'' ?>><?= e($t) ?></option><?php endforeach; ?></select></div><div><label>Health</label><select name="health"><?php foreach($healths as $h): ?><option <?= (($editProject['health']??'On Track')===$h)?'selected':'' ?>><?= e($h) ?></option><?php endforeach; ?></select></div></div>
    <label>PM</label><select name="owner_id"><option value="">Chọn PM</option><?php foreach($users as $u): ?><option value="<?= $u['id'] ?>" <?= (($editProject['owner_id']??'')==$u['id'])?'selected':'' ?>><?= e($u['name']) ?></option><?php endforeach; ?></select>
    <div class="form-row"><div><label>Start</label><input name="start_date" type="date" value="<?= e($editProject['start_date'] ?? '') ?>"></div><div><label>End</label><input name="end_date" type="date" value="<?= e($editProject['end_date'] ?? '') ?>"></div></div>
    <div class="form-row"><div><label>Progress %</label><input name="progress" type="number" value="<?= e($editProject['progress'] ?? 0) ?>"></div><div><label>Deliverable Target</label><input name="deliverable_target" type="number" value="<?= e($editProject['deliverable_target'] ?? 0) ?>"></div></div>
    <label>Status</label><select name="status"><?php foreach($statuses as $s): ?><option <?= (($editProject['status']??'Planning')===$s)?'selected':'' ?>><?= e($s) ?></option><?php endforeach; ?></select>
    <label>Objective</label><textarea name="objective"><?= e($editProject['objective'] ?? '') ?></textarea>
    <label>Mô tả project</label><textarea name="description" placeholder="Mô tả ngắn về bối cảnh, yêu cầu, lưu ý vận hành..."><?= e($editProject['description'] ?? '') ?></textarea>
    <label>Members</label><select name="members[]" multiple><?php foreach($users as $u): ?><option value="<?= $u['id'] ?>"><?= e($u['name']) ?></option><?php endforeach; ?></select>
    <button class="primary">Lưu project</button>
  </form>
</div>
