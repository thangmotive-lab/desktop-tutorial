<?php
if(!is_director_role() && !is_finance_role()) die('Bạn không có quyền Generate Documents.');
require_once __DIR__ . '/../services/documents/DocxTemplateEngine.php';
require_once __DIR__ . '/../services/documents/DocumentMappingBuilder.php';

$quotationId=(int)($_GET['quotation_id'] ?? $_POST['quotation_id'] ?? 0);
$templateId=(int)($_GET['template_id'] ?? $_POST['template_id'] ?? 0);
$flash='';

function doc_mapping_saved(PDO $pdo, int $quotationId, int $templateId): array {
  try{
    $stmt=$pdo->prepare('SELECT mapping_json FROM quotation_document_info WHERE quotation_id=? AND template_id=? LIMIT 1');
    $stmt->execute([$quotationId,$templateId]);
    $json=$stmt->fetchColumn();
    if($json){
      $data=json_decode($json,true);
      return is_array($data) ? $data : [];
    }
  }catch(Exception $e){}
  return [];
}

function doc_mapping_save(PDO $pdo, int $quotationId, int $templateId, string $documentType, array $mapping): void {
  $json=json_encode($mapping,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT);
  $userId=current_user()['id'] ?? null;
  $stmt=$pdo->prepare("INSERT INTO quotation_document_info(quotation_id,template_id,document_type,mapping_json,created_by,updated_by)
    VALUES(?,?,?,?,?,?)
    ON DUPLICATE KEY UPDATE document_type=VALUES(document_type), mapping_json=VALUES(mapping_json), updated_by=VALUES(updated_by), updated_at=CURRENT_TIMESTAMP");
  $stmt->execute([$quotationId,$templateId,$documentType,$json,$userId,$userId]);
}

function doc_mapping_build(PDO $pdo, int $quotationId, int $templateId): array {
  $type='contract';
  if($templateId){
    $tst=$pdo->prepare('SELECT document_type FROM document_templates WHERE id=?');
    $tst->execute([$templateId]);
    $type=$tst->fetchColumn() ?: 'contract';
  }
  $mapping=DocumentMappingBuilder::fromQuotation($pdo,$quotationId,$type);
  $saved=doc_mapping_saved($pdo,$quotationId,$templateId);
  foreach($saved as $k=>$v){
    if(!is_array($v) && !str_starts_with((string)$k,'_')) $mapping[$k]=$v;
  }
  return $mapping;
}

if($_SERVER['REQUEST_METHOD']==='POST' && (isset($_POST['save_mapping_info']) || isset($_POST['generate_docx']))){
  $templateId=(int)$_POST['template_id'];
  $quotationId=(int)$_POST['quotation_id'];
  $tplStmt=$pdo->prepare('SELECT * FROM document_templates WHERE id=? AND is_active=1');
  $tplStmt->execute([$templateId]);
  $tpl=$tplStmt->fetch();
  if(!$tpl) die('Không tìm thấy template.');

  $mapping=DocumentMappingBuilder::fromQuotation($pdo,$quotationId,$tpl['document_type']);
  foreach($_POST['mapping'] ?? [] as $k=>$v){
    if(is_string($k) && !str_starts_with($k,'_')) $mapping[$k]=$v;
  }

  if(isset($_POST['save_mapping_info']) && !isset($_POST['generate_docx'])){
    doc_mapping_save($pdo,$quotationId,$templateId,$tpl['document_type'],$mapping);
    redirect('app.php?page=doc_generate&quotation_id='.$quotationId.'&template_id='.$templateId.'&saved=1');
  }

  // Always save latest entered info before generating.
  doc_mapping_save($pdo,$quotationId,$templateId,$tpl['document_type'],$mapping);

  $docCode=$mapping['CONTRACT_CODE'] ?? ($mapping['QUOTE_CODE'] ?? 'DOC-'.$quotationId);
  if($tpl['document_type']==='acceptance') $docCode=$mapping['ACCEPTANCE_CODE'];
  if($tpl['document_type']==='payment_request') $docCode=$mapping['PAYMENT_CODE'];
  if($tpl['document_type']==='quotation') $docCode='BG-'.date('Y').'-'.str_pad((string)$quotationId,4,'0',STR_PAD_LEFT);

  $outDir=__DIR__.'/../uploads/generated_documents';
  if(!is_dir($outDir)) mkdir($outDir,0775,true);
  $safe=preg_replace('/[^a-zA-Z0-9_-]+/','_',$docCode.'_'.$tpl['template_code']);
  $docxRel='uploads/generated_documents/'.$safe.'_'.time().'.docx';
  $docxPath=__DIR__.'/../'.$docxRel;

  $result=DocxTemplateEngine::render(__DIR__.'/../'.$tpl['file_path'],$docxPath,$mapping);
  if($result['ok']){
    $rowsJson=json_encode(['items'=>$mapping['_ITEM_ROWS']??[],'payments'=>$mapping['_PAYMENT_ROWS']??[]],JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT);
    $mappingJson=json_encode($mapping,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT);
    $pdo->prepare('INSERT INTO generated_documents(template_id,source_type,source_id,document_type,document_code,title,docx_path,mapping_json,table_rows_json,created_by) VALUES(?,?,?,?,?,?,?,?,?,?)')
      ->execute([$templateId,'quotation',$quotationId,$tpl['document_type'],$docCode,$tpl['template_name'].' - '.$docCode,$docxRel,$mappingJson,$rowsJson,current_user()['id']]);

    try {
      $pdo->prepare('INSERT INTO ai_document_outputs(template_id,source_type,source_id,document_type,title,docx_path,mapping_json,created_by) VALUES(?,?,?,?,?,?,?,?)')
        ->execute([$templateId,'quotation',$quotationId,$tpl['document_type'],$tpl['template_name'].' - '.$docCode,$docxRel,$mappingJson,current_user()['id']]);
    } catch(Exception $e) {}

    redirect('app.php?page=doc_generate&quotation_id='.$quotationId.'&template_id='.$templateId.'&generated=1');
  } else {
    $flash='❌ '.$result['message'];
  }
}

$quotes=safe_rows($pdo,"SELECT id,quote_code,client_name,title,status,created_at FROM quotations ORDER BY id DESC LIMIT 200");
$templates=safe_rows($pdo,"SELECT * FROM document_templates WHERE is_active=1 ORDER BY document_type,template_name");

$quotation=null;$mapping=[];
if($quotationId){
  $st=$pdo->prepare('SELECT * FROM quotations WHERE id=?');
  $st->execute([$quotationId]);
  $quotation=$st->fetch();
  $mapping=doc_mapping_build($pdo,$quotationId,$templateId);
}
$recent=safe_rows($pdo,"SELECT gd.*,dt.template_name,u.name user_name FROM generated_documents gd LEFT JOIN document_templates dt ON dt.id=gd.template_id LEFT JOIN users u ON u.id=gd.created_by ORDER BY gd.id DESC LIMIT 30");
?>
<section class="workspace-hero finance-hero ai-hero">
  <div>
    <span class="eyebrow">DOCX Generator</span>
    <h1>Generate Word Documents</h1>
    <p class="muted">Chọn báo giá + template Word, nhập thông tin, lưu lại rồi generate DOCX.</p>
  </div>
  <a class="btn btn-soft" href="app.php?page=doc_templates">Templates</a>
</section>

<?php if($flash): ?><div class="alert"><?= e($flash) ?></div><?php endif; ?>
<?php if(!empty($_GET['saved'])): ?><div class="alert success">✅ Đã lưu thông tin nhập cho báo giá/template này.</div><?php endif; ?>
<?php if(!empty($_GET['generated'])): ?><div class="alert success">✅ Đã generate DOCX thành công. Xem trong danh sách bên dưới.</div><?php endif; ?>

<section class="card">
  <div class="card-head"><h2>Generate từ báo giá</h2></div>
  <form method="get" class="asana-toolbar">
    <input type="hidden" name="page" value="doc_generate">
    <select name="quotation_id" required>
      <option value="">Chọn báo giá</option>
      <?php foreach($quotes as $q): ?><option value="<?= $q['id'] ?>" <?= $quotationId===$q['id']?'selected':'' ?>><?= e($q['quote_code'].' — '.$q['client_name'].' — '.$q['status']) ?></option><?php endforeach; ?>
    </select>
    <select name="template_id">
      <option value="0">Chọn template sau</option>
      <?php foreach($templates as $t): ?><option value="<?= $t['id'] ?>" <?= $templateId===$t['id']?'selected':'' ?>><?= e($t['document_type'].' — '.$t['template_name']) ?></option><?php endforeach; ?>
    </select>
    <button class="primary">Load Mapping</button>
  </form>
</section>

<?php if($quotation): ?>
<section class="card">
  <div class="card-head">
    <div><h2>Thông tin hợp đồng / tài liệu</h2><p class="muted"><?= e($quotation['quote_code'].' — '.$quotation['client_name']) ?>. Bấm “Lưu thông tin” để lần sau mở lại vẫn còn dữ liệu đã nhập.</p></div>
  </div>
  <form method="post">
    <input type="hidden" name="quotation_id" value="<?= $quotationId ?>">
    <label>Template</label>
    <select name="template_id" required>
      <?php foreach($templates as $t): ?><option value="<?= $t['id'] ?>" <?= $templateId===$t['id']?'selected':'' ?>><?= e($t['document_type'].' — '.$t['template_name']) ?></option><?php endforeach; ?>
    </select>

    <div class="mapping-grid">
      <?php foreach($mapping as $k=>$v): if(is_array($v) || str_starts_with($k,'_')) continue; ?>
        <div>
          <label><?= e($k) ?></label>
          <textarea name="mapping[<?= e($k) ?>]" rows="<?= strlen((string)$v)>90?4:1 ?>"><?= e($v) ?></textarea>
        </div>
      <?php endforeach; ?>
    </div>
    <div class="form-actions sticky-doc-actions">
      <button class="btn btn-soft" name="save_mapping_info" value="1">Lưu thông tin</button>
      <button class="primary" name="generate_docx" value="1">Lưu & Generate DOCX</button>
    </div>
  </form>
</section>
<?php endif; ?>

<section class="card">
  <div class="card-head"><h2>Generated Documents</h2></div>
  <table class="dense-table">
    <thead><tr><th>Date</th><th>Code</th><th>Type</th><th>Title</th><th>Template</th><th>By</th><th>Action</th></tr></thead>
    <tbody>
    <?php foreach($recent as $r): ?>
      <tr>
        <td><?= e($r['created_at']) ?></td>
        <td><b><?= e($r['document_code']) ?></b></td>
        <td><span class="badge purple"><?= e($r['document_type']) ?></span></td>
        <td><?= e($r['title']) ?></td>
        <td><?= e($r['template_name']) ?></td>
        <td><?= e($r['user_name']) ?></td>
        <td><?php if($r['docx_path']): ?><a class="btn btn-soft" href="<?= e($r['docx_path']) ?>" target="_blank">Download DOCX</a><?php endif; ?></td>
      </tr>
    <?php endforeach; ?>
    <?php if(empty($recent)): ?><tr><td colspan="7" class="muted">Chưa có document.</td></tr><?php endif; ?>
    </tbody>
  </table>
</section>
