<?php
if(!is_director_role() && !user_is_admin()) die('Bạn không có quyền xem Team Productivity.');
$date=$_GET['date'] ?? date('Y-m-d');

$workload=safe_rows($pdo,"SELECT u.id,u.name,u.avatar,u.role,
  COUNT(CASE WHEN t.status!='Done' THEN t.id END) open_tasks,
  COUNT(CASE WHEN t.status!='Done' AND t.deadline < CURDATE() THEN t.id END) overdue_tasks,
  COUNT(CASE WHEN t.status='Done' AND DATE_FORMAT(COALESCE(t.completed_at,t.updated_at,t.deadline),'%Y-%m')=DATE_FORMAT(CURDATE(),'%Y-%m') THEN t.id END) done_month,
  COUNT(CASE WHEN t.status='Done' AND t.deadline IS NOT NULL AND COALESCE(t.completed_at,t.deadline) <= CONCAT(t.deadline,' 23:59:59') THEN t.id END) done_ontime
  FROM users u
  LEFT JOIN tasks t ON t.assignee_id=u.id
  WHERE u.status='active'
  GROUP BY u.id
  ORDER BY open_tasks DESC,u.name ASC");

$checkins=safe_rows($pdo,"SELECT dc.*,u.name,u.avatar,u.role FROM users u LEFT JOIN daily_checkins dc ON dc.user_id=u.id AND dc.checkin_date=".$pdo->quote($date)." WHERE u.status='active' ORDER BY u.name");
$focusRows=safe_rows($pdo,"SELECT ft.*,u.name user_name,p.name project_name,t.deadline,t.priority FROM focus_today ft LEFT JOIN users u ON u.id=ft.user_id LEFT JOIN tasks t ON t.id=ft.task_id LEFT JOIN projects p ON p.id=t.project_id WHERE ft.focus_date=".$pdo->quote($date)." ORDER BY u.name,ft.sort_order,ft.id");

$updated=0;$missing=0;
foreach($checkins as $c){ if(!empty($c['morning_plan']) || !empty($c['wrap_done'])) $updated++; else $missing++; }
?>
<section class="workspace-hero productivity-hero">
  <div>
    <span class="eyebrow">Team Productivity</span>
    <h1>Team Productivity OS</h1>
    <p class="muted">Theo dõi Focus Today, Daily Check-in và Workload Balance của team.</p>
  </div>
  <form method="get"><input type="hidden" name="page" value="team_productivity"><input type="date" name="date" value="<?= e($date) ?>"><button class="btn btn-soft">Xem</button></form>
</section>

<div class="stats-grid compact-stats">
  <div class="stat mint"><span>Đã update check-in</span><strong><?= $updated ?></strong></div>
  <div class="stat yellow"><span>Chưa update</span><strong><?= $missing ?></strong></div>
  <div class="stat coral"><span>Quá tải >15 task</span><strong><?= count(array_filter($workload,fn($w)=>(int)$w['open_tasks']>15)) ?></strong></div>
</div>

<section class="card">
  <div class="card-head"><h2>Workload Balance</h2><p class="muted">Không phải để phạt, mà để biết ai cần hỗ trợ hoặc điều phối lại task.</p></div>
  <table class="dense-table">
    <thead><tr><th>Nhân sự</th><th>Open</th><th>Overdue</th><th>Done tháng này</th><th>On-time</th><th>Load</th></tr></thead>
    <tbody>
      <?php foreach($workload as $w): 
        $open=(int)$w['open_tasks'];
        $load=$open>15?'Overloaded':($open<4?'Available':'Normal');
        $class=$open>15?'red':($open<4?'green':'orange');
        $ontime=(int)$w['done_month']>0?round(((int)$w['done_ontime']/(int)$w['done_month'])*100):0;
      ?>
        <tr>
          <td><span class="user-chip"><?= avatar_html(['name'=>$w['name'],'avatar'=>$w['avatar']],true) ?><?= e($w['name']) ?></span><br><span class="muted"><?= e($w['role']) ?></span></td>
          <td><b><?= $open ?></b></td>
          <td><?= (int)$w['overdue_tasks'] ?></td>
          <td><?= (int)$w['done_month'] ?></td>
          <td><?= $ontime ?>%</td>
          <td><span class="badge <?= $class ?>"><?= e($load) ?></span></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</section>

<div class="two-col">
<section class="card">
  <div class="card-head"><h2>Daily Check-in</h2></div>
  <table class="dense-table">
    <thead><tr><th>Nhân sự</th><th>Morning Plan</th><th>Wrap-up</th><th>Blocker</th></tr></thead>
    <tbody>
      <?php foreach($checkins as $c): ?>
        <tr>
          <td><span class="user-chip"><?= avatar_html(['name'=>$c['name'],'avatar'=>$c['avatar']],true) ?><?= e($c['name']) ?></span></td>
          <td><?= $c['morning_plan']?nl2br(e($c['morning_plan'])):'<span class="muted">Chưa update</span>' ?></td>
          <td><?= $c['wrap_done']?nl2br(e($c['wrap_done'])):'<span class="muted">Chưa wrap-up</span>' ?></td>
          <td><?= $c['blockers']?nl2br(e($c['blockers'])):'-' ?></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</section>

<section class="card">
  <div class="card-head"><h2>Focus Today của team</h2></div>
  <table class="dense-table">
    <thead><tr><th>Nhân sự</th><th>Focus</th><th>Project</th><th>Deadline</th></tr></thead>
    <tbody>
      <?php foreach($focusRows as $f): ?>
        <tr><td><?= e($f['user_name']) ?></td><td><b><?= e($f['title']) ?></b></td><td><?= e($f['project_name']) ?></td><td><?= e($f['deadline']) ?></td></tr>
      <?php endforeach; ?>
      <?php if(empty($focusRows)): ?><tr><td colspan="4" class="muted">Chưa có Focus Today.</td></tr><?php endif; ?>
    </tbody>
  </table>
</section>
</div>
