<?php
if(!can_view_business_finance()) die('Bạn không có quyền xem nghiệm thu.');

function acc_has_col(PDO $pdo,string $table,string $col): bool{try{$st=$pdo->prepare("SHOW COLUMNS FROM `$table` LIKE ?");$st->execute([$col]);return (bool)$st->fetch();}catch(Exception $e){return false;}}
function acc_add_col(PDO $pdo,string $table,string $ddl): void{$col=trim(strtok($ddl,' '));if(!acc_has_col($pdo,$table,$col)){try{$pdo->exec("ALTER TABLE `$table` ADD COLUMN $ddl");}catch(Exception $e){}}}
function acc_money_input($v){return (float)str_replace(['.',',',' '],['','',''],(string)$v);}
function acc_recalc_acceptance(PDO $pdo, int $accId): void{
  if($accId<=0) return;
  try{
    $st=$pdo->prepare('SELECT paid_amount,contract_value FROM acceptances WHERE id=?');
    $st->execute([$accId]);
    $acc=$st->fetch();
    if(!$acc) return;
    $it=$pdo->prepare('SELECT source_type,actual_quantity,unit_price,vat_rate,value_amount FROM acceptance_deliverables WHERE acceptance_id=?');
    $it->execute([$accId]);
    $before=0; $vat=0; $extraBefore=0;
    foreach($it->fetchAll() as $r){
      $qty=(float)($r['actual_quantity'] ?? 0);
      $unit=(float)($r['unit_price'] ?? 0);
      $line=$unit>0 ? ($qty*$unit) : (float)($r['value_amount'] ?? 0);
      $rate=(float)($r['vat_rate'] ?? 0);
      $before += $line;
      $vat += $line*($rate/100);
      if(($r['source_type'] ?? '')==='manual') $extraBefore += $line;
    }
    $accepted=$before+$vat;
    if($accepted<=0) $accepted=(float)($acc['contract_value'] ?? 0);
    $outstanding=$accepted-(float)($acc['paid_amount'] ?? 0);
    $pdo->prepare('UPDATE acceptances SET extra_value=?,accepted_value=?,outstanding_amount=? WHERE id=?')
      ->execute([$extraBefore,$accepted,$outstanding,$accId]);
  }catch(Exception $e){}
}

try{
  $pdo->exec("CREATE TABLE IF NOT EXISTS acceptances(
    id INT AUTO_INCREMENT PRIMARY KEY,
    acceptance_code VARCHAR(60) NULL,
    public_token VARCHAR(100) NULL,
    contract_id INT NULL,
    quotation_id INT NULL,
    client_name VARCHAR(255) NULL,
    client_contact VARCHAR(255) NULL,
    client_tax_code VARCHAR(80) NULL,
    client_address TEXT NULL,
    contract_code VARCHAR(80) NULL,
    contract_date DATE NULL,
    title VARCHAR(255) NULL,
    status VARCHAR(50) DEFAULT 'Draft',
    accepted_date DATE NULL,
    payment_due_days INT DEFAULT 5,
    contract_value DECIMAL(18,2) DEFAULT 0,
    paid_amount DECIMAL(18,2) DEFAULT 0,
    extra_value DECIMAL(18,2) DEFAULT 0,
    accepted_value DECIMAL(18,2) DEFAULT 0,
    outstanding_amount DECIMAL(18,2) DEFAULT 0,
    note TEXT NULL,
    created_by INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    INDEX(contract_id),INDEX(quotation_id),INDEX(public_token)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  $pdo->exec("CREATE TABLE IF NOT EXISTS acceptance_deliverables(
    id INT AUTO_INCREMENT PRIMARY KEY,
    acceptance_id INT NOT NULL,
    source_type VARCHAR(30) DEFAULT 'manual',
    source_id INT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT NULL,
    quoted_quantity DECIMAL(12,2) NULL,
    actual_quantity DECIMAL(12,2) DEFAULT 1,
    unit VARCHAR(50) NULL,
    delivery_url TEXT NULL,
    value_amount DECIMAL(18,2) DEFAULT 0,
    status VARCHAR(50) DEFAULT 'Đạt',
    client_feedback TEXT NULL,
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX(acceptance_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  // v6.9.4: keep acceptance deliverables aligned with quotation pricing.
  acc_add_col($pdo,'acceptance_deliverables','unit_price DECIMAL(18,2) DEFAULT 0');
  acc_add_col($pdo,'acceptance_deliverables','vat_rate DECIMAL(8,2) DEFAULT 10');
  acc_add_col($pdo,'acceptance_deliverables','is_extra TINYINT(1) DEFAULT 0');
}catch(Exception $e){ echo '<div class="card"><b>Lỗi khởi tạo Acceptance:</b> '.e($e->getMessage()).'</div>'; }

if(isset($_GET['delete']) && user_is_admin()){
  $id=(int)$_GET['delete'];
  $pdo->prepare('DELETE FROM acceptance_deliverables WHERE acceptance_id=?')->execute([$id]);
  $pdo->prepare('DELETE FROM acceptances WHERE id=?')->execute([$id]);
  redirect('app.php?page=acceptances');
}

if(isset($_GET['delete_item'])){
  $itemId=(int)$_GET['delete_item'];
  $accId=(int)($_GET['id']??0);
  $pdo->prepare('DELETE FROM acceptance_deliverables WHERE id=? AND acceptance_id=?')->execute([$itemId,$accId]);
  redirect('app.php?page=acceptances&id='.$accId);
}

if(isset($_GET['import_quote_items'])){
  $accId=(int)$_GET['import_quote_items'];
  $st=$pdo->prepare('SELECT * FROM acceptances WHERE id=?');$st->execute([$accId]);$acc=$st->fetch();
  if($acc && (int)$acc['quotation_id']>0){
    $versionId=0;
    try{ $qv=$pdo->prepare('SELECT current_version FROM quotations WHERE id=?');$qv->execute([$acc['quotation_id']]);$cv=$qv->fetchColumn();
      $v=$pdo->prepare('SELECT id FROM quotation_versions WHERE quotation_id=? AND version_no=? LIMIT 1');$v->execute([$acc['quotation_id'],$cv]);$versionId=(int)$v->fetchColumn();
    }catch(Exception $e){}
    if($versionId>0){$items=$pdo->prepare('SELECT * FROM quotation_items WHERE quotation_version_id=? ORDER BY sort_order,id');$items->execute([$versionId]);}
    else {$items=$pdo->prepare('SELECT * FROM quotation_items WHERE quotation_id=? ORDER BY sort_order,id');$items->execute([$acc['quotation_id']]);}
    $rows=$items->fetchAll();$order=1;
    foreach($rows as $it){
      $pdo->prepare('INSERT INTO acceptance_deliverables(acceptance_id,source_type,source_id,title,description,quoted_quantity,actual_quantity,unit,delivery_url,unit_price,vat_rate,value_amount,status,sort_order) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
        ->execute([
          $accId,'quotation_item',$it['id']??null,$it['service_name']??'Hạng mục',$it['description']??'',
          (float)($it['quantity']??1),(float)($it['quantity']??1),$it['unit']??'',$it['note']??'',
          (float)($it['unit_price']??0),(float)($it['vat_rate']??($it['vat_percent']??10)),
          (float)($it['subtotal']??(((float)($it['quantity']??1))*((float)($it['unit_price']??0)))),'Đạt',$order++
        ]);
    }
  }
  acc_recalc_acceptance($pdo,$accId);
  redirect('app.php?page=acceptances&id='.$accId);
}

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['save_acceptance'])){
  $id=(int)($_POST['acceptance_id']??0);
  $contractId=(int)($_POST['contract_id']??0) ?: null;
  $quotationId=(int)($_POST['quotation_id']??0) ?: null;
  $contractValue=acc_money_input($_POST['contract_value']??0);
  $paidAmount=acc_money_input($_POST['paid_amount']??0);
  $extraValue=acc_money_input($_POST['extra_value']??0);
  $acceptedValue=acc_money_input($_POST['accepted_value']??($contractValue+$extraValue));
  $outstanding=acc_money_input($_POST['outstanding_amount']??($acceptedValue-$paidAmount));
  if($id){
    $pdo->prepare('UPDATE acceptances SET contract_id=?,quotation_id=?,client_name=?,client_contact=?,client_tax_code=?,client_address=?,contract_code=?,contract_date=?,title=?,status=?,accepted_date=?,payment_due_days=?,contract_value=?,paid_amount=?,extra_value=?,accepted_value=?,outstanding_amount=?,note=? WHERE id=?')
      ->execute([$contractId,$quotationId,$_POST['client_name'],$_POST['client_contact'],$_POST['client_tax_code'],$_POST['client_address'],$_POST['contract_code'],$_POST['contract_date']?:null,$_POST['title'],$_POST['status'],$_POST['accepted_date']?:null,(int)$_POST['payment_due_days'],$contractValue,$paidAmount,$extraValue,$acceptedValue,$outstanding,$_POST['note'],$id]);
  }else{
    $code=next_auto_code($pdo,'ACC','acceptances','acceptance_code');
    $token=bin2hex(random_bytes(20));
    $pdo->prepare('INSERT INTO acceptances(acceptance_code,public_token,contract_id,quotation_id,client_name,client_contact,client_tax_code,client_address,contract_code,contract_date,title,status,accepted_date,payment_due_days,contract_value,paid_amount,extra_value,accepted_value,outstanding_amount,note,created_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
      ->execute([$code,$token,$contractId,$quotationId,$_POST['client_name'],$_POST['client_contact'],$_POST['client_tax_code'],$_POST['client_address'],$_POST['contract_code'],$_POST['contract_date']?:null,$_POST['title'],$_POST['status'],$_POST['accepted_date']?:null,(int)$_POST['payment_due_days'],$contractValue,$paidAmount,$extraValue,$acceptedValue,$outstanding,$_POST['note'],current_user()['id']??null]);
    $id=(int)$pdo->lastInsertId();
  }
  acc_recalc_acceptance($pdo,$id);
  redirect('app.php?page=acceptances&id='.$id);
}

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['save_deliverable'])){
  $accId=(int)$_POST['acceptance_id'];
  $itemId=(int)($_POST['item_id']??0);
  $quoted=($_POST['quoted_quantity']==='')?null:(float)$_POST['quoted_quantity'];
  $actual=($_POST['actual_quantity']==='')?1:(float)$_POST['actual_quantity'];
  $unitPrice=acc_money_input($_POST['unit_price']??0);
  $vatRate=(float)($_POST['vat_rate']??10);
  $value=$actual*$unitPrice;
  if($itemId){
    $pdo->prepare('UPDATE acceptance_deliverables SET title=?,description=?,quoted_quantity=?,actual_quantity=?,unit=?,delivery_url=?,unit_price=?,vat_rate=?,value_amount=?,status=?,client_feedback=?,sort_order=? WHERE id=? AND acceptance_id=?')
      ->execute([$_POST['title'],$_POST['description'],$quoted,$actual,$_POST['unit'],$_POST['delivery_url'],$unitPrice,$vatRate,$value,$_POST['status'],$_POST['client_feedback'],(int)$_POST['sort_order'],$itemId,$accId]);
  }else{
    $pdo->prepare('INSERT INTO acceptance_deliverables(acceptance_id,source_type,title,description,quoted_quantity,actual_quantity,unit,delivery_url,unit_price,vat_rate,value_amount,status,client_feedback,sort_order) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
      ->execute([$accId,'manual',$_POST['title'],$_POST['description'],$quoted,$actual,$_POST['unit'],$_POST['delivery_url'],$unitPrice,$vatRate,$value,$_POST['status'],$_POST['client_feedback'],(int)$_POST['sort_order']]);
  }
  acc_recalc_acceptance($pdo,$accId);
  redirect('app.php?page=acceptances&id='.$accId);
}

// Create from contract shortcut
if(isset($_GET['new_from_contract'])){
  $cid=(int)$_GET['new_from_contract'];
  $st=$pdo->prepare('SELECT c.*,q.id qid,q.quote_code,q.client_contact FROM contracts c LEFT JOIN quotations q ON q.id=c.quotation_id WHERE c.id=?');$st->execute([$cid]);$c=$st->fetch();
  if($c){
    $paid=(float)safe_sum($pdo,"SELECT COALESCE(SUM(amount),0) FROM payment_schedules WHERE contract_id=$cid AND status='paid'");
    $total=(float)$c['total_value'];
    $code=next_auto_code($pdo,'ACC','acceptances','acceptance_code');$token=bin2hex(random_bytes(20));
    $pdo->prepare('INSERT INTO acceptances(acceptance_code,public_token,contract_id,quotation_id,client_name,client_contact,contract_code,contract_date,title,status,accepted_date,payment_due_days,contract_value,paid_amount,extra_value,accepted_value,outstanding_amount,note,created_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
      ->execute([$code,$token,$cid,$c['qid']?:null,$c['client_name'],$c['client_contact']??'',$c['contract_code'],$c['signed_date']?:null,'Nghiệm thu và thanh lý hợp đồng','Draft',date('Y-m-d'),5,$total,$paid,0,$total,$total-$paid,'',current_user()['id']??null]);
    redirect('app.php?page=acceptances&id='.$pdo->lastInsertId());
  }
}

$id=(int)($_GET['id']??0);
$edit=null;$deliverables=[];$editItem=null;
if($id){
  $st=$pdo->prepare('SELECT * FROM acceptances WHERE id=?');$st->execute([$id]);$edit=$st->fetch();
  $it=$pdo->prepare('SELECT * FROM acceptance_deliverables WHERE acceptance_id=? ORDER BY sort_order,id');$it->execute([$id]);$deliverables=$it->fetchAll();
  if(isset($_GET['edit_item'])){foreach($deliverables as $d){if((int)$d['id']===(int)$_GET['edit_item']){$editItem=$d;break;}}}
}

$contracts=$pdo->query('SELECT id,contract_code,client_name,total_value,signed_date,quotation_id FROM contracts ORDER BY id DESC LIMIT 200')->fetchAll();
$quotations=$pdo->query('SELECT id,quote_code,client_name,title FROM quotations ORDER BY id DESC LIMIT 200')->fetchAll();
$rows=$pdo->query('SELECT a.*,c.contract_code ccode FROM acceptances a LEFT JOIN contracts c ON c.id=a.contract_id ORDER BY a.id DESC LIMIT 200')->fetchAll();
?>
<section class="workspace-hero finance-hero">
  <div><span class="eyebrow">Acceptance & Settlement</span><h1>Nghiệm thu theo sản phẩm thực tế</h1><p class="muted">Theo dõi số lượng bàn giao, link thực tế, phát sinh ngoài scope và số tiền khách còn phải thanh toán.</p></div>
  <button class="primary" onclick="openModal('acceptanceModal')">+ Tạo biên bản</button>
</section>

<div class="stats-grid compact-stats">
  <div class="stat purple"><span>Tổng nghiệm thu</span><strong><?= money(safe_sum($pdo,'SELECT COALESCE(SUM(accepted_value),0) FROM acceptances')) ?></strong></div>
  <div class="stat mint"><span>Đã thanh toán</span><strong><?= money(safe_sum($pdo,'SELECT COALESCE(SUM(paid_amount),0) FROM acceptances')) ?></strong></div>
  <div class="stat yellow"><span>Còn phải thu</span><strong><?= money(safe_sum($pdo,'SELECT COALESCE(SUM(outstanding_amount),0) FROM acceptances')) ?></strong></div>
</div>

<section class="card">
  <div class="card-head"><h2>Danh sách biên bản</h2></div>
  <table class="dense-table"><thead><tr><th>Mã BBNT</th><th>Khách hàng</th><th>Hợp đồng</th><th>Tổng nghiệm thu</th><th>Đã thu</th><th>Còn lại</th><th>Status</th><th>Action</th></tr></thead><tbody>
  <?php foreach($rows as $r): ?>
    <tr><td><b><?= e($r['acceptance_code']) ?></b></td><td><?= e($r['client_name']) ?></td><td><?= e($r['contract_code'] ?: $r['ccode']) ?></td><td><?= money($r['accepted_value']) ?></td><td><?= money($r['paid_amount']) ?></td><td><b><?= money($r['outstanding_amount']) ?></b></td><td><span class="badge <?= badge_class($r['status']) ?>"><?= e($r['status']) ?></span></td><td class="actions"><a class="btn btn-soft" href="app.php?page=acceptances&id=<?= $r['id'] ?>">Mở</a><a class="btn btn-soft" target="_blank" href="public_acceptance.php?token=<?= e($r['public_token']) ?>">PDF</a><?php if(user_is_admin()): ?><a class="btn btn-soft" onclick="return confirm('Xóa biên bản?')" href="app.php?page=acceptances&delete=<?= $r['id'] ?>">Xóa</a><?php endif; ?></td></tr>
  <?php endforeach; ?>
  <?php if(empty($rows)): ?><tr><td colspan="8" class="muted">Chưa có biên bản nghiệm thu.</td></tr><?php endif; ?>
  </tbody></table>
</section>

<?php if($edit): ?>
<section class="card">
  <div class="card-head"><div><span class="eyebrow"><?= e($edit['acceptance_code']) ?></span><h2><?= e($edit['title']) ?></h2><p class="muted">Khách hàng: <b><?= e($edit['client_name']) ?></b> · Còn phải thanh toán: <b><?= money($edit['outstanding_amount']) ?></b></p></div><div><button class="btn btn-soft" onclick="openModal('acceptanceModal')">Sửa thông tin</button> <?php if((int)$edit['quotation_id']>0): ?><a class="btn btn-soft" href="app.php?page=acceptances&import_quote_items=<?= $edit['id'] ?>">Import từ báo giá</a><?php endif; ?> <a class="primary" target="_blank" href="public_acceptance.php?token=<?= e($edit['public_token']) ?>">Xuất PDF</a></div></div>
  <div class="stats-grid compact-stats"><div class="stat"><span>Giá trị HĐ</span><strong><?= money($edit['contract_value']) ?></strong></div><div class="stat"><span>Phát sinh</span><strong><?= money($edit['extra_value']) ?></strong></div><div class="stat"><span>Đã thu</span><strong><?= money($edit['paid_amount']) ?></strong></div><div class="stat yellow"><span>Còn lại</span><strong><?= money($edit['outstanding_amount']) ?></strong></div></div>
</section>

<section class="card">
  <div class="card-head"><h2>Sản phẩm nghiệm thu thực tế</h2><button class="primary" onclick="openModal('deliverableModal')">+ Thêm hạng mục phát sinh/thực tế</button></div>
  <table class="dense-table"><thead><tr><th>STT</th><th>Sản phẩm</th><th>SL báo giá</th><th>SL thực tế</th><th>Đơn giá</th><th>VAT</th><th>Thành tiền</th><th>Action</th></tr></thead><tbody>
  <?php foreach($deliverables as $i=>$d): $line=(float)($d['unit_price']??0)>0 ? ((float)$d['actual_quantity']*(float)$d['unit_price']) : (float)$d['value_amount']; ?>
    <tr><td><?= $i+1 ?></td><td><b><?= e($d['title']) ?></b><br><span class="muted"><?= e($d['description']) ?></span><?php if(($d['source_type']??'')==='manual'): ?><br><span class="badge purple">Phát sinh</span><?php endif; ?></td><td><?= e($d['quoted_quantity']) ?> <?= e($d['unit']) ?></td><td><b><?= e($d['actual_quantity']) ?> <?= e($d['unit']) ?></b></td><td><?= money($d['unit_price']) ?></td><td><?= e((float)($d['vat_rate']??0)) ?>%</td><td><b><?= money($line) ?></b></td><td class="actions"><a class="btn btn-soft" href="app.php?page=acceptances&id=<?= $edit['id'] ?>&edit_item=<?= $d['id'] ?>">Sửa</a><a class="btn btn-soft" onclick="return confirm('Xóa hạng mục?')" href="app.php?page=acceptances&id=<?= $edit['id'] ?>&delete_item=<?= $d['id'] ?>">Xóa</a></td></tr>
  <?php endforeach; ?>
  <?php if(empty($deliverables)): ?><tr><td colspan="8" class="muted">Chưa có sản phẩm nghiệm thu. Bạn có thể import từ báo giá hoặc thêm thủ công các sản phẩm thực tế/phát sinh.</td></tr><?php endif; ?>
  </tbody></table>
</section>
<?php endif; ?>

<div class="modal-backdrop <?= ($id&&isset($_GET['edit_acceptance']))?'active':'' ?>" id="acceptanceModal"><div class="modal-panel wide-modal"><button class="modal-close" onclick="closeModal('acceptanceModal')">×</button><h2><?= $edit?'Sửa biên bản':'Tạo biên bản nghiệm thu' ?></h2><form method="post"><input type="hidden" name="save_acceptance" value="1"><input type="hidden" name="acceptance_id" value="<?= e($edit['id']??'') ?>">
  <div class="form-row"><div><label>Hợp đồng</label><select name="contract_id"><option value="">Chọn hợp đồng</option><?php foreach($contracts as $c): ?><option value="<?= $c['id'] ?>" <?= ($edit['contract_id']??'')==$c['id']?'selected':'' ?>><?= e($c['contract_code'].' - '.$c['client_name']) ?></option><?php endforeach; ?></select></div><div><label>Báo giá</label><select name="quotation_id"><option value="">Chọn báo giá</option><?php foreach($quotations as $q): ?><option value="<?= $q['id'] ?>" <?= ($edit['quotation_id']??'')==$q['id']?'selected':'' ?>><?= e($q['quote_code'].' - '.$q['client_name']) ?></option><?php endforeach; ?></select></div></div>
  <label>Tiêu đề</label><input name="title" value="<?= e($edit['title']??'Biên bản nghiệm thu và thanh lý hợp đồng') ?>">
  <div class="form-row"><div><label>Khách hàng</label><input name="client_name" required value="<?= e($edit['client_name']??'') ?>"></div><div><label>Người đại diện khách</label><input name="client_contact" value="<?= e($edit['client_contact']??'') ?>"></div></div>
  <div class="form-row"><div><label>MST khách</label><input name="client_tax_code" value="<?= e($edit['client_tax_code']??'') ?>"></div><div><label>Địa chỉ khách</label><input name="client_address" value="<?= e($edit['client_address']??'') ?>"></div></div>
  <div class="form-row"><div><label>Mã hợp đồng</label><input name="contract_code" value="<?= e($edit['contract_code']??'') ?>"></div><div><label>Ngày ký HĐ</label><input type="date" name="contract_date" value="<?= e($edit['contract_date']??'') ?>"></div></div>
  <div class="form-row-3"><div><label>Ngày nghiệm thu</label><input type="date" name="accepted_date" value="<?= e($edit['accepted_date']??date('Y-m-d')) ?>"></div><div><label>Status</label><select name="status"><?php foreach(['Draft','Sent','Waiting Client Review','Partially Accepted','Accepted','Closed'] as $s): ?><option <?= ($edit['status']??'Draft')===$s?'selected':'' ?>><?= e($s) ?></option><?php endforeach; ?></select></div><div><label>Hạn thanh toán còn lại sau ký</label><input type="number" name="payment_due_days" value="<?= e($edit['payment_due_days']??5) ?>"></div></div>
  <div class="form-row-3"><div><label>Giá trị hợp đồng</label><input class="money-input" name="contract_value" value="<?= e(number_format((float)($edit['contract_value']??0),0,',','.')) ?>"></div><div><label>Đã thanh toán</label><input class="money-input" name="paid_amount" value="<?= e(number_format((float)($edit['paid_amount']??0),0,',','.')) ?>"></div><div><label>Giá trị phát sinh</label><input class="money-input" name="extra_value" value="<?= e(number_format((float)($edit['extra_value']??0),0,',','.')) ?>"></div></div>
  <div class="form-row"><div><label>Tổng giá trị nghiệm thu</label><input class="money-input" name="accepted_value" value="<?= e(number_format((float)($edit['accepted_value']??0),0,',','.')) ?>"></div><div><label>Còn phải thanh toán</label><input class="money-input" name="outstanding_amount" value="<?= e(number_format((float)($edit['outstanding_amount']??0),0,',','.')) ?>"></div></div>
  <label>Ghi chú</label><textarea name="note"><?= e($edit['note']??'') ?></textarea><button class="primary">Lưu biên bản</button></form></div></div>

<?php if($edit): ?>
<div class="modal-backdrop <?= $editItem?'active':'' ?>" id="deliverableModal"><div class="modal-panel wide-modal"><button class="modal-close" onclick="closeModal('deliverableModal')">×</button><h2><?= $editItem?'Sửa sản phẩm nghiệm thu':'Thêm sản phẩm nghiệm thu/phát sinh' ?></h2><form method="post"><input type="hidden" name="save_deliverable" value="1"><input type="hidden" name="acceptance_id" value="<?= e($edit['id']) ?>"><input type="hidden" name="item_id" value="<?= e($editItem['id']??'') ?>">
  <label>Tên sản phẩm/hạng mục</label><input name="title" required value="<?= e($editItem['title']??'') ?>">
  <label>Mô tả</label><textarea name="description"><?= e($editItem['description']??'') ?></textarea>
  <div class="form-row-3"><div><label>SL theo báo giá</label><input type="number" step="0.01" name="quoted_quantity" value="<?= e($editItem['quoted_quantity']??'') ?>"></div><div><label>SL bàn giao thực tế</label><input type="number" step="0.01" name="actual_quantity" value="<?= e($editItem['actual_quantity']??1) ?>"></div><div><label>Đơn vị</label><input name="unit" value="<?= e($editItem['unit']??'') ?>" placeholder="bài/video/gói/trang"></div></div>
  <div class="form-row-3"><div><label>Đơn giá</label><input class="money-input" name="unit_price" value="<?= e(number_format((float)($editItem['unit_price']??0),0,',','.')) ?>"></div><div><label>VAT (%)</label><input type="number" step="0.01" name="vat_rate" value="<?= e($editItem['vat_rate']??10) ?>"></div><div><label>Thứ tự</label><input type="number" name="sort_order" value="<?= e($editItem['sort_order']??0) ?>"></div></div>
  <label>Link bàn giao thực tế (lưu nội bộ, không hiển thị trong bảng tài chính)</label><input name="delivery_url" value="<?= e($editItem['delivery_url']??'') ?>" placeholder="Google Drive / Website / YouTube URL">
  <input type="hidden" name="status" value="<?= e($editItem['status']??'Đạt') ?>">
  <label>Ghi chú/feedback khách</label><textarea name="client_feedback"><?= e($editItem['client_feedback']??'') ?></textarea><button class="primary">Lưu hạng mục</button></form></div></div>
<?php endif; ?>
