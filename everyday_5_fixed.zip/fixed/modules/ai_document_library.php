<?php
if(!is_director_role() && !is_finance_role()) die('Bạn không có quyền xem Document Library.');

$types=['Proposal','Quotation','Contract','Invoice','NDA','Hosting','HR','Legal','Other'];
$type=$_GET['type'] ?? '';
$rows=safe_rows($pdo,"SELECT * FROM document_templates WHERE is_active=1 ".($type?" AND COALESCE(library_type,document_type)=".$pdo->quote($type):"")." ORDER BY COALESCE(library_type,document_type),template_name");
?>
<section class="workspace-hero ai-workspace-hero">
  <div><span class="eyebrow">AI Workspace</span><h1>Document Library</h1><p class="muted">Thư viện template Word/DOCX dùng cho Proposal, Quotation, Contract, Invoice, NDA, HR, Legal.</p></div>
  <a class="primary" href="app.php?page=doc_templates">+ Template</a>
</section>

<form class="asana-toolbar" method="get"><input type="hidden" name="page" value="ai_document_library"><select name="type"><option value="">Tất cả type</option><?php foreach($types as $t): ?><option value="<?= e($t) ?>" <?= $type===$t?'selected':'' ?>><?= e($t) ?></option><?php endforeach; ?></select><button class="btn btn-soft">Filter</button></form>

<section class="card">
  <div class="card-head"><h2>Templates</h2></div>
  <table class="dense-table">
    <thead><tr><th>Template</th><th>Type</th><th>Code</th><th>Path</th><th>Action</th></tr></thead>
    <tbody>
      <?php foreach($rows as $r): ?>
        <tr><td><b><?= e($r['template_name']) ?></b></td><td><span class="badge purple"><?= e($r['library_type'] ?: $r['document_type']) ?></span></td><td><?= e($r['template_code']) ?></td><td><span class="muted"><?= e($r['file_path']) ?></span></td><td class="actions"><a class="btn btn-soft" href="app.php?page=doc_templates&edit=<?= $r['id'] ?>">Edit</a><a class="btn btn-soft" href="app.php?page=doc_generate&template_id=<?= $r['id'] ?>">Generate</a></td></tr>
      <?php endforeach; ?>
      <?php if(empty($rows)): ?><tr><td colspan="5" class="muted">Chưa có template.</td></tr><?php endif; ?>
    </tbody>
  </table>
</section>
