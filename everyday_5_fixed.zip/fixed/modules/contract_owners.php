<?php
if(!can_view_business_finance()) die('Bạn không có quyền chỉnh owner hợp đồng.');
if($_SERVER['REQUEST_METHOD']==='POST'){
  $cid=(int)$_POST['contract_id'];
  $pdo->prepare('UPDATE contracts SET sales_owner_id=?, care_owner_id=?, commission_rate=? WHERE id=?')
    ->execute([$_POST['sales_owner_id']?:null,$_POST['care_owner_id']?:null,$_POST['commission_rate']?:2,$cid]);
  if(!empty($_POST['generate_commission'])) generate_sales_commission_for_contract($pdo,$cid);
  redirect('app.php?page=contract_owners');
}
$contracts=$pdo->query('SELECT c.*,so.name sales_owner_name,co.name care_owner_name FROM contracts c LEFT JOIN users so ON so.id=c.sales_owner_id LEFT JOIN users co ON co.id=c.care_owner_id ORDER BY c.id DESC')->fetchAll();
$users=$pdo->query('SELECT id,name,role FROM users ORDER BY name')->fetchAll();
?>
<section class="workspace-hero finance-hero">
  <div><span class="eyebrow">Contract Ownership</span><h1>Người phụ trách hợp đồng</h1><p class="muted">Gắn sales owner/care owner để hệ thống tính commission 2%.</p></div>
</section>
<section class="card">
<table class="dense-table"><thead><tr><th>Contract</th><th>Client</th><th>Value</th><th>Sales Owner</th><th>Care Owner</th><th>Rate</th><th>Action</th></tr></thead><tbody>
<?php foreach($contracts as $c): ?>
<tr>
<form method="post">
<input type="hidden" name="contract_id" value="<?= $c['id'] ?>">
<td><b><?= e($c['contract_code']) ?></b></td><td><?= e($c['client_name']) ?></td><td><?= money($c['total_value']) ?></td>
<td><select name="sales_owner_id"><option value="">Chọn</option><?php foreach($users as $u): ?><option value="<?= $u['id'] ?>" <?= (int)$c['sales_owner_id']===(int)$u['id']?'selected':'' ?>><?= e($u['name']) ?></option><?php endforeach; ?></select></td>
<td><select name="care_owner_id"><option value="">Chọn</option><?php foreach($users as $u): ?><option value="<?= $u['id'] ?>" <?= (int)$c['care_owner_id']===(int)$u['id']?'selected':'' ?>><?= e($u['name']) ?></option><?php endforeach; ?></select></td>
<td><input type="number" step="0.1" name="commission_rate" value="<?= e($c['commission_rate'] ?: 2) ?>" style="width:80px">%</td>
<td><button class="btn btn-soft">Lưu</button> <button class="btn btn-coral" name="generate_commission" value="1">Generate</button></td>
</form>
</tr>
<?php endforeach; ?>
</tbody></table>
</section>
