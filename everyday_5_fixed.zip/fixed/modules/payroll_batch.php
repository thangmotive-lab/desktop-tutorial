<?php
if(!(user_is_admin() || in_array(current_user()['role'], ['HR','Finance']))) die('Bạn không có quyền truy cập.');

$users=$pdo->query("SELECT * FROM users WHERE status='active' ORDER BY name")->fetchAll();

if(isset($_POST['create_batch'])){
  $month=$_POST['month'];
  $stmt=$pdo->prepare('INSERT INTO payroll_batches(month,title,status,created_by) VALUES(?,?,?,?)');
  $stmt->execute([$month,'Bảng lương tháng '.$month,'draft',current_user()['id']]);
  $batchId=$pdo->lastInsertId();

  foreach($users as $u){
    $uid=(int)$u['id'];
    $base=(float)$u['base_salary'];
    $std=176;

    $att=$pdo->prepare("SELECT COALESCE(SUM(total_minutes),0) mins, COUNT(DISTINCT work_date) days FROM attendance WHERE user_id=? AND DATE_FORMAT(work_date,'%Y-%m')=?");
    $att->execute([$uid,$month]);
    $a=$att->fetch();
    $hours=round(((int)$a['mins'])/60,2);
    $days=(int)$a['days'];

    $task=$pdo->prepare("SELECT COUNT(*) done, SUM(CASE WHEN completed_at <= CONCAT(deadline,' 23:59:59') THEN 1 ELSE 0 END) ontime FROM tasks WHERE assignee_id=? AND status='Done' AND DATE_FORMAT(COALESCE(completed_at,created_at),'%Y-%m')=?");
    $task->execute([$uid,$month]);
    $tk=$task->fetch();
    $done=(int)$tk['done'];
    $ontime=(int)$tk['ontime'];
    $kpi=$done>0?round(($ontime/$done)*100,1):0;

    $workRatio=$std>0?min(1,$hours/$std):0;
    $workPay=$base*0.8*$workRatio;
    $kpiPay=$base*0.2*($kpi/100);
    $total=$workPay+$kpiPay;

    $stmt=$pdo->prepare('INSERT INTO payroll(user_id,month,batch_id,base_salary,standard_hours,actual_hours,actual_days,kpi_percent,kpi_done,kpi_ontime,project_completed,commission,bhxh,tncn,other_deduction,total_salary,note,status,employee_approval_status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
    $stmt->execute([$uid,$month,$batchId,$base,$std,$hours,$days,$kpi,$done,$ontime,0,0,0,0,0,$total,'Auto generated from attendance + KPI','draft','pending']);
  }
  log_activity($pdo,'create','payroll_batch',$batchId,'Tạo bảng lương tháng '.$month);
  redirect('admin.php?page=payroll_batch&batch_id='.$batchId);
}

if(isset($_POST['approve_batch'])){
  $batchId=(int)$_POST['batch_id'];
  $pdo->prepare("UPDATE payroll_batches SET status='approved', approved_by=?, approved_at=NOW() WHERE id=?")->execute([current_user()['id'],$batchId]);
  $pdo->prepare("UPDATE payroll SET status='published', employee_approval_status='pending' WHERE batch_id=?")->execute([$batchId]);
  $rows=$pdo->prepare("SELECT p.*,u.name FROM payroll p JOIN users u ON u.id=p.user_id WHERE p.batch_id=?");
  $rows->execute([$batchId]);
  foreach($rows->fetchAll() as $p){
    $msg='Bảng lương '.$p['month'].' đã được cập nhật. KPI: '.$p['kpi_percent'].'%, ngày làm: '.$p['actual_days'].', giờ làm: '.$p['actual_hours'].'h, thực nhận: '.money($p['total_salary']);
    create_notification($pdo,$p['user_id'],'Bảng lương tháng '.$p['month'],$msg,'payroll','app.php?page=payroll');
  }
  log_activity($pdo,'approve','payroll_batch',$batchId,'Duyệt và gửi thông báo bảng lương');
  redirect('admin.php?page=payroll_batch&batch_id='.$batchId);
}

$batches=$pdo->query('SELECT pb.*,u.name creator_name FROM payroll_batches pb LEFT JOIN users u ON u.id=pb.created_by ORDER BY pb.id DESC')->fetchAll();
$current=(int)($_GET['batch_id']??($batches[0]['id']??0));
$items=[];
if($current){
  $stmt=$pdo->prepare('SELECT p.*,u.name user_name,u.avatar user_avatar FROM payroll p JOIN users u ON u.id=p.user_id WHERE p.batch_id=? ORDER BY u.name');
  $stmt->execute([$current]);
  $items=$stmt->fetchAll();
}
?>
<section class="card">
  <div class="card-head">
    <h2>Tạo bảng lương theo tháng</h2>
    <button class="primary" onclick="openSlideDrawer('payrollBatchDrawer')">+ Tạo bảng lương tháng</button>
  </div>
  <div class="three-col">
    <?php foreach($batches as $b): ?>
      <a class="payroll-batch-card hvr-grow" href="admin.php?page=payroll_batch&batch_id=<?= $b['id'] ?>">
        <b><?= e($b['title']) ?></b><br>
        <span class="muted">Status: <?= e($b['status']) ?> · Created by <?= e($b['creator_name']) ?></span>
      </a>
    <?php endforeach; ?>
  </div>
</section>

<?php if($current): ?>
<section class="card">
  <div class="card-head">
    <h2>Chi tiết bảng lương</h2>
    <form method="post">
      <input type="hidden" name="batch_id" value="<?= $current ?>">
      <button class="btn-green" name="approve_batch" value="1">Duyệt & gửi thông báo tới nhân viên</button>
    </form>
  </div>
  <table>
    <thead><tr><th>Nhân sự</th><th>KPI</th><th>Ngày/Giờ làm</th><th>Lương cứng</th><th>Thưởng/khấu trừ</th><th>Thực nhận</th><th>Nhân viên xác nhận</th></tr></thead>
    <tbody>
      <?php foreach($items as $p): ?>
        <tr>
          <td><span class="user-chip"><?= avatar_html(['name'=>$p['user_name'],'avatar'=>$p['user_avatar']],true) ?><?= e($p['user_name']) ?></span></td>
          <td><?= e($p['kpi_percent']) ?>%<br><span class="muted">Done <?= e($p['kpi_done']) ?> · On-time <?= e($p['kpi_ontime']) ?></span></td>
          <td><?= e($p['actual_days']) ?> ngày<br><?= e($p['actual_hours']) ?> giờ</td>
          <td><?= money($p['base_salary']) ?></td>
          <td>Commission <?= money($p['commission']) ?><br>BHXH <?= money($p['bhxh']) ?><br>TNCN <?= money($p['tncn']) ?></td>
          <td><b><?= money($p['total_salary']) ?></b></td>
          <td><span class="approval-pill <?= $p['employee_approval_status']==='approved'?'approved':'pending' ?>"><?= e($p['employee_approval_status']) ?></span></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</section>
<?php endif; ?>

<div id="drawerBackdrop" class="drawer-backdrop" onclick="closeSlideDrawer('payrollBatchDrawer')"></div>
<div class="slide-drawer" id="payrollBatchDrawer">
  <div class="drawer-form-header">
    <div><span class="eyebrow">Payroll</span><h2>Tạo bảng lương tháng</h2></div>
    <button class="drawer-close-x" onclick="closeSlideDrawer('payrollBatchDrawer')" type="button">×</button>
  </div>
  <div class="drawer-form-note">Hệ thống sẽ lấy giờ làm từ chấm công và KPI từ task hoàn thành đúng hạn để tạo bảng lương nháp.</div>
  <form method="post">
    <label>Tháng lương</label><input name="month" type="month" value="<?= date('Y-m') ?>" required>
    <button class="primary" name="create_batch" value="1">Tạo bảng lương nháp</button>
  </form>
</div>
