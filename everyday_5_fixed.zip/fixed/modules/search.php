<?php
$me=current_user();
$q=trim($_GET['q']??'');
$results=[];
function push_search(&$results,$type,$title,$subtitle,$url,$meta=''){
  $results[]=['type'=>$type,'title'=>$title,'subtitle'=>$subtitle,'url'=>$url,'meta'=>$meta];
}
if($q!==''){
  $like='%'.$q.'%';

  try{
    $st=$pdo->prepare("SELECT id,name,company,phone,email,status FROM clients WHERE name LIKE ? OR company LIKE ? OR phone LIKE ? OR email LIKE ? ORDER BY id DESC LIMIT 12");
    $st->execute([$like,$like,$like,$like]);
    foreach($st->fetchAll() as $r) push_search($results,'Client',$r['name'],$r['company'].' · '.$r['phone'].' · '.$r['email'],'app.php?page=clients&q='.urlencode($q),$r['status']);
  }catch(Exception $e){}

  try{
    $st=$pdo->prepare("SELECT id,quote_code,client_name,title,status,expected_revenue FROM quotations WHERE quote_code LIKE ? OR client_name LIKE ? OR title LIKE ? ORDER BY id DESC LIMIT 12");
    $st->execute([$like,$like,$like]);
    foreach($st->fetchAll() as $r) push_search($results,'Quotation',$r['quote_code'].' · '.$r['client_name'],$r['title'],'app.php?page=quotation_edit&id='.$r['id'],money_short($r['expected_revenue']).' · '.$r['status']);
  }catch(Exception $e){}

  try{
    $st=$pdo->prepare("SELECT id,contract_code,client_name,status,total_value FROM contracts WHERE contract_code LIKE ? OR client_name LIKE ? ORDER BY id DESC LIMIT 12");
    $st->execute([$like,$like]);
    foreach($st->fetchAll() as $r) push_search($results,'Contract',$r['contract_code'].' · '.$r['client_name'],$r['status'],'app.php?page=contract_detail&id='.$r['id'],money_short($r['total_value']));
  }catch(Exception $e){}

  try{
    $st=$pdo->prepare("SELECT id,name,client_name,status,health,end_date FROM projects WHERE name LIKE ? OR client_name LIKE ? ORDER BY id DESC LIMIT 12");
    $st->execute([$like,$like]);
    foreach($st->fetchAll() as $r) push_search($results,'Project',$r['name'],$r['client_name'].' · '.$r['status'].' · '.$r['health'],'app.php?page=project_detail&id='.$r['id'],'End '.$r['end_date']);
  }catch(Exception $e){}

  try{
    $st=$pdo->prepare("SELECT t.id,t.title,t.status,t.deadline,p.id project_id,p.name project_name FROM tasks t LEFT JOIN projects p ON p.id=t.project_id WHERE t.title LIKE ? OR t.description LIKE ? OR p.name LIKE ? ORDER BY t.id DESC LIMIT 15");
    $st->execute([$like,$like,$like]);
    foreach($st->fetchAll() as $r) push_search($results,'Task',$r['title'],$r['project_name'].' · '.$r['status'],'app.php?page='.($r['project_id']?'project_detail&id='.$r['project_id']:'tasks'),$r['deadline']);
  }catch(Exception $e){}

  try{
    $st=$pdo->prepare("SELECT id,title,category,tags FROM ai_knowledge_base WHERE is_active=1 AND (title LIKE ? OR content LIKE ? OR tags LIKE ?) ORDER BY id DESC LIMIT 8");
    $st->execute([$like,$like,$like]);
    foreach($st->fetchAll() as $r) push_search($results,'Knowledge',$r['title'],$r['category'].' · '.$r['tags'],'app.php?page=ai_knowledge_base&edit='.$r['id'],'AI');
  }catch(Exception $e){}
}
?>
<section class="workspace-hero search-hero">
  <div><span class="eyebrow">Universal Search</span><h1>Tìm mọi thứ</h1><p class="muted">Tìm Client, Quotation, Contract, Project, Task và Knowledge Base.</p></div>
</section>

<section class="card">
  <form class="global-search-form" method="get">
    <input type="hidden" name="page" value="search">
    <input name="q" value="<?= e($q) ?>" placeholder="Gõ Aquafield, Mộc, contract code, task..." autofocus>
    <button class="primary">Search</button>
  </form>
</section>

<section class="card">
  <div class="card-head"><h2>Kết quả <?= $q!==''?'cho “'.e($q).'”':'' ?></h2><span class="muted"><?= count($results) ?> kết quả</span></div>
  <div class="search-result-list">
    <?php foreach($results as $r): ?>
      <a class="search-result-row" href="<?= e($r['url']) ?>">
        <span class="search-type"><?= e($r['type']) ?></span>
        <div><b><?= e($r['title']) ?></b><small><?= e($r['subtitle']) ?></small></div>
        <em><?= e($r['meta']) ?></em>
      </a>
    <?php endforeach; ?>
    <?php if($q==='' ): ?><p class="muted">Nhập từ khóa để bắt đầu tìm kiếm.</p><?php endif; ?>
    <?php if($q!=='' && empty($results)): ?><p class="muted">Không tìm thấy kết quả phù hợp.</p><?php endif; ?>
  </div>
</section>
