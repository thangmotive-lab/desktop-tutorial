<?php
if(!is_director_role() && !is_finance_role()) die('Bạn không có quyền xem Knowledge Base.');
if($_SERVER['REQUEST_METHOD']==='POST'){
  if(!empty($_POST['kb_id'])){
    $pdo->prepare('UPDATE ai_knowledge_base SET title=?,category=?,content=?,is_active=? WHERE id=?')
      ->execute([$_POST['title'],$_POST['category'],$_POST['content'],isset($_POST['is_active'])?1:0,$_POST['kb_id']]);
  } else {
    $pdo->prepare('INSERT INTO ai_knowledge_base(title,category,source_type,content,is_active,created_by) VALUES(?,?,?,?,?,?)')
      ->execute([$_POST['title'],$_POST['category'],'text',$_POST['content'],isset($_POST['is_active'])?1:0,current_user()['id']]);
  }
  redirect('app.php?page=ai_knowledge');
}
if(isset($_GET['delete']) && user_is_admin()){
  $pdo->prepare('DELETE FROM ai_knowledge_base WHERE id=?')->execute([(int)$_GET['delete']]);
  redirect('app.php?page=ai_knowledge');
}
$edit=null;
if(isset($_GET['edit'])){
  $st=$pdo->prepare('SELECT * FROM ai_knowledge_base WHERE id=?');
  $st->execute([(int)$_GET['edit']]);$edit=$st->fetch();
}
$rows=safe_rows($pdo,"SELECT kb.*,u.name user_name FROM ai_knowledge_base kb LEFT JOIN users u ON u.id=kb.created_by ORDER BY kb.category,kb.id DESC");
?>
<section class="workspace-hero finance-hero ai-hero">
  <div><span class="eyebrow">AI Knowledge Base</span><h1>Motive Brain</h1><p class="muted">Lưu văn phong, mẫu hợp đồng, ratecard, quy trình để AI generate đúng chất Motive.</p></div>
  <button class="btn btn-soft" onclick="openModal('kbModal')">+ Knowledge</button>
</section>
<section class="card">
  <table class="dense-table"><thead><tr><th>Title</th><th>Category</th><th>Content</th><th>Status</th><th>By</th><th>Action</th></tr></thead><tbody>
  <?php foreach($rows as $r): ?><tr><td><b><?= e($r['title']) ?></b></td><td><?= e($r['category']) ?></td><td><?= e(mb_substr($r['content'],0,180)) ?>...</td><td><span class="badge <?= $r['is_active']?'green':'gray' ?>"><?= $r['is_active']?'active':'off' ?></span></td><td><?= e($r['user_name']) ?></td><td><a class="btn btn-soft" href="app.php?page=ai_knowledge&edit=<?= $r['id'] ?>">Edit</a><?php if(user_is_admin()): ?> <a class="btn btn-soft" onclick="return confirm('Xóa knowledge?')" href="app.php?page=ai_knowledge&delete=<?= $r['id'] ?>">Xóa</a><?php endif; ?></td></tr><?php endforeach; ?>
  </tbody></table>
</section>
<div class="modal-backdrop <?= $edit?'active':'' ?>" id="kbModal">
  <div class="modal-panel">
    <button class="modal-close" onclick="closeModal('kbModal')">×</button>
    <h2><?= $edit?'Edit Knowledge':'New Knowledge' ?></h2>
    <form method="post">
      <input type="hidden" name="kb_id" value="<?= e($edit['id']??'') ?>">
      <label>Title</label><input name="title" required value="<?= e($edit['title']??'') ?>">
      <label>Category</label><input name="category" value="<?= e($edit['category']??'general') ?>" placeholder="contract_marketing, finance, ratecard...">
      <label>Content</label><textarea name="content" style="min-height:360px" required><?= e($edit['content']??'') ?></textarea>
      <label class="check-row"><input type="checkbox" name="is_active" <?= ($edit['is_active']??1)?'checked':'' ?>> Active</label>
      <button class="primary">Save Knowledge</button>
    </form>
  </div>
</div>
<?php if($edit): ?><script>document.addEventListener('DOMContentLoaded',()=>openModal('kbModal'));</script><?php endif; ?>
