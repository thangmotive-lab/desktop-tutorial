<?php
if(!user_is_admin()) die('Bạn không có quyền truy cập Settings.');

$defaults = [
  'app_name'=>'Motiveeveryday',
  'website_name'=>'Motive Agency Workspace',
  'website_url'=>'https://motiveagency.vn',
  'homepage_description'=>'Agency operating system for Motive team.',
  'logo_light'=>'',
  'logo_dark'=>'',
  'app_icon'=>'',
  'favicon'=>'',
  'login_theme'=>'vector'
];

if($_SERVER['REQUEST_METHOD']==='POST'){
  foreach(['logo_light','logo_dark','app_icon','favicon'] as $fileKey){
    $current = get_setting($pdo,$fileKey,$defaults[$fileKey]);
    if(!empty($_FILES[$fileKey]['name'])){
      $ext=pathinfo($_FILES[$fileKey]['name'],PATHINFO_EXTENSION);
      $filename='uploads/files/'.$fileKey.'_'.time().'.'.$ext;
      move_uploaded_file($_FILES[$fileKey]['tmp_name'], __DIR__.'/../'.$filename);
      $_POST[$fileKey]=$filename;
    } else {
      $_POST[$fileKey]=$current;
    }
  }
  foreach($defaults as $k=>$v){
    set_setting($pdo,$k,$_POST[$k] ?? $v);
  }
  log_activity($pdo,'update','settings',null,'Cập nhật app settings');
  redirect('admin.php?page=settings');
}
?>
<section class="card">
  <div class="card-head"><div><span class="eyebrow">Admin Setting</span><h2>Cấu hình thương hiệu ứng dụng</h2></div></div>
  <form method="post" enctype="multipart/form-data">
    <div class="form-row">
      <div><label>Tên ứng dụng</label><input name="app_name" value="<?= e(get_setting($pdo,'app_name',$defaults['app_name'])) ?>"></div>
      <div><label>Tên website</label><input name="website_name" value="<?= e(get_setting($pdo,'website_name',$defaults['website_name'])) ?>"></div>
    </div>
    <label>Link website</label><input name="website_url" value="<?= e(get_setting($pdo,'website_url',$defaults['website_url'])) ?>">
    <label>Mô tả ngoài trang chủ</label><textarea name="homepage_description"><?= e(get_setting($pdo,'homepage_description',$defaults['homepage_description'])) ?></textarea>

    <label>Login Theme</label>
    <select name="login_theme">
      <?php foreach(['classic'=>'Classic / Cũ ổn định','vector'=>'Vector Prairie / Key visual mới'] as $k=>$v): ?>
        <option value="<?= e($k) ?>" <?= get_setting($pdo,'login_theme',$defaults['login_theme'])===$k?'selected':'' ?>><?= e($v) ?></option>
      <?php endforeach; ?>
    </select>
    <p class="muted">Classic dùng khi cần giao diện đăng nhập đơn giản, Vector Prairie dùng key visual mới.</p>

    <div class="form-row-3">
      <div>
        <label>Logo dương bản</label>
        <?php if(get_setting($pdo,'logo_light','')): ?><p><img src="<?= e(get_setting($pdo,'logo_light','')) ?>" style="max-height:48px"></p><?php endif; ?>
        <input name="logo_light" type="file">
      </div>
      <div>
        <label>Logo âm bản</label>
        <?php if(get_setting($pdo,'logo_dark','')): ?><p><img src="<?= e(get_setting($pdo,'logo_dark','')) ?>" style="max-height:48px;background:#111;padding:6px;border-radius:10px"></p><?php endif; ?>
        <input name="logo_dark" type="file">
      </div>
      <div>
        <label>Icon app</label>
        <?php if(get_setting($pdo,'app_icon','')): ?><p><img src="<?= e(get_setting($pdo,'app_icon','')) ?>" style="max-height:48px"></p><?php endif; ?>
        <input name="app_icon" type="file">
      </div>
    </div>

    <label>Fav icon</label>
    <?php if(get_setting($pdo,'favicon','')): ?><p><img src="<?= e(get_setting($pdo,'favicon','')) ?>" style="max-height:32px"></p><?php endif; ?>
    <input name="favicon" type="file">

    <br><br>
    <button class="primary">Lưu settings</button>
  </form>
</section>
