<?php
$me=current_user();
if(isset($_GET['read'])){
  $pdo->prepare('UPDATE task_mentions SET is_read=1, read_at=NOW() WHERE id=? AND mentioned_user_id=?')->execute([(int)$_GET['read'],$me['id']]);
  redirect('app.php?page=task_mentions');
}
$rows=$pdo->prepare('SELECT tm.*,t.title task_title,t.status task_status,p.name project_name,u.name mentioned_by_name,u.avatar mentioned_by_avatar
  FROM task_mentions tm
  LEFT JOIN tasks t ON t.id=tm.task_id
  LEFT JOIN projects p ON p.id=t.project_id
  LEFT JOIN users u ON u.id=tm.mentioned_by
  WHERE tm.mentioned_user_id=?
  ORDER BY tm.is_read ASC, tm.created_at DESC
  LIMIT 100');
$rows->execute([$me['id']]);
$rows=$rows->fetchAll();
?>
<section class="card">
  <div class="card-head"><div><span class="eyebrow">Mentions</span><h2>@Mentions của tôi</h2><p class="muted">Các comment task có nhắc tới bạn.</p></div></div>
  <table class="dense-table">
    <thead><tr><th>Task</th><th>Project</th><th>Người nhắc</th><th>Time</th><th>Status</th><th>Action</th></tr></thead>
    <tbody>
      <?php foreach($rows as $r): ?>
      <tr class="<?= !$r['is_read']?'active-row':'' ?>">
        <td><b><?= e($r['task_title']) ?></b><br><span class="muted"><?= e($r['task_status']) ?></span></td>
        <td><?= e($r['project_name']) ?></td>
        <td><span class="user-chip"><?= avatar_html(['name'=>$r['mentioned_by_name'],'avatar'=>$r['mentioned_by_avatar']],true) ?><?= e($r['mentioned_by_name']) ?></span></td>
        <td><?= e($r['created_at']) ?></td>
        <td><span class="badge <?= $r['is_read']?'green':'orange' ?>"><?= $r['is_read']?'Đã đọc':'Mới' ?></span></td>
        <td><a class="btn btn-soft" href="app.php?page=tasks&focus=<?= $r['task_id'] ?>">Mở task</a><?php if(!$r['is_read']): ?> <a class="btn btn-soft" href="app.php?page=task_mentions&read=<?= $r['id'] ?>">Đã đọc</a><?php endif; ?></td>
      </tr>
      <?php endforeach; ?>
      <?php if(empty($rows)): ?><tr><td colspan="6" class="muted">Chưa có mention.</td></tr><?php endif; ?>
    </tbody>
  </table>
</section>
