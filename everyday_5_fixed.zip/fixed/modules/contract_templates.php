<?php
if(!user_is_admin()) die('Bạn không có quyền truy cập Contract Templates.');

if($_SERVER['REQUEST_METHOD']==='POST'){
  $filePath=$_POST['existing_file'] ?? '';
  if(!empty($_FILES['template_file']['name'])){
    $ext=strtolower(pathinfo($_FILES['template_file']['name'],PATHINFO_EXTENSION));
    if($ext !== 'docx') die('Chỉ hỗ trợ file .docx');
    $filename='uploads/contract_templates/template_'.time().'_'.rand(100,999).'.docx';
    move_uploaded_file($_FILES['template_file']['tmp_name'], __DIR__.'/../'.$filename);
    $filePath=$filename;
  }
  if(!empty($_POST['template_id'])){
    $pdo->prepare('UPDATE contract_templates SET template_name=?,template_type=?,file_path=?,description=?,status=? WHERE id=?')
      ->execute([$_POST['template_name'],$_POST['template_type'],$filePath,$_POST['description'],$_POST['status'],$_POST['template_id']]);
  } else {
    $pdo->prepare('INSERT INTO contract_templates(template_name,template_type,file_path,description,status,created_by) VALUES(?,?,?,?,?,?)')
      ->execute([$_POST['template_name'],$_POST['template_type'],$filePath,$_POST['description'],$_POST['status'],current_user()['id']]);
  }
  redirect((strpos($_SERVER['SCRIPT_NAME'],'admin.php')!==false?'admin.php':'app.php').'?page=contract_templates');
}

$rows=$pdo->query('SELECT * FROM contract_templates ORDER BY template_type,id')->fetchAll();
?>
<section class="card">
  <div class="card-head"><div><span class="eyebrow">Admin Studio</span><h2>Contract Template Center</h2><p class="muted">Template DOCX sử dụng placeholder như {{CLIENT_NAME}}, {{CONTRACT_CODE}}, {{AMOUNT}}, {{VAT}}, {{START_DATE}}, {{END_DATE}}.</p></div><button class="primary" onclick="openModal('templateModal')">+ Template</button></div>
  <table><thead><tr><th>Tên template</th><th>Type</th><th>File</th><th>Status</th><th>Note</th></tr></thead><tbody>
  <?php foreach($rows as $r): ?><tr><td><b><?= e($r['template_name']) ?></b></td><td><?= e($r['template_type']) ?></td><td><a class="btn btn-soft" href="<?= e($r['file_path']) ?>" target="_blank">Download DOCX</a></td><td><span class="badge <?= badge_class($r['status']) ?>"><?= e($r['status']) ?></span></td><td><?= e($r['description']) ?></td></tr><?php endforeach; ?>
  </tbody></table>
</section>
<div class="modal-backdrop" id="templateModal">
  <div class="modal-panel">
    <button class="modal-close" onclick="closeModal('templateModal')">×</button>
    <h2>Thêm template DOCX</h2>
    <form method="post" enctype="multipart/form-data">
      <label>Tên template</label><input name="template_name" required>
      <label>Loại template</label><select name="template_type"><option value="hosting">Hosting</option><option value="marketing">Marketing Retainer</option><option value="freelancer">Freelancer</option><option value="acceptance">Nghiệm thu / Thanh lý</option></select>
      <label>File .docx</label><input name="template_file" type="file" accept=".docx" required>
      <label>Mô tả</label><textarea name="description"></textarea>
      <label>Status</label><select name="status"><option>active</option><option>inactive</option></select>
      <button class="primary">Lưu template</button>
    </form>
  </div>
</div>
