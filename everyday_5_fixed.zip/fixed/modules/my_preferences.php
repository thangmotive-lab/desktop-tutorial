<?php
$me=current_user();
if($_SERVER['REQUEST_METHOD']==='POST'){
  $pdo->prepare('INSERT INTO user_preferences(user_id,mute_notification,mute_sound,popup_position) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE mute_notification=VALUES(mute_notification), mute_sound=VALUES(mute_sound), popup_position=VALUES(popup_position)')
    ->execute([$me['id'],isset($_POST['mute_notification'])?1:0,isset($_POST['mute_sound'])?1:0,$_POST['popup_position']??'top-right']);
  redirect('app.php?page=my_preferences&saved=1');
}
$pref=user_pref($pdo,$me['id']);
?>
<section class="card">
  <div class="card-head"><div><span class="eyebrow">Preferences</span><h2>Cài đặt thông báo cá nhân</h2></div></div>
  <?php if(!empty($_GET['saved'])): ?><div class="alert success">Đã lưu cài đặt.</div><?php endif; ?>
  <form method="post">
    <label class="check-row"><input type="checkbox" name="mute_notification" <?= !empty($pref['mute_notification'])?'checked':'' ?>> Tắt popup notification</label>
    <label class="check-row"><input type="checkbox" name="mute_sound" <?= !empty($pref['mute_sound'])?'checked':'' ?>> Tắt âm thanh thông báo</label>
    <label>Vị trí popup</label>
    <select name="popup_position"><option value="top-right" <?= ($pref['popup_position']??'top-right')==='top-right'?'selected':'' ?>>Góc phải trên</option><option value="bottom-right" <?= ($pref['popup_position']??'')==='bottom-right'?'selected':'' ?>>Góc phải dưới</option></select>
    <button class="primary">Lưu cài đặt</button>
  </form>
</section>
