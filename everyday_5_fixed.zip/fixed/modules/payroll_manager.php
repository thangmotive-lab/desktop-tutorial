<?php
if(!can_view_business_finance()) die('Bạn không có quyền xem Payroll Manager.');

$month=$_GET['month'] ?? date('Y-m');

// Compatibility patch: older databases may not have payroll.paid_at yet.
// Keep the Payroll Manager usable after uploading this source without requiring manual SQL first.
try {
  $pdo->exec("ALTER TABLE payroll ADD COLUMN paid_at DATETIME NULL");
} catch (Throwable $e) {
  // Column already exists or DB user cannot ALTER; status update below has a safe fallback.
}

$payrollStatuses=[
  'draft'=>'Draft',
  'notified'=>'Gửi thông báo',
  'approved'=>'Phê duyệt bảng lương',
  'paid'=>'Đã thanh toán'
];

if(isset($_GET['delete_payroll']) && user_is_admin()){
  $pid=(int)$_GET['delete_payroll'];
  $pdo->prepare('DELETE FROM payroll WHERE id=?')->execute([$pid]);
  log_activity($pdo,'delete','payroll',$pid,'Xóa bảng lương');
  redirect('app.php?page=payroll_manager&month='.$month);
}

if(isset($_GET['status_payroll'])){
  $pid=(int)$_GET['status_payroll'];
  $next=$_GET['to'] ?? 'draft';
  if(!array_key_exists($next,$payrollStatuses)) $next='draft';

  if($next==='notified'){
    $stmt=$pdo->prepare("UPDATE payroll SET status='notified', employee_approval_status='pending', approved_by_hr=?, approved_at=NOW() WHERE id=?");
    $stmt->execute([current_user()['id'],$pid]);
    $u=$pdo->prepare('SELECT pr.*,u.id uid,u.name FROM payroll pr JOIN users u ON u.id=pr.user_id WHERE pr.id=?');
    $u->execute([$pid]);
    $row=$u->fetch();
    if($row){
      create_notification($pdo,$row['uid'],'Bảng lương đã được gửi','Bảng lương tháng '.$row['month'].' đã được gửi để bạn kiểm tra.','payroll','app.php?page=my_finance&month='.$row['month']);
    }
  } elseif($next==='approved'){
    $pdo->prepare("UPDATE payroll SET status='approved', approved_by_hr=?, approved_at=NOW() WHERE id=?")->execute([current_user()['id'],$pid]);
  } elseif($next==='paid'){
    try {
      $pdo->prepare("UPDATE payroll SET status='paid', paid_at=NOW() WHERE id=?")->execute([$pid]);
    } catch (Throwable $e) {
      $pdo->prepare("UPDATE payroll SET status='paid' WHERE id=?")->execute([$pid]);
    }
  } else {
    $pdo->prepare("UPDATE payroll SET status='draft' WHERE id=?")->execute([$pid]);
  }

  log_activity($pdo,'update','payroll',$pid,'Cập nhật trạng thái bảng lương: '.$next);
  redirect('app.php?page=payroll_manager&month='.$month);
}

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['save_payroll_manager'])){
  $pid=(int)($_POST['payroll_id'] ?? 0);
  $uid=(int)$_POST['user_id'];
  $salaryMonth=$_POST['month'];
  $base=(float)str_replace(['.',',',' '],['','',''],$_POST['base_salary'] ?? 0);
  $actualDays=(float)($_POST['actual_days'] ?? 0);
  $kpi=(float)($_POST['kpi_percent'] ?? 0);
  $commission=(float)str_replace(['.',',',' '],['','',''],$_POST['commission'] ?? 0);
  $bhxh=(float)str_replace(['.',',',' '],['','',''],$_POST['bhxh'] ?? 0);
  $tncn=(float)str_replace(['.',',',' '],['','',''],$_POST['tncn'] ?? 0);
  $other=(float)str_replace(['.',',',' '],['','',''],$_POST['other_deduction'] ?? 0);
  $status=$_POST['status'] ?? 'draft';
  if(!array_key_exists($status,$payrollStatuses)) $status='draft';

  $standardHours=176;
  $actualHours=round($actualDays*8,2);

  // 80% lương cứng theo ngày công thực tế / 22 ngày + 20% thưởng KPI
  $workPay=$base*0.8*min(1,$actualDays/22);
  $kpiPay=$base*0.2*($kpi/100);
  $total=$workPay+$kpiPay+$commission-$bhxh-$tncn-$other;

  if($pid){
    $pdo->prepare('UPDATE payroll SET user_id=?, month=?, salary_month=?, base_salary=?, standard_hours=?, actual_hours=?, actual_days=?, kpi_percent=?, commission=?, bhxh=?, tncn=?, other_deduction=?, total_salary=?, net_salary=?, note=?, status=? WHERE id=?')
      ->execute([$uid,$salaryMonth,$salaryMonth,$base,$standardHours,$actualHours,$actualDays,$kpi,$commission,$bhxh,$tncn,$other,$total,$total,$_POST['note']??'',$status,$pid]);
  } else {
    $pdo->prepare('INSERT INTO payroll(user_id,month,salary_month,base_salary,standard_hours,actual_hours,actual_days,kpi_percent,commission,bhxh,tncn,other_deduction,total_salary,net_salary,note,status,employee_approval_status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
      ->execute([$uid,$salaryMonth,$salaryMonth,$base,$standardHours,$actualHours,$actualDays,$kpi,$commission,$bhxh,$tncn,$other,$total,$total,$_POST['note']??'',$status,'pending']);
  }
  redirect('app.php?page=payroll_manager&month='.$salaryMonth);
}

if(isset($_GET['generate_month'])){
  $genMonth=$_GET['generate_month'] ?: $month;
  $activeUsers=$pdo->query("SELECT id,name,base_salary FROM users WHERE status='active' ORDER BY name")->fetchAll();
  foreach($activeUsers as $u){
    $uid=(int)$u['id'];
    $exists=$pdo->prepare("SELECT id FROM payroll WHERE user_id=? AND COALESCE(salary_month,month)=? LIMIT 1");
    $exists->execute([$uid,$genMonth]);
    if($exists->fetchColumn()) continue;
    $att=$pdo->prepare("SELECT COUNT(DISTINCT work_date) days FROM attendance WHERE user_id=? AND DATE_FORMAT(work_date,'%Y-%m')=?");
    $att->execute([$uid,$genMonth]);
    $days=(float)($att->fetchColumn() ?: 0);
    $base=(float)$u['base_salary'];
    $workPay=$base*0.8*min(1,$days/22);
    $kpiPay=0;
    $total=$workPay+$kpiPay;
    $pdo->prepare('INSERT INTO payroll(user_id,month,salary_month,base_salary,standard_hours,actual_hours,actual_days,kpi_percent,commission,bhxh,tncn,other_deduction,total_salary,net_salary,note,status,employee_approval_status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
      ->execute([$uid,$genMonth,$genMonth,$base,176,round($days*8,2),$days,0,0,0,0,0,$total,$total,'Auto ngày 30: 80% theo ngày công / 22 ngày + 20% KPI chờ cập nhật','draft','pending']);
  }
  redirect('app.php?page=payroll_manager&month='.$genMonth);
}

$editPayroll=null;
if(isset($_GET['edit_payroll'])){
  $st=$pdo->prepare('SELECT * FROM payroll WHERE id=?');
  $st->execute([(int)$_GET['edit_payroll']]);
  $editPayroll=$st->fetch();
}

$allRows=$pdo->prepare("SELECT pr.*,u.name user_name,u.avatar user_avatar,u.role user_role 
  FROM payroll pr JOIN users u ON u.id=pr.user_id 
  WHERE COALESCE(pr.salary_month,pr.month)=?
  ORDER BY FIELD(pr.status,'draft','notified','approved','paid'), u.name");
$allRows->execute([$month]); 
$rows=$allRows->fetchAll();

$monthGroups=[];
$monthRows=$pdo->query("SELECT COALESCE(salary_month,month) m, COUNT(*) c, SUM(COALESCE(net_salary,total_salary,0)) total FROM payroll GROUP BY COALESCE(salary_month,month) ORDER BY m DESC LIMIT 12")->fetchAll();
foreach($monthRows as $mr){ $monthGroups[$mr['m']]=$mr; }

$total=0;$statusCount=['draft'=>0,'notified'=>0,'approved'=>0,'paid'=>0];
foreach($rows as $r){
  $total+=(float)($r['net_salary'] ?: $r['total_salary']);
  $s=$r['status'] ?: 'draft';
  if(!isset($statusCount[$s])) $s='draft';
  $statusCount[$s]++;
}

$users=$pdo->query('SELECT id,name,role FROM users ORDER BY name')->fetchAll();
function payroll_status_class($s){
  return [
    'draft'=>'payroll-draft',
    'notified'=>'payroll-notified',
    'approved'=>'payroll-approved',
    'paid'=>'payroll-paid'
  ][$s ?: 'draft'] ?? 'payroll-draft';
}
?>
<section class="payroll-hero-v2">
  <div>
    <span class="eyebrow">Private Control Room</span>
    <h1>Bảng lương <?= e($month) ?></h1>
    <p>Quản lý bảng lương theo tháng, theo dõi trạng thái duyệt và thanh toán rõ ràng hơn.</p>
  </div>
  <div class="payroll-hero-actions">
    <form method="get">
      <input type="hidden" name="page" value="payroll_manager">
      <input type="month" name="month" value="<?= e($month) ?>">
      <button class="btn btn-soft">Xem tháng</button>
    </form>
    <a class="btn btn-soft" href="app.php?page=payroll_manager&month=<?= e($month) ?>&generate_month=<?= e($month) ?>">Auto ngày 30</a>
    <button class="primary" onclick="openModal('payrollModal')">+ Tạo bảng lương</button>
  </div>
</section>

<section class="payroll-month-strip">
  <?php foreach($monthGroups as $m=>$mr): ?>
    <a class="<?= $m===$month?'active':'' ?>" href="app.php?page=payroll_manager&month=<?= e($m) ?>">
      <span><?= e($m) ?></span>
      <b><?= (int)$mr['c'] ?> bảng</b>
      <small><?= money_short($mr['total']) ?></small>
    </a>
  <?php endforeach; ?>
</section>

<section class="payroll-kpi-v2">
  <div><span>Total Payroll</span><strong><?= money_short($total) ?></strong></div>
  <div><span>Draft</span><strong><?= (int)$statusCount['draft'] ?></strong></div>
  <div><span>Đã gửi</span><strong><?= (int)$statusCount['notified'] ?></strong></div>
  <div><span>Phê duyệt</span><strong><?= (int)$statusCount['approved'] ?></strong></div>
  <div><span>Đã thanh toán</span><strong><?= (int)$statusCount['paid'] ?></strong></div>
</section>

<section class="card payroll-wide-card">
  <div class="card-head">
    <div><h2>Danh sách bảng lương</h2><p class="muted">Không gian rộng hơn để nhìn rõ từng nhân sự, số tiền và trạng thái xử lý.</p></div>
    <button class="btn btn-soft" onclick="openModal('payrollModal')">+ Tạo mới</button>
  </div>

  <div class="payroll-v2-table">
    <div class="payroll-v2-head">
      <span>Nhân sự</span>
      <span>Lương</span>
      <span>Công / KPI</span>
      <span>Khấu trừ</span>
      <span>Thực nhận</span>
      <span>Trạng thái</span>
      <span>Action</span>
    </div>
    <?php foreach($rows as $r): 
      $status=$r['status'] ?: 'draft';
      if(!array_key_exists($status,$payrollStatuses)) $status='draft';
      $deduction=($r['bhxh']??0)+($r['tncn']??0)+($r['other_deduction']??0);
    ?>
      <div class="payroll-v2-row">
        <div class="payroll-employee-cell">
          <?= avatar_html(['name'=>$r['user_name'],'avatar'=>$r['user_avatar']],true) ?>
          <div><b><?= e($r['user_name']) ?></b><small><?= e($r['user_role']) ?> · <?= e($r['month']) ?></small></div>
        </div>
        <div><b><?= money($r['base_salary']) ?></b><small>Base salary</small></div>
        <div><b><?= e($r['actual_days'] ?? 0) ?> ngày · <?= e($r['kpi_percent']) ?>%</b><small><?= e($r['actual_hours']) ?>/<?= e($r['standard_hours']) ?>h · Project <?= e($r['project_completed'] ?? 0) ?></small></div>
        <div><b><?= money($deduction) ?></b><small>BHXH/TNCN/Khác</small></div>
        <div><b><?= money($r['net_salary'] ?: $r['total_salary']) ?></b><small><?= e($r['note']) ?></small></div>
        <div>
          <span class="payroll-status-pill <?= payroll_status_class($status) ?>"><?= e($payrollStatuses[$status]) ?></span>
          <small>NV: <?= e($r['employee_approval_status'] ?: 'pending') ?></small>
        </div>
        <div class="payroll-actions">
          <a class="btn btn-soft" href="app.php?page=payroll_manager&month=<?= e($month) ?>&edit_payroll=<?= $r['id'] ?>">Sửa</a>
          <?php if($status==='draft'): ?><a class="btn btn-soft" href="app.php?page=payroll_manager&month=<?= e($month) ?>&status_payroll=<?= $r['id'] ?>&to=notified">Gửi</a><?php endif; ?>
          <?php if($status==='notified'): ?><a class="btn btn-soft" href="app.php?page=payroll_manager&month=<?= e($month) ?>&status_payroll=<?= $r['id'] ?>&to=approved">Duyệt</a><?php endif; ?>
          <?php if($status==='approved'): ?><a class="btn btn-green" href="app.php?page=payroll_manager&month=<?= e($month) ?>&status_payroll=<?= $r['id'] ?>&to=paid">Paid</a><?php endif; ?>
          <?php if(user_is_admin()): ?><a class="btn btn-soft danger-link" onclick="return confirm('Xóa bảng lương này?')" href="app.php?page=payroll_manager&month=<?= e($month) ?>&delete_payroll=<?= $r['id'] ?>">Xóa</a><?php endif; ?>
        </div>
      </div>
    <?php endforeach; ?>
    <?php if(empty($rows)): ?><div class="payroll-empty muted">Chưa có bảng lương tháng này.</div><?php endif; ?>
  </div>
</section>

<div class="modal-backdrop <?= $editPayroll?'active':'' ?>" id="payrollModal">
  <div class="modal-panel payroll-edit-modal">
    <button class="modal-close" onclick="closeModal('payrollModal')">×</button>
    <div class="modal-title-row">
      <div>
        <span class="eyebrow">Payroll Editor</span>
        <h2><?= $editPayroll?'Chỉnh sửa bảng lương':'Tạo bảng lương mới' ?></h2>
      </div>
    </div>
    <form method="post">
      <input type="hidden" name="save_payroll_manager" value="1">
      <input type="hidden" name="payroll_id" value="<?= e($editPayroll['id']??'') ?>">
      <div class="form-row">
        <div><label>Nhân sự</label><select name="user_id"><?php foreach($users as $u): ?><option value="<?= $u['id'] ?>" <?= ($editPayroll['user_id']??'')==$u['id']?'selected':'' ?>><?= e($u['name'].' — '.$u['role']) ?></option><?php endforeach; ?></select></div>
        <div><label>Tháng</label><input type="month" name="month" value="<?= e($editPayroll['salary_month']??$editPayroll['month']??$month) ?>"></div>
      </div>
      <div class="form-row">
        <div><label>Lương cứng</label><input class="money-input" inputmode="numeric" name="base_salary" value="<?= e(number_format((float)($editPayroll['base_salary']??0),0,',','.')) ?>"></div>
        <div><label>Status</label><select name="status"><?php foreach($payrollStatuses as $k=>$v): ?><option value="<?= e($k) ?>" <?= ($editPayroll['status']??'draft')===$k?'selected':'' ?>><?= e($v) ?></option><?php endforeach; ?></select></div>
      </div>
      <div class="form-row">
        <div><label>Ngày công thực tế</label><input type="number" step="0.5" name="actual_days" value="<?= e($editPayroll['actual_days']??22) ?>"><small class="muted">80% lương = lương cứng × ngày công / 22</small></div>
        <div><label>KPI %</label><input type="number" name="kpi_percent" value="<?= e($editPayroll['kpi_percent']??0) ?>"><small class="muted">20% còn lại theo KPI</small></div>
      </div>
      <div class="form-row">
        <div><label>Commission/Bonus</label><input class="money-input" inputmode="numeric" name="commission" value="<?= e(number_format((float)($editPayroll['commission']??0),0,',','.')) ?>"></div>
        <div><label>BHXH/BHYT</label><input class="money-input" inputmode="numeric" name="bhxh" value="<?= e(number_format((float)($editPayroll['bhxh']??0),0,',','.')) ?>"></div>
      </div>
      <div class="form-row">
        <div><label>TNCN</label><input class="money-input" inputmode="numeric" name="tncn" value="<?= e(number_format((float)($editPayroll['tncn']??0),0,',','.')) ?>"></div>
        <div><label>Khấu trừ khác</label><input class="money-input" inputmode="numeric" name="other_deduction" value="<?= e(number_format((float)($editPayroll['other_deduction']??0),0,',','.')) ?>"></div>
      </div>
      <label>Note</label><textarea name="note"><?= e($editPayroll['note']??'') ?></textarea>
      <button class="primary">Lưu bảng lương</button>
    </form>
  </div>
</div>
<?php if($editPayroll): ?><script>document.addEventListener('DOMContentLoaded',()=>openModal('payrollModal'));</script><?php endif; ?>
