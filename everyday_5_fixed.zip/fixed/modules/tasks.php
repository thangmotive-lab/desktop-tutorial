<?php
$me=current_user();

if(isset($_POST['task_delight_v2_ajax'])){
  header('Content-Type: application/json; charset=utf-8');
  $tid=(int)($_POST['task_id'] ?? 0);
  if($tid>0){
    try{
      $pdo->prepare("UPDATE tasks SET status='Done', completed_at=NOW(), updated_at=NOW() WHERE id=? AND (assignee_id=? OR created_by=? OR ?=1)")
        ->execute([$tid,$me['id'],$me['id'],user_is_admin()?1:0]);
      log_activity($pdo,'complete','task',$tid,'Task Delight V2 complete');
      echo json_encode(['ok'=>true,'task_id'=>$tid]);
      exit;
    }catch(Exception $e){
      echo json_encode(['ok'=>false,'error'=>$e->getMessage()]);
      exit;
    }
  }
  echo json_encode(['ok'=>false,'error'=>'missing_task_id']);
  exit;
}


if(isset($_POST['quick_done_ajax'])){
  header('Content-Type: application/json; charset=utf-8');
  $tid=(int)($_POST['task_id'] ?? 0);
  if($tid>0){
    $pdo->prepare("UPDATE tasks SET status='Done', completed_at=NOW(), updated_at=NOW() WHERE id=? AND (assignee_id=? OR created_by=? OR ?=1)")
      ->execute([$tid,$me['id'],$me['id'],user_is_admin()?1:0]);
    log_activity($pdo,'complete','task',$tid,'Quick complete task');
    echo json_encode(['ok'=>true]);
    exit;
  }
  echo json_encode(['ok'=>false]);
  exit;
}

$statuses=['Todo','Doing','Review','Waiting Approval','Done'];
$priorities=['Khẩn cấp làm ngay','Làm ngay','Quan trọng','Lúc nào làm cũng được'];

// V6: personal priority ordering for My Tasks. Safe no-op if the column already exists.
try { $pdo->exec("ALTER TABLE tasks ADD COLUMN priority_order INT NULL"); } catch (Exception $e) {}
$hasPriorityOrder = false;
try { $hasPriorityOrder = (bool)$pdo->query("SHOW COLUMNS FROM tasks LIKE 'priority_order'")->fetch(); } catch (Exception $e) { $hasPriorityOrder = false; }

if(isset($_POST['priority_update_ajax'])){
  header('Content-Type: application/json; charset=utf-8');
  $tid=(int)($_POST['task_id'] ?? 0);
  $priority=normalize_priority($_POST['priority'] ?? '');
  if($tid>0){
    try{
      $st=$pdo->prepare('SELECT id, assignee_id, created_by FROM tasks WHERE id=? LIMIT 1');
      $st->execute([$tid]);
      $task=$st->fetch();
      if($task && ((int)$task['assignee_id']===(int)$me['id'] || (int)$task['created_by']===(int)$me['id'] || user_is_admin())){
        $pdo->prepare('UPDATE tasks SET priority=?, updated_at=NOW() WHERE id=?')->execute([$priority,$tid]);
        log_activity($pdo,'priority','task',$tid,'Update task priority to '.$priority);
        echo json_encode(['ok'=>true,'priority'=>$priority,'class'=>badge_class($priority)]);
        exit;
      }
      echo json_encode(['ok'=>false,'error'=>'permission_denied']);
      exit;
    }catch(Exception $e){ echo json_encode(['ok'=>false,'error'=>$e->getMessage()]); exit; }
  }
  echo json_encode(['ok'=>false,'error'=>'missing_task_id']);
  exit;
}

if(isset($_POST['priority_reorder_ajax'])){
  header('Content-Type: application/json; charset=utf-8');
  if(empty($hasPriorityOrder)){ echo json_encode(['ok'=>false,'error'=>'priority_order_column_missing']); exit; }
  $idsRaw=(string)($_POST['ordered_ids'] ?? '');
  $ids=array_values(array_filter(array_map('intval', explode(',', $idsRaw))));
  if($ids){
    try{
      $pdo->beginTransaction();
      $order=10;
      $st=$pdo->prepare('UPDATE tasks SET priority_order=?, updated_at=NOW() WHERE id=? AND (assignee_id=? OR created_by=? OR ?=1)');
      foreach($ids as $id){
        $st->execute([$order,$id,$me['id'],$me['id'],user_is_admin()?1:0]);
        $order+=10;
      }
      $pdo->commit();
      echo json_encode(['ok'=>true]);
      exit;
    }catch(Exception $e){ if($pdo->inTransaction()) $pdo->rollBack(); echo json_encode(['ok'=>false,'error'=>$e->getMessage()]); exit; }
  }
  echo json_encode(['ok'=>false,'error'=>'missing_order']);
  exit;
}

$tab=$_GET['tab'] ?? 'active';
if(!in_array($tab,['active','due','done','delegated'])) $tab='active';
$q=trim($_GET['q'] ?? '');
$projectFilter=(int)($_GET['project_id'] ?? 0);
$statusFilter=$_GET['status'] ?? '';

function notify_task_owner($pdo,$task,$title,$message){
  $ids=array_unique(array_filter([(int)($task['created_by']??0),(int)($task['assignee_id']??0)]));
  foreach($ids as $uid){ create_notification($pdo,$uid,$title,$message,'task','app.php?page=tasks&focus='.$task['id']); }
}

if(isset($_GET['advance'])){
  $tid=(int)$_GET['advance'];
  $stmt=$pdo->prepare('SELECT * FROM tasks WHERE id=?');$stmt->execute([$tid]);$task=$stmt->fetch();
  if($task){
    $next=task_status_next($task['status']);
    if($next==='Waiting Approval'){
      $pdo->prepare('UPDATE tasks SET status=?, submitted_at=NOW() WHERE id=?')->execute([$next,$tid]);
    } elseif($next==='Done'){
      if(user_is_admin() || (int)$task['created_by']===(int)$me['id']){
        $pdo->prepare('UPDATE tasks SET status=?, approved_by=?, approved_at=NOW(), completed_at=NOW() WHERE id=?')->execute([$next,$me['id'],$tid]);
      } else {
        $next='Waiting Approval';
        $pdo->prepare('UPDATE tasks SET status=?, submitted_at=NOW() WHERE id=?')->execute([$next,$tid]);
      }
    } else {
      $pdo->prepare('UPDATE tasks SET status=? WHERE id=?')->execute([$next,$tid]);
    }
    notify_task_owner($pdo,$task,'Task cập nhật trạng thái',$task['title'].' → '.$next);
    log_activity($pdo,'status','task',$tid,'Update task status to '.$next);
  }
  redirect('app.php?page=tasks&tab='.$tab.'&amazing=1');
}

if(isset($_GET['approve'])){
  $tid=(int)$_GET['approve'];
  $stmt=$pdo->prepare('SELECT * FROM tasks WHERE id=?');$stmt->execute([$tid]);$task=$stmt->fetch();
  if($task && (user_is_admin() || (int)$task['created_by']===(int)$me['id'])){
    $pdo->prepare("UPDATE tasks SET status='Done', approved_by=?, approved_at=NOW(), completed_at=NOW() WHERE id=?")->execute([$me['id'],$tid]);
    notify_task_owner($pdo,$task,'Task đã được duyệt',$task['title'].' đã chuyển Done');
    log_activity($pdo,'approve','task',$tid,'Duyệt task');
  }
  redirect('app.php?page=tasks&tab=approval&yay=1');
}

if(isset($_GET['request_help'])){
  $tid=(int)$_GET['request_help'];
  $stmt=$pdo->prepare('SELECT * FROM tasks WHERE id=?');$stmt->execute([$tid]);$task=$stmt->fetch();
  if($task){
    $pdo->prepare('UPDATE tasks SET need_support=1, help_requested=1, help_requested_at=NOW() WHERE id=?')->execute([$tid]);
    notify_task_owner($pdo,$task,'Task cần hỗ trợ','Task cần hỗ trợ: '.$task['title']);
    log_activity($pdo,'request_help','task',$tid,'Yêu cầu hỗ trợ');
  }
  redirect('app.php?page=tasks&tab='.$tab);
}

if(isset($_GET['clear_help'])){
  $tid=(int)$_GET['clear_help'];
  $pdo->prepare('UPDATE tasks SET need_support=0, help_requested=0 WHERE id=?')->execute([$tid]);
  redirect('app.php?page=tasks&tab='.$tab);
}

if(isset($_POST['add_comment'])){
  $tid=(int)$_POST['task_id'];
  $comment=trim($_POST['comment']);
  if($comment!==''){
    $pdo->prepare('INSERT INTO task_comments(task_id,user_id,comment) VALUES(?,?,?)')->execute([$tid,$me['id'],$comment]);
    $cid=$pdo->lastInsertId();
    if(function_exists('create_task_mentions_from_comment')){
      create_task_mentions_from_comment($pdo,$tid,$cid,$comment,$me['id']);
    }
    log_activity($pdo,'comment','task',$tid,'Comment task');
  }
  redirect('app.php?page=tasks&focus='.$tid);
}

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['save_task'])){
  if(!empty($_POST['task_id'])){
    $stmt=$pdo->prepare('UPDATE tasks SET project_id=?, title=?, assignee_id=?, priority=?, start_date=?, deadline=?, status=?, phase=?, brief=?, deliverable=?, deliverable_type=?, deliverable_count=?, reference_link=?, approver=?, file_link=?, product_quantity=?, product_unit_price=? WHERE id=?');
    $stmt->execute([$_POST['project_id'],$_POST['title'],$_POST['assignee_id'],normalize_priority($_POST['priority'] ?? ''),$_POST['start_date'],$_POST['deadline'],$_POST['status'],$_POST['phase'],$_POST['brief'],$_POST['deliverable'],$_POST['deliverable_type'],$_POST['deliverable_count']?:1,$_POST['reference_link'],$_POST['approver'],$_POST['file_link'],$_POST['product_quantity']?:0,$_POST['product_unit_price']?:0,$_POST['task_id']]);
    $tid=(int)$_POST['task_id'];
  } else {
    $stmt=$pdo->prepare('INSERT INTO tasks(project_id,title,assignee_id,priority,start_date,deadline,status,phase,brief,deliverable,deliverable_type,deliverable_count,reference_link,approver,file_link,created_by,product_quantity,product_unit_price) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
    $stmt->execute([$_POST['project_id'],$_POST['title'],$_POST['assignee_id'],normalize_priority($_POST['priority'] ?? ''),$_POST['start_date'],$_POST['deadline'],$_POST['status'],$_POST['phase'],$_POST['brief'],$_POST['deliverable'],$_POST['deliverable_type'],$_POST['deliverable_count']?:1,$_POST['reference_link'],$_POST['approver'],$_POST['file_link'],$me['id'],$_POST['product_quantity']?:0,$_POST['product_unit_price']?:0]);
    $tid=$pdo->lastInsertId();
    create_notification($pdo,$_POST['assignee_id'],'Task mới','Bạn được giao task: '.$_POST['title'],'task','app.php?page=tasks&focus='.$tid);
  }
  log_activity($pdo,'save','task',$tid,'Lưu task '.$_POST['title']);
  redirect('app.php?page=tasks&focus='.$tid);
}

$where=[];$params=[];
if($tab==='active'){ $where[]='t.assignee_id=? AND t.status!="Done"'; $params[]=$me['id']; }
elseif($tab==='due'){ $where[]='t.assignee_id=? AND t.status!="Done" AND t.deadline BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 3 DAY)'; $params[]=$me['id']; }
elseif($tab==='approval'){ $where[]='t.status="Waiting Approval" AND (t.created_by=? OR p.owner_id=? OR ?=1)'; $params[]=$me['id'];$params[]=$me['id'];$params[]=user_is_admin()?1:0; }
elseif($tab==='done'){ $where[]='t.assignee_id=? AND t.status="Done"'; $params[]=$me['id']; }
elseif($tab==='delegated'){ $where[]='t.created_by=?'; $params[]=$me['id']; }
else { $where[]='1=1'; }

if($q!==''){ $where[]='(t.title LIKE ? OR t.brief LIKE ? OR p.name LIKE ? OR u.name LIKE ?)'; array_push($params,"%$q%","%$q%","%$q%","%$q%");}
if($projectFilter){ $where[]='t.project_id=?'; $params[]=$projectFilter; }
if($statusFilter){ $where[]='t.status=?'; $params[]=$statusFilter; }

$whereSql = implode(' AND ', $where);
$sql = "SELECT t.*, p.name project_name, p.owner_id project_owner_id, u.name assignee_name, u.avatar assignee_avatar,
  (SELECT COUNT(*) FROM task_comments c WHERE c.task_id=t.id) comment_count
  FROM tasks t
  LEFT JOIN projects p ON p.id=t.project_id
  LEFT JOIN users u ON u.id=t.assignee_id
  WHERE $whereSql
  ORDER BY
    CASE WHEN t.need_support=1 OR t.help_requested=1 THEN 0 ELSE 1 END,
    ".($hasPriorityOrder ? "CASE WHEN t.priority_order IS NULL THEN 999999 ELSE t.priority_order END ASC," : "0 ASC,")."
    CASE
      WHEN t.priority='Khẩn cấp làm ngay' THEN 1
      WHEN t.priority='Làm ngay' THEN 2
      WHEN t.priority='Quan trọng' THEN 3
      ELSE 4
    END ASC,
    t.deadline ASC,
    t.id DESC";
$stmt=$pdo->prepare($sql);$stmt->execute($params);$tasks=$stmt->fetchAll();

$projects=$pdo->query('SELECT id,name FROM projects ORDER BY name')->fetchAll();
$users=$pdo->query('SELECT id,name,avatar FROM users ORDER BY name')->fetchAll();
$focus=(int)($_GET['focus']??0);
$focusTask=null;$comments=[];
if($focus){
  $st=$pdo->prepare('SELECT t.*,p.name project_name,u.name assignee_name,u.avatar assignee_avatar FROM tasks t LEFT JOIN projects p ON p.id=t.project_id LEFT JOIN users u ON u.id=t.assignee_id WHERE t.id=?');
  $st->execute([$focus]);$focusTask=$st->fetch();
  if($focusTask){
    $cs=$pdo->prepare('SELECT c.*,u.name user_name,u.avatar user_avatar FROM task_comments c LEFT JOIN users u ON u.id=c.user_id WHERE c.task_id=? ORDER BY c.id ASC');
    $cs->execute([$focus]);$comments=$cs->fetchAll();
  }
}
$tabs=['active'=>'Đang làm','due'=>'Sắp làm','done'=>'Hoàn thành','delegated'=>'Tôi giao'];
?>
<?php if(!empty($_GET['yay'])): ?><div class="yay-toast">YAY-ME ✨</div><?php endif; ?>

<section class="card workspace-detail-card task-workspace-head">
  <div class="card-head">
    <div><span class="eyebrow">My Tasks V2</span><h2>Tasks Workspace</h2><p class="muted">Todo → Doing → Review → Approval → Done</p></div>
    <button class="primary icon-action" onclick="openSlideDrawer('taskDrawer')" title="Tạo task">＋</button>
  </div>
  <div class="tabs">
    <?php foreach($tabs as $key=>$label): ?><a class="<?= $tab===$key?'active':'' ?>" href="app.php?page=tasks&tab=<?= $key ?>"><?= e($label) ?></a><?php endforeach; ?>
  </div>
</section>

<section class="card dense-card workspace-detail-card">
<table class="dense-table workspace-table">
<thead><tr><th>Task</th><th>Project</th><th>Assignee</th><th>Priority</th><th>Deadline</th><th>Status</th><th>Deliverable</th><th>Flags</th><th>Action</th></tr></thead>
<tbody>
<?php foreach($tasks as $t): ?>
<tr class="<?= $focus===$t['id']?'active-row':'' ?>" data-task-id="<?= $t['id'] ?>">
  <td class="task-name-cell <?= $t['status']==='Done'?'task-is-done':'' ?>">
    <?php if($t['status']!=='Done'): ?><a class="task-check js-task-delight-done js-quick-done" title="Hoàn thành" href="app.php?page=tasks&tab=<?= e($tab) ?>&advance=<?= $t['id'] ?>" data-task-id="<?= $t['id'] ?>">✓</a><?php else: ?><span class="task-check done">✓</span><?php endif; ?>
    <div><button type="button" class="task-title-link task-detail-open" data-task-id="<?= $t['id'] ?>"><b><?= e($t['title']) ?></b></button><br><span class="muted"><?= e(mb_substr($t['brief']??'',0,90)) ?></span></div>
  </td>
  <td><?php if($t['project_id']): ?><a class="project-link" href="app.php?page=project_detail&id=<?= $t['project_id'] ?>"><?= e($t['project_name']) ?></a><?php else: ?><span class="muted">Task cá nhân</span><?php endif; ?><br><span class="muted"><?= e($t['phase']) ?></span></td>
  <td><span class="user-chip"><?= avatar_html(['name'=>$t['assignee_name'],'avatar'=>$t['assignee_avatar']],true) ?><?= e($t['assignee_name']) ?></span></td>
  <td class="priority-edit-cell">
    <select class="priority-inline-select <?= badge_class($t['priority']) ?>" data-task-id="<?= $t['id'] ?>" title="Đổi priority">
      <?php foreach(priority_options() as $pv=>$pl): ?><option value="<?= e($pv) ?>" <?= normalize_priority($t['priority']??'')===$pv?'selected':'' ?>><?= e($pl) ?></option><?php endforeach; ?>
    </select>
  </td>
  <td><?= e($t['deadline']) ?></td>
  <td><span class="badge <?= badge_class($t['status']) ?>"><?= e($t['status']) ?></span></td>
  <td><?= e($t['deliverable_type']) ?> <?= (int)$t['deliverable_count'] ? '× '.(int)$t['deliverable_count'] : '' ?></td>
  <td><?php if($t['need_support'] || $t['help_requested']): ?><span class="support-pill active">🆘</span><?php endif; ?> <?php if($t['comment_count']): ?><span class="badge purple">💬 <?= (int)$t['comment_count'] ?></span><?php endif; ?></td>
  <td class="actions icon-actions">
    <button type="button" class="btn btn-soft icon-action task-move-up" title="Đưa lên">↑</button>
    <button type="button" class="btn btn-soft icon-action task-move-down" title="Đưa xuống">↓</button>
    <button type="button" class="btn btn-soft icon-action task-detail-open" data-task-id="<?= $t['id'] ?>" title="Xem chi tiết">○</button>
    <a class="btn btn-soft icon-action" title="Mở trang chi tiết" href="app.php?page=task_detail&id=<?= $t['id'] ?>">↗</a>
    <?php if($t['status']==='Waiting Approval' && (user_is_admin() || (int)$t['created_by']===(int)$me['id'])): ?><a class="btn btn-coral icon-action" title="Duyệt" href="app.php?page=tasks&tab=approval&approve=<?= $t['id'] ?>">✓</a><?php endif; ?>
    <?php if(!($t['need_support']||$t['help_requested'])): ?><a class="btn btn-soft icon-action" title="Cần hỗ trợ" href="app.php?page=tasks&tab=<?= e($tab) ?>&request_help=<?= $t['id'] ?>">!</a><?php else: ?><a class="btn btn-soft icon-action" title="Clear hỗ trợ" href="app.php?page=tasks&tab=<?= e($tab) ?>&clear_help=<?= $t['id'] ?>">×</a><?php endif; ?>
  </td>
</tr>
<?php endforeach; ?>
<?php if(empty($tasks)): ?><tr><td colspan="9" class="muted">Không có task.</td></tr><?php endif; ?>
</tbody></table>
</section>

<?php if($focusTask): ?>
<div class="modal-backdrop active" id="taskDetailModal"><div class="modal-panel task-detail-modal">
  <button class="modal-close" onclick="location.href='app.php?page=tasks&tab=<?= e($tab) ?>'">×</button><div class="card-head"><div><span class="eyebrow">Task Detail</span><h2><?= e($focusTask['title']) ?></h2><p class="muted"><?= e($focusTask['project_name']) ?> · Deadline: <?= e($focusTask['deadline'] ?: 'Chưa có') ?> · <?= e($focusTask['status']) ?></p></div><span class="badge <?= badge_class($focusTask['status']) ?>"><?= e($focusTask['status']) ?></span></div>
  <div class="task-detail-meta">
    <div><span>Project</span><b><?php if($focusTask['project_id']): ?><a href="app.php?page=project_detail&id=<?= $focusTask['project_id'] ?>"><?= e($focusTask['project_name']) ?></a><?php else: ?>Task cá nhân<?php endif; ?></b></div>
    <div><span>Assignee</span><b><?= e($focusTask['assignee_name'] ?: 'Chưa giao') ?></b></div>
    <div><span>Priority</span><b><?= e($focusTask['priority']) ?></b></div>
    <div><span>Start</span><b><?= e($focusTask['start_date'] ?: '-') ?></b></div>
    <div><span>Deadline</span><b><?= e($focusTask['deadline'] ?: 'Chưa có') ?></b></div>
    <div><span>Phase</span><b><?= e($focusTask['phase'] ?: '-') ?></b></div>
    <div><span>Deliverable</span><b><?= e($focusTask['deliverable_type']) ?> <?= (int)$focusTask['deliverable_count'] ? '× '.(int)$focusTask['deliverable_count'] : '' ?></b></div>
    <div><span>Status</span><b><?= e($focusTask['status']) ?></b></div>
  </div>
  <h3>Brief</h3>
  <p><?= nl2br(e($focusTask['brief'])) ?></p>
  <?php if(!empty($focusTask['deliverable']) || !empty($focusTask['reference_link']) || !empty($focusTask['file_link'])): ?>
    <div class="task-detail-extra">
      <?php if(!empty($focusTask['deliverable'])): ?><p><b>Deliverable note:</b> <?= e($focusTask['deliverable']) ?></p><?php endif; ?>
      <?php if(!empty($focusTask['reference_link'])): ?><p><b>Reference:</b> <a href="<?= e($focusTask['reference_link']) ?>" target="_blank">Mở reference</a></p><?php endif; ?>
      <?php if(!empty($focusTask['file_link'])): ?><p><b>File:</b> <a href="<?= e($focusTask['file_link']) ?>" target="_blank">Mở file</a></p><?php endif; ?>
    </div>
  <?php endif; ?>
  <div class="task-comment-list">
    <?php foreach($comments as $c): ?><div class="task-comment"><?= avatar_html(['name'=>$c['user_name'],'avatar'=>$c['user_avatar']],true) ?><div><b><?= e($c['user_name']) ?></b><span><?= e($c['created_at']) ?></span><p><?= nl2br(e($c['comment'])) ?></p></div></div><?php endforeach; ?>
  </div>
  <form method="post" class="comment-form"><input type="hidden" name="task_id" value="<?= $focus ?>"><textarea name="comment" placeholder="Comment, dùng @Tên để mention..."></textarea><button class="primary" name="add_comment" value="1">Gửi comment</button></form>
</div></div>
<?php endif; ?>

<div id="drawerBackdrop" class="drawer-backdrop" onclick="closeSlideDrawer('taskDrawer')"></div>
<div class="slide-drawer" id="taskDrawer">
  <div class="drawer-form-header"><div><span class="eyebrow">Task V2</span><h2>Tạo / sửa task</h2></div><button class="drawer-close-x" onclick="closeSlideDrawer('taskDrawer')" type="button">×</button></div>
  <form method="post">
    <input type="hidden" name="save_task" value="1">
    <label>Project</label><select name="project_id"><?php foreach($projects as $p): ?><option value="<?= $p['id'] ?>"><?= e($p['name']) ?></option><?php endforeach; ?></select>
    <label>Title</label><input name="title" required>
    <label>Assignee</label><select name="assignee_id"><?php foreach($users as $u): ?><option value="<?= $u['id'] ?>"><?= e($u['name']) ?></option><?php endforeach; ?></select>
    <div class="form-row"><div><label>Priority</label><select name="priority"><?php foreach(priority_options() as $pv=>$pl): ?><option value="<?= e($pv) ?>"><?= e($pl) ?></option><?php endforeach; ?></select></div><div><label>Status</label><select name="status"><?php foreach($statuses as $s): ?><option><?= e($s) ?></option><?php endforeach; ?></select></div></div>
    <div class="form-row"><div><label>Start</label><input name="start_date" type="date" value="<?= date('Y-m-d') ?>"></div><div><label>Deadline</label><input name="deadline" type="date"></div></div>
    <label>Phase</label><input name="phase" value="General">
    <label>Brief</label><textarea name="brief"></textarea>
    <div class="form-row"><div><label>Deliverable Type</label><input name="deliverable_type" placeholder="Social Post, Video, Photo..."></div><div><label>Deliverable Count</label><input name="deliverable_count" type="number" value="1"></div></div>
    <label>Deliverable Note</label><input name="deliverable">
    <label>Reference link</label><input name="reference_link">
    <label>File link</label><input name="file_link">
    <label>Approver</label><input name="approver">
    <input type="hidden" name="product_quantity" value="0"><input type="hidden" name="product_unit_price" value="0">
    <button class="primary">Lưu task</button>
  </form>
</div>

<script>
document.addEventListener('click',function(e){
  const btn=e.target.closest('.task-detail-open');
  if(!btn) return;
  const id=btn.dataset.taskId;
  if(id) location.href='app.php?page=tasks&tab=<?= e($tab) ?>&focus='+encodeURIComponent(id);
});

(function(){
  function postTaskOrder(){
    const rows=[...document.querySelectorAll('.dense-table tbody tr[data-task-id]')];
    const ids=rows.map(r=>r.dataset.taskId).filter(Boolean).join(',');
    if(!ids) return;
    fetch('app.php?page=tasks&tab=<?= e($tab) ?>',{
      method:'POST',
      headers:{'Content-Type':'application/x-www-form-urlencoded'},
      body:'priority_reorder_ajax=1&ordered_ids='+encodeURIComponent(ids)
    }).then(r=>r.json()).then(data=>{
      if(!data || !data.ok) throw new Error(data && data.error ? data.error : 'unknown');
    }).catch(err=>{ console.error(err); alert('Chưa lưu được thứ tự task. Vui lòng tải lại trang và thử lại.'); });
  }
  function moveRow(btn,dir){
    const row=btn.closest('tr[data-task-id]'); if(!row) return;
    const target=dir<0?row.previousElementSibling:row.nextElementSibling;
    if(!target || !target.matches('tr[data-task-id]')) return;
    if(dir<0) row.parentNode.insertBefore(row,target); else row.parentNode.insertBefore(target,row);
    row.classList.add('priority-order-saved'); setTimeout(()=>row.classList.remove('priority-order-saved'),520);
    postTaskOrder();
  }
  document.addEventListener('click',function(e){
    const up=e.target.closest('.task-move-up'); if(up){ e.preventDefault(); moveRow(up,-1); return; }
    const down=e.target.closest('.task-move-down'); if(down){ e.preventDefault(); moveRow(down,1); return; }
  });
  document.addEventListener('change',function(e){
    const sel=e.target.closest('.priority-inline-select'); if(!sel) return;
    const id=sel.dataset.taskId; const value=sel.value;
    sel.classList.add('saving');
    fetch('app.php?page=tasks&tab=<?= e($tab) ?>',{
      method:'POST',
      headers:{'Content-Type':'application/x-www-form-urlencoded'},
      body:'priority_update_ajax=1&task_id='+encodeURIComponent(id)+'&priority='+encodeURIComponent(value)
    }).then(r=>r.json()).then(data=>{
      if(!data || !data.ok) throw new Error(data && data.error ? data.error : 'unknown');
      sel.className='priority-inline-select '+(data.class||'purple');
      sel.classList.add('saved'); setTimeout(()=>sel.classList.remove('saved'),700);
    }).catch(err=>{ console.error(err); alert('Chưa đổi được priority. Vui lòng thử lại.'); })
      .finally(()=>sel.classList.remove('saving'));
  });
})();
</script>

<script>
window.MOTIVE_USERS = <?= mention_options_json($pdo) ?>;
document.addEventListener('input', function(e){
  if(!e.target.matches('textarea[name="comment"], input[name="comment"]')) return;
  const val=e.target.value;
  const at=val.lastIndexOf('@');
  let box=document.getElementById('mentionSuggestBox');
  if(!box){
    box=document.createElement('div'); box.id='mentionSuggestBox'; box.className='mention-suggest-box'; document.body.appendChild(box);
  }
  if(at<0){ box.style.display='none'; return; }
  const query=val.slice(at+1).toLowerCase().trim();
  if(query.length<1){ box.style.display='none'; return; }
  const users=(window.MOTIVE_USERS||[]).filter(u=>u.name.toLowerCase().includes(query) || (u.email||'').toLowerCase().includes(query)).slice(0,6);
  if(!users.length){ box.style.display='none'; return; }
  const rect=e.target.getBoundingClientRect();
  box.style.left=(rect.left+window.scrollX)+'px';
  box.style.top=(rect.bottom+window.scrollY+6)+'px';
  box.innerHTML=users.map(u=>`<button type="button" data-name="${u.name}">@${u.name}</button>`).join('');
  box.style.display='block';
  box.querySelectorAll('button').forEach(btn=>{
    btn.onclick=function(){
      const before=val.slice(0,at);
      e.target.value=before+'@'+this.dataset.name+' ';
      box.style.display='none';
      e.target.focus();
    }
  });
});
document.addEventListener('click',function(e){
  const box=document.getElementById('mentionSuggestBox');
  if(box && !e.target.closest('#mentionSuggestBox') && !e.target.matches('textarea[name="comment"], input[name="comment"]')) box.style.display='none';
});
</script>
