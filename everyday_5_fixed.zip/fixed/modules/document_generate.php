<?php
require __DIR__ . '/doc_generate.php';
