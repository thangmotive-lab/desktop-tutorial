<?php
if(!can_view_business_finance()) die('Bạn không có quyền xem hợp đồng.');
$month=$_GET['month'] ?? date('Y-m');
$status=$_GET['status'] ?? '';
$statuses=['Đang soạn','Đã ký','Đang thực hiện','Nghiệm thu','Thanh lý','Hoàn thành'];

if(isset($_GET['delete'])){
  $id=(int)$_GET['delete'];
  $pdo->prepare('DELETE FROM contracts WHERE id=?')->execute([$id]);
  redirect('app.php?page=contracts&month='.$month);
}
if(isset($_GET['duplicate'])){
  $id=(int)$_GET['duplicate'];
  $st=$pdo->prepare('SELECT * FROM contracts WHERE id=?');$st->execute([$id]);$c=$st->fetch();
  if($c){
    $code=next_auto_code($pdo,'HD','contracts','contract_code');
    $pdo->prepare('INSERT INTO contracts(contract_code,quotation_id,client_name,total_value,signed_date,start_date,end_date,status,quote_owner_id,contract_owner_id,account_manager_id,commission_rate,contract_month) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)')
      ->execute([$code,$c['quotation_id'],$c['client_name'].' Copy',$c['total_value'],$c['signed_date'],$c['start_date'],$c['end_date'],'Đang soạn',$c['quote_owner_id'],$c['contract_owner_id'],$c['account_manager_id'],$c['commission_rate'],$c['contract_month']]);
  }
  redirect('app.php?page=contracts&month='.$month);
}
if($_SERVER['REQUEST_METHOD']==='POST'){
  if(!empty($_POST['contract_id'])){
    $pdo->prepare('UPDATE contracts SET contract_code=?,client_name=?,total_value=?,signed_date=?,start_date=?,end_date=?,status=?,contract_owner_id=?,account_manager_id=?,commission_rate=? WHERE id=?')
      ->execute([$_POST['contract_code'],$_POST['client_name'],$_POST['total_value']?:0,$_POST['signed_date']?:null,$_POST['start_date']?:null,$_POST['end_date']?:null,$_POST['status'],$_POST['contract_owner_id']?:null,$_POST['account_manager_id']?:null,$_POST['commission_rate']?:2,$_POST['contract_id']]);
  } else {
    $code=$_POST['contract_code'] ?: next_auto_code($pdo,'HD','contracts','contract_code');
    $pdo->prepare('INSERT INTO contracts(contract_code,client_name,total_value,signed_date,start_date,end_date,status,contract_owner_id,account_manager_id,commission_rate,contract_month) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
      ->execute([$code,$_POST['client_name'],$_POST['total_value']?:0,$_POST['signed_date']?:null,$_POST['start_date']?:null,$_POST['end_date']?:null,$_POST['status'],$_POST['contract_owner_id']?:null,$_POST['account_manager_id']?:null,$_POST['commission_rate']?:2,date('Y-m',strtotime($_POST['signed_date']?:date('Y-m-d')))]);
  }
  redirect('app.php?page=contracts&month='.$month);
}
$edit=null;
if(isset($_GET['edit'])){
  $st=$pdo->prepare('SELECT * FROM contracts WHERE id=?');$st->execute([(int)$_GET['edit']]);$edit=$st->fetch();
}
$where=[];$params=[];
if($month){$where[]="DATE_FORMAT(COALESCE(c.signed_date,c.created_at),'%Y-%m')=?";$params[]=$month;}
if($status){$where[]="c.status=?";$params[]=$status;}
$sql='SELECT c.*, q.quote_code, qo.name quote_owner_name, co.name account_manager_name 
FROM contracts c 
LEFT JOIN quotations q ON q.id=c.quotation_id
LEFT JOIN users qo ON qo.id=c.quote_owner_id 
LEFT JOIN users co ON co.id=COALESCE(c.account_manager_id,c.contract_owner_id)';
if($where) $sql.=' WHERE '.implode(' AND ',$where);
$sql.=' ORDER BY c.id DESC';
$stmt=$pdo->prepare($sql);$stmt->execute($params);$rows=$stmt->fetchAll();
$users=$pdo->query('SELECT id,name FROM users ORDER BY name')->fetchAll();
$total=0;foreach($rows as $r)$total+=(float)$r['total_value'];
?>
<section class="card">
  <div class="card-head"><div><span class="eyebrow">Contract V2</span><h2>Hợp đồng theo tháng</h2><p class="muted">Chỉ tạo hợp đồng khi khách đã đồng ý/chốt. Không đổ toàn bộ báo giá sang hợp đồng để tránh rối dữ liệu doanh thu.</p><p class="muted">Tổng giá trị: <b><?= money($total) ?></b></p></div><div><a class="btn btn-soft" href="app.php?page=quotation_list">Tạo từ báo giá đã đồng ý</a> <button class="primary" onclick="openModal('contractModal')">+ Thêm hợp đồng</button></div></div>
  <form method="get" class="asana-toolbar"><input type="hidden" name="page" value="contracts"><input name="month" type="month" value="<?= e($month) ?>"><select name="status"><option value="">Tất cả status</option><?php foreach($statuses as $s): ?><option <?= $status===$s?'selected':'' ?>><?= e($s) ?></option><?php endforeach; ?></select><button class="btn btn-soft">Filter</button></form>
  <table class="dense-table">
    <thead><tr><th>Mã HĐ</th><th>Khách hàng</th><th>Giá trị</th><th>Báo giá</th><th>Người báo giá</th><th>Account</th><th>Ngày ký</th><th>Status</th><th>Action</th></tr></thead>
    <tbody>
    <?php foreach($rows as $r): ?>
      <tr>
        <td><b><?= e($r['contract_code']) ?></b></td><td><?= e($r['client_name']) ?></td><td><?= money($r['total_value']) ?></td><td><?= e($r['quote_code']) ?></td><td><?= e($r['quote_owner_name']) ?></td><td><?= e($r['account_manager_name']) ?></td><td><?= e($r['signed_date']) ?></td><td><span class="badge <?= badge_class($r['status']) ?>"><?= e($r['status']) ?></span></td>
        <td class="actions contract-compact-actions"><a class="btn btn-soft" href="app.php?page=contract_detail&id=<?= $r['id'] ?>">Detail</a><a class="btn btn-soft" href="app.php?page=contracts&month=<?= e($month) ?>&edit=<?= $r['id'] ?>">Edit</a><a class="btn btn-soft" href="app.php?page=contracts&month=<?= e($month) ?>&duplicate=<?= $r['id'] ?>">Nhân đôi</a><a class="btn btn-soft" onclick="return confirm('Xóa hợp đồng?')" href="app.php?page=contracts&month=<?= e($month) ?>&delete=<?= $r['id'] ?>">Xóa</a></td>
      </tr>
    <?php endforeach; ?>
    <?php if(empty($rows)): ?><tr><td colspan="10" class="muted">Không có hợp đồng trong bộ lọc này.</td></tr><?php endif; ?>
    </tbody>
  </table>
</section>
<div class="modal-backdrop <?= $edit?'active':'' ?>" id="contractModal">
  <div class="modal-panel">
    <button class="modal-close" onclick="closeModal('contractModal')">×</button>
    <h2><?= $edit?'Edit hợp đồng':'Thêm hợp đồng' ?></h2>
    <form method="post">
      <input type="hidden" name="contract_id" value="<?= e($edit['id']??'') ?>">
      <label>Mã HĐ</label><input name="contract_code" value="<?= e($edit['contract_code']??next_auto_code($pdo,'HD','contracts','contract_code')) ?>">
      <label>Khách hàng</label><input name="client_name" required value="<?= e($edit['client_name']??'') ?>">
      <label>Giá trị</label><input type="number" name="total_value" value="<?= e($edit['total_value']??0) ?>">
      <div class="form-row-3"><div><label>Ngày ký</label><input type="date" name="signed_date" value="<?= e($edit['signed_date']??date('Y-m-d')) ?>"></div><div><label>Start</label><input type="date" name="start_date" value="<?= e($edit['start_date']??'') ?>"></div><div><label>End</label><input type="date" name="end_date" value="<?= e($edit['end_date']??'') ?>"></div></div>
      <label>Status</label><select name="status"><?php foreach($statuses as $s): ?><option <?= ($edit['status']??'Đang soạn')===$s?'selected':'' ?>><?= e($s) ?></option><?php endforeach; ?></select>
      <div class="form-row"><div><label>Owner</label><select name="contract_owner_id"><option value="">Chọn</option><?php foreach($users as $u): ?><option value="<?= $u['id'] ?>" <?= ($edit['contract_owner_id']??'')==$u['id']?'selected':'' ?>><?= e($u['name']) ?></option><?php endforeach; ?></select></div><div><label>Account Manager</label><select name="account_manager_id"><option value="">Chọn</option><?php foreach($users as $u): ?><option value="<?= $u['id'] ?>" <?= ($edit['account_manager_id']??'')==$u['id']?'selected':'' ?>><?= e($u['name']) ?></option><?php endforeach; ?></select></div></div>
      <label>Commission %</label><input type="number" step="0.1" name="commission_rate" value="<?= e($edit['commission_rate']??2) ?>">
      <button class="primary">Lưu hợp đồng</button>
    </form>
  </div>
</div>
<?php if($edit): ?><script>document.addEventListener('DOMContentLoaded',()=>openModal('contractModal'));</script><?php endif; ?>
