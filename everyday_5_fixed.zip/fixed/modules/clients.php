<?php
if(isset($_GET['delete'])){
  $cid=(int)$_GET['delete'];
  if($cid>0){ $pdo->prepare('DELETE FROM clients WHERE id=?')->execute([$cid]); log_activity($pdo,'delete','client',$cid,'Xóa khách hàng'); }
  redirect('app.php?page=clients');
}

if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['bulk_action'])) {
  $ids = array_values(array_filter(array_map('intval', $_POST['client_ids'] ?? [])));
  $action = $_POST['bulk_action'];
  if($ids){
    $in = implode(',', array_fill(0,count($ids),'?'));
    if($action==='delete'){
      $pdo->prepare("DELETE FROM clients WHERE id IN ($in)")->execute($ids);
      log_activity($pdo,'bulk_delete','client',0,'Xóa nhiều khách hàng CRM');
    }
    if($action==='duplicate'){
      $st=$pdo->prepare("SELECT name,contact_person,phone,email,industry,note FROM clients WHERE id IN ($in)");
      $st->execute($ids);
      $rows=$st->fetchAll();
      $ins=$pdo->prepare('INSERT INTO clients(name, contact_person, phone, email, industry, note) VALUES(?,?,?,?,?,?)');
      foreach($rows as $r){
        $ins->execute([$r['name'].' - Copy',$r['contact_person'],$r['phone'],$r['email'],$r['industry'],$r['note']]);
      }
      log_activity($pdo,'bulk_duplicate','client',0,'Nhân bản nhiều khách hàng CRM');
    }
  }
  redirect('app.php?page=clients');
}

if ($_SERVER['REQUEST_METHOD']==='POST' && !isset($_POST['bulk_action'])) {
  if(!empty($_POST['client_id'])){
    $stmt=$pdo->prepare('UPDATE clients SET name=?, contact_person=?, phone=?, email=?, industry=?, note=? WHERE id=?');
    $stmt->execute([$_POST['name'],$_POST['contact_person'],$_POST['phone'],$_POST['email'],$_POST['industry'],$_POST['note'],$_POST['client_id']]);
  } else {
    $stmt=$pdo->prepare('INSERT INTO clients(name, contact_person, phone, email, industry, note) VALUES(?,?,?,?,?,?)');
    $stmt->execute([$_POST['name'],$_POST['contact_person'],$_POST['phone'],$_POST['email'],$_POST['industry'],$_POST['note']]);
    log_activity($pdo,'create','client',$pdo->lastInsertId(),'Tạo khách hàng '.$_POST['name']);
  }
  redirect('app.php?page=clients');
}
$edit=null;
if(isset($_GET['edit'])){
  $st=$pdo->prepare('SELECT * FROM clients WHERE id=?');$st->execute([(int)$_GET['edit']]);$edit=$st->fetch();
}
$clients=$pdo->query('SELECT * FROM clients ORDER BY id DESC')->fetchAll();
?>
<section class="card clients-v5 crm-bulk-card">
  <div class="card-head crm-head-v5">
    <div><span class="eyebrow">CRM</span><h2>Khách hàng & khách hàng tiềm năng</h2><p class="muted">Tick nhiều khách hàng để xoá, nhân bản hoặc copy nhanh dữ liệu CRM.</p></div>
    <button class="primary" onclick="openModal('clientModal')" title="Tạo khách hàng tiềm năng"><i data-lucide="plus"></i> Tạo khách hàng</button>
  </div>
  <form method="post" id="crmBulkForm">
    <input type="hidden" name="bulk_action" id="crmBulkAction" value="">
    <div class="crm-bulk-toolbar" id="crmBulkToolbar">
      <label class="crm-check-all"><input type="checkbox" id="crmSelectAll"> Chọn tất cả</label>
      <span><b id="crmSelectedCount">0</b> khách hàng đã chọn</span>
      <button type="button" class="btn btn-soft" onclick="copySelectedClients()"><i data-lucide="copy"></i> Copy CRM</button>
      <button type="button" class="btn btn-soft" onclick="submitCrmBulk('duplicate')"><i data-lucide="copy-plus"></i> Nhân bản</button>
      <button type="button" class="btn btn-soft danger" onclick="submitCrmBulk('delete')"><i data-lucide="trash-2"></i> Xoá</button>
    </div>
    <table class="dense-table crm-table-v5"><thead><tr><th style="width:42px"></th><th>Khách hàng</th><th>Liên hệ</th><th>SĐT</th><th>Email</th><th>Ngành</th><th>Doanh thu</th><th>Profit</th><th>Note</th><th>Action</th></tr></thead><tbody>
    <?php foreach($clients as $c):
    $stmt=$pdo->prepare('SELECT COALESCE(SUM(c.total_value),0) FROM contracts c WHERE c.client_name=?'); $stmt->execute([$c['name']]); $rev=$stmt->fetchColumn();
    $stmt=$pdo->prepare('SELECT COALESCE(SUM(ici.total),0) FROM quotations q JOIN internal_cost_items ici ON ici.quotation_id=q.id WHERE q.client_name=?'); $stmt->execute([$c['name']]); $cost=$stmt->fetchColumn();
    ?>
    <tr data-client-row data-copy="<?= e(($c['name']??'').'\t'.($c['contact_person']??'').'\t'.($c['phone']??'').'\t'.($c['email']??'').'\t'.($c['industry']??'').'\t'.($c['note']??'')) ?>">
      <td><input class="crm-row-check" type="checkbox" name="client_ids[]" value="<?= (int)$c['id'] ?>"></td>
      <td><b><?= e($c['name']) ?></b></td>
      <td><?= e($c['contact_person']) ?></td>
      <td><?= e($c['phone']) ?></td>
      <td><?= e($c['email']) ?></td>
      <td><?= e($c['industry']) ?></td>
      <td><?= money($rev) ?></td>
      <td><?= money($rev-$cost) ?></td>
      <td><?= e($c['note']) ?></td>
      <td class="actions icon-actions"><a class="btn btn-soft icon-action" title="Sửa" href="app.php?page=clients&edit=<?= $c['id'] ?>"><i data-lucide="pencil"></i></a><a class="btn btn-soft icon-action danger" title="Xoá" onclick="return confirm('Xóa khách hàng này?')" href="app.php?page=clients&delete=<?= $c['id'] ?>"><i data-lucide="trash-2"></i></a></td>
    </tr>
    <?php endforeach; ?>
    <?php if(empty($clients)): ?><tr><td colspan="10" class="muted">Chưa có khách hàng.</td></tr><?php endif; ?>
    </tbody></table>
  </form>
</section>

<div class="modal-backdrop <?= $edit?'active':'' ?>" id="clientModal">
  <div class="modal-panel">
    <button class="modal-close" onclick="closeModal('clientModal')">×</button>
    <h2><?= $edit?'Edit khách hàng':'Thêm khách hàng' ?></h2>
    <form method="post">
      <input type="hidden" name="client_id" value="<?= e($edit['id']??'') ?>">
      <label>Tên khách hàng</label><input name="name" required value="<?= e($edit['name']??'') ?>">
      <label>Người liên hệ</label><input name="contact_person" value="<?= e($edit['contact_person']??'') ?>">
      <div class="form-row"><div><label>Số điện thoại</label><input name="phone" value="<?= e($edit['phone']??'') ?>"></div><div><label>Email</label><input name="email" value="<?= e($edit['email']??'') ?>"></div></div>
      <label>Ngành hàng</label><input name="industry" value="<?= e($edit['industry']??'') ?>">
      <label>Ghi chú</label><textarea name="note"><?= e($edit['note']??'') ?></textarea>
      <button class="primary">Lưu khách hàng</button>
    </form>
  </div>
</div>
<script>
(function(){
  const all=document.getElementById('crmSelectAll');
  const checks=[...document.querySelectorAll('.crm-row-check')];
  const count=document.getElementById('crmSelectedCount');
  function update(){
    const n=checks.filter(c=>c.checked).length;
    if(count) count.textContent=n;
    checks.forEach(c=>c.closest('tr')?.classList.toggle('selected', c.checked));
    if(all) all.checked = checks.length>0 && n===checks.length;
  }
  if(all) all.addEventListener('change',()=>{checks.forEach(c=>c.checked=all.checked);update();});
  checks.forEach(c=>c.addEventListener('change',update));
  window.submitCrmBulk=function(action){
    if(!checks.some(c=>c.checked)){ alert('Bạn cần chọn ít nhất 1 khách hàng.'); return; }
    if(action==='delete' && !confirm('Xoá các khách hàng đã chọn?')) return;
    document.getElementById('crmBulkAction').value=action;
    document.getElementById('crmBulkForm').submit();
  };
  window.copySelectedClients=function(){
    let rows=checks.filter(c=>c.checked).map(c=>c.closest('tr').dataset.copy);
    if(!rows.length) rows=[...document.querySelectorAll('[data-client-row]')].map(r=>r.dataset.copy);
    const text=['Khách hàng\tLiên hệ\tSĐT\tEmail\tNgành\tNote',...rows].join('\n');
    navigator.clipboard.writeText(text).then(()=>alert('Đã copy dữ liệu CRM vào clipboard.'));
  };
  update();
})();
</script>
<?php if($edit): ?><script>document.addEventListener('DOMContentLoaded',()=>openModal('clientModal'));</script><?php endif; ?>
