<?php
$me=current_user();
$isManager = user_is_admin() || in_array($me['role'], ['Giám đốc','CEO','Kế toán','HR','Finance']);
$targetUserId = $isManager && !empty($_GET['user_id']) ? (int)$_GET['user_id'] : (int)$me['id'];
if(isset($_GET['approve_rate']) && $isManager){
  $rid=(int)$_GET['approve_rate'];
  $pdo->prepare("UPDATE personal_rates SET rate_status='approved', approved_by=?, approved_at=NOW() WHERE id=?")->execute([$me['id'],$rid]);
  redirect('app.php?page=personal_rates&user_id='.$targetUserId);
}

if($_SERVER['REQUEST_METHOD']==='POST'){
  $uid = $isManager && !empty($_POST['user_id']) ? (int)$_POST['user_id'] : (int)$me['id'];
  if(!empty($_POST['rate_id'])){
    $pdo->prepare('UPDATE personal_rates SET item_name=?,unit=?,unit_price=?,note=?,status=? WHERE id=? AND user_id=?')
      ->execute([$_POST['item_name'],$_POST['unit'],$_POST['unit_price'],$_POST['note'],$_POST['status'],$_POST['rate_id'],$uid]);
  } else {
    $pdo->prepare('INSERT INTO personal_rates(user_id,item_name,unit,unit_price,note,status) VALUES(?,?,?,?,?,?)')
      ->execute([$uid,$_POST['item_name'],$_POST['unit'],$_POST['unit_price'],$_POST['note'],'active']);
      try { $pdo->prepare("UPDATE personal_rates SET rate_status=? WHERE id=?")->execute([$isManager?'approved':'draft',$pdo->lastInsertId()]); } catch(Exception $e) {}
  }
  log_activity($pdo,'save','personal_rate',$uid,'Cập nhật personal rate');
  redirect('app.php?page=personal_rates'.($isManager?'&user_id='.$uid:''));
}
$users=$pdo->query("SELECT id,name,role FROM users ORDER BY name")->fetchAll();
$stmt=$pdo->prepare('SELECT * FROM personal_rates WHERE user_id=? ORDER BY id DESC');
$stmt->execute([$targetUserId]);
$rates=$stmt->fetchAll();
?>
<section class="card">
  <div class="card-head">
    <div><span class="eyebrow">Collaborator Rate</span><h2>Personal Rate</h2><p class="muted">CTV có thể tự chỉnh rate theo từng đầu sản phẩm.</p></div>
    <button class="primary" onclick="openModal('rateModal')">+ Thêm rate</button>
  </div>
  <?php if($isManager): ?>
  <form method="get" class="asana-toolbar"><input type="hidden" name="page" value="personal_rates"><select name="user_id" onchange="this.form.submit()"><?php foreach($users as $u): ?><option value="<?= $u['id'] ?>" <?= $u['id']==$targetUserId?'selected':'' ?>><?= e($u['name']) ?> — <?= e($u['role']) ?></option><?php endforeach; ?></select></form>
  <?php endif; ?>
  <table><thead><tr><th>Đầu sản phẩm</th><th>Đơn vị</th><th>Đơn giá</th><th>Ghi chú</th><th>Status</th><th>Approval</th><th>Action</th></tr></thead><tbody>
  <?php foreach($rates as $r): ?><tr><td><b><?= e($r['item_name']) ?></b></td><td><?= e($r['unit']) ?></td><td><?= money($r['unit_price']) ?></td><td><?= e($r['note']) ?></td><td><span class="badge <?= badge_class($r['status']) ?>"><?= e($r['status']) ?></span></td><td><span class="badge <?= badge_class($r['rate_status'] ?? 'approved') ?>"><?= e($r['rate_status'] ?? 'approved') ?></span></td><td><?php if($isManager && ($r['rate_status']??'approved')!=='approved'): ?><a class="btn btn-soft" href="app.php?page=personal_rates&user_id=<?= $targetUserId ?>&approve_rate=<?= $r['id'] ?>">Approve</a><?php endif; ?></td></tr><?php endforeach; ?>
  <?php if(empty($rates)): ?><tr><td colspan="5" class="muted">Chưa có personal rate.</td></tr><?php endif; ?>
  </tbody></table>
</section>

<div class="modal-backdrop" id="rateModal">
  <div class="modal-panel">
    <button class="modal-close" onclick="closeModal('rateModal')">×</button>
    <h2>Thêm personal rate</h2>
    <form method="post">
      <?php if($isManager): ?><label>Nhân sự/CTV</label><select name="user_id"><?php foreach($users as $u): ?><option value="<?= $u['id'] ?>" <?= $u['id']==$targetUserId?'selected':'' ?>><?= e($u['name']) ?></option><?php endforeach; ?></select><?php endif; ?>
      <label>Đầu sản phẩm</label><input name="item_name" required placeholder="VD: 01 video edit, 01 social post">
      <label>Đơn vị</label><input name="unit" value="sản phẩm">
      <label>Đơn giá</label><input name="unit_price" type="number" required>
      <label>Ghi chú</label><textarea name="note"></textarea>
      <input type="hidden" name="status" value="active">
      <button class="primary">Lưu rate</button>
    </form>
  </div>
</div>
