<?php
if(!is_director_role() && !is_finance_role()) die('Bạn không có quyền xem Prompt Studio.');

$categories=['Proposal','Quotation','Contract','Content','SEO','PR','Legal','Finance','General'];
$category=$_GET['category'] ?? '';
$edit=null;

if(isset($_GET['delete']) && user_is_admin()){
  $pdo->prepare("UPDATE ai_prompt_studio SET is_active=0, updated_by=? WHERE id=?")->execute([current_user()['id'],(int)$_GET['delete']]);
  redirect('app.php?page=ai_prompt_studio');
}
if(isset($_GET['duplicate'])){
  $st=$pdo->prepare("SELECT * FROM ai_prompt_studio WHERE id=?");$st->execute([(int)$_GET['duplicate']]);$r=$st->fetch();
  if($r){
    $pdo->prepare("INSERT INTO ai_prompt_studio(prompt_name,category,prompt_body,version,is_active,created_by,updated_by) VALUES(?,?,?,?,?,?,?)")
      ->execute([$r['prompt_name'].' Copy',$r['category'],$r['prompt_body'],$r['version'],1,current_user()['id'],current_user()['id']]);
  }
  redirect('app.php?page=ai_prompt_studio');
}
if(isset($_GET['edit'])){
  $st=$pdo->prepare("SELECT * FROM ai_prompt_studio WHERE id=?");$st->execute([(int)$_GET['edit']]);$edit=$st->fetch();
}
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['save_prompt'])){
  if(!empty($_POST['prompt_id'])){
    $pdo->prepare("UPDATE ai_prompt_studio SET prompt_name=?,category=?,prompt_body=?,version=?,is_active=?,updated_by=? WHERE id=?")
      ->execute([$_POST['prompt_name'],$_POST['category'],$_POST['prompt_body'],$_POST['version'],isset($_POST['is_active'])?1:0,current_user()['id'],$_POST['prompt_id']]);
  } else {
    $pdo->prepare("INSERT INTO ai_prompt_studio(prompt_name,category,prompt_body,version,is_active,created_by,updated_by) VALUES(?,?,?,?,?,?,?)")
      ->execute([$_POST['prompt_name'],$_POST['category'],$_POST['prompt_body'],$_POST['version']?:'1.0',isset($_POST['is_active'])?1:0,current_user()['id'],current_user()['id']]);
  }
  redirect('app.php?page=ai_prompt_studio');
}
$where=["is_active=1"];$params=[];
if($category){$where[]="category=?";$params[]=$category;}
$stmt=$pdo->prepare("SELECT * FROM ai_prompt_studio WHERE ".implode(" AND ",$where)." ORDER BY category,prompt_name");
$stmt->execute($params);$rows=$stmt->fetchAll();
?>
<section class="workspace-hero ai-workspace-hero">
  <div><span class="eyebrow">AI Workspace</span><h1>Prompt Studio</h1><p class="muted">Quản lý prompt chuẩn của Motive để dùng lại trong proposal, hợp đồng, content và finance.</p></div>
  <button class="primary" onclick="openModal('promptModal')">+ Prompt</button>
</section>

<form class="asana-toolbar" method="get"><input type="hidden" name="page" value="ai_prompt_studio"><select name="category"><option value="">Tất cả category</option><?php foreach($categories as $c): ?><option value="<?= e($c) ?>" <?= $category===$c?'selected':'' ?>><?= e($c) ?></option><?php endforeach; ?></select><button class="btn btn-soft">Filter</button></form>

<section class="card">
  <div class="card-head"><h2>Prompt Library</h2></div>
  <table class="dense-table">
    <thead><tr><th>Prompt</th><th>Category</th><th>Version</th><th>Usage</th><th>Action</th></tr></thead>
    <tbody>
    <?php foreach($rows as $r): ?>
      <tr><td><b><?= e($r['prompt_name']) ?></b><br><span class="muted"><?= e(mb_substr($r['prompt_body'],0,150)) ?></span></td><td><?= e($r['category']) ?></td><td><?= e($r['version']) ?></td><td><?= (int)$r['usage_count'] ?></td><td class="actions"><a class="btn btn-soft" href="app.php?page=ai_prompt_studio&edit=<?= $r['id'] ?>">Edit</a><a class="btn btn-soft" href="app.php?page=ai_prompt_studio&duplicate=<?= $r['id'] ?>">Duplicate</a><?php if(user_is_admin()): ?><a class="btn btn-soft" href="app.php?page=ai_prompt_studio&delete=<?= $r['id'] ?>" onclick="return confirm('Archive prompt?')">Archive</a><?php endif; ?></td></tr>
    <?php endforeach; ?>
    <?php if(empty($rows)): ?><tr><td colspan="5" class="muted">Chưa có prompt.</td></tr><?php endif; ?>
    </tbody>
  </table>
</section>

<div class="modal-backdrop <?= $edit?'active':'' ?>" id="promptModal">
  <div class="modal-panel large-modal">
    <button class="modal-close" onclick="closeModal('promptModal')">×</button>
    <h2><?= $edit?'Edit Prompt':'Create Prompt' ?></h2>
    <form method="post">
      <input type="hidden" name="save_prompt" value="1">
      <input type="hidden" name="prompt_id" value="<?= e($edit['id']??'') ?>">
      <label>Prompt Name</label><input name="prompt_name" required value="<?= e($edit['prompt_name']??'') ?>">
      <div class="form-row"><div><label>Category</label><select name="category"><?php foreach($categories as $c): ?><option value="<?= e($c) ?>" <?= ($edit['category']??'')===$c?'selected':'' ?>><?= e($c) ?></option><?php endforeach; ?></select></div><div><label>Version</label><input name="version" value="<?= e($edit['version']??'1.0') ?>"></div></div>
      <label>Prompt Body</label><textarea name="prompt_body" rows="14" required><?= e($edit['prompt_body']??'') ?></textarea>
      <label class="check-row"><input type="checkbox" name="is_active" value="1" <?= !isset($edit['is_active']) || $edit['is_active']?'checked':'' ?>> Active</label>
      <button class="primary">Save Prompt</button>
    </form>
  </div>
</div>
<?php if($edit): ?><script>document.addEventListener('DOMContentLoaded',()=>openModal('promptModal'));</script><?php endif; ?>
