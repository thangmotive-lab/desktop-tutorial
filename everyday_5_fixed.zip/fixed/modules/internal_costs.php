<?php
$id=(int)($_GET['id']??0); if(!$id){$id=(int)$pdo->query('SELECT id FROM quotations ORDER BY id DESC LIMIT 1')->fetchColumn(); if($id) redirect('app.php?page=internal_costs&id='.$id);}
$stmt=$pdo->prepare('SELECT * FROM quotations WHERE id=?'); $stmt->execute([$id]); $q=$stmt->fetch(); if(!$q) die('Chưa có báo giá.');
if($_SERVER['REQUEST_METHOD']==='POST'){
  $pdo->prepare('DELETE FROM internal_cost_items WHERE quotation_id=?')->execute([$id]);
  foreach($_POST['costs']??[] as $idx=>$c){
    if(trim($c['item_name']??'')==='') continue;
    $qty=(float)$c['quantity']; $unit=(float)$c['unit_cost']; $total=$qty*$unit;
    $pdo->prepare('INSERT INTO internal_cost_items(quotation_id,sort_order,cost_group,item_name,description,unit,quantity,unit_cost,total,owner,note) VALUES(?,?,?,?,?,?,?,?,?,?,?)')->execute([$id,$idx+1,$c['cost_group'],$c['item_name'],$c['description'],$c['unit'],$qty,$unit,$total,$c['owner'],$c['note']]);
  }
  log_activity($pdo,'update','internal_cost',$id,'Cập nhật internal cost '.$q['quote_code']);
  redirect('app.php?page=internal_costs&id='.$id);
}
$stmt=$pdo->prepare('SELECT * FROM internal_cost_items WHERE quotation_id=? ORDER BY sort_order,id'); $stmt->execute([$id]); $costs=$stmt->fetchAll();
for($i=count($costs);$i<12;$i++) $costs[]=['cost_group'=>'','item_name'=>'','description'=>'','unit'=>'','quantity'=>1,'unit_cost'=>0,'total'=>0,'owner'=>'','note'=>''];
$t=quotation_totals($pdo,$id);
$grossRevenue=(float)($t['total'] ?? 0);
$tax10=round($grossRevenue*0.10);
$netRevenue=$grossRevenue-$tax10;
$totalCost=(float)($t['cost'] ?? 0);
$netProfit=$netRevenue-$totalCost;
$netGp=$netRevenue>0?round(($netProfit/$netRevenue)*100,1):0;
$quotes=$pdo->query('SELECT id,quote_code,client_name FROM quotations ORDER BY id DESC')->fetchAll();
?>
<div class="tabs"><a href="app.php?page=quotation_edit&id=<?= $id ?>">Builder</a><a href="public_quote.php?token=<?= e($q['public_token']) ?>" target="_blank">Client Landing Page</a><a class="active" href="app.php?page=internal_costs&id=<?= $id ?>">Internal Cost</a><a href="app.php?page=payments&id=<?= $id ?>">Payment</a></div>
<section class="card"><div class="card-head"><h2>Internal Cost Sheet — <?= e($q['quote_code']) ?></h2><form method="get"><input type="hidden" name="page" value="internal_costs"><select name="id" onchange="this.form.submit()"><?php foreach($quotes as $qq): ?><option value="<?= $qq['id'] ?>" <?= $qq['id']==$id?'selected':'' ?>><?= e($qq['quote_code']) ?> - <?= e($qq['client_name']) ?></option><?php endforeach; ?></select></form></div>
<div class="summary-box" style="margin-bottom:18px">
  <div class="row"><span>Revenue gross</span><b><?= money($grossRevenue) ?></b></div>
  <div class="row"><span>Thuế 10%</span><b>-<?= money($tax10) ?></b></div>
  <div class="row"><span>Revenue sau thuế</span><b><?= money($netRevenue) ?></b></div>
  <div class="row"><span>Total Cost</span><b><?= money($totalCost) ?></b></div>
  <div class="row"><span>Profit sau thuế</span><b><?= money($netProfit) ?></b></div>
  <div class="row"><span>Margin sau thuế</span><b><?= $netGp ?>%</b></div>
</div>
<form method="post"><table class="sheet-table"><thead><tr><th>STT</th><th>Nhóm</th><th>Hạng mục</th><th>Mô tả</th><th>Đơn vị</th><th>SL</th><th>Đơn giá</th><th>Thành tiền</th><th>Owner</th><th>Ghi chú</th></tr></thead><tbody>
<?php foreach($costs as $idx=>$c): ?><tr class="cost-row"><td><?= $idx+1 ?></td><td><input name="costs[<?= $idx ?>][cost_group]" value="<?= e($c['cost_group']) ?>"></td><td><input name="costs[<?= $idx ?>][item_name]" value="<?= e($c['item_name']) ?>"></td><td><textarea name="costs[<?= $idx ?>][description]"><?= e($c['description']) ?></textarea></td><td><input name="costs[<?= $idx ?>][unit]" value="<?= e($c['unit']) ?>"></td><td><input name="costs[<?= $idx ?>][quantity]" type="number" step="0.1" value="<?= e($c['quantity']) ?>"></td><td><input name="costs[<?= $idx ?>][unit_cost]" type="number" value="<?= e($c['unit_cost']) ?>"></td><td class="js-cost-total"><?= money($c['total']) ?></td><td><input name="costs[<?= $idx ?>][owner]" value="<?= e($c['owner']) ?>"></td><td><input name="costs[<?= $idx ?>][note]" value="<?= e($c['note']) ?>"></td></tr><?php endforeach; ?>
</tbody></table><br><button class="primary">Lưu Internal Cost</button></form></section>
