<?php
$me=current_user();
$month=$_GET['month'] ?? date('Y-m');

$payStmt=$pdo->prepare("SELECT * FROM payroll WHERE user_id=? AND COALESCE(salary_month,month)=? ORDER BY id DESC LIMIT 1");
$payStmt->execute([$me['id'],$month]);
$pay=$payStmt->fetch();

$ratesStmt=$pdo->prepare("SELECT * FROM personal_rates WHERE user_id=? AND status='active' ORDER BY item_name");
$ratesStmt->execute([$me['id']]);
$rates=$ratesStmt->fetchAll();

$tasksStmt=$pdo->prepare("SELECT t.*,p.name project_name FROM tasks t LEFT JOIN projects p ON p.id=t.project_id WHERE t.assignee_id=? AND t.status='Done' AND DATE_FORMAT(COALESCE(t.completed_at,t.deadline),'%Y-%m')=? ORDER BY t.completed_at DESC,t.id DESC LIMIT 100");
$tasksStmt->execute([$me['id'],$month]);
$doneTasks=$tasksStmt->fetchAll();

$taskValue=0;
foreach($doneTasks as $t){ $taskValue += (float)($t['product_quantity']??0) * (float)($t['product_unit_price']??0); }
?>
<section class="workspace-hero finance-hero">
  <div>
    <span class="eyebrow">My Finance</span>
    <h1>Tài chính cá nhân</h1>
    <p class="muted">Xem personal rate, bảng lương, KPI, bonus và task đã hoàn thành trong tháng.</p>
  </div>
  <form method="get"><input type="hidden" name="page" value="my_finance"><input type="month" name="month" value="<?= e($month) ?>"><button class="btn btn-soft">Xem</button></form>
</section>

<div class="stats-grid compact-stats">
  <div class="stat mint"><span>Thực nhận</span><strong><?= money_short($pay['net_salary'] ?? $pay['total_salary'] ?? 0) ?></strong></div>
  <div class="stat purple"><span>KPI</span><strong><?= e($pay['kpi_percent'] ?? 0) ?>%</strong></div>
  <div class="stat yellow"><span>Bonus/Commission</span><strong><?= money_short(($pay['bonus'] ?? 0)+($pay['commission'] ?? 0)+($pay['sales_commission'] ?? 0)) ?></strong></div>
  <div class="stat coral"><span>Task Value</span><strong><?= money_short($taskValue) ?></strong></div>
</div>

<div class="two-col">
<section class="card">
  <div class="card-head"><h2>Bảng lương tháng <?= e($month) ?></h2></div>
  <?php if($pay): ?>
  <table class="dense-table"><tbody>
    <tr><th>Lương cứng</th><td><?= money($pay['base_salary'] ?? 0) ?></td></tr>
    <tr><th>Giờ/ngày làm</th><td><?= e($pay['actual_hours'] ?? 0) ?>h · <?= e($pay['actual_days'] ?? 0) ?> ngày</td></tr>
    <tr><th>KPI</th><td><?= e($pay['kpi_percent'] ?? 0) ?>%</td></tr>
    <tr><th>Commission</th><td><?= money(($pay['commission'] ?? 0)+($pay['sales_commission'] ?? 0)) ?></td></tr>
    <tr><th>Bonus</th><td><?= money($pay['bonus'] ?? 0) ?></td></tr>
    <tr><th>Khấu trừ</th><td><?= money(($pay['bhxh'] ?? 0)+($pay['tncn'] ?? 0)+($pay['other_deduction'] ?? 0)) ?></td></tr>
    <tr><th>Thực nhận</th><td><b><?= money($pay['net_salary'] ?? $pay['total_salary'] ?? 0) ?></b></td></tr>
    <tr><th>Trạng thái</th><td><span class="badge <?= badge_class($pay['employee_approval_status'] ?? $pay['status']) ?>"><?= e($pay['employee_approval_status'] ?? $pay['status']) ?></span></td></tr>
  </tbody></table>
  <?php if(($pay['employee_approval_status'] ?? '')!=='approved'): ?><p><a class="btn btn-coral" href="app.php?page=payroll&approve_salary=<?= (int)$pay['id'] ?>">Tôi đồng ý bảng lương</a></p><?php endif; ?>
  <?php else: ?><p class="muted">Chưa có bảng lương tháng này.</p><?php endif; ?>
</section>

<section class="card">
  <div class="card-head"><h2>Personal Rate</h2><a class="btn btn-soft" href="app.php?page=personal_rates">Cập nhật rate</a></div>
  <table class="dense-table"><thead><tr><th>Sản phẩm</th><th>Đơn vị</th><th>Rate</th></tr></thead><tbody>
    <?php foreach($rates as $r): ?><tr><td><?= e($r['item_name']) ?></td><td><?= e($r['unit']) ?></td><td><?= money($r['unit_price']) ?></td></tr><?php endforeach; ?>
    <?php if(empty($rates)): ?><tr><td colspan="3" class="muted">Chưa có personal rate.</td></tr><?php endif; ?>
  </tbody></table>
</section>
</div>

<section class="card">
  <div class="card-head"><h2>Task đã hoàn thành trong tháng</h2></div>
  <table class="dense-table"><thead><tr><th>Task</th><th>Project</th><th>Deliverable</th><th>Completed</th><th>Value</th></tr></thead><tbody>
    <?php foreach($doneTasks as $t): $v=(float)($t['product_quantity']??0)*(float)($t['product_unit_price']??0); ?>
      <tr><td><b><?= e($t['title']) ?></b></td><td><?= e($t['project_name']) ?></td><td><?= e($t['deliverable_type']) ?> × <?= e($t['deliverable_count']) ?></td><td><?= e($t['completed_at']) ?></td><td><?= money($v) ?></td></tr>
    <?php endforeach; ?>
    <?php if(empty($doneTasks)): ?><tr><td colspan="5" class="muted">Chưa có task Done trong tháng.</td></tr><?php endif; ?>
  </tbody></table>
</section>
