<?php
$me=current_user();
$stmt=$pdo->prepare('SELECT * FROM users WHERE id=?');
$stmt->execute([$me['id']]);
$user=$stmt->fetch();

if($_SERVER['REQUEST_METHOD']==='POST'){
  $avatar=$user['avatar'];
  if(!empty($_FILES['avatar']['name'])){
    $ext=pathinfo($_FILES['avatar']['name'],PATHINFO_EXTENSION);
    $filename='uploads/avatars/avatar_'.time().'_'.rand(100,999).'.'.$ext;
    move_uploaded_file($_FILES['avatar']['tmp_name'], __DIR__.'/../'.$filename);
    $avatar=$filename;
  }

  $fields=[
    'name','email','phone','birthday','birth_year','zodiac','numerology_number',
    'citizen_id','personal_tax_code','home_address','hometown','bank_account',
    'bank_name','bank_account_name'
  ];

  $data=[];
  foreach($fields as $f){ $data[$f]=$_POST[$f] ?? ''; }

  if(!empty($_POST['password'])){
    $hash=password_hash($_POST['password'], PASSWORD_DEFAULT);
    $sql='UPDATE users SET name=?,email=?,phone=?,birthday=?,birth_year=?,zodiac=?,numerology_number=?,citizen_id=?,personal_tax_code=?,home_address=?,hometown=?,bank_account=?,bank_name=?,bank_account_name=?,password_hash=?,avatar=? WHERE id=?';
    $pdo->prepare($sql)->execute([$data['name'],$data['email'],$data['phone'],$data['birthday'],$data['birth_year'],$data['zodiac'],$data['numerology_number'],$data['citizen_id'],$data['personal_tax_code'],$data['home_address'],$data['hometown'],$data['bank_account'],$data['bank_name'],$data['bank_account_name'],$hash,$avatar,$me['id']]);
  } else {
    $sql='UPDATE users SET name=?,email=?,phone=?,birthday=?,birth_year=?,zodiac=?,numerology_number=?,citizen_id=?,personal_tax_code=?,home_address=?,hometown=?,bank_account=?,bank_name=?,bank_account_name=?,avatar=? WHERE id=?';
    $pdo->prepare($sql)->execute([$data['name'],$data['email'],$data['phone'],$data['birthday'],$data['birth_year'],$data['zodiac'],$data['numerology_number'],$data['citizen_id'],$data['personal_tax_code'],$data['home_address'],$data['hometown'],$data['bank_account'],$data['bank_name'],$data['bank_account_name'],$avatar,$me['id']]);
  }

  $_SESSION['user']['name']=$data['name'];
  $_SESSION['user']['email']=$data['email'];
  $_SESSION['user']['avatar']=$avatar;
  log_activity($pdo,'update','profile',$me['id'],'Cập nhật profile cá nhân chi tiết');
  redirect('app.php?page=profile');
}
?>

<?php if(user_is_admin()): ?>
<section class="card admin-profile-entry">
  <div class="card-head">
    <div>
      <span class="eyebrow">Admin Access</span>
      <h2>Admin Studio</h2>
      <p class="muted">Lối vào dành cho quản trị hệ thống: user, phân quyền, Mcoin, cấu hình AI, billing và activity log.</p>
    </div>
    <a class="primary" href="admin.php?page=users"><i data-lucide="settings"></i> Mở Admin Studio</a>
  </div>
</section>
<?php endif; ?>

<section class="card profile-card">
  <div class="card-head">
    <div><span class="eyebrow">Personal Profile</span><h2>Thông tin cá nhân</h2><p class="muted">Trang này chỉ chỉnh sửa hồ sơ của chính bạn.</p></div>
    <?= avatar_html($user) ?>
  </div>
  <form method="post" enctype="multipart/form-data">
    <div class="form-row"><div><label>Họ tên</label><input name="name" value="<?= e($user['name']??'') ?>" required></div><div><label>Email</label><input name="email" type="email" value="<?= e($user['email']??'') ?>" required></div></div>
    <div class="form-row-3"><div><label>Số điện thoại</label><input name="phone" value="<?= e($user['phone']??'') ?>"></div><div><label>Ngày sinh</label><input name="birthday" type="date" value="<?= e($user['birthday']??'') ?>"></div><div><label>Năm sinh</label><input name="birth_year" type="number" value="<?= e($user['birth_year']??'') ?>"></div></div>
    <div class="form-row-3"><div><label>Cung hoàng đạo</label><input name="zodiac" value="<?= e($user['zodiac']??'') ?>"></div><div><label>Thần số học</label><input name="numerology_number" value="<?= e($user['numerology_number']??'') ?>"></div><div><label>Quê quán</label><input name="hometown" value="<?= e($user['hometown']??'') ?>"></div></div>
    <div class="form-row"><div><label>Số CCCD</label><input name="citizen_id" value="<?= e($user['citizen_id']??'') ?>"></div><div><label>Mã số thuế cá nhân</label><input name="personal_tax_code" value="<?= e($user['personal_tax_code']??'') ?>"></div></div>
    <label>Địa chỉ nhà</label><input name="home_address" value="<?= e($user['home_address']??'') ?>">
    <div class="form-row-3"><div><label>Số tài khoản ngân hàng</label><input name="bank_account" value="<?= e($user['bank_account']??'') ?>"></div><div><label>Ngân hàng</label><input name="bank_name" value="<?= e($user['bank_name']??'') ?>"></div><div><label>Chủ tài khoản</label><input name="bank_account_name" value="<?= e($user['bank_account_name']??'') ?>"></div></div>
    <div class="form-row"><div><label>Đổi mật khẩu</label><input name="password" type="password" placeholder="Để trống nếu không đổi"></div><div><label>Avatar</label><input name="avatar" type="file" accept="image/*"></div></div>
    <button class="primary">Lưu profile</button>
  </form>
</section>
