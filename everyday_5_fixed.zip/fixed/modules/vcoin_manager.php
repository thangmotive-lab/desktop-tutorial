<?php
vcoin_ensure_schema($pdo);
$month = $_GET['month'] ?? date('Y-m');
$success='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  if(isset($_POST['save_Mcoin_rules'])){
    foreach(['task_done_early','task_done','attendance_checkin','pomodoro_complete','conversion_rate'] as $k){
      vcoin_set_setting($pdo,$k,(int)($_POST[$k] ?? 0));
    }
    $success='Đã lưu cấu hình Mcoin.';
  }
  if(isset($_POST['manual_award'])){
    vcoin_award($pdo,(int)$_POST['user_id'],(int)$_POST['amount'],trim($_POST['reason'] ?: 'Thưởng Mcoin thủ công'),'manual',null,null,trim($_POST['note'] ?? ''));
    $success='Đã cộng Mcoin thủ công.';
  }
  if(isset($_POST['settle_month'])){
    $rate=(float)vcoin_get_setting($pdo,'conversion_rate',1);
    $rows=safe_rows($pdo,"SELECT u.id user_id, COALESCE(SUM(v.amount),0) total FROM users u LEFT JOIN vcoin_transactions v ON v.user_id=u.id AND v.payroll_month=? AND v.status='earned' GROUP BY u.id",[$month]);
    foreach($rows as $r){
      if((int)$r['total']<=0) continue;
      $amount=(int)$r['total']*$rate;
      $pdo->prepare("INSERT INTO vcoin_monthly_settlements(user_id,payroll_month,vcoin_total,conversion_rate,amount_vnd,status,settled_at) VALUES(?,?,?,?,?,'settled',NOW()) ON DUPLICATE KEY UPDATE vcoin_total=VALUES(vcoin_total),conversion_rate=VALUES(conversion_rate),amount_vnd=VALUES(amount_vnd),status='settled',settled_at=NOW()")->execute([(int)$r['user_id'],$month,(int)$r['total'],$rate,$amount]);
      $pdo->prepare("UPDATE vcoin_transactions SET status='settled', settled_at=NOW() WHERE user_id=? AND payroll_month=? AND status='earned'")->execute([(int)$r['user_id'],$month]);
    }
    $success='Đã chốt Mcoin tháng '.$month.' để cộng vào lương.';
  }
}
$rules=[
 'task_done_early'=>(int)vcoin_get_setting($pdo,'task_done_early',2000),
 'task_done'=>(int)vcoin_get_setting($pdo,'task_done',1000),
 'attendance_checkin'=>(int)vcoin_get_setting($pdo,'attendance_checkin',1500),
 'pomodoro_complete'=>(int)vcoin_get_setting($pdo,'pomodoro_complete',1200),
 'conversion_rate'=>(int)vcoin_get_setting($pdo,'conversion_rate',1),
];
$users=safe_rows($pdo,"SELECT id,name,role,avatar FROM users ORDER BY name ASC");
$summary=safe_rows($pdo,"SELECT u.id,u.name,u.role,u.avatar,COALESCE(SUM(CASE WHEN v.status='earned' THEN v.amount ELSE 0 END),0) earned,COALESCE(SUM(CASE WHEN v.status='settled' THEN v.amount ELSE 0 END),0) settled FROM users u LEFT JOIN vcoin_transactions v ON v.user_id=u.id AND v.payroll_month=? GROUP BY u.id ORDER BY earned DESC,u.name",[$month]);
$recent=safe_rows($pdo,"SELECT v.*,u.name,u.avatar FROM vcoin_transactions v LEFT JOIN users u ON u.id=v.user_id ORDER BY v.id DESC LIMIT 30");
?>
<?php if($success): ?><div class="alert success"><?= e($success) ?></div><?php endif; ?>
<section class="card Mcoin-hero-card">
  <div class="card-head"><div><span class="eyebrow">Reward System</span><h2>Mcoin Manager</h2><p class="muted">Quản lý luật thưởng, quy đổi và cộng Mcoin vào lương hàng tháng.</p></div><form method="get"><input type="hidden" name="page" value="vcoin_manager"><input type="month" name="month" value="<?= e($month) ?>" onchange="this.form.submit()"></form></div>
  <form method="post" class="vcoin-rule-grid">
    <input type="hidden" name="save_Mcoin_rules" value="1">
    <div><label>Task xong sớm</label><input type="number" name="task_done_early" value="<?= $rules['task_done_early'] ?>"><small>Gợi ý 2.000 Mcoin</small></div>
    <div><label>Task hoàn thành</label><input type="number" name="task_done" value="<?= $rules['task_done'] ?>"><small>Gợi ý 1.000 Mcoin</small></div>
    <div><label>Chấm công đều</label><input type="number" name="attendance_checkin" value="<?= $rules['attendance_checkin'] ?>"><small>Gợi ý 1.500 Mcoin/ngày</small></div>
    <div><label>Pomodoro hoàn thành</label><input type="number" name="pomodoro_complete" value="<?= $rules['pomodoro_complete'] ?>"><small>Gợi ý 1.200 Mcoin/phiên</small></div>
    <div><label>Quy đổi sang VNĐ</label><input type="number" name="conversion_rate" value="<?= $rules['conversion_rate'] ?>"><small>1 Mcoin = ? VNĐ</small></div>
    <div class="vcoin-rule-action"><button class="primary">Lưu luật thưởng</button></div>
  </form>
</section>

<div class="two-col">
<section class="card">
  <div class="card-head"><div><span class="eyebrow">Monthly Payroll</span><h2>Bảng cộng Mcoin tháng <?= e($month) ?></h2></div><form method="post"><input type="hidden" name="settle_month" value="1"><button class="primary" onclick="return confirm('Chốt Mcoin tháng này để cộng vào lương?')">Chốt cộng lương</button></form></div>
  <table class="dense-table mobile-card-table"><thead><tr><th>Nhân sự</th><th>Mcoin chưa chốt</th><th>Đã chốt</th><th>Quy đổi</th></tr></thead><tbody>
    <?php foreach($summary as $r): ?><tr><td data-label="Nhân sự"><?= avatar_html($r,true) ?> <b><?= e($r['name']) ?></b><small><?= e($r['role']) ?></small></td><td data-label="Chưa chốt"><b><?= number_format((int)$r['earned'],0,',','.') ?></b></td><td data-label="Đã chốt"><?= number_format((int)$r['settled'],0,',','.') ?></td><td data-label="Quy đổi"><?= money(((int)$r['earned']+(int)$r['settled'])*$rules['conversion_rate']) ?></td></tr><?php endforeach; ?>
  </tbody></table>
</section>
<section class="card">
  <div class="card-head"><div><span class="eyebrow">Manual</span><h2>Cộng Mcoin thủ công</h2></div></div>
  <form method="post"><input type="hidden" name="manual_award" value="1"><label>Nhân sự</label><select name="user_id"><?php foreach($users as $u): ?><option value="<?= $u['id'] ?>"><?= e($u['name']) ?> · <?= e($u['role']) ?></option><?php endforeach; ?></select><label>Số Mcoin</label><input name="amount" type="number" value="1000"><label>Lý do</label><input name="reason" value="Thưởng chủ động"><label>Ghi chú</label><textarea name="note"></textarea><button class="primary">Cộng Mcoin</button></form>
</section>
</div>
<section class="card"><div class="card-head"><div><span class="eyebrow">History</span><h2>Lịch sử Mcoin gần đây</h2></div></div><table class="dense-table mobile-card-table"><thead><tr><th>Ngày</th><th>Nhân sự</th><th>Lý do</th><th>Mcoin</th><th>Trạng thái</th></tr></thead><tbody><?php foreach($recent as $v): ?><tr><td data-label="Ngày"><?= e($v['created_at']) ?></td><td data-label="Nhân sự"><?= avatar_html($v,true) ?> <?= e($v['name']) ?></td><td data-label="Lý do"><?= e($v['reason']) ?><small><?= e($v['note']) ?></small></td><td data-label="Mcoin"><b>+<?= number_format((int)$v['amount'],0,',','.') ?></b></td><td data-label="Trạng thái"><span class="badge <?= $v['status']==='settled'?'green':'orange' ?>"><?= e($v['status']) ?></span></td></tr><?php endforeach; ?></tbody></table></section>
