<?php
mcoin_ensure_schema($pdo);
$me=current_user();
$success='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  if(isset($_POST['create_need_help'])){
    $taskId=(int)($_POST['task_id'] ?? 0);
    $reason=trim($_POST['reason'] ?? 'Cần hỗ trợ');
    $message=trim($_POST['message'] ?? '');
    need_help_create($pdo,$taskId,(int)$me['id'],$reason,$message);
    $success='Đã gửi yêu cầu hỗ trợ tới quản lý.';
  }
  if(isset($_POST['resolve_help']) && user_is_admin()){
    $id=(int)$_POST['help_id'];
    $pdo->prepare("UPDATE need_help_requests SET status='resolved', resolved_by=?, resolved_at=NOW() WHERE id=?")->execute([(int)$me['id'],$id]);
    $success='Đã đánh dấu đã hỗ trợ.';
  }
}
$where = user_is_admin() ? '1=1' : 'h.user_id='.(int)$me['id'];
$rows=safe_rows($pdo,"SELECT h.*,t.title task_title,p.name project_name,u.name user_name,u.avatar user_avatar FROM need_help_requests h LEFT JOIN tasks t ON t.id=h.task_id LEFT JOIN projects p ON p.id=t.project_id LEFT JOIN users u ON u.id=h.user_id WHERE $where ORDER BY FIELD(h.status,'open','resolved'), h.id DESC LIMIT 80");
$tasks=safe_rows($pdo,"SELECT id,title FROM tasks WHERE assignee_id=? OR created_by=? ORDER BY id DESC LIMIT 80",[(int)$me['id'],(int)$me['id']]);
?>
<?php if($success): ?><div class="alert success"><?= e($success) ?></div><?php endif; ?>
<section class="card need-help-hero"><div class="card-head"><div><span class="eyebrow">Need Help</span><h2>Task cần hỗ trợ</h2><p class="muted">Báo hiệu sớm khi thiếu thông tin, khách chậm phản hồi hoặc deadline gấp.</p></div><button class="primary" onclick="openModal('needHelpCreateModal')">🚨 Gửi yêu cầu</button></div></section>
<section class="card"><div class="need-help-grid">
<?php foreach($rows as $r): ?><article class="need-help-card <?= e($r['status']) ?>"><div class="need-help-top"><div><?= avatar_html(['name'=>$r['user_name'],'avatar'=>$r['user_avatar']],true) ?><b><?= e($r['user_name']) ?></b></div><span class="badge <?= $r['status']==='resolved'?'green':'red' ?>"><?= e($r['status']) ?></span></div><h3><?= e($r['reason']) ?></h3><p><?= e($r['message']) ?></p><small><?= e($r['task_title'] ?: 'Không gắn task') ?><?= $r['project_name']?' · '.e($r['project_name']):'' ?></small><?php if(user_is_admin() && $r['status']!=='resolved'): ?><form method="post"><input type="hidden" name="resolve_help" value="1"><input type="hidden" name="help_id" value="<?= (int)$r['id'] ?>"><button class="btn-soft">Đã hỗ trợ</button></form><?php endif; ?></article><?php endforeach; ?>
<?php if(empty($rows)): ?><p class="muted">Chưa có yêu cầu hỗ trợ nào.</p><?php endif; ?>
</div></section>
<div class="modal-backdrop" id="needHelpCreateModal"><div class="modal-panel"><button type="button" class="modal-close" onclick="closeModal('needHelpCreateModal')">×</button><span class="eyebrow">Need Help</span><h2>Gửi yêu cầu hỗ trợ</h2><form method="post"><input type="hidden" name="create_need_help" value="1"><label>Gắn với task</label><select name="task_id"><option value="0">Không gắn task cụ thể</option><?php foreach($tasks as $t): ?><option value="<?= (int)$t['id'] ?>"><?= e($t['title']) ?></option><?php endforeach; ?></select><label>Lý do</label><select name="reason"><option>Thiếu thông tin</option><option>Thiếu nguồn lực</option><option>Khách hàng chậm phản hồi</option><option>Deadline gấp</option><option>Khác</option></select><label>Chi tiết</label><textarea name="message" placeholder="Mình đang vướng ở đâu?"></textarea><button class="primary">Gửi hỗ trợ</button></form></div></div>
