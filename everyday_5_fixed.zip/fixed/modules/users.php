<?php
$edit=null;
if(isset($_GET['edit'])){
  $stmt=$pdo->prepare('SELECT * FROM users WHERE id=?');
  $stmt->execute([(int)$_GET['edit']]);
  $edit=$stmt->fetch();
}
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $avatar = $_POST['old_avatar'] ?? '';
  if (!empty($_FILES['avatar']['name'])) {
    $ext = pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION);
    $filename = 'uploads/avatars/avatar_'.time().'_'.rand(100,999).'.'.$ext;
    move_uploaded_file($_FILES['avatar']['tmp_name'], __DIR__.'/../'.$filename);
    $avatar = $filename;
  }

  if(!empty($_POST['user_id'])){
    if(!empty($_POST['password'])){
      $hash=password_hash($_POST['password'], PASSWORD_DEFAULT);
      $stmt=$pdo->prepare('UPDATE users SET name=?, email=?, password_hash=?, role=?, avatar=?, base_salary=?, kpi_target=?, status=? WHERE id=?');
      $stmt->execute([$_POST['name'],$_POST['email'],$hash,$_POST['role'],$avatar,$_POST['base_salary'],$_POST['kpi_target'],$_POST['status'],$_POST['user_id']]);
    } else {
      $stmt=$pdo->prepare('UPDATE users SET name=?, email=?, role=?, avatar=?, base_salary=?, kpi_target=?, status=? WHERE id=?');
      $stmt->execute([$_POST['name'],$_POST['email'],$_POST['role'],$avatar,$_POST['base_salary'],$_POST['kpi_target'],$_POST['status'],$_POST['user_id']]);
    }
    log_activity($pdo,'update','user',$_POST['user_id'],'Cập nhật user '.$_POST['name']);
  } else {
    $hash = password_hash($_POST['password'] ?: '123456', PASSWORD_DEFAULT);
    $stmt=$pdo->prepare('INSERT INTO users(name,email,password_hash,role,avatar,base_salary,kpi_target,status) VALUES(?,?,?,?,?,?,?,?)');
    $stmt->execute([$_POST['name'],$_POST['email'],$hash,$_POST['role'],$avatar,$_POST['base_salary'],$_POST['kpi_target'],'active']);
    log_activity($pdo,'create','user',$pdo->lastInsertId(),'Tạo user '.$_POST['name']);
  }
  redirect('app.php?page=users');
}
$users=$pdo->query('SELECT * FROM users ORDER BY id DESC')->fetchAll();
?>
<section class="card">
  <div class="card-head">
    <h2>User Manager</h2>
    <button class="primary" onclick="openModal('userModal')">+ Thêm nhân sự</button>
  </div>
  <table>
    <thead><tr><th>Avatar</th><th>Name</th><th>Email</th><th>Role</th><th>Lương cứng</th><th>KPI target</th><th>Status</th><th>Action</th></tr></thead>
    <tbody>
    <?php foreach($users as $u): ?>
      <tr>
        <td><?= avatar_html($u) ?></td>
        <td><b><?= e($u['name']) ?></b></td>
        <td><?= e($u['email']) ?></td>
        <td><?= e($u['role']) ?></td>
        <td><?= money($u['base_salary']) ?></td>
        <td><?= e($u['kpi_target']) ?></td>
        <td><span class="badge <?= badge_class($u['status']) ?>"><?= e($u['status']) ?></span></td>
        <td><a class="btn btn-soft" href="app.php?page=users&edit=<?= $u['id'] ?>">Sửa</a></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</section>

<div class="modal-backdrop <?= $edit?'active':'' ?>" id="userModal">
  <div class="modal-panel">
    <button class="modal-close" onclick="closeModal('userModal')">×</button>
    <h2><?= $edit?'Sửa nhân sự':'Thêm nhân sự' ?></h2>
    <form method="post" enctype="multipart/form-data">
      <input type="hidden" name="user_id" value="<?= e($edit['id']??'') ?>">
      <input type="hidden" name="old_avatar" value="<?= e($edit['avatar']??'') ?>">
      <label>Họ tên</label><input name="name" required value="<?= e($edit['name']??'') ?>">
      <label>Email</label><input name="email" type="email" required value="<?= e($edit['email']??'') ?>">
      <label>Password <?= $edit?'(để trống nếu không đổi)':'' ?></label><input name="password" value="">
      <label>Role</label>
      <select name="role">
        <?php foreach(['Founder','CEO','BD','Finance','HR','Production','Designer','Content','Editor'] as $role): ?>
          <option <?= ($edit['role']??'')===$role?'selected':'' ?>><?= $role ?></option>
        <?php endforeach; ?>
      </select>
      <div class="form-row">
        <div><label>Lương cứng</label><input name="base_salary" type="number" value="<?= e($edit['base_salary']??0) ?>"></div>
        <div><label>Status</label><select name="status"><option <?= ($edit['status']??'active')==='active'?'selected':'' ?>>active</option><option <?= ($edit['status']??'')==='inactive'?'selected':'' ?>>inactive</option></select></div>
      </div>
      <label>KPI target</label><input name="kpi_target" value="<?= e($edit['kpi_target']??'Task đúng hạn, project hoàn thành') ?>">
      <label>Avatar</label><input name="avatar" type="file" accept="image/*">
      <button class="primary">Lưu user</button>
    </form>
  </div>
</div>
