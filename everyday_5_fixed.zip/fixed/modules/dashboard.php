<?php
$me=current_user();
$month=$_GET['month'] ?? date('Y-m');
sprint31_ensure_schema($pdo);
$flow=agency_money_flow_metrics($pdo,$month);
$team=sprint31_attendance_summary($pdo,$month);
[$start,$end]=sprint31_month_bounds($month);

$totalDays=array_sum(array_column($team,'days'));
$totalHours=array_sum(array_column($team,'hours'));
$totalOt=array_sum(array_column($team,'ot_hours'));
$avgScore=count($team)?round(array_sum(array_column($team,'score'))/count($team)):0;
$topTeam=array_slice($team,0,8);

$monthSeries=[];
for($i=5;$i>=0;$i--){
  $m=date('Y-m', strtotime("-$i months", strtotime($month.'-01')));
  $f=agency_money_flow_metrics($pdo,$m);
  $monthSeries[]=['month'=>$m,'label'=>date('m/Y',strtotime($m.'-01')),'income'=>$f['cash_collected'],'outcome'=>$f['internal_cost_total']+$f['payroll_total']+$f['expense_total'],'profit'=>$f['cash_profit']];
}
$maxChart=max(1,...array_map(fn($r)=>max($r['income'],$r['outcome'],abs($r['profit'])),$monthSeries));

$overdue=safe_rows($pdo,"SELECT ps.*,COALESCE(c.client_name,q.client_name) client_name,COALESCE(c.contract_code,q.quote_code) code FROM payment_schedules ps LEFT JOIN contracts c ON c.id=ps.contract_id LEFT JOIN quotations q ON q.id=ps.quotation_id WHERE ps.status!='paid' AND ps.due_date<CURDATE() ORDER BY ps.due_date ASC LIMIT 6");
$riskProjects=safe_rows($pdo,"SELECT p.*,u.name owner_name,(SELECT COUNT(*) FROM tasks t WHERE t.project_id=p.id AND t.status!='Done' AND t.deadline<CURDATE()) overdue_tasks FROM projects p LEFT JOIN users u ON u.id=p.owner_id WHERE p.health IN ('Risk','Delayed') OR p.end_date<CURDATE() ORDER BY p.end_date ASC LIMIT 6");
$waitingApproval=safe_rows($pdo,"SELECT t.*,p.name project_name,u.name assignee_name,u.avatar assignee_avatar FROM tasks t LEFT JOIN projects p ON p.id=t.project_id LEFT JOIN users u ON u.id=t.assignee_id WHERE t.status='Waiting Approval' ORDER BY t.submitted_at DESC,t.deadline ASC LIMIT 6");
?>
<section class="card ceo31-hero">
  <div class="card-head">
    <div>
      <span class="eyebrow">SPRINT 31 · CEO DASHBOARD</span>
      <h2>Operating Dashboard</h2>
      <p class="muted">Một màn hình để nhìn dòng tiền, hiệu suất nhân sự, task cần duyệt và rủi ro dự án trong tháng.</p>
    </div>
    <form class="month-switch" method="get"><input type="hidden" name="page" value="dashboard"><input type="month" name="month" value="<?= e($month) ?>"><button class="btn btn-soft">Xem tháng</button></form>
  </div>
  <div class="ceo31-kpis">
    <a href="app.php?page=business_finance&month=<?= e($month) ?>"><span>Tiền vào</span><b><?= money_short($flow['cash_collected']) ?></b><small>Đã thu trong tháng</small></a>
    <a href="app.php?page=business_finance&month=<?= e($month) ?>"><span>Tiền ra</span><b><?= money_short($flow['internal_cost_total']+$flow['payroll_total']+$flow['expense_total']) ?></b><small>Cost + payroll + expense</small></a>
    <a href="app.php?page=business_finance&month=<?= e($month) ?>"><span>Lợi nhuận cash</span><b><?= money_short($flow['cash_profit']) ?></b><small>Dòng tiền sau chi</small></a>
    <a href="app.php?page=attendance&month=<?= e($month) ?>"><span>Work Score</span><b><?= $avgScore ?></b><small><?= number_format($totalHours,1,',','.') ?>h · <?= number_format($totalDays,1,',','.') ?> công</small></a>
  </div>
</section>

<div class="ceo31-grid">
  <section class="card ceo31-chart-card">
    <div class="card-head"><div><h2>Biểu đồ doanh số 6 tháng</h2><p class="muted">Dùng để đặt mục tiêu doanh thu, kiểm soát tiền vào/ra và lợi nhuận.</p></div><a class="btn btn-soft" href="app.php?page=business_finance">Finance</a></div>
    <div class="ceo31-bars">
      <?php foreach($monthSeries as $r): ?>
      <div class="ceo31-month">
        <div class="ceo31-barbox">
          <i class="income" title="Tiền vào" style="height:<?= max(8,round($r['income']/$maxChart*180)) ?>px"></i>
          <i class="outcome" title="Tiền ra" style="height:<?= max(8,round($r['outcome']/$maxChart*180)) ?>px"></i>
          <i class="profit" title="Lợi nhuận" style="height:<?= max(8,round(abs($r['profit'])/$maxChart*180)) ?>px"></i>
        </div>
        <b><?= e($r['label']) ?></b><small><?= money_short($r['income']) ?></small>
      </div>
      <?php endforeach; ?>
    </div>
    <div class="chart-legend"><span><i class="income"></i>Tiền vào</span><span><i class="outcome"></i>Tiền ra</span><span><i class="profit"></i>Lợi nhuận</span></div>
  </section>

  <section class="card ceo31-team-card">
    <div class="card-head"><div><h2>Team Work Score</h2><p class="muted">Tính từ công, giờ làm, task đúng hạn, Mcoin và lỗi chấm công.</p></div><a class="btn btn-soft" href="app.php?page=attendance&month=<?= e($month) ?>">Bảng công</a></div>
    <div class="ceo31-team-list">
      <?php foreach($topTeam as $s): ?>
      <div class="ceo31-person">
        <div class="person-main"><?= avatar_html(['name'=>$s['user']['name'],'avatar'=>$s['user']['avatar']],true) ?><div><b><?= e($s['user']['name']) ?></b><small><?= number_format($s['days'],1,',','.') ?> công · <?= number_format($s['hours'],1,',','.') ?>h · OT <?= number_format($s['ot_hours'],1,',','.') ?>h</small></div></div>
        <span class="score-pill <?= $s['score']>=85?'good':($s['score']>=60?'ok':'risk') ?>"><?= (int)$s['score'] ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </section>
</div>

<div class="ceo31-grid-3">
  <section class="card">
    <div class="card-head"><h2>Công nợ quá hạn</h2><a class="btn btn-soft" href="app.php?page=payments">Chase</a></div>
    <table class="dense-table"><thead><tr><th>Khách</th><th>Mã</th><th>Số tiền</th><th>Due</th></tr></thead><tbody>
    <?php foreach($overdue as $p): ?><tr><td><b><?= e($p['client_name']) ?></b></td><td><?= e($p['code']) ?></td><td><?= money($p['amount']) ?></td><td><?= e($p['due_date']) ?></td></tr><?php endforeach; ?>
    <?php if(empty($overdue)): ?><tr><td colspan="4" class="muted">Không có công nợ quá hạn.</td></tr><?php endif; ?>
    </tbody></table>
  </section>

  <section class="card">
    <div class="card-head"><h2>Task chờ duyệt</h2><a class="btn btn-soft" href="app.php?page=approval_center">Duyệt</a></div>
    <table class="dense-table"><thead><tr><th>Task</th><th>Assignee</th><th>Deadline</th></tr></thead><tbody>
    <?php foreach($waitingApproval as $t): ?><tr><td><b><?= e($t['title']) ?></b><small><?= e($t['project_name']) ?></small></td><td><span class="user-chip"><?= avatar_html(['name'=>$t['assignee_name'],'avatar'=>$t['assignee_avatar']],true) ?><?= e($t['assignee_name']) ?></span></td><td><?= e($t['deadline']) ?></td></tr><?php endforeach; ?>
    <?php if(empty($waitingApproval)): ?><tr><td colspan="3" class="muted">Không có task chờ duyệt.</td></tr><?php endif; ?>
    </tbody></table>
  </section>

  <section class="card">
    <div class="card-head"><h2>Project risk</h2><a class="btn btn-soft" href="app.php?page=projects">Projects</a></div>
    <table class="dense-table"><thead><tr><th>Project</th><th>PM</th><th>Health</th></tr></thead><tbody>
    <?php foreach($riskProjects as $p): ?><tr><td><b><?= e($p['name']) ?></b><small><?= e($p['client_name']) ?></small></td><td><?= e($p['owner_name']) ?></td><td><span class="badge <?= badge_class($p['health']) ?>"><?= e($p['health']) ?></span></td></tr><?php endforeach; ?>
    <?php if(empty($riskProjects)): ?><tr><td colspan="3" class="muted">Không có project rủi ro.</td></tr><?php endif; ?>
    </tbody></table>
  </section>
</div>
