<?php
require __DIR__ . '/doc_templates.php';
