<?php
if(!is_director_role() && !is_finance_role()) die('Bạn không có quyền dùng AI Quote.');
require_once __DIR__ . '/../services/ai/AIService.php';
require_once __DIR__ . '/../services/ai/PromptBuilder.php';
require_once __DIR__ . '/../services/ai/QuoteBuilder.php';
require_once __DIR__ . '/../services/ai/CostBuilder.php';
require_once __DIR__ . '/../services/ai/ContractBuilder.php';
require_once __DIR__ . '/../services/ai/KnowledgeBuilder.php';
require_once __DIR__ . '/../services/ai/DocumentBuilder.php';

$ai = new AIService($pdo);
$quoteId = (int)($_GET['quotation_id'] ?? $_POST['quotation_id'] ?? 0);
$quotation = null;
if($quoteId){
  $st=$pdo->prepare('SELECT * FROM quotations WHERE id=? LIMIT 1');
  $st->execute([$quoteId]);
  $quotation=$st->fetch();
}

function ai_redirect_quote($quoteId,$extra=''){
  redirect('app.php?page=ai_quote&amp;quotation_id='.$quoteId.$extra);
}

if(isset($_POST['generate_quote_ai']) && $quotation){
  $payload=PromptBuilder::quotationPayload($pdo,$quoteId);
  $payload=KnowledgeBuilder::appendToPayload($pdo,$payload,['finance','contract_marketing']);
  $res=$ai->generateFromTemplate('QUOTE_FULL_PROPOSAL',$payload,['source_type'=>'quotation','source_id'=>$quoteId,'type'=>'quotation','user_id'=>current_user()['id']]);
  if($res['ok']){
    $draftId=QuoteBuilder::saveDraft($pdo,$quoteId,'quote',$res['content'],current_user()['id']);
    ai_redirect_quote($quoteId,'&amp;draft='.$draftId);
  }
  $_SESSION['flash_ai']='❌ '.$res['message'];
  ai_redirect_quote($quoteId);
}

if(isset($_POST['generate_cost_ai']) && $quotation){
  $payload=PromptBuilder::quotationPayload($pdo,$quoteId);
  $payload=KnowledgeBuilder::appendToPayload($pdo,$payload,['finance']);
  $res=$ai->generateFromTemplate('COST_INTERNAL_PLAN',$payload,['source_type'=>'quotation','source_id'=>$quoteId,'type'=>'internal_cost','user_id'=>current_user()['id']]);
  if($res['ok']){
    $draftId=QuoteBuilder::saveDraft($pdo,$quoteId,'cost',$res['content'],current_user()['id']);
    ai_redirect_quote($quoteId,'&amp;draft='.$draftId);
  }
  $_SESSION['flash_ai'] = '❌ '.$res['message'];
  ai_redirect_quote($quoteId);
}

if(isset($_GET['apply_cost']) && $quotation){
  $draftId=(int)$_GET['apply_cost'];
  $st=$pdo->prepare('SELECT * FROM quotation_ai_drafts WHERE id=? AND quotation_id=?');
  $st->execute([$draftId,$quoteId]);
  $draft=$st->fetch();
  if($draft){
    $res=CostBuilder::applyInternalCostJson($pdo,$quoteId,$draft['generated_content']);
    $_SESSION['flash_ai']=($res['ok']?'✅ ':'❌ ').$res['message'];
  }
  ai_redirect_quote($quoteId);
}

if(isset($_POST['generate_contract_ai']) && $quotation){
  $payload=PromptBuilder::contractPayloadFromQuotation($pdo,$quoteId);
  $type=$_POST['contract_type'] ?? 'CONTRACT_MARKETING';
  $kbCats = $type==='CONTRACT_HOSTING' ? ['contract_hosting','finance'] : ($type==='CONTRACT_FREELANCER' ? ['contract_freelancer','finance'] : ['contract_marketing','finance']);
  $payload=KnowledgeBuilder::appendToPayload($pdo,$payload,$kbCats);
  $res=$ai->generateFromTemplate($type,$payload,['source_type'=>'quotation','source_id'=>$quoteId,'type'=>'contract','user_id'=>current_user()['id']]);
  if($res['ok']){
    $saved=DocumentBuilder::saveHtml($pdo,'quotation',$quoteId,'contract',$quotation['quote_code'].' Contract',$res['content'],current_user()['id']);
    $content="<p><b>Generated Contract:</b> <a href='".e($saved['path'])."' target='_blank'>Open / Print Contract</a></p>".$res['content'];
    $draftId=QuoteBuilder::saveDraft($pdo,$quoteId,'contract',$content,current_user()['id']);
    ai_redirect_quote($quoteId,'&amp;draft='.$draftId);
  }
  $_SESSION['flash_ai'] = '❌ '.$res['message'];
  ai_redirect_quote($quoteId);
}

if(isset($_POST['generate_acceptance_ai']) && $quotation){
  $payload=PromptBuilder::contractPayloadFromQuotation($pdo,$quoteId);
  $payload=KnowledgeBuilder::appendToPayload($pdo,$payload,['acceptance','finance']);
  $res=$ai->generateFromTemplate('ACCEPTANCE_REPORT',$payload,['source_type'=>'quotation','source_id'=>$quoteId,'type'=>'acceptance','user_id'=>current_user()['id']]);
  if($res['ok']){
    $saved=DocumentBuilder::saveHtml($pdo,'quotation',$quoteId,'acceptance',$quotation['quote_code'].' Acceptance Report',$res['content'],current_user()['id']);
    $content="<p><b>Acceptance Report:</b> <a href='".e($saved['path'])."' target='_blank'>Open / Print Acceptance</a></p>".$res['content'];
    $draftId=QuoteBuilder::saveDraft($pdo,$quoteId,'acceptance',$content,current_user()['id']);
    ai_redirect_quote($quoteId,'&amp;draft='.$draftId);
  }
  $_SESSION['flash_ai'] = '❌ '.$res['message'];
  ai_redirect_quote($quoteId);
}

if(isset($_POST['generate_payment_request_ai']) && $quotation){
  $paymentId=(int)($_POST['payment_id'] ?? 0);
  $payload=$paymentId ? PromptBuilder::paymentPayload($pdo,$paymentId) : PromptBuilder::quotationPayload($pdo,$quoteId);
  $payload=KnowledgeBuilder::appendToPayload($pdo,$payload,['finance']);
  $res=$ai->generateFromTemplate('PAYMENT_REQUEST',$payload,['source_type'=>$paymentId?'payment':'quotation','source_id'=>$paymentId?:$quoteId,'type'=>'payment_request','user_id'=>current_user()['id']]);
  if($res['ok']){
    $saved=DocumentBuilder::saveHtml($pdo,$paymentId?'payment':'quotation',$paymentId?:$quoteId,'payment_request',$quotation['quote_code'].' Payment Request',$res['content'],current_user()['id']);
    $content="<p><b>Payment Request:</b> <a href='".e($saved['path'])."' target='_blank'>Open / Print Payment Request</a></p>".$res['content'];
    $draftId=QuoteBuilder::saveDraft($pdo,$quoteId,'payment_request',$content,current_user()['id']);
    ai_redirect_quote($quoteId,'&amp;draft='.$draftId);
  }
  $_SESSION['flash_ai'] = '❌ '.$res['message'];
  ai_redirect_quote($quoteId);
}

if(isset($_GET['apply_draft'])){
  $result=QuoteBuilder::applyDraftToQuotation($pdo,(int)$_GET['apply_draft']);
  $_SESSION['flash_ai'] = ($result['ok']?'✅ ':'❌ ').$result['message'];
  ai_redirect_quote($quoteId);
}

if(isset($_GET['delete_draft'])){
  $pdo->prepare('DELETE FROM quotation_ai_drafts WHERE id=?')->execute([(int)$_GET['delete_draft']]);
  ai_redirect_quote($quoteId);
}

$quotes=$pdo->query('SELECT id,quote_code,client_name,title,status,created_at FROM quotations ORDER BY id DESC LIMIT 150')->fetchAll();
$drafts=[];$activeDraft=null;$payments=[];
if($quotation){
  $ds=$pdo->prepare('SELECT d.*,u.name user_name FROM quotation_ai_drafts d LEFT JOIN users u ON u.id=d.created_by WHERE d.quotation_id=? ORDER BY d.id DESC');
  $ds->execute([$quoteId]); $drafts=$ds->fetchAll();
  $ps=$pdo->prepare('SELECT * FROM payment_schedules WHERE quotation_id=? ORDER BY due_date,id');
  $ps->execute([$quoteId]); $payments=$ps->fetchAll();
  if(isset($_GET['draft'])){
    $st=$pdo->prepare('SELECT * FROM quotation_ai_drafts WHERE id=? AND quotation_id=?');
    $st->execute([(int)$_GET['draft'],$quoteId]);
    $activeDraft=$st->fetch();
  } elseif($drafts) $activeDraft=$drafts[0];
}
$flash=$_SESSION['flash_ai'] ?? ''; unset($_SESSION['flash_ai']);
?>
<section class="workspace-hero finance-hero ai-hero">
  <div>
    <span class="eyebrow">Sprint 7A Full</span>
    <h1>AI Quote / Cost / Contract</h1>
    <p class="muted">Generate proposal, internal cost, contract, acceptance và payment request theo dữ liệu Motive.</p>
  </div>
  <a class="btn btn-soft" href="app.php?page=ai_center">AI Center</a>
  <a class="btn btn-soft" href="app.php?page=doc_generate">Generate DOCX</a>
</section>
<?php if($flash): ?><div class="alert success"><?= e($flash) ?></div><?php endif; ?>

<section class="card">
  <div class="card-head"><h2>Chọn báo giá</h2></div>
  <form method="get" class="asana-toolbar">
    <input type="hidden" name="page" value="ai_quote">
    <select name="quotation_id" required>
      <option value="">Chọn quotation</option>
      <?php foreach($quotes as $q): ?><option value="<?= $q['id'] ?>" <?= $quoteId===$q['id']?'selected':'' ?>><?= e($q['quote_code'].' — '.$q['client_name'].' — '.$q['status']) ?></option><?php endforeach; ?>
    </select>
    <button class="primary">Mở AI tools</button>
  </form>
</section>

<?php if($quotation): ?>
<div class="two-col">
<section class="card">
  <div class="card-head"><div><h2><?= e($quotation['quote_code']) ?></h2><p class="muted"><?= e($quotation['client_name']) ?> · <?= e($quotation['status']) ?></p></div><a class="btn btn-soft" href="app.php?page=quotation_edit&id=<?= $quoteId ?>">Edit Quote</a></div>

  <form method="post" class="ai-tool-box">
    <input type="hidden" name="quotation_id" value="<?= $quoteId ?>">
    <h3>✨ Generate Full Proposal</h3>
    <p class="muted">Executive Summary, Scope, Deliverables, Timeline, Payment Terms.</p>
    <button class="primary" name="generate_quote_ai" value="1">Generate Proposal Draft</button>
  </form>

  <form method="post" class="ai-tool-box">
    <input type="hidden" name="quotation_id" value="<?= $quoteId ?>">
    <h3>💸 Generate Internal Cost</h3>
    <p class="muted">AI trả JSON cost plan. Sau khi preview có thể Apply vào Internal Cost.</p>
    <button class="btn btn-soft" name="generate_cost_ai" value="1">Generate Cost Plan</button>
  </form>

  <form method="post" class="ai-tool-box">
    <input type="hidden" name="quotation_id" value="<?= $quoteId ?>">
    <h3>📄 Generate Contract</h3>
    <select name="contract_type"><option value="CONTRACT_MARKETING">Marketing Retainer</option><option value="CONTRACT_HOSTING">Hosting</option><option value="CONTRACT_FREELANCER">Freelancer/CTV</option></select>
    <button class="btn btn-soft" name="generate_contract_ai" value="1">Generate Contract</button>
  </form>

  <form method="post" class="ai-tool-box">
    <input type="hidden" name="quotation_id" value="<?= $quoteId ?>">
    <h3>✅ Generate Acceptance Report</h3>
    <button class="btn btn-soft" name="generate_acceptance_ai" value="1">Generate Acceptance</button>
  </form>

  <form method="post" class="ai-tool-box">
    <input type="hidden" name="quotation_id" value="<?= $quoteId ?>">
    <h3>💳 Generate Payment Request</h3>
    <select name="payment_id"><option value="0">Theo toàn bộ báo giá</option><?php foreach($payments as $p): ?><option value="<?= $p['id'] ?>"><?= e(($p['milestone']?:$p['title']).' — '.money($p['amount'])) ?></option><?php endforeach; ?></select>
    <button class="btn btn-soft" name="generate_payment_request_ai" value="1">Generate Payment Request</button>
  </form>
</section>

<section class="card">
  <div class="card-head"><h2>AI Drafts</h2></div>
  <table class="dense-table"><thead><tr><th>Version</th><th>Type</th><th>By</th><th>Date</th><th>Action</th></tr></thead><tbody>
  <?php foreach($drafts as $d): ?><tr><td>V<?= $d['version_no'] ?></td><td><span class="badge purple"><?= e($d['draft_type']) ?></span></td><td><?= e($d['user_name']) ?></td><td><?= e($d['created_at']) ?></td><td><a class="btn btn-soft" href="app.php?page=ai_quote&amp;quotation_id=<?= $quoteId ?>&amp;draft=<?= $d['id'] ?>">Preview</a> <a class="btn btn-soft" onclick="return confirm('Xóa draft?')" href="app.php?page=ai_quote&amp;quotation_id=<?= $quoteId ?>&amp;delete_draft=<?= $d['id'] ?>">Xóa</a></td></tr><?php endforeach; ?>
  <?php if(empty($drafts)): ?><tr><td colspan="5" class="muted">Chưa có AI draft.</td></tr><?php endif; ?>
  </tbody></table>
</section>
</div>

<?php if($activeDraft): ?>
<section class="card">
  <div class="card-head">
    <div><h2>Preview Draft V<?= (int)$activeDraft['version_no'] ?> — <?= e($activeDraft['draft_type']) ?></h2><p class="muted"><?= e($activeDraft['created_at']) ?></p></div>
    <div>
      <?php if($activeDraft['draft_type']==='quote'): ?><a class="primary" href="app.php?page=ai_quote&amp;quotation_id=<?= $quoteId ?>&amp;apply_draft=<?= $activeDraft['id'] ?>">Apply vào Quote Intro</a><?php endif; ?>
      <?php if($activeDraft['draft_type']==='cost'): ?><a class="primary" href="app.php?page=ai_quote&amp;quotation_id=<?= $quoteId ?>&amp;apply_cost=<?= $activeDraft['id'] ?>">Apply Internal Cost</a><?php endif; ?>
    </div>
  </div>
  <div class="ai-preview-content"><?= $activeDraft['generated_content'] ?></div>
</section>
<?php endif; ?>
<?php endif; ?>
