<?php
if(!is_director_role() && !is_finance_role()) die('Bạn không có quyền xem Generate Center.');
$recent=safe_rows($pdo,"SELECT gd.*,dt.template_name FROM generated_documents gd LEFT JOIN document_templates dt ON dt.id=gd.template_id ORDER BY gd.id DESC LIMIT 12");
?>
<section class="workspace-hero ai-workspace-hero">
  <div><span class="eyebrow">AI Workspace</span><h1>Generate Center</h1><p class="muted">Một nơi duy nhất để generate proposal, quotation, contract, invoice và DOCX.</p></div>
</section>

<div class="generate-grid">
  <a class="generate-card" href="app.php?page=ai_proposal_engine"><b>AI Proposal Engine V2</b><span>Generate proposal từ Knowledge Base + Prompt Studio + báo giá.</span></a>
  <a class="generate-card" href="app.php?page=ai_quote"><b>Generate Quotation</b><span>Tạo draft báo giá từ AI.</span></a>
  <a class="generate-card" href="app.php?page=doc_generate"><b>Generate Contract / DOCX</b><span>Xuất file Word từ báo giá và template.</span></a>
  <a class="generate-card" href="app.php?page=quotation_create"><b>Smart Quotation Builder</b><span>Tạo báo giá có item, cost, VAT.</span></a>
  <a class="generate-card" href="app.php?page=ai_document_library"><b>Choose Template</b><span>Chọn template trước khi generate.</span></a>
</div>

<section class="card">
  <div class="card-head"><h2>Recent Generated Files</h2></div>
  <table class="dense-table">
    <thead><tr><th>Code</th><th>Title</th><th>Type</th><th>Template</th><th>Action</th></tr></thead>
    <tbody>
      <?php foreach($recent as $r): ?>
        <tr><td><b><?= e($r['document_code']) ?></b></td><td><?= e($r['title']) ?></td><td><?= e($r['document_type']) ?></td><td><?= e($r['template_name']) ?></td><td><?php if($r['docx_path']): ?><a class="btn btn-soft" href="<?= e($r['docx_path']) ?>" target="_blank">Download</a><?php endif; ?></td></tr>
      <?php endforeach; ?>
      <?php if(empty($recent)): ?><tr><td colspan="5" class="muted">Chưa có file generated.</td></tr><?php endif; ?>
    </tbody>
  </table>
</section>
