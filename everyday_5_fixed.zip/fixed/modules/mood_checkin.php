<?php
$me=current_user();
$moods=[
  'very_happy'=>'😄 Rất vui',
  'good'=>'🙂 Ổn',
  'normal'=>'😐 Bình thường',
  'overloaded'=>'😵 Hơi quá tải',
  'sad'=>'😔 Hơi buồn'
];
$locations=['Office'=>'🏢 Office','Remote'=>'🏠 Remote','Onsite'=>'🎬 Onsite','Business Trip'=>'✈️ Công tác'];

if($_SERVER['REQUEST_METHOD']==='POST'){
  $mood=$_POST['mood'] ?? 'normal';
  $score=mood_score($mood);
  $pdo->prepare('INSERT INTO mood_checkins(user_id,checkin_date,mood,energy_score,work_location,focus_1,focus_2,focus_3,need_support,note)
    VALUES(?,?,?,?,?,?,?,?,?,?)
    ON DUPLICATE KEY UPDATE mood=VALUES(mood),energy_score=VALUES(energy_score),work_location=VALUES(work_location),focus_1=VALUES(focus_1),focus_2=VALUES(focus_2),focus_3=VALUES(focus_3),need_support=VALUES(need_support),note=VALUES(note),updated_at=NOW()')
    ->execute([$me['id'],date('Y-m-d'),$mood,$score,$_POST['work_location']??'Office',$_POST['focus_1']??'',$_POST['focus_2']??'',$_POST['focus_3']??'',isset($_POST['need_support'])?1:0,$_POST['note']??'']);

  if(isset($_POST['need_support'])){
    try {
      $admins=$pdo->query("SELECT id FROM users WHERE role IN ('CEO','Director','HR') OR email='admin@motive.vn'")->fetchAll();
      foreach($admins as $a){
        create_notification($pdo,$a['id'],'Mood cần quan tâm',($me['name']??'Nhân sự').' đang cần hỗ trợ hôm nay','mood','app.php?page=dashboard');
      }
    } catch(Exception $e){}
  }
  log_activity($pdo,'mood_checkin','mood',$me['id'],'Mood check-in hôm nay');
  redirect($_POST['redirect_to'] ?? 'app.php?page=workspace');
}

$stmt=$pdo->prepare('SELECT * FROM mood_checkins WHERE user_id=? AND checkin_date=CURDATE() LIMIT 1');
$stmt->execute([$me['id']]);
$current=$stmt->fetch();
?>
<section class="mood-page-card">
  <div class="mood-card">
    <span class="eyebrow">Daily Pulse</span>
    <h1>Năng lượng hôm nay của bạn thế nào?</h1>
    <p>Chia sẻ nhanh để CEO/HR nắm được tinh thần team và hỗ trợ đúng lúc.</p>
    <form method="post">
      <input type="hidden" name="redirect_to" value="<?= e($_GET['redirect_to'] ?? 'app.php?page=workspace') ?>">
      <div class="mood-options">
        <?php foreach($moods as $key=>$label): ?>
          <label class="mood-option <?= ($current['mood']??'')===$key?'selected':'' ?>">
            <input type="radio" name="mood" value="<?= e($key) ?>" <?= (($current['mood']??'normal')===$key || (!$current && $key==='normal'))?'checked':'' ?>>
            <span><?= e($label) ?></span>
          </label>
        <?php endforeach; ?>
      </div>
      <label>Hôm nay bạn làm việc ở đâu?</label>
      <select name="work_location"><?php foreach($locations as $key=>$label): ?><option value="<?= e($key) ?>" <?= ($current['work_location']??'Office')===$key?'selected':'' ?>><?= e($label) ?></option><?php endforeach; ?></select>
      <label>3 việc quan trọng nhất hôm nay</label>
      <input name="focus_1" placeholder="Việc #1" value="<?= e($current['focus_1']??'') ?>">
      <input name="focus_2" placeholder="Việc #2" value="<?= e($current['focus_2']??'') ?>">
      <input name="focus_3" placeholder="Việc #3" value="<?= e($current['focus_3']??'') ?>">
      <label class="check-row"><input type="checkbox" name="need_support" <?= !empty($current['need_support'])?'checked':'' ?>> Mình cần CEO/HR hỗ trợ hôm nay</label>
      <label>Ghi chú ngắn</label>
      <textarea name="note" placeholder="Có điều gì team cần biết không?"><?= e($current['note']??'') ?></textarea>
      <button class="primary">Lưu Daily Pulse</button>
    </form>
  </div>
</section>
