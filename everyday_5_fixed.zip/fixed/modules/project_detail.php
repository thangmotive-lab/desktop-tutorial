<?php
$id=(int)($_GET['id']??0);
$stmt=$pdo->prepare('SELECT p.*,u.name owner_name,u.avatar owner_avatar FROM projects p LEFT JOIN users u ON u.id=p.owner_id WHERE p.id=?');
$stmt->execute([$id]);
$p=$stmt->fetch();
if(!$p) die('Không tìm thấy project.');


function handle_project_avatar_upload_detail($current=''){
  if(!empty($_FILES['project_avatar']['name'])){
    $ext=strtolower(pathinfo($_FILES['project_avatar']['name'],PATHINFO_EXTENSION));
    if(!in_array($ext,['jpg','jpeg','png','webp','gif'])) return $current;
    $dir=__DIR__.'/../uploads/projects';
    if(!is_dir($dir)) mkdir($dir,0775,true);
    $filename='uploads/projects/project_'.time().'_'.rand(1000,9999).'.'.$ext;
    move_uploaded_file($_FILES['project_avatar']['tmp_name'],__DIR__.'/../'.$filename);
    return $filename;
  }
  return $current;
}

if(isset($_POST['save_project_general'])){
  $avatar=handle_project_avatar_upload_detail($_POST['current_avatar']??($p['avatar']??''));
  $pdo->prepare("UPDATE projects SET name=?, client_name=?, project_type=?, health=?, status=?, start_date=?, end_date=?, objective=?, description=?, avatar=? WHERE id=?")
    ->execute([$_POST['name'],$_POST['client_name'],$_POST['project_type'],$_POST['health'],$_POST['status'],$_POST['start_date']?:null,$_POST['end_date']?:null,$_POST['objective']??'',$_POST['description']??'',$avatar,$id]);
  redirect('app.php?page=project_detail&id='.$id.'&updated=1');
}

if(isset($_POST['save_section_order'])){
  foreach($_POST['section_order']??[] as $section=>$order){
    $pdo->prepare("INSERT INTO project_section_order(project_id,section_name,sort_order) VALUES(?,?,?) ON DUPLICATE KEY UPDATE sort_order=VALUES(sort_order)")
      ->execute([$id,$section,(int)$order]);
  }
  redirect('app.php?page=project_detail&id='.$id.'&amazing=1');
}

if(isset($_POST['generate_quote_tasks'])){
  $source = trim($_POST['source_note'] ?? 'Contract deliverable');
  $created=0;
  $items=[];
  if(!empty($p['quotation_id'])){
    try{
      $st=$pdo->prepare("SELECT item_name,description,quantity FROM quotation_items WHERE quotation_id=? ORDER BY id ASC");
      $st->execute([$p['quotation_id']]);
      $items=$st->fetchAll();
    }catch(Exception $e){}
  }
  if(empty($items)){
    $items=[['item_name'=>'Kickoff & planning','description'=>$source,'quantity'=>1],['item_name'=>'Production / Execution','description'=>$source,'quantity'=>1],['item_name'=>'Review & handover','description'=>$source,'quantity'=>1]];
  }
  foreach($items as $it){
    $title=trim($it['item_name'] ?? $it['title'] ?? '');
    if($title==='') continue;
    $exists=$pdo->prepare("SELECT id FROM tasks WHERE project_id=? AND title=? LIMIT 1");
    $exists->execute([$id,$title]);
    if($exists->fetch()) continue;
    $pdo->prepare("INSERT INTO tasks(project_id,title,brief,status,priority,phase,deliverable_count,created_by,created_at) VALUES(?,?,?,?,?,?,?,?,NOW())")
      ->execute([$id,$title,$it['description'] ?? $source,'Todo','Quan trọng','General',(int)($it['quantity']??1),current_user()['id']]);
    $created++;
  }
  log_activity($pdo,'generate','project_tasks',$id,'Generate '.$created.' task từ hợp đồng/báo giá');
  redirect('app.php?page=project_detail&id='.$id.'&generated='.$created);
}




if(isset($_POST['save_task_drawer'])){
  $tid=(int)$_POST['task_id'];
  $allowed = true;
  $st=$pdo->prepare("SELECT * FROM tasks WHERE id=? AND project_id=? LIMIT 1");
  $st->execute([$tid,$id]);
  $oldTask=$st->fetch();
  if($oldTask && $allowed){
    $pdo->prepare("UPDATE tasks SET title=?, brief=?, description=?, assignee_id=?, priority=?, deadline=?, status=?, reference_link=?, file_link=? WHERE id=? AND project_id=?")
      ->execute([
        trim($_POST['title']??''),
        $_POST['brief']??'',
        $_POST['description']??'',
        ($_POST['assignee_id']??'')?:null,
        normalize_priority($_POST['priority'] ?? ''),
        ($_POST['deadline']??'')?:null,
        $_POST['status']??'Todo',
        $_POST['reference_link']??'',
        $_POST['file_link']??'',
        $tid,$id
      ]);
    log_activity($pdo,'update','task',$tid,'Cập nhật task từ drawer');
  }
  redirect('app.php?page=project_detail&id='.$id.'&task_saved=1');
}

if(isset($_POST['add_task_comment_drawer'])){
  $tid=(int)$_POST['task_id'];
  $comment=trim($_POST['comment']??'');
  if($comment!==''){
    $pdo->prepare("INSERT INTO task_comments(task_id,user_id,comment) VALUES(?,?,?)")->execute([$tid,current_user()['id'],$comment]);
    $cid=$pdo->lastInsertId();
    if(function_exists('create_task_mentions_from_comment')) create_task_mentions_from_comment($pdo,$tid,$cid,$comment,current_user()['id']);
    log_activity($pdo,'comment','task',$tid,'Comment task drawer');
  }
  redirect('app.php?page=project_detail&id='.$id.'&task_commented=1');
}

if(isset($_GET['delete_project_task'])){
  $tid=(int)$_GET['delete_project_task'];
  if(user_is_admin() || (int)$p['owner_id']===(int)current_user()['id']){
    $pdo->prepare('DELETE FROM task_comments WHERE task_id=?')->execute([$tid]);
    try{ $pdo->prepare('DELETE FROM task_links WHERE task_id=?')->execute([$tid]); }catch(Exception $e){}
    $pdo->prepare('DELETE FROM tasks WHERE id=? AND project_id=?')->execute([$tid,$id]);
    log_activity($pdo,'delete','task',$tid,'Xóa task trong project');
  }
  redirect('app.php?page=project_detail&id='.$id);
}
if(isset($_POST['add_project_file_link'])){
  $title=trim($_POST['title']??'');
  $url=trim($_POST['url']??'');
  if($url!==''){
    $pdo->prepare('INSERT INTO file_links(title,url,related_type,related_id,note,created_by) VALUES(?,?,?,?,?,?)')
      ->execute([$title?:'Link',$url,'project',$id,$_POST['note']??'',current_user()['id']]);
  }
  redirect('app.php?page=project_detail&id='.$id.'#projectFiles');
}

if(isset($_POST['save_project_file'])){
  $pdo->prepare('INSERT INTO file_links(title,url,related_type,related_id,note,created_by) VALUES(?,?,?,?,?,?)')
    ->execute([$_POST['title'],$_POST['url'],'project',$id,$_POST['note'],current_user()['id']]);
  log_activity($pdo,'create','project_file',$id,'Thêm file link trong project');
  redirect('app.php?page=project_detail&id='.$id.'#projectFiles');
}
if(isset($_POST['update_project_folders'])){
  $pdo->prepare('UPDATE projects SET drive_folder_link=?, canva_folder_link=? WHERE id=?')->execute([$_POST['drive_folder_link'],$_POST['canva_folder_link'],$id]);
  redirect('app.php?page=project_detail&id='.$id.'#projectFiles');
}


if(isset($_POST['save_deliverables'])){
  $pdo->prepare('DELETE FROM project_deliverables WHERE project_id=?')->execute([$id]);
  foreach($_POST['deliverables']??[] as $d){
    $type=trim($d['type']??'');
    if($type==='') continue;
    $pdo->prepare('INSERT INTO project_deliverables(project_id,deliverable_type,target_count,note) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE target_count=VALUES(target_count), note=VALUES(note)')
      ->execute([$id,$type,(int)($d['target']??0),$d['note']??'']);
  }
  log_activity($pdo,'update','project_deliverables',$id,'Cập nhật deliverable target');
  redirect('app.php?page=project_detail&id='.$id);
}


if(isset($_GET['advance'])){
  $tid=(int)$_GET['advance'];
  $stmt=$pdo->prepare('SELECT * FROM tasks WHERE id=? AND project_id=?');$stmt->execute([$tid,$id]);$task=$stmt->fetch();
  if($task){
    $next=task_status_next($task['status']);
    if($next==='Waiting Approval') $pdo->prepare('UPDATE tasks SET status=?, submitted_at=NOW() WHERE id=?')->execute([$next,$tid]);
    elseif($next==='Done' && (user_is_admin() || (int)$task['created_by']===(int)current_user()['id'] || (int)$p['owner_id']===(int)current_user()['id'])) $pdo->prepare('UPDATE tasks SET status=?, approved_by=?, approved_at=NOW(), completed_at=NOW() WHERE id=?')->execute([$next,current_user()['id'],$tid]);
    else $pdo->prepare('UPDATE tasks SET status=? WHERE id=?')->execute([$next,$tid]);
  }
  redirect('app.php?page=project_detail&id='.$id);
}
if(isset($_GET['request_help_project'])){
  $tid=(int)$_GET['request_help_project'];
  $pdo->prepare("UPDATE tasks SET need_support=1, help_requested=1, help_requested_at=NOW() WHERE id=? AND project_id=?")->execute([$tid,$id]);
  if(!empty($p['owner_id'])) create_notification($pdo,$p['owner_id'],'Task cần hỗ trợ','Có task trong project '.$p['name'].' cần hỗ trợ','help','app.php?page=project_detail&id='.$id);
  log_activity($pdo,'request_help','task',$tid,'Báo cần hỗ trợ trong project');
  redirect('app.php?page=project_detail&id='.$id);
}
if(isset($_GET['approve'])){
  $tid=(int)$_GET['approve'];
  if(user_is_admin() || (int)$p['owner_id']===(int)current_user()['id']){
    $pdo->prepare("UPDATE tasks SET status='Done', approved_by=?, approved_at=NOW(), completed_at=NOW() WHERE id=? AND project_id=?")->execute([current_user()['id'],$tid,$id]);
  }
  redirect('app.php?page=project_detail&id='.$id.'&yay=1');
}
if(isset($_POST['add_project_comment'])){
  $tid=(int)$_POST['task_id'];
  $comment=trim($_POST['comment']);
  if($comment!==''){
    $pdo->prepare('INSERT INTO task_comments(task_id,user_id,comment) VALUES(?,?,?)')->execute([$tid,current_user()['id'],$comment]);
    $cid=$pdo->lastInsertId();
    if(function_exists('create_task_mentions_from_comment')) create_task_mentions_from_comment($pdo,$tid,$cid,$comment,current_user()['id']);
    log_activity($pdo,'comment','task',$tid,'Bình luận task trong project');
  }
  redirect('app.php?page=project_detail&id='.$id);
}

$users=$pdo->query('SELECT id,name,avatar FROM users ORDER BY name')->fetchAll();
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['save_task'])){
  $stmt=$pdo->prepare('INSERT INTO tasks(project_id,title,assignee_id,priority,start_date,deadline,status,phase,brief,deliverable,deliverable_type,deliverable_count,reference_link,approver,file_link,created_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
  $stmt->execute([$id,$_POST['title'],$_POST['assignee_id'],$_POST['priority'],$_POST['start_date'],$_POST['deadline'],$_POST['status'],$_POST['phase'],$_POST['brief'],$_POST['deliverable'],$_POST['deliverable_type'],$_POST['deliverable_count']?:1,$_POST['reference_link'],$_POST['approver'],$_POST['file_link'],current_user()['id']]);
  create_notification($pdo,$_POST['assignee_id'],'Task mới','Bạn được giao task: '.$_POST['title'],'task','app.php?page=project_detail&id='.$id);
  redirect('app.php?page=project_detail&id='.$id);
}

$stmt=$pdo->prepare('SELECT t.*,u.name assignee_name,u.avatar assignee_avatar,
  (SELECT COUNT(*) FROM task_comments c WHERE c.task_id=t.id) comment_count
  FROM tasks t LEFT JOIN users u ON u.id=t.assignee_id WHERE t.project_id=? ORDER BY phase ASC, deadline ASC, id DESC');
$stmt->execute([$id]);
$tasks=$stmt->fetchAll();
$groups=[];foreach($tasks as $t){$groups[$t['phase'] ?: 'General'][]=$t;}
$orderRows=safe_rows($pdo,"SELECT section_name,sort_order FROM project_section_order WHERE project_id=$id");
$sectionOrder=[];foreach($orderRows as $or){$sectionOrder[$or['section_name']]=(int)$or['sort_order'];}
uksort($groups,function($a,$b) use($sectionOrder){
  if($a==='General' && $b!=='General') return -1;
  if($b==='General' && $a!=='General') return 1;
  return ($sectionOrder[$a]??999) <=> ($sectionOrder[$b]??999) ?: strcmp($a,$b);
});
list($done,$total,$pct)=project_progress_from_tasks($pdo,$id);
$waiting=0;$support=0;
foreach($tasks as $t){
  if($t['status']==='Waiting Approval')$waiting++;
  if($t['need_support']||$t['help_requested'])$support++;
}
$deliverables = deliverable_summary($pdo,$id);
$fileStmt=$pdo->prepare("SELECT fl.*,u.name user_name,u.avatar user_avatar FROM file_links fl LEFT JOIN users u ON u.id=fl.created_by WHERE fl.related_type='project' AND fl.related_id=? ORDER BY fl.id DESC");
$fileStmt->execute([$id]);
$fileLinks=$fileStmt->fetchAll();

$commentsByTask=[];
if(!empty($tasks)){
  $ids=array_map(fn($x)=>(int)$x['id'],$tasks);
  $in=implode(',',array_fill(0,count($ids),'?'));
  $cs=$pdo->prepare("SELECT c.*,u.name user_name,u.avatar user_avatar FROM task_comments c LEFT JOIN users u ON u.id=c.user_id WHERE c.task_id IN ($in) ORDER BY c.id ASC");
  $cs->execute($ids);
  foreach($cs->fetchAll() as $c){ $commentsByTask[(int)$c['task_id']][]=$c; }
}


?>
<?php if(!empty($_GET['yay'])): ?><div class="yay-toast">YAY-ME ✨</div><?php endif; ?>
<section class="project-compact-header workspace-detail-hero">
  <div class="project-compact-main">
    <?php if(!empty($p['avatar'])): ?><span class="project-compact-avatar"><img src="<?= e($p['avatar']) ?>" alt=""></span><?php else: ?><span class="project-compact-avatar"><?= e(mb_substr($p['name'],0,1)) ?></span><?php endif; ?>
    <div class="project-compact-copy">
      <span class="eyebrow">Project Detail</span>
      <h1><?= e($p['name']) ?></h1>
      <div class="project-compact-meta">
        <span><?= e($p['client_name']) ?></span>
        <span><?= e($p['project_type']) ?></span>
        <span>PM: <?= e($p['owner_name'] ?: '-') ?></span>
        <span><?= e($p['start_date'] ?: '-') ?> → <?= e($p['end_date'] ?: '-') ?></span>
        <span class="badge <?= $p['health']==='Delayed'?'red':($p['health']==='Risk'?'orange':'green') ?>"><?= e($p['health'] ?: 'On Track') ?></span>
        <span class="badge <?= badge_class($p['status']) ?>"><?= e($p['status']) ?></span>
      </div>
    </div>
  </div>
  <div class="project-compact-actions">
    <a class="btn btn-soft btn-outline-icon" href="app.php?page=projects"><span aria-hidden="true">←</span> Projects</a>
    <button class="btn btn-soft btn-outline-icon" onclick="openModal('projectGeneralModal')">Edit</button>
    <button class="btn btn-soft btn-outline-icon" onclick="openModal('generateTasksModal')">Từ báo giá</button>
    <button class="primary compact-primary" onclick="openSlideDrawer('taskDrawer')">+ Task</button>
  </div>
</section>
<div class="modal-backdrop" id="projectGeneralModal">
  <div class="modal-panel large-modal">
    <button class="modal-close" onclick="closeModal('projectGeneralModal')">×</button>
    <h2>Edit Project Details</h2>
    <form method="post" enctype="multipart/form-data">
      <input type="hidden" name="save_project_general" value="1">
      <input type="hidden" name="current_avatar" value="<?= e($p['avatar'] ?? '') ?>">
      <label>Avatar dự án</label>
      <?php if(!empty($p['avatar'])): ?><p><img src="<?= e($p['avatar']) ?>" style="width:72px;height:72px;object-fit:cover;border-radius:22px"></p><?php endif; ?>
      <input type="file" name="project_avatar" accept="image/*">
      <div class="form-row"><div><label>Tên project</label><input name="name" value="<?= e($p['name']) ?>"></div><div><label>Client</label><input name="client_name" value="<?= e($p['client_name']) ?>"></div></div>
      <div class="form-row"><div><label>Type</label><input name="project_type" value="<?= e($p['project_type']) ?>"></div><div><label>Health</label><input name="health" value="<?= e($p['health']) ?>"></div></div>
      <div class="form-row"><div><label>Status</label><input name="status" value="<?= e($p['status']) ?>"></div><div><label>Start</label><input type="date" name="start_date" value="<?= e($p['start_date']) ?>"></div></div>
      <label>End</label><input type="date" name="end_date" value="<?= e($p['end_date']) ?>">
      <label>Objective</label><textarea name="objective" rows="4"><?= e($p['objective'] ?? '') ?></textarea>
      <label>Mô tả project</label><textarea name="description" rows="5"><?= e($p['description'] ?? '') ?></textarea>
      <button class="primary">Lưu project details</button>
    </form>
  </div>
</div>

<div class="modal-backdrop" id="sectionOrderModal">
  <div class="modal-panel">
    <button class="modal-close" onclick="closeModal('sectionOrderModal')">×</button>
    <h2>Sắp xếp section</h2>
    <form method="post">
      <input type="hidden" name="save_section_order" value="1">
      <?php $k=1; foreach(array_keys($groups) as $phase): ?>
        <div class="form-row"><div><label><?= e($phase) ?></label><input type="number" name="section_order[<?= e($phase) ?>]" value="<?= e($sectionOrder[$phase] ?? $k) ?>"></div></div>
      <?php $k++; endforeach; ?>
      <button class="primary">Lưu thứ tự</button>
    </form>
  </div>
</div>

<div class="modal-backdrop" id="generateTasksModal">
  <div class="modal-panel">
    <button class="modal-close" onclick="closeModal('generateTasksModal')">×</button>
    <h2>Generate task từ báo giá/Báo giá</h2>
    <p class="muted">Hệ thống sẽ tạo các đầu task từ các hạng mục trong báo giá đã gắn với project. Sau đó team tự phân người và thời gian.</p>
    <form method="post">
      <input type="hidden" name="generate_quote_tasks" value="1">
      <label>Ghi chú nguồn</label><input name="source_note" value="Generated from quotation items">
      <button class="primary">Generate tasks</button>
    </form>
  </div>
</div>


<?php foreach($groups as $phase=>$items): ?>
<section class="card dense-card project-task-section workspace-detail-card">
  <div class="card-head compact-card-head"><h2><?= e($phase) ?></h2></div>
  <table class="dense-table workspace-table">
    <thead><tr><th>Task</th><th>Assignee</th><th>Priority</th><th>Deadline</th><th>Status</th><th></th></tr></thead>
    <tbody>
    <?php foreach($items as $t): ?>
      <tr>
        <td class="task-name-cell <?= $t['status']==='Done'?'task-is-done':'' ?>">
          <?php if($t['status']!=='Done'): ?><a class="task-check js-task-delight-done" title="Hoàn thành / trạng thái tiếp theo" href="app.php?page=project_detail&id=<?= $id ?>&advance=<?= $t['id'] ?>" data-task-id="<?= $t['id'] ?>">✓</a><?php else: ?><span class="task-check done">✓</span><?php endif; ?>
          <div><button class="task-title-link task-detail-trigger" type="button" data-task-id="<?= $t['id'] ?>" data-task-title="<?= e($t['title']) ?>" data-task-brief="<?= e($t['brief']??'') ?>" data-task-desc="<?= e($t['description']??'') ?>" data-task-assignee="<?= e($t['assignee_name']??'') ?>" data-task-assignee-id="<?= e($t['assignee_id']??'') ?>" data-task-deadline="<?= e($t['deadline']??'') ?>" data-task-status="<?= e($t['status']??'') ?>" data-task-priority="<?= e(normalize_priority($t['priority']??'')) ?>" data-task-reference="<?= e($t['reference_link']??'') ?>" data-task-file="<?= e($t['file_link']??'') ?>"><b><?= e($t['title']) ?></b></button><br><span class="muted"><?= e(mb_substr($t['brief']??'',0,90)) ?></span></div>
        </td>
        <td><span class="user-chip"><?= avatar_html(['name'=>$t['assignee_name'],'avatar'=>$t['assignee_avatar']],true) ?><?= e($t['assignee_name']) ?></span></td>
        <td><span class="badge <?= badge_class($t['priority']) ?>"><?= e($t['priority']) ?></span></td>
        <td><?= e($t['deadline']) ?></td>
        <td><span class="badge <?= badge_class($t['status']) ?>"><?= e($t['status']) ?></span></td>
        <td><?= e($t['deliverable_type']) ?> <?= (int)$t['deliverable_count']?'× '.(int)$t['deliverable_count']:'' ?></td>
        <td class="actions task-icon-actions">
          <?php if($t['status']==='Waiting Approval' && (user_is_admin() || (int)$p['owner_id']===(int)current_user()['id'])): ?><a class="icon-action" title="Duyệt" href="app.php?page=project_detail&id=<?= $id ?>&approve=<?= $t['id'] ?>">✔</a><?php endif; ?>
          <a class="icon-action outline-icon sos-icon" title="Cần hỗ trợ" href="app.php?page=project_detail&id=<?= $id ?>&request_help_project=<?= $t['id'] ?>">!</a>
          <?php if(user_is_admin() || (int)$p['owner_id']===(int)current_user()['id']): ?><a class="icon-action outline-icon danger-icon" title="Xóa task" onclick="return confirm('Xóa task này?')" href="app.php?page=project_detail&id=<?= $id ?>&delete_project_task=<?= $t['id'] ?>">×</a><?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</section>
<?php endforeach; ?>


<section class="card" id="projectFiles">
  <div class="card-head">
    <div><h2>Project Files & Documents</h2><p class="muted">Link, file, tài liệu và ghi chú liên quan tới project.</p></div>
    <button class="btn btn-soft" onclick="openModal('projectFileModal')">+ Add link</button>

  </div>
  <table class="dense-table workspace-table">
    <thead><tr><th>File</th><th>Ghi chú link</th><th>By</th><th>Action</th></tr></thead>
    <tbody>
    <?php foreach($fileLinks as $fl): ?>
      <tr><td><b><?= e($fl['title']) ?></b><br><span class="muted"><?= e($fl['url']) ?></span></td><td><?= e($fl['note']) ?></td><td><?= e($fl['user_name']) ?></td><td><a class="btn btn-soft" href="<?= e($fl['url']) ?>" target="_blank">Open</a></td></tr>
    <?php endforeach; ?>
    <?php if(empty($fileLinks)): ?><tr><td colspan="4" class="muted">Chưa có file link.</td></tr><?php endif; ?>
    </tbody>
  </table>
</section>

<div class="modal-backdrop" id="projectFileModal">
  <div class="modal-panel">
    <button class="modal-close" onclick="closeModal('projectFileModal')">×</button>
    <h2>Thêm file link</h2>
    <form method="post">
      <input type="hidden" name="add_project_file_link" value="1">
      <label>Title</label><input name="title" required>
      <label>URL</label><input name="url" required>
      <label>Ghi chú link đính kèm là gì?</label><textarea name="note" placeholder="Ví dụ: Folder raw footage, file brief, link Canva KV..."></textarea>
      <button class="primary">Lưu file</button>
    </form>
  </div>
</div>

<section class="card">
  <div class="card-head">
    <div><h2>Deliverable Progress</h2><p class="muted">Theo dõi sản lượng thực tế theo loại: Social Post, Video, Photo...</p></div>
    <button class="btn btn-soft" onclick="openModal('deliverableModal')">Cập nhật target</button>
  </div>
  <div class="deliverable-grid">
    <?php foreach($deliverables as $type=>$d): $target=$d['target'] ?: $d['total_task']; $dp=$target?round($d['done']/$target*100):0; ?>
      <div class="deliverable-card"><b><?= e($type) ?></b><strong><?= $d['done'] ?>/<?= $target ?></strong><div class="progress"><span style="width:<?= min(100,$dp) ?>%"></span></div><small><?= $dp ?>% · Task volume <?= (int)$d['total_task'] ?></small></div>
    <?php endforeach; ?>
    <?php if(empty($deliverables)): ?><p class="muted">Chưa có deliverable.</p><?php endif; ?>
  </div>
</section>
<div class="modal-backdrop" id="deliverableModal">
  <div class="modal-panel">
    <button class="modal-close" onclick="closeModal('deliverableModal')">×</button>
    <h2>Deliverable Targets</h2>
    <form method="post">
      <input type="hidden" name="save_deliverables" value="1">
      <?php $i=0; foreach($deliverables as $type=>$d): ?>
        <div class="form-row"><div><label>Loại</label><input name="deliverables[<?= $i ?>][type]" value="<?= e($type) ?>"></div><div><label>Target</label><input name="deliverables[<?= $i ?>][target]" type="number" value="<?= (int)$d['target'] ?>"></div></div>
        <label>Note</label><input name="deliverables[<?= $i ?>][note]"><?php $i++; ?>
      <?php endforeach; ?>
      <?php for($j=$i;$j<$i+3;$j++): ?>
        <div class="form-row"><div><label>Loại mới</label><input name="deliverables[<?= $j ?>][type]" placeholder="Social Post, Video..."></div><div><label>Target</label><input name="deliverables[<?= $j ?>][target]" type="number" value="0"></div></div>
        <label>Note</label><input name="deliverables[<?= $j ?>][note]">
      <?php endfor; ?>
      <button class="primary">Lưu target</button>
    </form>
  </div>
</div>





<div class="task-comment-templates" style="display:none">
<?php foreach($tasks as $tcTask): ?>
  <div id="taskComments<?= (int)$tcTask['id'] ?>">
    <?php foreach(($commentsByTask[(int)$tcTask['id']] ?? []) as $c): ?>
      <div class="task-comment">
        <?= avatar_html(['name'=>$c['user_name'],'avatar'=>$c['user_avatar']],true) ?>
        <div><b><?= e($c['user_name']) ?></b><span><?= e($c['created_at']) ?></span><p><?= nl2br(e($c['comment'])) ?></p></div>
      </div>
    <?php endforeach; ?>
    <?php if(empty($commentsByTask[(int)$tcTask['id']] ?? [])): ?><p class="muted">Chưa có bình luận.</p><?php endif; ?>
  </div>
<?php endforeach; ?>
</div>

<div class="task-detail-backdrop" id="taskDetailBackdrop" onclick="closeTaskDetailDrawer()"></div>
<aside class="task-detail-drawer editable-task-drawer" id="taskDetailDrawer">
  <button class="modal-close" onclick="closeTaskDetailDrawer()">×</button>
  <form method="post" id="taskDrawerForm">
    <input type="hidden" name="save_task_drawer" value="1">
    <input type="hidden" name="task_id" id="tdTaskId">
    <span class="eyebrow">Task Detail</span>
    <label>Title</label>
    <input name="title" id="tdTitleInput" class="drawer-title-input" required>
    <div class="form-row">
      <div><label>Assignee</label><div class="drawer-assignee-preview" id="tdAssigneePreview"><span class="avatar small">?</span><b>Chưa giao</b></div><select name="assignee_id" id="tdAssigneeSelect"><option value="">Chưa giao</option><?php foreach($users as $u): ?><option value="<?= $u['id'] ?>" data-avatar="<?= e($u['avatar'] ?? '') ?>" data-name="<?= e($u['name']) ?>"><?= e($u['name']) ?></option><?php endforeach; ?></select></div>
      <div><label>Deadline</label><input type="date" name="deadline" id="tdDeadlineInput"></div>
    </div>
    <div class="form-row">
      <div><label>Status</label><select name="status" id="tdStatusSelect"><?php foreach(['Todo','Doing','Review','Waiting Approval','Done'] as $s): ?><option><?= e($s) ?></option><?php endforeach; ?></select></div>
      <div><label>Priority</label><select name="priority" id="tdPrioritySelect"><?php foreach(priority_options() as $pv=>$pl): ?><option value="<?= e($pv) ?>"><?= e($pl) ?></option><?php endforeach; ?></select></div>
    </div>
    <label>Brief</label>
    <textarea name="brief" id="tdBriefInput" rows="4"></textarea>
    <label>Chi tiết yêu cầu</label>
    <textarea name="description" id="tdDescInput" rows="6"></textarea>
    <label>Reference link</label>
    <input name="reference_link" id="tdRefInput" placeholder="https://...">
    <label>File link</label>
    <input name="file_link" id="tdFileInput" placeholder="https://...">
    <div class="task-drawer-sticky-actions">
      <button class="primary">Lưu task</button>
      <a id="tdFull" class="btn btn-soft" href="#">Mở trang đầy đủ</a>
    </div>
  </form>

  <section class="drawer-comments-section"><h3>Bình luận</h3><div class="task-comment-list" id="tdDrawerComments"></div></section>

  <form method="post" class="drawer-comment-form">
    <input type="hidden" name="add_task_comment_drawer" value="1">
    <input type="hidden" name="task_id" id="tdCommentTaskId">
    <label>Bình luận nhanh</label>
    <textarea name="comment" placeholder="Góp ý nhanh cho task này..."></textarea>
    <button class="btn btn-soft">Gửi bình luận</button>
  </form>
</aside>
<div id="drawerBackdrop" class="drawer-backdrop" onclick="closeSlideDrawer('taskDrawer')"></div>
<div class="slide-drawer" id="taskDrawer">
  <div class="drawer-form-header"><div><span class="eyebrow">Task V2</span><h2>Tạo task trong project</h2></div><button class="drawer-close-x" onclick="closeSlideDrawer('taskDrawer')" type="button">×</button></div>
  <form method="post">
    <input type="hidden" name="save_task" value="1">
    <label>Title</label><input name="title" required>
    <label>Assignee</label><select name="assignee_id"><?php foreach($users as $u): ?><option value="<?= $u['id'] ?>" data-avatar="<?= e($u['avatar'] ?? '') ?>" data-name="<?= e($u['name']) ?>"><?= e($u['name']) ?></option><?php endforeach; ?></select>
    <div class="form-row"><div><label>Priority</label><select name="priority"><?php foreach(priority_options() as $pv=>$pl): ?><option value="<?= e($pv) ?>"><?= e($pl) ?></option><?php endforeach; ?></select></div><div><label>Status</label><select name="status"><option>Todo</option><option>Doing</option><option>Review</option><option>Waiting Approval</option></select></div></div>
    <div class="form-row"><div><label>Start</label><input name="start_date" type="date" value="<?= date('Y-m-d') ?>"></div><div><label>Deadline</label><input name="deadline" type="date"></div></div>
    <label>Phase</label><input name="phase" value="General">
    <label>Brief</label><textarea name="brief"></textarea>
    <div class="form-row"><div><label>Deliverable Type</label><input name="deliverable_type" placeholder="Social Post, Video..."></div><div><label>Deliverable Count</label><input name="deliverable_count" type="number" value="1"></div></div>
    <label>Deliverable Note</label><input name="deliverable">
    <label>Reference link</label><input name="reference_link">
    <label>File link</label><input name="file_link">
    <label>Approver</label><input name="approver">
    <button class="primary">Lưu task</button>
  </form>
</div>


<script>
window.MOTIVE_USERS = <?= mention_options_json($pdo) ?>;
document.addEventListener('input', function(e){
  if(!e.target.matches('textarea[name="comment"], input[name="comment"]')) return;
  const val=e.target.value;
  const at=val.lastIndexOf('@');
  let box=document.getElementById('mentionSuggestBox');
  if(!box){
    box=document.createElement('div'); box.id='mentionSuggestBox'; box.className='mention-suggest-box'; document.body.appendChild(box);
  }
  if(at<0){ box.style.display='none'; return; }
  const query=val.slice(at+1).toLowerCase().trim();
  if(query.length<1){ box.style.display='none'; return; }
  const users=(window.MOTIVE_USERS||[]).filter(u=>u.name.toLowerCase().includes(query) || (u.email||'').toLowerCase().includes(query)).slice(0,6);
  if(!users.length){ box.style.display='none'; return; }
  const rect=e.target.getBoundingClientRect();
  box.style.left=(rect.left+window.scrollX)+'px';
  box.style.top=(rect.bottom+window.scrollY+6)+'px';
  box.innerHTML=users.map(u=>`<button type="button" data-name="${u.name}">@${u.name}</button>`).join('');
  box.style.display='block';
  box.querySelectorAll('button').forEach(btn=>{
    btn.onclick=function(){
      const before=val.slice(0,at);
      e.target.value=before+'@'+this.dataset.name+' ';
      box.style.display='none';
      e.target.focus();
    }
  });
});
document.addEventListener('click',function(e){
  const box=document.getElementById('mentionSuggestBox');
  if(box && !e.target.closest('#mentionSuggestBox') && !e.target.matches('textarea[name="comment"], input[name="comment"]')) box.style.display='none';
});
</script>
