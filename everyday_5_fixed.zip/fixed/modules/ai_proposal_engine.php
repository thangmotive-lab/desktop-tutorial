<?php
if(!is_director_role() && !is_finance_role()) die('Bạn không có quyền dùng AI Proposal Engine.');
require_once __DIR__ . '/../services/ai/AIService.php';
require_once __DIR__ . '/../services/ai/PromptBuilder.php';

$ai = new AIService($pdo);
$quoteId=(int)($_GET['quotation_id'] ?? $_POST['quotation_id'] ?? 0);
$proposalId=(int)($_GET['proposal_id'] ?? 0);
$flash='';

$quotes=safe_rows($pdo,"SELECT id,quote_code,client_name,title,status,expected_revenue,created_at FROM quotations ORDER BY id DESC LIMIT 200");
$quote=null;
if($quoteId){
  $st=$pdo->prepare("SELECT * FROM quotations WHERE id=? LIMIT 1");
  $st->execute([$quoteId]);
  $quote=$st->fetch();
}

$knowledge=safe_rows($pdo,"SELECT * FROM ai_knowledge_base WHERE is_active=1 ORDER BY category,title LIMIT 500");
$prompts=safe_rows($pdo,"SELECT * FROM ai_prompt_studio WHERE is_active=1 AND category IN ('Proposal','General') ORDER BY category,prompt_name");
$selectedPromptId=(int)($_POST['prompt_id'] ?? $_GET['prompt_id'] ?? 0);

function proposal_selected_knowledge(PDO $pdo, array $ids): array {
  $ids=array_values(array_filter(array_map('intval',$ids)));
  if(empty($ids)) return [];
  $ph=implode(',',array_fill(0,count($ids),'?'));
  $st=$pdo->prepare("SELECT id,title,category,content,tags,version FROM ai_knowledge_base WHERE id IN ($ph) AND is_active=1 ORDER BY category,title");
  $st->execute($ids);
  return $st->fetchAll();
}

function proposal_payload(PDO $pdo, int $quoteId, array $knowledgeRows, ?array $promptRow): array {
  $payload=PromptBuilder::quotationPayload($pdo,$quoteId);
  $payload['proposal_context']=[
    'knowledge_base'=>array_map(function($k){
      return [
        'title'=>$k['title'],
        'category'=>$k['category'],
        'tags'=>$k['tags'] ?? '',
        'version'=>$k['version'] ?? '',
        'content'=>$k['content']
      ];
    },$knowledgeRows),
    'prompt_name'=>$promptRow['prompt_name'] ?? 'Proposal Engine V2',
    'prompt_version'=>$promptRow['version'] ?? '2.0'
  ];
  return $payload;
}

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['generate_proposal_v2']) && $quote){
  $knowledgeIds=$_POST['knowledge_ids'] ?? [];
  $knowledgeRows=proposal_selected_knowledge($pdo,$knowledgeIds);
  $promptRow=null;
  if($selectedPromptId){
    $st=$pdo->prepare("SELECT * FROM ai_prompt_studio WHERE id=? AND is_active=1 LIMIT 1");
    $st->execute([$selectedPromptId]);
    $promptRow=$st->fetch();
  }
  if(!$promptRow){
    $st=$pdo->prepare("SELECT * FROM ai_prompt_studio WHERE prompt_name='Proposal Engine V2' AND is_active=1 LIMIT 1");
    $st->execute();
    $promptRow=$st->fetch();
  }

  $payload=proposal_payload($pdo,$quoteId,$knowledgeRows,$promptRow ?: null);
  $prompt=($promptRow['prompt_body'] ?? 'Viết proposal chuyên nghiệp cho báo giá này.')
    . "\n\nDỮ LIỆU BÁO GIÁ + KNOWLEDGE BASE JSON:\n"
    . json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT);

  $res=$ai->generateRaw($prompt,[
    'source_type'=>'quotation',
    'source_id'=>$quoteId,
    'type'=>'proposal_v2',
    'template_code'=>'PROPOSAL_ENGINE_V2',
    'user_id'=>current_user()['id']
  ]);

  if($res['ok']){
    $json=json_encode(array_column($knowledgeRows,'id'),JSON_UNESCAPED_UNICODE);
    $stmt=$pdo->prepare("INSERT INTO ai_proposal_drafts(quotation_id,proposal_title,selected_knowledge_json,selected_prompt_id,generated_content,status,created_by) VALUES(?,?,?,?,?,?,?)");
    $stmt->execute([$quoteId,($_POST['proposal_title'] ?: ('Proposal - '.$quote['client_name'])),$json,$promptRow['id']??null,$res['content'],'draft',current_user()['id']]);
    $pid=(int)$pdo->lastInsertId();
    redirect('app.php?page=ai_proposal_engine&quotation_id='.$quoteId.'&proposal_id='.$pid.'&generated=1');
  } else {
    $flash='❌ '.$res['message'];
  }
}

if(isset($_POST['save_proposal_draft'])){
  $pid=(int)$_POST['proposal_id'];
  $pdo->prepare("UPDATE ai_proposal_drafts SET proposal_title=?, generated_content=?, updated_at=CURRENT_TIMESTAMP WHERE id=?")
    ->execute([$_POST['proposal_title'],$_POST['generated_content'],$pid]);
  redirect('app.php?page=ai_proposal_engine&quotation_id='.$quoteId.'&proposal_id='.$pid.'&saved=1');
}

if(isset($_GET['archive_proposal'])){
  $pid=(int)$_GET['archive_proposal'];
  $pdo->prepare("UPDATE ai_proposal_drafts SET status='archived' WHERE id=?")->execute([$pid]);
  redirect('app.php?page=ai_proposal_engine&quotation_id='.$quoteId);
}

$current=null;
if($proposalId){
  $st=$pdo->prepare("SELECT * FROM ai_proposal_drafts WHERE id=? LIMIT 1");
  $st->execute([$proposalId]);
  $current=$st->fetch();
}

$drafts=[];
if($quoteId){
  $st=$pdo->prepare("SELECT apd.*,u.name user_name FROM ai_proposal_drafts apd LEFT JOIN users u ON u.id=apd.created_by WHERE apd.quotation_id=? AND apd.status!='archived' ORDER BY apd.id DESC");
  $st->execute([$quoteId]);
  $drafts=$st->fetchAll();
}
?>
<section class="workspace-hero ai-workspace-hero">
  <div>
    <span class="eyebrow">AI Proposal Engine V2</span>
    <h1>Generate Proposal từ Knowledge Base</h1>
    <p class="muted">AI kéo dữ liệu báo giá, Knowledge Base, Prompt Studio để viết proposal có cấu trúc rõ ràng hơn.</p>
  </div>
  <a class="btn btn-soft" href="app.php?page=ai_workspace">AI Workspace</a>
</section>

<?php if($flash): ?><div class="alert"><?= e($flash) ?></div><?php endif; ?>
<?php if(!empty($_GET['generated'])): ?><div class="alert success">✅ Đã generate proposal draft.</div><?php endif; ?>
<?php if(!empty($_GET['saved'])): ?><div class="alert success">✅ Đã lưu proposal draft.</div><?php endif; ?>

<section class="card">
  <div class="card-head"><h2>1. Chọn báo giá</h2></div>
  <form method="get" class="asana-toolbar">
    <input type="hidden" name="page" value="ai_proposal_engine">
    <select name="quotation_id" required>
      <option value="">Chọn báo giá</option>
      <?php foreach($quotes as $q): ?>
        <option value="<?= $q['id'] ?>" <?= $quoteId===$q['id']?'selected':'' ?>><?= e($q['quote_code'].' — '.$q['client_name'].' — '.$q['title']) ?></option>
      <?php endforeach; ?>
    </select>
    <button class="primary">Load</button>
  </form>
</section>

<?php if($quote): ?>
<section class="card">
  <div class="card-head">
    <div><h2>2. Generate Proposal</h2><p class="muted"><?= e($quote['quote_code'].' — '.$quote['client_name'].' — '.$quote['title']) ?></p></div>
  </div>
  <form method="post">
    <input type="hidden" name="quotation_id" value="<?= $quoteId ?>">
    <label>Proposal title</label>
    <input name="proposal_title" value="<?= e('Proposal - '.$quote['client_name'].' - '.$quote['title']) ?>">

    <label>Prompt Studio</label>
    <select name="prompt_id">
      <option value="">Auto: Proposal Engine V2</option>
      <?php foreach($prompts as $p): ?>
        <option value="<?= $p['id'] ?>" <?= $selectedPromptId===$p['id']?'selected':'' ?>><?= e($p['category'].' — '.$p['prompt_name'].' v'.$p['version']) ?></option>
      <?php endforeach; ?>
    </select>

    <label>Knowledge Base dùng cho proposal</label>
    <div class="knowledge-picker">
      <?php foreach($knowledge as $k): ?>
        <label class="knowledge-check">
          <input type="checkbox" name="knowledge_ids[]" value="<?= $k['id'] ?>">
          <span><b><?= e($k['title']) ?></b><small><?= e($k['category'].' · '.($k['tags'] ?? '')) ?></small></span>
        </label>
      <?php endforeach; ?>
      <?php if(empty($knowledge)): ?><p class="muted">Chưa có Knowledge Base. Hãy thêm tại AI → Knowledge Base.</p><?php endif; ?>
    </div>
    <button class="primary" name="generate_proposal_v2" value="1">Generate Proposal V2</button>
  </form>
</section>

<?php if($drafts): ?>
<section class="card">
  <div class="card-head"><h2>Proposal Drafts</h2></div>
  <table class="dense-table">
    <thead><tr><th>Title</th><th>Created</th><th>By</th><th>Action</th></tr></thead>
    <tbody>
      <?php foreach($drafts as $d): ?>
        <tr><td><b><?= e($d['proposal_title']) ?></b></td><td><?= e($d['created_at']) ?></td><td><?= e($d['user_name']) ?></td><td class="actions"><a class="btn btn-soft" href="app.php?page=ai_proposal_engine&quotation_id=<?= $quoteId ?>&proposal_id=<?= $d['id'] ?>">Open</a><a class="btn btn-soft" href="app.php?page=ai_proposal_engine&quotation_id=<?= $quoteId ?>&archive_proposal=<?= $d['id'] ?>">Archive</a></td></tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</section>
<?php endif; ?>

<?php if($current): ?>
<section class="card">
  <div class="card-head"><h2>Edit Proposal Draft</h2><span class="badge purple">Draft #<?= (int)$current['id'] ?></span></div>
  <form method="post">
    <input type="hidden" name="save_proposal_draft" value="1">
    <input type="hidden" name="proposal_id" value="<?= (int)$current['id'] ?>">
    <input type="hidden" name="quotation_id" value="<?= $quoteId ?>">
    <label>Title</label><input name="proposal_title" value="<?= e($current['proposal_title']) ?>">
    <label>Generated content</label><textarea class="proposal-editor" name="generated_content" rows="24"><?= e($current['generated_content']) ?></textarea>
    <button class="primary">Lưu draft</button>
  </form>
</section>
<?php endif; ?>
<?php endif; ?>
