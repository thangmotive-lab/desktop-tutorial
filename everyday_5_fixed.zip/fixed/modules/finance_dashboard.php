<?php
if(function_exists('can_view_business_finance') && !can_view_business_finance()) die('Bạn không có quyền xem dashboard tài chính.');

function finance_dashboard_payment_has_col(PDO $pdo, string $table, string $col): bool {
  try{
    $stmt=$pdo->prepare("SHOW COLUMNS FROM `$table` LIKE ?");
    $stmt->execute([$col]);
    return (bool)$stmt->fetch();
  }catch(Exception $e){ return false; }
}
function finance_dashboard_payment_add_col(PDO $pdo, string $table, string $ddl): void {
  $col=trim(strtok($ddl,' '));
  if(!finance_dashboard_payment_has_col($pdo,$table,$col)){
    try{ $pdo->exec("ALTER TABLE `$table` ADD COLUMN $ddl"); }catch(Exception $e){}
  }
}
function finance_dashboard_payment_ensure_schema(PDO $pdo): void {
  try{
    $pdo->exec("CREATE TABLE IF NOT EXISTS payment_schedules(
      id INT AUTO_INCREMENT PRIMARY KEY,
      contract_id INT NULL,
      quotation_id INT NULL,
      payment_code VARCHAR(50) NULL,
      title VARCHAR(255) NULL,
      milestone VARCHAR(255) NULL,
      amount DECIMAL(15,2) DEFAULT 0,
      due_date DATE NULL,
      paid_date DATE NULL,
      status VARCHAR(50) DEFAULT 'pending',
      note TEXT NULL,
      carry_month VARCHAR(7) NULL,
      moved_from_month VARCHAR(7) NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  }catch(Exception $e){}
  finance_dashboard_payment_add_col($pdo,'payment_schedules','contract_id INT NULL');
  finance_dashboard_payment_add_col($pdo,'payment_schedules','quotation_id INT NULL');
  finance_dashboard_payment_add_col($pdo,'payment_schedules','payment_code VARCHAR(50) NULL');
  finance_dashboard_payment_add_col($pdo,'payment_schedules','title VARCHAR(255) NULL');
  finance_dashboard_payment_add_col($pdo,'payment_schedules','milestone VARCHAR(255) NULL');
  finance_dashboard_payment_add_col($pdo,'payment_schedules','amount DECIMAL(15,2) DEFAULT 0');
  finance_dashboard_payment_add_col($pdo,'payment_schedules','due_date DATE NULL');
  finance_dashboard_payment_add_col($pdo,'payment_schedules','paid_date DATE NULL');
  finance_dashboard_payment_add_col($pdo,'payment_schedules',"status VARCHAR(50) DEFAULT 'pending'");
  finance_dashboard_payment_add_col($pdo,'payment_schedules','note TEXT NULL');
  finance_dashboard_payment_add_col($pdo,'payment_schedules','carry_month VARCHAR(7) NULL');
  finance_dashboard_payment_add_col($pdo,'payment_schedules','moved_from_month VARCHAR(7) NULL');
  finance_dashboard_payment_add_col($pdo,'payment_schedules','created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP');
  finance_dashboard_payment_add_col($pdo,'payment_schedules','updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP');
}
finance_dashboard_payment_ensure_schema($pdo);

function finance_dashboard_money_value($v): float { return (float)($v ?? 0); }
function finance_dashboard_pct($current, $previous): ?float {
  $current = (float)$current;
  $previous = (float)$previous;
  if($previous <= 0){ return $current > 0 ? null : 0.0; }
  return (($current - $previous) / $previous) * 100;
}
function finance_dashboard_pct_text($pct): string {
  if($pct === null) return 'Mới';
  $sign = $pct > 0 ? '+' : '';
  return $sign . number_format((float)$pct, 1, ',', '.') . '%';
}
function finance_dashboard_growth_class($pct): string {
  if($pct === null) return 'up';
  if($pct > 0.01) return 'up';
  if($pct < -0.01) return 'down';
  return 'flat';
}
function finance_dashboard_date($date): string {
  $date = trim((string)$date);
  if($date === '') return '—';
  $ts = strtotime($date);
  return $ts ? date('d/m/Y', $ts) : $date;
}

$selectedMonth = trim((string)($_GET['month'] ?? date('Y-m')));
if(!preg_match('/^\d{4}-\d{2}$/', $selectedMonth)) $selectedMonth = date('Y-m');
try{ $baseMonth = new DateTime($selectedMonth . '-01'); }catch(Exception $e){ $baseMonth = new DateTime(date('Y-m-01')); $selectedMonth = $baseMonth->format('Y-m'); }

$months = [];
for($i=-5; $i<=6; $i++){
  $d = clone $baseMonth;
  $d->modify(($i >= 0 ? '+' : '') . $i . ' months');
  $key = $d->format('Y-m');
  $months[$key] = [
    'label' => 'T' . $d->format('m') . '/' . $d->format('y'),
    'due' => 0.0,
    'paid' => 0.0,
    'pending' => 0.0,
    'growth_due' => null,
    'growth_paid' => null,
  ];
}
$monthKeys = array_keys($months);
$startMonth = reset($monthKeys);
$endMonth = end($monthKeys);

$monthExpr = "COALESCE(NULLIF(ps.carry_month,''), DATE_FORMAT(COALESCE(ps.due_date, DATE(ps.created_at)), '%Y-%m'))";
$paidMonthExpr = "COALESCE(DATE_FORMAT(ps.paid_date, '%Y-%m'), NULLIF(ps.carry_month,''), DATE_FORMAT(COALESCE(ps.due_date, DATE(ps.created_at)), '%Y-%m'))";

try{
  $stmt = $pdo->prepare("SELECT $monthExpr AS month_key,
    COALESCE(SUM(ps.amount),0) AS total_due,
    COALESCE(SUM(CASE WHEN COALESCE(ps.status,'pending')!='paid' THEN ps.amount ELSE 0 END),0) AS total_pending
    FROM payment_schedules ps
    WHERE $monthExpr BETWEEN ? AND ?
    GROUP BY month_key
    ORDER BY month_key ASC");
  $stmt->execute([$startMonth, $endMonth]);
  foreach($stmt->fetchAll() as $r){
    $key = (string)$r['month_key'];
    if(isset($months[$key])){
      $months[$key]['due'] = finance_dashboard_money_value($r['total_due']);
      $months[$key]['pending'] = finance_dashboard_money_value($r['total_pending']);
    }
  }
}catch(Exception $e){}

try{
  $stmt = $pdo->prepare("SELECT $paidMonthExpr AS month_key,
    COALESCE(SUM(ps.amount),0) AS total_paid
    FROM payment_schedules ps
    WHERE COALESCE(ps.status,'pending')='paid'
      AND $paidMonthExpr BETWEEN ? AND ?
    GROUP BY month_key
    ORDER BY month_key ASC");
  $stmt->execute([$startMonth, $endMonth]);
  foreach($stmt->fetchAll() as $r){
    $key = (string)$r['month_key'];
    if(isset($months[$key])) $months[$key]['paid'] = finance_dashboard_money_value($r['total_paid']);
  }
}catch(Exception $e){}

$previousKey = null;
foreach($months as $key => $row){
  if($previousKey !== null){
    $months[$key]['growth_due'] = finance_dashboard_pct($months[$key]['due'], $months[$previousKey]['due']);
    $months[$key]['growth_paid'] = finance_dashboard_pct($months[$key]['paid'], $months[$previousKey]['paid']);
  }
  $previousKey = $key;
}

$current = $months[$selectedMonth] ?? ['due'=>0,'paid'=>0,'pending'=>0,'growth_due'=>0,'growth_paid'=>0];
$prevMonthObj = clone $baseMonth; $prevMonthObj->modify('-1 month');
$prevKey = $prevMonthObj->format('Y-m');
$previous = $months[$prevKey] ?? ['due'=>0,'paid'=>0,'pending'=>0];
$dueGrowth = finance_dashboard_pct($current['due'], $previous['due']);
$paidGrowth = finance_dashboard_pct($current['paid'], $previous['paid']);
$completionRate = $current['due'] > 0 ? min(100, ($current['paid'] / $current['due']) * 100) : 0;

$upcoming7 = 0; $upcoming30 = 0; $overdueTotal = 0;
try{
  $upcoming7 = (float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM payment_schedules WHERE COALESCE(status,'pending')!='paid' AND due_date IS NOT NULL AND due_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)")->fetchColumn();
  $upcoming30 = (float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM payment_schedules WHERE COALESCE(status,'pending')!='paid' AND due_date IS NOT NULL AND due_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)")->fetchColumn();
  $overdueTotal = (float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM payment_schedules WHERE COALESCE(status,'pending')!='paid' AND due_date IS NOT NULL AND due_date < CURDATE()")->fetchColumn();
}catch(Exception $e){}

$topClients = [];
try{
  $stmt = $pdo->prepare("SELECT COALESCE(c.client_name, q.client_name, 'Chưa gắn khách') AS client_name,
    COALESCE(SUM(ps.amount),0) AS amount,
    COUNT(ps.id) AS items,
    MIN(ps.due_date) AS next_due
    FROM payment_schedules ps
    LEFT JOIN contracts c ON c.id=ps.contract_id
    LEFT JOIN quotations q ON q.id=ps.quotation_id
    WHERE $monthExpr=? AND COALESCE(ps.status,'pending')!='paid'
    GROUP BY client_name
    ORDER BY amount DESC
    LIMIT 6");
  $stmt->execute([$selectedMonth]);
  $topClients = $stmt->fetchAll();
}catch(Exception $e){}

$overdueRows = [];
try{
  $stmt = $pdo->query("SELECT ps.payment_code, ps.title, ps.amount, ps.due_date,
    COALESCE(c.client_name, q.client_name, 'Chưa gắn khách') AS client_name,
    DATEDIFF(CURDATE(), ps.due_date) AS overdue_days
    FROM payment_schedules ps
    LEFT JOIN contracts c ON c.id=ps.contract_id
    LEFT JOIN quotations q ON q.id=ps.quotation_id
    WHERE COALESCE(ps.status,'pending')!='paid' AND ps.due_date IS NOT NULL AND ps.due_date < CURDATE()
    ORDER BY ps.due_date ASC, ps.amount DESC
    LIMIT 8");
  $overdueRows = $stmt->fetchAll();
}catch(Exception $e){}

$maxValue = 1;
foreach($months as $r){ $maxValue = max($maxValue, $r['due'], $r['paid']); }
$growthAbsMax = 1;
foreach($months as $r){
  if($r['growth_due'] !== null) $growthAbsMax = max($growthAbsMax, abs($r['growth_due']));
}
$prevLinkObj = clone $baseMonth; $prevLinkObj->modify('-1 month');
$nextLinkObj = clone $baseMonth; $nextLinkObj->modify('+1 month');
?>

<section class="workspace-hero finance-hero finance-growth-hero">
  <div>
    <span class="eyebrow">Finance Dashboard</span>
    <h1>Dashboard tăng trưởng dòng tiền</h1>
    <p class="muted">Theo dõi phải thu, đã thu, tỷ lệ hoàn thành và tăng trưởng giữa các tháng.</p>
  </div>
  <div class="actions finance-month-nav">
    <a class="btn btn-soft" href="app.php?page=finance_dashboard&month=<?= e($prevLinkObj->format('Y-m')) ?>">← Tháng trước</a>
    <form method="get" class="inline-month-form">
      <input type="hidden" name="page" value="finance_dashboard">
      <input type="month" name="month" value="<?= e($selectedMonth) ?>">
      <button class="primary">Xem</button>
    </form>
    <a class="btn btn-soft" href="app.php?page=finance_dashboard&month=<?= e($nextLinkObj->format('Y-m')) ?>">Tháng sau →</a>
  </div>
</section>

<div class="stats-grid compact-stats finance-kpi-grid">
  <div class="stat yellow"><span>Phải thu tháng <?= e($selectedMonth) ?></span><strong><?= money($current['due']) ?></strong><small class="growth-chip <?= finance_dashboard_growth_class($dueGrowth) ?>"><?= finance_dashboard_pct_text($dueGrowth) ?> so với tháng trước</small></div>
  <div class="stat mint"><span>Đã thu tháng <?= e($selectedMonth) ?></span><strong><?= money($current['paid']) ?></strong><small class="growth-chip <?= finance_dashboard_growth_class($paidGrowth) ?>"><?= finance_dashboard_pct_text($paidGrowth) ?> so với tháng trước</small></div>
  <div class="stat coral"><span>Còn phải chase</span><strong><?= money($current['pending']) ?></strong><small>Riêng các khoản chưa thanh toán trong tháng</small></div>
  <div class="stat purple"><span>Tỷ lệ hoàn thành</span><strong><?= number_format($completionRate, 1, ',', '.') ?>%</strong><small>Đã thu / phải thu theo tháng</small></div>
</div>

<div class="stats-grid compact-stats finance-kpi-grid secondary">
  <div class="stat"><span>Sắp thu 7 ngày tới</span><strong><?= money($upcoming7) ?></strong></div>
  <div class="stat"><span>Sắp thu 30 ngày tới</span><strong><?= money($upcoming30) ?></strong></div>
  <div class="stat"><span>Công nợ quá hạn</span><strong><?= money($overdueTotal) ?></strong></div>
</div>

<section class="card finance-chart-card">
  <div class="card-head">
    <div><h2>Phải thu vs Đã thu theo tháng</h2><p class="muted">Cột cao thể hiện tổng lịch thanh toán; cột thấp hơn thể hiện tiền đã thu thực tế.</p></div>
    <a class="btn btn-soft" href="app.php?page=payments&month=<?= e($selectedMonth) ?>">Xem lịch thanh toán</a>
  </div>
  <div class="finance-bar-chart" aria-label="Biểu đồ phải thu và đã thu theo tháng">
    <?php foreach($months as $key=>$r): $duePct=($r['due']/$maxValue)*100; $paidPct=($r['paid']/$maxValue)*100; ?>
      <div class="finance-bar-group <?= $key===$selectedMonth?'active':'' ?>">
        <div class="finance-bars">
          <span class="bar due" style="height:<?= max(3, round($duePct,1)) ?>%" title="Phải thu <?= e($r['label']) ?>: <?= e(money($r['due'])) ?>"></span>
          <span class="bar paid" style="height:<?= max(3, round($paidPct,1)) ?>%" title="Đã thu <?= e($r['label']) ?>: <?= e(money($r['paid'])) ?>"></span>
        </div>
        <strong><?= e($r['label']) ?></strong>
        <small><?= money($r['due']) ?></small>
      </div>
    <?php endforeach; ?>
  </div>
  <div class="finance-chart-legend"><span><i class="due"></i> Phải thu</span><span><i class="paid"></i> Đã thu</span></div>
</section>

<section class="card finance-chart-card">
  <div class="card-head"><div><h2>Tỷ lệ tăng trưởng phải thu giữa các tháng</h2><p class="muted">Tăng trưởng được tính theo công thức: (tháng hiện tại - tháng trước) / tháng trước.</p></div></div>
  <div class="finance-growth-chart">
    <?php foreach($months as $key=>$r): $pct=$r['growth_due']; $abs=$pct===null ? $growthAbsMax : abs($pct); $height=max(8,min(100,($abs/$growthAbsMax)*100)); ?>
      <div class="growth-col <?= finance_dashboard_growth_class($pct) ?> <?= $key===$selectedMonth?'active':'' ?>">
        <div class="growth-meter"><span style="height:<?= round($height,1) ?>%"></span></div>
        <b><?= e(finance_dashboard_pct_text($pct)) ?></b>
        <small><?= e($r['label']) ?></small>
      </div>
    <?php endforeach; ?>
  </div>
</section>

<div class="finance-dashboard-grid">
  <section class="card">
    <div class="card-head"><div><h2>Top khách cần chase tháng <?= e($selectedMonth) ?></h2><p class="muted">Ưu tiên theo số tiền chưa thanh toán.</p></div></div>
    <table class="dense-table finance-mini-table">
      <thead><tr><th>Khách hàng</th><th>Số khoản</th><th>Due gần nhất</th><th>Số tiền</th></tr></thead>
      <tbody>
      <?php foreach($topClients as $c): ?>
        <tr><td><b><?= e($c['client_name']) ?></b></td><td><?= (int)$c['items'] ?></td><td><?= e(finance_dashboard_date($c['next_due'] ?? '')) ?></td><td><strong><?= money($c['amount']) ?></strong></td></tr>
      <?php endforeach; ?>
      <?php if(empty($topClients)): ?><tr><td colspan="4" class="muted">Chưa có khoản cần chase trong tháng này.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </section>

  <section class="card">
    <div class="card-head"><div><h2>Công nợ quá hạn</h2><p class="muted">Các khoản nên gọi/chase trước.</p></div></div>
    <table class="dense-table finance-mini-table">
      <thead><tr><th>Mã PAY</th><th>Khách hàng</th><th>Quá hạn</th><th>Số tiền</th></tr></thead>
      <tbody>
      <?php foreach($overdueRows as $r): ?>
        <tr><td><b><?= e($r['payment_code'] ?: '—') ?></b></td><td><?= e($r['client_name']) ?></td><td><?= (int)$r['overdue_days'] ?> ngày</td><td><strong><?= money($r['amount']) ?></strong></td></tr>
      <?php endforeach; ?>
      <?php if(empty($overdueRows)): ?><tr><td colspan="4" class="muted">Không có khoản quá hạn.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </section>
</div>

<section class="card finance-chart-card">
  <div class="card-head"><div><h2>Bảng dữ liệu tăng trưởng</h2><p class="muted">Dùng bảng này để kế toán/CEO kiểm tra con số chart.</p></div></div>
  <table class="dense-table finance-mini-table">
    <thead><tr><th>Tháng</th><th>Phải thu</th><th>Đã thu</th><th>Còn chase</th><th>Tăng trưởng phải thu</th><th>Tăng trưởng đã thu</th><th>Hoàn thành</th></tr></thead>
    <tbody>
    <?php foreach($months as $key=>$r): $rate=$r['due']>0?min(100,($r['paid']/$r['due'])*100):0; ?>
      <tr class="<?= $key===$selectedMonth?'current-row':'' ?>"><td><b><?= e($key) ?></b></td><td><?= money($r['due']) ?></td><td><?= money($r['paid']) ?></td><td><?= money($r['pending']) ?></td><td><span class="growth-chip <?= finance_dashboard_growth_class($r['growth_due']) ?>"><?= e(finance_dashboard_pct_text($r['growth_due'])) ?></span></td><td><span class="growth-chip <?= finance_dashboard_growth_class($r['growth_paid']) ?>"><?= e(finance_dashboard_pct_text($r['growth_paid'])) ?></span></td><td><?= number_format($rate,1,',','.') ?>%</td></tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</section>
