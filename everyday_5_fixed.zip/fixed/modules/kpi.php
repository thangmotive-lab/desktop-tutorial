<?php
if($_SERVER['REQUEST_METHOD']==='POST' && (user_is_admin() || in_array(current_user()['role'], ['HR','Finance']))){
  $stmt=$pdo->prepare('INSERT INTO kpi_commitments(user_id,month,title,target_value,unit,weight,note,status) VALUES(?,?,?,?,?,?,?,?)');
  $stmt->execute([$_POST['user_id'],$_POST['month'],$_POST['title'],$_POST['target_value'],$_POST['unit'],$_POST['weight'],$_POST['note'],'active']);
  log_activity($pdo,'create','kpi_commitment',$pdo->lastInsertId(),'Set KPI cam kết '.$_POST['title']);
  redirect((isset($_GET['admin'])?'admin.php':'app.php').'?page=kpi');
}
$users=$pdo->query('SELECT * FROM users ORDER BY name')->fetchAll();
$commitments=$pdo->query('SELECT kc.*,u.name user_name,u.avatar user_avatar FROM kpi_commitments kc JOIN users u ON u.id=kc.user_id ORDER BY kc.month DESC,kc.id DESC')->fetchAll();
?>
<div class="two-col">
<section class="card">
  <div class="card-head"><h2>KPI theo cam kết</h2><button class="primary" onclick="openSlideDrawer('kpiDrawer')">+ Set KPI</button></div>
  <?php foreach($commitments as $k): ?>
    <div class="kpi-commitment">
      <b><?= e($k['title']) ?></b><br>
      <span class="user-chip"><?= avatar_html(['name'=>$k['user_name'],'avatar'=>$k['user_avatar']],true) ?><?= e($k['user_name']) ?></span>
      <span class="muted"> · <?= e($k['month']) ?> · Target: <?= e($k['target_value']) ?> <?= e($k['unit']) ?> · Weight <?= e($k['weight']) ?>%</span>
      <p class="muted"><?= e($k['note']) ?></p>
    </div>
  <?php endforeach; ?>
</section>
<section class="card">
  <div class="card-head"><h2>KPI Dashboard</h2></div>
  <table>
    <thead><tr><th>Nhân sự</th><th>Task hoàn thành</th><th>Task đúng hạn</th><th>Project tham gia</th><th>KPI Target</th></tr></thead>
    <tbody>
    <?php foreach($users as $u):
      $stmt=$pdo->prepare("SELECT COUNT(*) FROM tasks WHERE assignee_id=? AND status='Done'");$stmt->execute([$u['id']]);$done=$stmt->fetchColumn();
      $stmt=$pdo->prepare("SELECT COUNT(*) FROM tasks WHERE assignee_id=? AND status='Done' AND completed_at <= CONCAT(deadline,' 23:59:59')");$stmt->execute([$u['id']]);$ontime=$stmt->fetchColumn();
      $stmt=$pdo->prepare("SELECT COUNT(DISTINCT project_id) FROM tasks WHERE assignee_id=?");$stmt->execute([$u['id']]);$projects=$stmt->fetchColumn();
    ?>
      <tr>
        <td><span class="user-chip"><?= avatar_html($u,true) ?><?= e($u['name']) ?></span></td>
        <td><?= (int)$done ?></td>
        <td><?= (int)$ontime ?></td>
        <td><?= (int)$projects ?></td>
        <td><?= e($u['kpi_target']) ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</section>
</div>

<div id="drawerBackdrop" class="drawer-backdrop" onclick="closeSlideDrawer('kpiDrawer')"></div>
<div class="slide-drawer" id="kpiDrawer">
  <div class="drawer-form-header">
    <div><span class="eyebrow">KPI Commitment</span><h2>Set KPI theo cam kết</h2></div>
    <button class="drawer-close-x" onclick="closeSlideDrawer('kpiDrawer')" type="button">×</button>
  </div>
  <form method="post">
    <label>Nhân sự</label><select name="user_id"><?php foreach($users as $u): ?><option value="<?= $u['id'] ?>"><?= e($u['name']) ?></option><?php endforeach; ?></select>
    <label>Tháng</label><input name="month" type="month" value="<?= date('Y-m') ?>">
    <label>Tên KPI</label><input name="title" required placeholder="VD: Hoàn thành task đúng hạn">
    <div class="form-row"><div><label>Target</label><input name="target_value" type="number" step="0.1" value="80"></div><div><label>Đơn vị</label><input name="unit" value="%"></div></div>
    <label>Trọng số %</label><input name="weight" type="number" value="20">
    <label>Ghi chú / cam kết</label><textarea name="note"></textarea>
    <button class="primary">Lưu KPI</button>
  </form>
</div>
