<?php
if(!can_view_business_finance()) die('Bạn không có quyền duyệt CTV payroll.');
$month=$_GET['month'] ?? date('Y-m');

if(isset($_GET['approve'])){
  $id=(int)$_GET['approve'];
  $pdo->prepare("UPDATE ctv_payrolls SET status='approved', approved_by=?, approved_at=NOW() WHERE id=?")->execute([current_user()['id'],$id]);
  $st=$pdo->prepare('SELECT * FROM ctv_payrolls WHERE id=?');$st->execute([$id]);$p=$st->fetch();
  if($p) create_notification($pdo,$p['user_id'],'CTV payroll đã được duyệt','Bảng thanh toán CTV tháng '.$p['payroll_month'].' đã được duyệt.','payroll','app.php?page=ctv_payroll&month='.$p['payroll_month']);
  redirect('app.php?page=ctv_approval&month='.$month);
}
if(isset($_GET['paid'])){
  $id=(int)$_GET['paid'];
  $proof='';
  if(!empty($_FILES['proof']['name'])){
    $dir=__DIR__.'/../uploads/payment_proofs'; if(!is_dir($dir)) mkdir($dir,0775,true);
    $ext=pathinfo($_FILES['proof']['name'],PATHINFO_EXTENSION);
    $proof='uploads/payment_proofs/ctv_'.$id.'_'.time().'.'.$ext;
    move_uploaded_file($_FILES['proof']['tmp_name'],__DIR__.'/../'.$proof);
  }
  $pdo->prepare("UPDATE ctv_payrolls SET status='paid', paid_by=?, paid_at=NOW(), payment_proof=COALESCE(NULLIF(?,''),payment_proof) WHERE id=?")->execute([current_user()['id'],$proof,$id]);
  if($proof) $pdo->prepare('INSERT INTO payment_proofs(target_type,target_id,file_path,note,uploaded_by) VALUES(?,?,?,?,?)')->execute(['ctv_payroll',$id,$proof,'CTV payment proof',current_user()['id']]);
  redirect('app.php?page=ctv_approval&month='.$month);
}
$rows=$pdo->prepare('SELECT cp.*,u.name user_name,u.avatar user_avatar,u.role user_role FROM ctv_payrolls cp JOIN users u ON u.id=cp.user_id WHERE cp.payroll_month=? ORDER BY FIELD(cp.status,"pending","approved","draft","paid"), cp.net_amount DESC');
$rows->execute([$month]);$rows=$rows->fetchAll();
$total=0;foreach($rows as $r)$total+=(float)$r['net_amount'];
?>
<section class="workspace-hero finance-hero">
  <div><span class="eyebrow">CTV Approval</span><h1>CTV cần thanh toán</h1><p class="muted">Duyệt và đánh dấu đã chi trả CTV/freelancer.</p></div>
  <form method="get"><input type="hidden" name="page" value="ctv_approval"><input type="month" name="month" value="<?= e($month) ?>"><button class="btn btn-soft">Xem</button></form>
</section>
<div class="stats-grid compact-stats"><div class="stat coral"><span>Total payout</span><strong><?= money_short($total) ?></strong></div><div class="stat yellow"><span>Số payroll</span><strong><?= count($rows) ?></strong></div></div>
<section class="card">
  <table class="dense-table"><thead><tr><th>CTV</th><th>Gross</th><th>Deduction</th><th>Net</th><th>Status</th><th>Proof</th><th>Action</th></tr></thead><tbody>
  <?php foreach($rows as $r): ?>
    <tr>
      <td><span class="user-chip"><?= avatar_html(['name'=>$r['user_name'],'avatar'=>$r['user_avatar']],true) ?><?= e($r['user_name']) ?></span><br><span class="muted"><?= e($r['user_role']) ?></span></td>
      <td><?= money($r['gross_amount']) ?></td><td><?= money($r['deduction']) ?></td><td><b><?= money($r['net_amount']) ?></b></td>
      <td><span class="badge <?= badge_class($r['status']) ?>"><?= e($r['status']) ?></span></td>
      <td><?php if($r['payment_proof']): ?><a class="btn btn-soft" href="<?= e($r['payment_proof']) ?>" target="_blank">Proof</a><?php endif; ?></td>
      <td>
        <?php if($r['status']==='pending' || $r['status']==='draft'): ?><a class="btn btn-coral" href="app.php?page=ctv_approval&month=<?= e($month) ?>&approve=<?= $r['id'] ?>">Approve</a><?php endif; ?>
        <?php if($r['status']==='approved'): ?>
        <form method="post" enctype="multipart/form-data" action="app.php?page=ctv_approval&month=<?= e($month) ?>&paid=<?= $r['id'] ?>" class="inline-upload"><input type="file" name="proof"><button class="btn btn-soft">Paid</button></form>
        <?php endif; ?>
      </td>
    </tr>
  <?php endforeach; ?>
  <?php if(empty($rows)): ?><tr><td colspan="7" class="muted">Chưa có CTV payroll tháng này.</td></tr><?php endif; ?>
  </tbody></table>
</section>
