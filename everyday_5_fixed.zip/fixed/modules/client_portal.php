<?php
if(!is_director_role($me) && !is_finance_role($me)) die('Bạn không có quyền xem Client Portal.');

try{
  $pdo->exec("CREATE TABLE IF NOT EXISTS client_portal_access (
    id INT AUTO_INCREMENT PRIMARY KEY,
    client_id INT NOT NULL,
    token VARCHAR(80) NOT NULL UNIQUE,
    is_active TINYINT(1) DEFAULT 1,
    note TEXT NULL,
    created_by INT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL,
    INDEX(client_id), INDEX(token)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}catch(Exception $e){}

function sprint3_portal_token(){ return bin2hex(random_bytes(24)); }

if(isset($_GET['generate'])){
  $cid=(int)$_GET['generate'];
  $st=$pdo->prepare('SELECT id FROM clients WHERE id=? LIMIT 1'); $st->execute([$cid]);
  if($st->fetch()){
    $old=$pdo->prepare('SELECT id FROM client_portal_access WHERE client_id=? LIMIT 1'); $old->execute([$cid]);
    if($row=$old->fetch()){
      $pdo->prepare('UPDATE client_portal_access SET token=?, is_active=1, updated_at=NOW() WHERE id=?')->execute([sprint3_portal_token(),$row['id']]);
    }else{
      $pdo->prepare('INSERT INTO client_portal_access(client_id,token,created_by) VALUES(?,?,?)')->execute([$cid,sprint3_portal_token(),$me['id']]);
    }
    log_activity($pdo,'generate','client_portal',$cid,'Tạo link client portal');
  }
  redirect('app.php?page=client_portal');
}
if(isset($_GET['toggle'])){
  $id=(int)$_GET['toggle'];
  $pdo->prepare('UPDATE client_portal_access SET is_active=1-is_active, updated_at=NOW() WHERE id=?')->execute([$id]);
  redirect('app.php?page=client_portal');
}

$base = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS']==='on' ? 'https://' : 'http://') . ($_SERVER['HTTP_HOST'] ?? '') . rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? ''),'/\\');
$rows=safe_rows($pdo,"SELECT c.*, a.id access_id,a.token,a.is_active,a.created_at,
  (SELECT COUNT(*) FROM projects p WHERE p.client_name=c.name) project_count,
  (SELECT COUNT(*) FROM quotations q WHERE q.client_name=c.name) quote_count,
  (SELECT COUNT(*) FROM contracts ct WHERE ct.client_name=c.name) contract_count
  FROM clients c LEFT JOIN client_portal_access a ON a.client_id=c.id ORDER BY c.id DESC");
?>
<section class="workspace-hero client-portal-hero">
  <div>
    <span class="eyebrow">Sprint 3</span>
    <h1>Client Portal</h1>
    <p class="muted">Tạo link riêng để khách hàng xem tiến độ project, báo giá, hợp đồng và trạng thái bàn giao.</p>
  </div>
  <a class="btn btn-soft" href="app.php?page=clients">Quản lý khách hàng</a>
</section>

<section class="card">
  <div class="card-head">
    <div><h2>Danh sách link khách hàng</h2><p class="muted">Link có token bảo mật. Có thể bật/tắt bất cứ lúc nào.</p></div>
  </div>
  <table class="dense-table mobile-card-table">
    <thead><tr><th>Khách hàng</th><th>Portal</th><th>Project</th><th>Báo giá</th><th>Hợp đồng</th><th>Trạng thái</th><th>Action</th></tr></thead>
    <tbody>
      <?php foreach($rows as $r): $url=$base.'/client_portal.php?token='.($r['token']??''); ?>
      <tr>
        <td data-label="Khách hàng"><b><?= e($r['name']) ?></b><br><span class="muted"><?= e($r['contact_person'] ?: $r['email']) ?></span></td>
        <td data-label="Portal">
          <?php if(!empty($r['token'])): ?>
            <input class="portal-link-input" readonly value="<?= e($url) ?>" onclick="this.select()">
          <?php else: ?><span class="muted">Chưa tạo</span><?php endif; ?>
        </td>
        <td data-label="Project"><span class="badge purple"><?= (int)$r['project_count'] ?></span></td>
        <td data-label="Báo giá"><span class="badge orange"><?= (int)$r['quote_count'] ?></span></td>
        <td data-label="Hợp đồng"><span class="badge green"><?= (int)$r['contract_count'] ?></span></td>
        <td data-label="Trạng thái"><?= !empty($r['token']) ? '<span class="badge '.($r['is_active']?'green':'red').'">'.($r['is_active']?'Active':'Off').'</span>' : '-' ?></td>
        <td data-label="Action" class="actions">
          <a class="btn btn-coral" href="app.php?page=client_portal&generate=<?= (int)$r['id'] ?>"><?= empty($r['token'])?'Tạo link':'Reset link' ?></a>
          <?php if(!empty($r['token'])): ?><a class="btn btn-soft" target="_blank" href="<?= e($url) ?>">Mở</a><a class="btn btn-soft" href="app.php?page=client_portal&toggle=<?= (int)$r['access_id'] ?>"><?= $r['is_active']?'Tắt':'Bật' ?></a><?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
      <?php if(empty($rows)): ?><tr><td colspan="7" class="muted">Chưa có khách hàng.</td></tr><?php endif; ?>
    </tbody>
  </table>
</section>
