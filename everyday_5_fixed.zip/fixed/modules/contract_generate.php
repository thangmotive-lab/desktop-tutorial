<?php
$qid=(int)($_GET['quotation_id'] ?? $_GET['quotient_id'] ?? $_GET['q'] ?? 0);
if(!$qid && isset($_GET['quotient_id'])) $qid=(int)$_GET['quotient_id'];
$stmt=$pdo->prepare('SELECT q.*,u.name owner_name FROM quotations q LEFT JOIN users u ON u.id=q.owner_id WHERE q.id=?');
$stmt->execute([$qid]);
$q=$stmt->fetch();
if(!$q) die('Không tìm thấy báo giá để tạo hợp đồng.');

$v=ensure_quotation_version($pdo,$qid);
$totals=quotation_version_totals($pdo,$v['id']);
$itemsStmt=$pdo->prepare('SELECT * FROM quotation_items WHERE quotation_version_id=? ORDER BY sort_order,id');
$itemsStmt->execute([$v['id']]);
$items=$itemsStmt->fetchAll();
$templates=$pdo->query("SELECT * FROM contract_templates WHERE status='active' ORDER BY template_type,id")->fetchAll();
$users=$pdo->query('SELECT id,name FROM users ORDER BY name')->fetchAll();

if($_SERVER['REQUEST_METHOD']==='POST'){
  $templateId=(int)$_POST['template_id'];
  $tstmt=$pdo->prepare('SELECT * FROM contract_templates WHERE id=?');
  $tstmt->execute([$templateId]);
  $tpl=$tstmt->fetch();
  if(!$tpl) die('Không tìm thấy template.');

  $contractCode = $_POST['contract_code'] ?: next_auto_code($pdo,'HD','contracts','contract_code');
  $uploadDir = __DIR__.'/../uploads/contracts';
  if(!is_dir($uploadDir)) mkdir($uploadDir,0775,true);
  $outputRel = 'uploads/contracts/'.$contractCode.'_'.time().'.docx';
  $outputAbs = __DIR__.'/../'.$outputRel;

  $services=[];
  foreach($items as $it){ if($it['service_name']) $services[]=$it['service_name'].' x '.$it['quantity'].' '.$it['unit']; }

  $data=[
    'CLIENT_NAME'=>$_POST['client_name'],
    'CONTRACT_CODE'=>$contractCode,
    'QUOTE_CODE'=>$q['quote_code'],
    'AMOUNT'=>money($totals['subtotal']),
    'VAT'=>money($totals['vat']),
    'TOTAL'=>money($totals['total']),
    'START_DATE'=>$_POST['start_date'],
    'END_DATE'=>$_POST['end_date'],
    'SIGNED_DATE'=>$_POST['signed_date'],
    'ACCOUNT_MANAGER'=>$_POST['account_manager_name'] ?? '',
    'SERVICE_NAME'=>$_POST['service_name'],
    'SERVICES'=>implode('; ',$services),
    'PAYMENT_TERMS'=>$_POST['payment_terms'],
    'CLIENT_REPRESENTATIVE'=>$_POST['client_representative'],
    'CLIENT_POSITION'=>$_POST['client_position'],
    'CLIENT_ADDRESS'=>$_POST['client_address'],
    'CLIENT_TAX_CODE'=>$_POST['client_tax_code'],
    'CLIENT_PHONE'=>$_POST['client_phone'],
    'CLIENT_EMAIL'=>$_POST['client_email'],
  ];

  try{
    replace_docx_placeholders(__DIR__.'/../'.$tpl['file_path'],$outputAbs,$data);
  }catch(Exception $e){
    die('Lỗi generate DOCX: '.e($e->getMessage()));
  }

  $pdo->prepare('INSERT INTO contracts(contract_code,quotation_id,template_id,client_name,total_value,signed_date,start_date,end_date,status,generated_file,quote_owner_id,contract_owner_id,account_manager_id,commission_rate,contract_month) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
    ->execute([$contractCode,$qid,$templateId,$_POST['client_name'],$totals['total'],$_POST['signed_date'],$_POST['start_date'],$_POST['end_date'],'Đã ký',$outputRel,$q['owner_id']?:null,$_POST['account_manager_id']?:null,$_POST['account_manager_id']?:null,2,date('Y-m',strtotime($_POST['signed_date'] ?: date('Y-m-d')))]);
  $cid=$pdo->lastInsertId();
  $pdo->prepare('UPDATE quotations SET contract_id=?, signed_contract=1, status="Contract Signed", signed_at=NOW() WHERE id=?')->execute([$cid,$qid]);

  foreach($_POST['payments']??[] as $idx=>$p){
    if(empty($p['amount'])) continue;
    $payCode=next_auto_code($pdo,'PAY','payment_schedules','payment_code');
    $pdo->prepare('INSERT INTO payment_schedules(contract_id,quotation_id,payment_code,title,milestone,amount,due_date,status,note) VALUES(?,?,?,?,?,?,?,?,?)')
      ->execute([$cid,$qid,$payCode,$p['title'] ?: ('Đợt '.($idx+1)),$p['title'] ?: ('Đợt '.($idx+1)),(float)$p['amount'],$p['due_date'] ?: null,'pending','Generated from contract']);
  }

  log_activity($pdo,'create','contract',$cid,'Generate contract '.$contractCode.' từ '.$q['quote_code']);
  redirect('app.php?page=contract_detail&id='.$cid);
}
?>
<section class="card">
  <div class="card-head"><div><span class="eyebrow">Contract Engine</span><h2>Generate Contract từ báo giá</h2><p class="muted"><?= e($q['quote_code']) ?> · <?= e($q['client_name']) ?> · V<?= (int)$v['version_no'] ?></p></div><a class="btn btn-soft" href="app.php?page=quotation_edit&id=<?= $qid ?>">← Báo giá</a></div>
  <div class="stats-grid compact-stats"><div class="stat mint"><span>Subtotal</span><strong><?= money_short($totals['subtotal']) ?></strong></div><div class="stat yellow"><span>VAT</span><strong><?= money_short($totals['vat']) ?></strong></div><div class="stat coral"><span>Total</span><strong><?= money_short($totals['total']) ?></strong></div></div>
</section>
<section class="card">
<form method="post">
  <div class="form-row"><div><label>Mã hợp đồng</label><input name="contract_code" value="<?= e(next_auto_code($pdo,'HD','contracts','contract_code')) ?>"></div><div><label>Template</label><select name="template_id"><?php foreach($templates as $tpl): ?><option value="<?= $tpl['id'] ?>"><?= e($tpl['template_name']) ?> — <?= e($tpl['template_type']) ?></option><?php endforeach; ?></select></div></div>
  <div class="form-row"><div><label>Khách hàng</label><input name="client_name" value="<?= e($q['client_name']) ?>"></div><div><label>Dịch vụ chính</label><input name="service_name" value="<?= e($q['title']) ?>"></div></div>
  <div class="form-row-3"><div><label>Ngày ký</label><input name="signed_date" type="date" value="<?= date('Y-m-d') ?>"></div><div><label>Start</label><input name="start_date" type="date"></div><div><label>End</label><input name="end_date" type="date"></div></div>
  <div class="form-row"><div><label>Đại diện bên A</label><input name="client_representative"></div><div><label>Chức vụ</label><input name="client_position"></div></div>
  <label>Địa chỉ bên A</label><input name="client_address">
  <div class="form-row-3"><div><label>MST bên A</label><input name="client_tax_code"></div><div><label>Điện thoại</label><input name="client_phone"></div><div><label>Email hóa đơn</label><input name="client_email"></div></div>
  <label>Account Manager</label><select name="account_manager_id"><?php foreach($users as $u): ?><option value="<?= $u['id'] ?>"><?= e($u['name']) ?></option><?php endforeach; ?></select>
  <label>Điều khoản thanh toán</label><textarea name="payment_terms"><?= e($q['payment_terms']) ?></textarea>

  <h3>Payment Schedule</h3>
  <div class="payment-grid">
    <div><label>Đợt 1</label><input name="payments[0][title]" value="Đợt 1"><input name="payments[0][amount]" type="number" value="<?= round($totals['total']/2) ?>"><input name="payments[0][due_date]" type="date"></div>
    <div><label>Đợt 2</label><input name="payments[1][title]" value="Đợt 2"><input name="payments[1][amount]" type="number" value="<?= round($totals['total']/2) ?>"><input name="payments[1][due_date]" type="date"></div>
    <div><label>Đợt 3</label><input name="payments[2][title]" value="Đợt 3"><input name="payments[2][amount]" type="number" value="0"><input name="payments[2][due_date]" type="date"></div>
  </div>
  <br><button class="primary">Generate Contract DOCX & Tạo hợp đồng</button>
</form>
</section>
