<?php
$type=$_GET['type'] ?? '';
$user=(int)($_GET['user_id'] ?? 0);
$q=trim($_GET['q'] ?? '');

$where=[];$params=[];
if($type){$where[]='al.target_type=?';$params[]=$type;}
if($user){$where[]='al.user_id=?';$params[]=$user;}
if($q!==''){$where[]='(al.description LIKE ? OR al.action LIKE ? OR al.target_type LIKE ?)';array_push($params,"%$q%","%$q%","%$q%");}
$sql='SELECT al.*,u.name user_name,u.avatar user_avatar FROM activity_logs al LEFT JOIN users u ON u.id=al.user_id';
if($where) $sql.=' WHERE '.implode(' AND ',$where);
$sql.=' ORDER BY al.id DESC LIMIT 200';
$stmt=$pdo->prepare($sql);$stmt->execute($params);$rows=$stmt->fetchAll();
$users=safe_rows($pdo,"SELECT id,name FROM users WHERE status='active' ORDER BY name");
$types=safe_rows($pdo,"SELECT DISTINCT target_type FROM activity_logs WHERE target_type<>'' ORDER BY target_type LIMIT 50");

function timeline_icon($action,$target){
  $a=mb_strtolower($action.' '.$target,'UTF-8');
  if(str_contains($a,'payment')) return '💰';
  if(str_contains($a,'contract')) return '📄';
  if(str_contains($a,'quote') || str_contains($a,'quotation')) return '🧾';
  if(str_contains($a,'task')) return '✅';
  if(str_contains($a,'project')) return '📁';
  if(str_contains($a,'ai')) return '✨';
  return '•';
}
?>
<section class="workspace-hero activity-hero">
  <div><span class="eyebrow">Activity Timeline</span><h1>Nhật ký hoạt động</h1><p class="muted">Theo dõi ai đã làm gì, ở module nào, vào thời điểm nào.</p></div>
</section>

<section class="card">
  <form class="asana-toolbar" method="get">
    <input type="hidden" name="page" value="activity">
    <input name="q" value="<?= e($q) ?>" placeholder="Tìm action, mô tả...">
    <select name="type"><option value="">Tất cả module</option><?php foreach($types as $t): ?><option value="<?= e($t['target_type']) ?>" <?= $type===$t['target_type']?'selected':'' ?>><?= e($t['target_type']) ?></option><?php endforeach; ?></select>
    <select name="user_id"><option value="0">Tất cả nhân sự</option><?php foreach($users as $u): ?><option value="<?= $u['id'] ?>" <?= $user===$u['id']?'selected':'' ?>><?= e($u['name']) ?></option><?php endforeach; ?></select>
    <button class="btn btn-soft">Filter</button>
  </form>
</section>

<section class="card">
  <div class="card-head"><h2>Timeline</h2><span class="muted"><?= count($rows) ?> hoạt động gần nhất</span></div>
  <div class="activity-timeline">
    <?php foreach($rows as $r): ?>
      <article class="timeline-item">
        <div class="timeline-dot"><?= timeline_icon($r['action'],$r['target_type']) ?></div>
        <div class="timeline-content">
          <div class="timeline-top">
            <span class="user-chip"><?= avatar_html(['name'=>$r['user_name'],'avatar'=>$r['user_avatar']],true) ?><?= e($r['user_name'] ?: 'System') ?></span>
            <small><?= e($r['created_at']) ?></small>
          </div>
          <h3><?= e(ucfirst($r['action'])) ?> <span><?= e($r['target_type']) ?><?= $r['target_id']?' #'.e($r['target_id']):'' ?></span></h3>
          <p><?= e($r['description']) ?></p>
        </div>
      </article>
    <?php endforeach; ?>
    <?php if(empty($rows)): ?><p class="muted">Chưa có activity phù hợp.</p><?php endif; ?>
  </div>
</section>
