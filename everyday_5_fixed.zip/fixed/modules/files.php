<?php
if($_SERVER['REQUEST_METHOD']==='POST'){
  if(isset($_POST['project_folder_update'])){
    $pdo->prepare('UPDATE projects SET drive_folder_link=?, canva_folder_link=? WHERE id=?')->execute([$_POST['drive_folder_link'],$_POST['canva_folder_link'],$_POST['project_id']]);
    log_activity($pdo,'update','project_folder',$_POST['project_id'],'Cập nhật folder Drive/Canva cho project');
    redirect('app.php?page=files');
  }
  $pdo->prepare('INSERT INTO file_links(title,url,related_type,related_id,note,created_by) VALUES(?,?,?,?,?,?)')->execute([$_POST['title'],$_POST['url'],$_POST['related_type'],$_POST['related_id'],$_POST['note'],current_user()['id']]);
  log_activity($pdo,'create','file_link',$pdo->lastInsertId(),'Thêm file link '.$_POST['title']);
  redirect('app.php?page=files');
}
$projects=$pdo->query('SELECT id,name,client_name,drive_folder_link,canva_folder_link FROM projects ORDER BY name')->fetchAll();
$rows=$pdo->query('SELECT fl.*,u.name user_name,u.avatar user_avatar FROM file_links fl LEFT JOIN users u ON u.id=fl.created_by ORDER BY fl.id DESC')->fetchAll();
?>
<section class="card">
  <div class="card-head"><h2>Project Folder Links</h2></div>
  <table>
    <thead><tr><th>Project</th><th>Drive Folder</th><th>Canva Folder</th><th>Action</th></tr></thead>
    <tbody>
    <?php foreach($projects as $p): ?>
      <tr>
        <td><b><?= e($p['name']) ?></b><br><span class="muted"><?= e($p['client_name']) ?></span></td>
        <td><?php if($p['drive_folder_link']): ?><a class="btn btn-soft" target="_blank" href="<?= e($p['drive_folder_link']) ?>">Open Drive</a><?php else: ?><span class="muted">Chưa có</span><?php endif; ?></td>
        <td><?php if($p['canva_folder_link']): ?><a class="btn btn-soft" target="_blank" href="<?= e($p['canva_folder_link']) ?>">Open Canva</a><?php else: ?><span class="muted">Chưa có</span><?php endif; ?></td>
        <td><button class="btn btn-soft" onclick="openProjectFolderModal(<?= $p['id'] ?>,'<?= e($p['drive_folder_link']) ?>','<?= e($p['canva_folder_link']) ?>')">Edit folder</button></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</section>

<section class="card">
  <div class="card-head"><h2>File Links</h2><button class="primary" onclick="openModal('fileLinkModal')">+ Thêm link file</button></div>
  <table><thead><tr><th>Title</th><th>Link</th><th>Related</th><th>Created by</th><th>Note</th></tr></thead><tbody>
<?php foreach($rows as $r): ?><tr><td><b><?= e($r['title']) ?></b></td><td><a class="btn btn-soft" href="<?= e($r['url']) ?>" target="_blank">Open</a></td><td><?= e($r['related_type']) ?> #<?= e($r['related_id']) ?></td><td><span class="user-chip"><?= avatar_html(['name'=>$r['user_name'],'avatar'=>$r['user_avatar']],true) ?><?= e($r['user_name']) ?></span></td><td><?= e($r['note']) ?></td></tr><?php endforeach; ?>
</tbody></table>
</section>

<div class="modal-backdrop" id="fileLinkModal">
  <div class="modal-panel">
    <button class="modal-close" onclick="closeModal('fileLinkModal')">×</button>
    <h2>Thêm link file</h2>
    <form method="post">
      <label>Title</label><input name="title" required>
      <label>URL</label><input name="url" required>
      <div class="form-row"><div><label>Related type</label><select name="related_type"><option>task</option><option>project</option><option>quotation</option><option>client</option></select></div><div><label>Related ID</label><input name="related_id" type="number" value="0"></div></div>
      <label>Note</label><textarea name="note"></textarea>
      <button class="primary">Lưu link</button>
    </form>
  </div>
</div>

<div class="modal-backdrop" id="projectFolderModal">
  <div class="modal-panel">
    <button class="modal-close" onclick="closeModal('projectFolderModal')">×</button>
    <h2>Cập nhật folder project</h2>
    <form method="post">
      <input type="hidden" name="project_folder_update" value="1">
      <input type="hidden" name="project_id" id="folderProjectId">
      <label>Google Drive Folder</label><input name="drive_folder_link" id="folderDrive">
      <label>Canva Folder</label><input name="canva_folder_link" id="folderCanva">
      <button class="primary">Lưu folder</button>
    </form>
  </div>
</div>
<script>
function openProjectFolderModal(id, drive, canva){
  document.getElementById('folderProjectId').value=id;
  document.getElementById('folderDrive').value=drive || '';
  document.getElementById('folderCanva').value=canva || '';
  openModal('projectFolderModal');
}
</script>
