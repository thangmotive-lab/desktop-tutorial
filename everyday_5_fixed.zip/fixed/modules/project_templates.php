<?php
$me=current_user();
if(!is_director_role($me) && !is_finance_role($me) && !user_is_admin()) { echo '<section class="card"><h2>Không có quyền truy cập</h2></section>'; return; }
try{
  $pdo->exec("CREATE TABLE IF NOT EXISTS project_templates(id INT AUTO_INCREMENT PRIMARY KEY,template_name VARCHAR(190) NOT NULL,template_type VARCHAR(80) DEFAULT 'General',description TEXT NULL,is_active TINYINT DEFAULT 1,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  $pdo->exec("CREATE TABLE IF NOT EXISTS project_template_tasks(id INT AUTO_INCREMENT PRIMARY KEY,template_id INT NOT NULL,sort_order INT DEFAULT 0,title VARCHAR(255) NOT NULL,phase VARCHAR(120) NULL,priority VARCHAR(80) DEFAULT 'Quan trọng',due_offset_days INT DEFAULT 3,assignee_role VARCHAR(80) NULL,brief TEXT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}catch(Exception $e){}
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['save_template'])){
  $pdo->prepare('INSERT INTO project_templates(template_name,template_type,description,is_active) VALUES(?,?,?,1)')->execute([$_POST['template_name'],$_POST['template_type'],$_POST['description']]);
  $tid=(int)$pdo->lastInsertId();
  foreach($_POST['tasks']??[] as $i=>$t){ if(trim($t['title']??'')==='') continue; $pdo->prepare('INSERT INTO project_template_tasks(template_id,sort_order,title,phase,priority,due_offset_days,brief) VALUES(?,?,?,?,?,?,?)')->execute([$tid,$i+1,$t['title'],$t['phase']??'Milestone',$t['priority']??'Quan trọng',(int)($t['due_offset_days']??3),$t['brief']??'']); }
  redirect('app.php?page=project_templates');
}
if(isset($_GET['delete']) && user_is_admin()){
  $id=(int)$_GET['delete']; $pdo->prepare('DELETE FROM project_template_tasks WHERE template_id=?')->execute([$id]); $pdo->prepare('DELETE FROM project_templates WHERE id=?')->execute([$id]); redirect('app.php?page=project_templates');
}
$templates=safe_rows($pdo,'SELECT * FROM project_templates ORDER BY id DESC');
?>
<section class="card"><div class="card-head"><div><span class="eyebrow">Automation</span><h2>Project Templates</h2><p class="muted">Template dùng để tự sinh milestone/task khi tạo project từ báo giá.</p></div><a class="btn btn-soft" href="app.php?page=quote_project_generator">Quote → Project</a></div>
<table class="dense-table"><thead><tr><th>Template</th><th>Type</th><th>Tasks</th><th>Action</th></tr></thead><tbody><?php foreach($templates as $t): $cnt=(int)safe_sum($pdo,'SELECT COUNT(*) FROM project_template_tasks WHERE template_id='.(int)$t['id']); ?><tr><td><b><?= e($t['template_name']) ?></b><br><span class="muted"><?= e($t['description']) ?></span></td><td><?= e($t['template_type']) ?></td><td><?= $cnt ?></td><td><?php if(user_is_admin()): ?><a class="btn btn-soft" onclick="return confirm('Xóa template?')" href="app.php?page=project_templates&delete=<?= $t['id'] ?>">Xóa</a><?php endif; ?></td></tr><?php endforeach; ?></tbody></table></section>
<section class="card"><div class="card-head"><div><span class="eyebrow">New</span><h2>Tạo template nhanh</h2></div></div><form method="post"><div class="form-row"><div><label>Tên template</label><input name="template_name" required placeholder="Video Production / Event / Website"></div><div><label>Type</label><input name="template_type" value="General"></div></div><label>Mô tả</label><textarea name="description"></textarea><div id="templateTasks"><label>Task template</label><?php for($i=0;$i<6;$i++): ?><div class="form-row-3"><input name="tasks[<?= $i ?>][title]" placeholder="Tên task"><input name="tasks[<?= $i ?>][phase]" placeholder="Phase"><select name="tasks[<?= $i ?>][priority]"><option>Khẩn cấp làm ngay</option><option>Làm ngay</option><option selected>Quan trọng</option><option>Lúc nào làm cũng được</option></select></div><textarea name="tasks[<?= $i ?>][brief]" placeholder="Brief ngắn"></textarea><input name="tasks[<?= $i ?>][due_offset_days]" type="number" value="<?= ($i+1)*3 ?>" placeholder="Due offset days"><hr><?php endfor; ?></div><button class="primary" name="save_template" value="1">Lưu template</button></form></section>
