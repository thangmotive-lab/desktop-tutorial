<?php
if(!user_is_admin()) die('Bạn không có quyền truy cập trang này.');
$features = [
  'workspace'=>'Workspace',
  'dashboard'=>'CEO Dashboard',
  'clients'=>'CRM Khách hàng',
  'quotation'=>'Báo giá / AI Generate',
  'contracts'=>'Hợp đồng',
  'payments'=>'Công nợ',
  'projects'=>'Projects',
  'tasks'=>'Tasks',
  'internal_cost'=>'Internal Cost',
  'users'=>'Hồ sơ nhân sự',
  'leave_requests'=>'Đơn từ',
  'attendance'=>'Chấm công',
  'payroll'=>'Bảng lương',
  'kpi'=>'KPI',
  'activity'=>'Activity Log',
  'admin'=>'Admin Area'
];

if($_SERVER['REQUEST_METHOD']==='POST'){
  $pdo->prepare('DELETE FROM user_permissions WHERE user_id=?')->execute([$_POST['user_id']]);
  foreach($_POST['features']??[] as $f){
    $pdo->prepare('INSERT INTO user_permissions(user_id,feature_key,can_view,can_edit) VALUES(?,?,?,?)')->execute([$_POST['user_id'],$f,1, in_array($f, $_POST['edit_features']??[]) ? 1 : 0]);
  }
  log_activity($pdo,'update','permissions',$_POST['user_id'],'Cập nhật phân quyền tài khoản');
  redirect('app.php?page=permissions&user_id='.$_POST['user_id']);
}

$users=$pdo->query('SELECT * FROM users ORDER BY name')->fetchAll();
$currentId=(int)($_GET['user_id']??($users[0]['id']??0));
$stmt=$pdo->prepare('SELECT * FROM user_permissions WHERE user_id=?');
$stmt->execute([$currentId]);
$perms=$stmt->fetchAll();
$view=array_column($perms,'feature_key');
$edit=[];
foreach($perms as $p){ if($p['can_edit']) $edit[]=$p['feature_key']; }
?>
<div class="two-col">
<section class="card">
  <div class="card-head"><h2>Chọn tài khoản</h2></div>
  <table>
    <thead><tr><th>Nhân sự</th><th>Role</th><th>Action</th></tr></thead>
    <tbody>
    <?php foreach($users as $u): ?>
      <tr>
        <td><span class="user-chip"><?= avatar_html($u,true) ?><?= e($u['name']) ?></span></td>
        <td><?= e($u['role']) ?></td>
        <td><a class="btn btn-soft" href="app.php?page=permissions&user_id=<?= $u['id'] ?>">Phân quyền</a></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</section>
<section class="card">
  <div class="card-head"><h2>Phân quyền chức năng</h2></div>
  <form method="post">
    <input type="hidden" name="user_id" value="<?= $currentId ?>">
    <p class="muted">Tick “Xem” để tài khoản nhìn thấy module. Tick “Sửa” để có quyền thao tác.</p>
    <div class="permission-grid">
      <?php foreach($features as $key=>$label): ?>
        <label>
          <input type="checkbox" name="features[]" value="<?= e($key) ?>" <?= in_array($key,$view)?'checked':'' ?>>
          <span><?= e($label) ?></span>
        </label>
        <label>
          <input type="checkbox" name="edit_features[]" value="<?= e($key) ?>" <?= in_array($key,$edit)?'checked':'' ?>>
          <span>Sửa <?= e($label) ?></span>
        </label>
      <?php endforeach; ?>
    </div>
    <br>
    <button class="primary">Lưu phân quyền</button>
  </form>
</section>
</div>
