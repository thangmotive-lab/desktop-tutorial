<?php
if(!can_view_business_finance()) die('Bạn không có quyền xem Business Finance.');
$month = $_GET['month'] ?? date('Y-m');
$start = date('Y-m-01', strtotime($month.'-01'));
$end = date('Y-m-t', strtotime($month.'-01'));

$cashIn = safe_sum($pdo, "SELECT COALESCE(SUM(amount),0) FROM payment_schedules WHERE status='paid' AND COALESCE(paid_date,due_date) BETWEEN '$start' AND '$end'");
$cashOutExpenses = safe_sum($pdo, "SELECT COALESCE(SUM(amount),0) FROM business_expenses WHERE expense_month='$month'");
$cashOutPayroll = safe_sum($pdo, "SELECT COALESCE(SUM(COALESCE(net_salary,total_salary,0)),0) FROM payroll WHERE COALESCE(salary_month,month)='$month'");
$cashOutCtv = safe_sum($pdo, "SELECT COALESCE(SUM(net_amount),0) FROM ctv_payrolls WHERE payroll_month='$month' AND status IN ('approved','paid')");
$cashOut = $cashOutExpenses + $cashOutPayroll + $cashOutCtv;
$profit = $cashIn - $cashOut;
$receivable = safe_sum($pdo, "SELECT COALESCE(SUM(amount),0) FROM payment_schedules WHERE status!='paid' AND COALESCE(carry_month,DATE_FORMAT(due_date,'%Y-%m'))='$month'");
$overdue = safe_sum($pdo, "SELECT COALESCE(SUM(amount),0) FROM payment_schedules WHERE status!='paid' AND due_date < CURDATE()");

$months=[];
for($i=5;$i>=0;$i--){ $months[]=date('Y-m', strtotime("-$i month", strtotime($month.'-01'))); }
$chartRows=[]; $maxRevenue=1;
foreach($months as $mo){
  $s=date('Y-m-01',strtotime($mo.'-01')); $e=date('Y-m-t',strtotime($mo.'-01'));
  $rev=safe_sum($pdo,"SELECT COALESCE(SUM(amount),0) FROM payment_schedules WHERE status='paid' AND COALESCE(paid_date,due_date) BETWEEN '$s' AND '$e'");
  $out=safe_sum($pdo,"SELECT COALESCE(SUM(amount),0) FROM business_expenses WHERE expense_month='$mo'") + safe_sum($pdo,"SELECT COALESCE(SUM(COALESCE(net_salary,total_salary,0)),0) FROM payroll WHERE COALESCE(salary_month,month)='$mo'") + safe_sum($pdo,"SELECT COALESCE(SUM(net_amount),0) FROM ctv_payrolls WHERE payroll_month='$mo' AND status IN ('approved','paid')");
  $chartRows[]=['month'=>$mo,'in'=>$rev,'out'=>$out,'profit'=>$rev-$out];
  $maxRevenue=max($maxRevenue,$rev,$out,abs($rev-$out));
}

$inRows = safe_rows($pdo, "SELECT ps.*, COALESCE(c.client_name,q.client_name) client_name, COALESCE(c.contract_code,q.quote_code,ps.payment_code) code FROM payment_schedules ps LEFT JOIN contracts c ON c.id=ps.contract_id LEFT JOIN quotations q ON q.id=ps.quotation_id WHERE status='paid' AND COALESCE(paid_date,due_date) BETWEEN '$start' AND '$end' ORDER BY COALESCE(paid_date,due_date) DESC LIMIT 12");
$outRows = safe_rows($pdo, "SELECT category, title, note, amount, expense_date FROM business_expenses WHERE expense_month='$month' ORDER BY expense_date DESC,id DESC LIMIT 12");
$forecastRows = safe_rows($pdo, "SELECT ps.*, COALESCE(c.client_name,q.client_name) client_name, COALESCE(c.contract_code,q.quote_code,ps.payment_code) code FROM payment_schedules ps LEFT JOIN contracts c ON c.id=ps.contract_id LEFT JOIN quotations q ON q.id=ps.quotation_id WHERE status!='paid' ORDER BY due_date ASC LIMIT 10");
?>
<section class="workspace-hero finance-dashboard-v5-hero">
  <div>
    <span class="eyebrow">Finance Dashboard</span>
    <h1>Tổng quan dòng tiền <?= e($month) ?></h1>
    <p class="muted">Nhìn nhanh tiền vào, tiền ra, lợi nhuận, công nợ và biểu đồ doanh số từng tháng để đặt mục tiêu.</p>
  </div>
  <form method="get" class="finance-month-picker"><input type="hidden" name="page" value="business_finance"><input type="month" name="month" value="<?= e($month) ?>"><button class="btn btn-soft">Xem</button></form>
</section>

<div class="finance-kpi-grid-v5">
  <div class="finance-kpi-card income"><span>Tiền vào</span><strong><?= money_short($cashIn) ?></strong><small>Đã thu trong tháng</small></div>
  <div class="finance-kpi-card outcome"><span>Tiền ra</span><strong><?= money_short($cashOut) ?></strong><small>Chi phí + lương + CTV</small></div>
  <div class="finance-kpi-card profit"><span>Lợi nhuận tạm tính</span><strong><?= money_short($profit) ?></strong><small><?= $profit>=0?'Dương dòng tiền':'Âm dòng tiền' ?></small></div>
  <div class="finance-kpi-card debt"><span>Công nợ cần thu</span><strong><?= money_short($receivable) ?></strong><small>Quá hạn: <?= money_short($overdue) ?></small></div>
</div>

<section class="card finance-chart-card-v5">
  <div class="card-head"><div><h2>Biểu đồ doanh số 6 tháng</h2><p class="muted">Cột thể hiện tiền vào/tiền ra. Đường lợi nhuận tạm tính để xem tháng nào đang hiệu quả.</p></div><a class="btn btn-soft" href="app.php?page=payments&month=<?= e($month) ?>">Mở công nợ</a></div>
  <div class="finance-bars-v5" style="--max:<?= (float)$maxRevenue ?>">
    <?php foreach($chartRows as $r): ?>
      <div class="finance-month-col">
        <div class="finance-bar-stack">
          <span class="bar in" title="Tiền vào <?= money($r['in']) ?>" style="height:<?= max(6,round($r['in']/$maxRevenue*150)) ?>px"></span>
          <span class="bar out" title="Tiền ra <?= money($r['out']) ?>" style="height:<?= max(6,round($r['out']/$maxRevenue*150)) ?>px"></span>
        </div>
        <b><?= e(date('m/Y',strtotime($r['month'].'-01'))) ?></b>
        <small><?= money_short($r['profit']) ?></small>
      </div>
    <?php endforeach; ?>
  </div>
</section>

<div class="finance-three-col-v5">
  <section class="card">
    <div class="card-head"><h2>Tiền vào gần nhất</h2></div>
    <table class="dense-table"><thead><tr><th>Khách</th><th>Số tiền</th><th>Ngày</th></tr></thead><tbody>
    <?php foreach($inRows as $r): ?><tr><td><b><?= e($r['client_name']) ?></b><br><span class="muted"><?= e($r['code']) ?></span></td><td><?= money($r['amount']) ?></td><td><?= e($r['paid_date'] ?: $r['due_date']) ?></td></tr><?php endforeach; ?>
    <?php if(empty($inRows)): ?><tr><td colspan="3" class="muted">Chưa có khoản thu.</td></tr><?php endif; ?>
    </tbody></table>
  </section>
  <section class="card">
    <div class="card-head"><h2>Tiền ra gần nhất</h2></div>
    <table class="dense-table"><thead><tr><th>Khoản chi</th><th>Số tiền</th><th>Ngày</th></tr></thead><tbody>
    <?php foreach($outRows as $r): ?><tr><td><b><?= e($r['title'] ?: $r['category']) ?></b><br><span class="muted"><?= e($r['category']) ?></span></td><td><?= money($r['amount']) ?></td><td><?= e($r['expense_date']) ?></td></tr><?php endforeach; ?>
    <?php if(empty($outRows)): ?><tr><td colspan="3" class="muted">Chưa có khoản chi.</td></tr><?php endif; ?>
    </tbody></table>
  </section>
  <section class="card">
    <div class="card-head"><h2>Sắp phải thu</h2></div>
    <table class="dense-table"><thead><tr><th>Khách</th><th>Số tiền</th><th>Due</th></tr></thead><tbody>
    <?php foreach($forecastRows as $r): ?><tr><td><b><?= e($r['client_name']) ?></b><br><span class="muted"><?= e($r['code']) ?></span></td><td><?= money($r['amount']) ?></td><td><?= e($r['due_date']) ?></td></tr><?php endforeach; ?>
    <?php if(empty($forecastRows)): ?><tr><td colspan="3" class="muted">Không có khoản cần thu.</td></tr><?php endif; ?>
    </tbody></table>
  </section>
</div>
