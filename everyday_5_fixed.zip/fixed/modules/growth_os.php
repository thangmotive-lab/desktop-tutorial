<?php
$me=current_user();
$uid=(int)($_GET['user_id'] ?? $me['id']);
$month=$_GET['month'] ?? date('Y-m');
$isManager = is_director_role() || user_is_admin();
if(!$isManager) $uid=(int)$me['id'];

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['complete_focus_session'])){
  $userId=(int)$me['id'];
  $minutes=max(1,(int)($_POST['actual_minutes'] ?? $_POST['planned_minutes'] ?? 50));
  $xp=max(1, floor($minutes/10));
  $stmt=$pdo->prepare("INSERT INTO focus_sessions(user_id,project_id,task_id,title,planned_minutes,actual_minutes,outcome,status,session_date,started_at,completed_at) VALUES(?,?,?,?,?,?,?,?,CURDATE(),?,NOW())");
  $stmt->execute([$userId,($_POST['project_id']?:null),($_POST['task_id']?:null),trim($_POST['title'] ?: 'Focus Session'),(int)$_POST['planned_minutes'],$minutes,$_POST['outcome']??'','completed',$_POST['started_at']?:date('Y-m-d H:i:s')]);
  $sid=(int)$pdo->lastInsertId();
  $pdo->prepare("INSERT INTO growth_xp_events(user_id,source_type,source_id,xp,title,description,event_date) VALUES(?,?,?,?,?,?,CURDATE())")
      ->execute([$userId,'focus_session',$sid,$xp,'Deep Work Session','+'.$minutes.' phút focus']);
  log_activity($pdo,'complete','focus_session',$sid,'Hoàn thành focus session +'.$xp.' XP');
  redirect('app.php?page=growth_os&user_id='.$userId.'&month='.$month.'&focus_done=1');
}

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['complete_learning'])){
  $jid=(int)$_POST['journey_id'];
  $userId=(int)$me['id'];
  $st=$pdo->prepare("SELECT * FROM learning_journeys WHERE id=? LIMIT 1");
  $st->execute([$jid]);
  $j=$st->fetch();
  if($j){
    $pdo->prepare("INSERT INTO user_learning_progress(user_id,journey_id,status,completed_at) VALUES(?,?,?,NOW()) ON DUPLICATE KEY UPDATE status='done', completed_at=NOW()")
        ->execute([$userId,$jid,'done']);
    $pdo->prepare("INSERT INTO growth_xp_events(user_id,source_type,source_id,xp,title,description,event_date) VALUES(?,?,?,?,?,?,CURDATE())")
        ->execute([$userId,'learning_journey',$jid,(int)$j['xp_reward'],'Learning: '.$j['skill_name'],$j['description']]);
  }
  redirect('app.php?page=growth_os&user_id='.$userId.'&month='.$month.'&learned=1');
}

$users=safe_rows($pdo,"SELECT id,name,role,avatar FROM users WHERE status='active' ORDER BY name");
$user=null;
foreach($users as $u){ if((int)$u['id']===$uid) $user=$u; }
if(!$user) $user=$me;

$start=$month.'-01';
$end=date('Y-m-t',strtotime($start));

$taskDone=(int)safe_sum($pdo,"SELECT COUNT(*) FROM tasks WHERE assignee_id=$uid AND status='Done' AND DATE(COALESCE(completed_at,updated_at,deadline,created_at)) BETWEEN '$start' AND '$end'");
$taskOpen=(int)safe_sum($pdo,"SELECT COUNT(*) FROM tasks WHERE assignee_id=$uid AND status!='Done'");
$onTimeDone=(int)safe_sum($pdo,"SELECT COUNT(*) FROM tasks WHERE assignee_id=$uid AND status='Done' AND deadline IS NOT NULL AND DATE(COALESCE(completed_at,updated_at,deadline)) <= deadline AND DATE(COALESCE(completed_at,updated_at,deadline,created_at)) BETWEEN '$start' AND '$end'");
$attendanceDays=(int)safe_sum($pdo,"SELECT COUNT(DISTINCT work_date) FROM attendance WHERE user_id=$uid AND work_date BETWEEN '$start' AND '$end'");
$focusMinutes=(int)safe_sum($pdo,"SELECT COALESCE(SUM(actual_minutes),0) FROM focus_sessions WHERE user_id=$uid AND session_date BETWEEN '$start' AND '$end'");
$manualXp=(int)safe_sum($pdo,"SELECT COALESCE(SUM(xp),0) FROM growth_xp_events WHERE user_id=$uid AND event_date BETWEEN '$start' AND '$end'");

$taskXp=$taskDone*5 + $onTimeDone*3;
$totalXp=$manualXp + $taskXp;
$level=max(1,floor($totalXp/250)+1);
$levelBase=($level-1)*250;
$levelProgress=$totalXp-$levelBase;
$levelPct=min(100,round($levelProgress/250*100));

$taskScore=min(100,$taskDone*5);
$onTimeRate=$taskDone>0?round($onTimeDone/$taskDone*100):0;
$focusScore=min(100,round($focusMinutes/60/20*100)); // 20h/month target
$attendanceScore=min(100,round($attendanceDays/22*100));
$productivityScore=round($taskScore*.4 + $onTimeRate*.25 + $focusScore*.2 + $attendanceScore*.15);

$winBoard=safe_rows($pdo,"SELECT u.id,u.name,u.role,u.avatar,
  COALESCE(SUM(x.xp),0) xp,
  COUNT(CASE WHEN t.status='Done' AND DATE(COALESCE(t.completed_at,t.updated_at,t.deadline,t.created_at)) BETWEEN '$start' AND '$end' THEN t.id END) done_tasks,
  COALESCE(SUM(fs.actual_minutes),0) focus_minutes
  FROM users u
  LEFT JOIN growth_xp_events x ON x.user_id=u.id AND x.event_date BETWEEN '$start' AND '$end'
  LEFT JOIN tasks t ON t.assignee_id=u.id
  LEFT JOIN focus_sessions fs ON fs.user_id=u.id AND fs.session_date BETWEEN '$start' AND '$end'
  WHERE u.status='active'
  GROUP BY u.id
  ORDER BY xp DESC, done_tasks DESC
  LIMIT 10");

$xpEvents=safe_rows($pdo,"SELECT * FROM growth_xp_events WHERE user_id=$uid AND event_date BETWEEN '$start' AND '$end' ORDER BY event_date DESC,id DESC LIMIT 50");
$focusSessions=safe_rows($pdo,"SELECT fs.*,p.name project_name,t.title task_title FROM focus_sessions fs LEFT JOIN projects p ON p.id=fs.project_id LEFT JOIN tasks t ON t.id=fs.task_id WHERE fs.user_id=$uid AND fs.session_date BETWEEN '$start' AND '$end' ORDER BY fs.id DESC LIMIT 20");
$tasks=safe_rows($pdo,"SELECT t.id,t.title,p.name project_name FROM tasks t LEFT JOIN projects p ON p.id=t.project_id WHERE t.assignee_id=".$me['id']." AND t.status!='Done' ORDER BY t.deadline ASC,t.id DESC LIMIT 100");
$projects=safe_rows($pdo,"SELECT id,name,client_name FROM projects WHERE status NOT IN ('Completed','Hoàn tất','Đã nghiệm thu') ORDER BY name LIMIT 100");

$role=$user['role'] ?? '';
$roleKey='General';
if(stripos($role,'content')!==false) $roleKey='Content';
elseif(stripos($role,'design')!==false || stripos($role,'designer')!==false) $roleKey='Designer';
elseif(stripos($role,'BD')!==false) $roleKey='BD';
elseif(stripos($role,'account')!==false || stripos($role,'sale')!==false) $roleKey='Account';
$journeys=safe_rows($pdo,"SELECT lj.*,ulp.status progress_status FROM learning_journeys lj LEFT JOIN user_learning_progress ulp ON ulp.journey_id=lj.id AND ulp.user_id=$uid WHERE lj.is_active=1 AND lj.role_name IN ('$roleKey','General') ORDER BY lj.level_no,lj.skill_name LIMIT 50");
?>
<section class="workspace-hero growth-hero">
  <div>
    <span class="eyebrow">Growth OS</span>
    <h1>Personal Growth Dashboard</h1>
    <p class="muted">XP, Productivity Score, Focus Hours, Attendance và Learning Journey.</p>
  </div>
  <form method="get" class="growth-filter">
    <input type="hidden" name="page" value="growth_os">
    <?php if($isManager): ?><select name="user_id"><?php foreach($users as $u): ?><option value="<?= $u['id'] ?>" <?= $uid==$u['id']?'selected':'' ?>><?= e($u['name'].' — '.$u['role']) ?></option><?php endforeach; ?></select><?php endif; ?>
    <input type="month" name="month" value="<?= e($month) ?>">
    <button class="btn btn-soft">Xem</button>
  </form>
</section>

<?php if(!empty($_GET['focus_done'])): ?><div class="alert success">✅ Đã cộng XP cho Focus Session.</div><?php endif; ?>
<?php if(!empty($_GET['learned'])): ?><div class="alert success">🚀 Đã hoàn thành Learning Journey và cộng XP.</div><?php endif; ?>

<section class="growth-profile-card card">
  <div class="growth-user">
    <?= avatar_html($user) ?>
    <div><span class="eyebrow"><?= e($user['role'] ?? '') ?></span><h2><?= e($user['name'] ?? 'Me') ?></h2><p class="muted">Level <?= $level ?> · <?= num($totalXp) ?> XP tháng này</p></div>
  </div>
  <div class="xp-progress">
    <div><b><?= num($levelProgress) ?>/250 XP</b><span>Level <?= $level ?> progress</span></div>
    <div class="progress"><span style="width:<?= $levelPct ?>%"></span></div>
  </div>
</section>

<div class="stats-grid growth-stats">
  <div class="stat purple"><span>Productivity Score</span><strong><?= $productivityScore ?></strong><small><?= $productivityScore>=85?'Excellent':($productivityScore>=70?'Good':'Needs coaching') ?></small></div>
  <div class="stat mint"><span>Task Completed</span><strong><?= $taskDone ?></strong><small>+<?= $taskDone*5 ?> XP</small></div>
  <div class="stat yellow"><span>On-time</span><strong><?= $onTimeRate ?>%</strong><small><?= $onTimeDone ?> task đúng hạn</small></div>
  <div class="stat coral"><span>Focus Hours</span><strong><?= round($focusMinutes/60,1) ?>h</strong><small>+<?= floor($focusMinutes/10) ?> XP</small></div>
  <div class="stat mint"><span>Attendance</span><strong><?= $attendanceDays ?>/22</strong><small><?= $attendanceScore ?>%</small></div>
</div>

<div class="two-col">
<section class="card">
  <div class="card-head"><div><h2>Focus Timer V2</h2><p class="muted">Chọn task, bấm timer, hoàn thành và nhận XP.</p></div></div>
  <form method="post" id="focusV2Form">
    <input type="hidden" name="complete_focus_session" value="1">
    <input type="hidden" name="actual_minutes" id="focusActualMinutes" value="50">
    <input type="hidden" name="started_at" id="focusStartedAt" value="">
    <label>Tiêu đề focus</label><input name="title" id="focusTitle" placeholder="Ví dụ: Proposal Aquafield" required>
    <div class="form-row"><div><label>Project</label><select name="project_id"><option value="">Không chọn</option><?php foreach($projects as $p): ?><option value="<?= $p['id'] ?>"><?= e($p['name'].' — '.$p['client_name']) ?></option><?php endforeach; ?></select></div><div><label>Task</label><select name="task_id"><option value="">Không chọn</option><?php foreach($tasks as $t): ?><option value="<?= $t['id'] ?>"><?= e($t['title'].' — '.$t['project_name']) ?></option><?php endforeach; ?></select></div></div>
    <label>Thời lượng</label><div class="focus-duration-buttons"><button type="button" data-min="25">25 phút</button><button type="button" data-min="50" class="active">50 phút</button><button type="button" data-min="90">90 phút</button></div>
    <input type="hidden" name="planned_minutes" id="focusPlannedMinutes" value="50">
    <div class="focus-timer-display" id="focusTimerDisplay">50:00</div>
    <div class="focus-timer-actions"><button type="button" class="btn btn-soft" id="focusStartBtn">Start</button><button type="button" class="btn btn-soft" id="focusPauseBtn">Pause</button><button type="button" class="btn btn-soft" id="focusResetBtn">Reset</button></div>
    <label>Outcome sau phiên focus</label><textarea name="outcome" placeholder="Bạn đã hoàn thành gì sau phiên này?"></textarea>
    <button class="primary focus-complete-btn">Hoàn thành & cộng XP</button>
  </form>
</section>

<section class="card">
  <div class="card-head"><h2>Win Board tháng này</h2></div>
  <div class="win-board">
    <?php foreach($winBoard as $i=>$w): ?>
      <div class="win-row rank-<?= $i+1 ?>">
        <span class="win-rank"><?= $i===0?'🥇':($i===1?'🥈':($i===2?'🥉':'#'.($i+1))) ?></span>
        <span class="user-chip"><?= avatar_html(['name'=>$w['name'],'avatar'=>$w['avatar']],true) ?><?= e($w['name']) ?></span>
        <div><b><?= num($w['xp']) ?> XP</b><small><?= (int)$w['done_tasks'] ?> task · <?= round((int)$w['focus_minutes']/60,1) ?>h focus</small></div>
      </div>
    <?php endforeach; ?>
  </div>
</section>
</div>

<div class="two-col">
<section class="card">
  <div class="card-head"><h2>Learning Journey</h2><span class="muted"><?= e($roleKey) ?></span></div>
  <div class="learning-list">
    <?php foreach($journeys as $j): ?>
      <form method="post" class="learning-item <?= $j['progress_status']==='done'?'done':'' ?>">
        <input type="hidden" name="complete_learning" value="1"><input type="hidden" name="journey_id" value="<?= $j['id'] ?>">
        <span>Lv<?= (int)$j['level_no'] ?></span>
        <div><b><?= e($j['skill_name']) ?></b><small><?= e($j['description']) ?> · +<?= (int)$j['xp_reward'] ?> XP</small></div>
        <?php if($j['progress_status']==='done'): ?><em>✓ Done</em><?php else: ?><button class="btn btn-soft">Hoàn thành</button><?php endif; ?>
      </form>
    <?php endforeach; ?>
    <?php if(empty($journeys)): ?><p class="muted">Chưa có learning journey cho role này.</p><?php endif; ?>
  </div>
</section>

<section class="card">
  <div class="card-head"><h2>XP Timeline</h2></div>
  <div class="xp-timeline">
    <?php foreach($xpEvents as $x): ?>
      <div class="xp-event"><span>+<?= (int)$x['xp'] ?></span><div><b><?= e($x['title']) ?></b><small><?= e($x['event_date'].' · '.$x['description']) ?></small></div></div>
    <?php endforeach; ?>
    <?php if(empty($xpEvents)): ?><p class="muted">Chưa có XP event tháng này.</p><?php endif; ?>
  </div>
</section>
</div>
