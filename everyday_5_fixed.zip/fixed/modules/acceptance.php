<?php
if(!can_view_business_finance() && !is_director_role(current_user())) die('Bạn không có quyền xem biên bản nghiệm thu.');

function acc_has_col(PDO $pdo, string $table, string $col): bool {
  try{ $st=$pdo->prepare("SHOW COLUMNS FROM `$table` LIKE ?"); $st->execute([$col]); return (bool)$st->fetch(); }catch(Exception $e){ return false; }
}
function acc_add_col(PDO $pdo, string $table, string $ddl): void {
  $col=trim(strtok($ddl,' '));
  if(!acc_has_col($pdo,$table,$col)){ try{ $pdo->exec("ALTER TABLE `$table` ADD COLUMN $ddl"); }catch(Exception $e){} }
}
function acc_ensure_schema(PDO $pdo): void {
  try{
    $pdo->exec("CREATE TABLE IF NOT EXISTS acceptances(
      id INT AUTO_INCREMENT PRIMARY KEY,
      acceptance_code VARCHAR(60) NULL,
      public_token VARCHAR(100) NULL,
      contract_id INT NULL,
      quotation_id INT NULL,
      contract_code VARCHAR(100) NULL,
      contract_date DATE NULL,
      client_name VARCHAR(255) NULL,
      client_contact VARCHAR(255) NULL,
      client_position VARCHAR(255) NULL,
      client_address TEXT NULL,
      client_tax_code VARCHAR(100) NULL,
      service_summary TEXT NULL,
      total_value DECIMAL(15,2) DEFAULT 0,
      paid_amount DECIMAL(15,2) DEFAULT 0,
      remaining_amount DECIMAL(15,2) DEFAULT 0,
      payment_due_days INT DEFAULT 5,
      status VARCHAR(50) DEFAULT 'draft',
      signed_date DATE NULL,
      note TEXT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_acceptance_public_token(public_token),
      INDEX idx_acceptance_contract(contract_id),
      INDEX idx_acceptance_quote(quotation_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS acceptance_items(
      id INT AUTO_INCREMENT PRIMARY KEY,
      acceptance_id INT NOT NULL,
      sort_order INT DEFAULT 0,
      service_name VARCHAR(255) NULL,
      description TEXT NULL,
      quantity DECIMAL(12,2) DEFAULT 1,
      unit VARCHAR(50) NULL,
      unit_price DECIMAL(15,2) DEFAULT 0,
      subtotal DECIMAL(15,2) DEFAULT 0,
      vat_rate DECIMAL(5,2) DEFAULT 10,
      vat_amount DECIMAL(15,2) DEFAULT 0,
      total DECIMAL(15,2) DEFAULT 0,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_acceptance_items_acceptance(acceptance_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  }catch(Exception $e){}
  foreach([
    'acceptance_code VARCHAR(60) NULL','public_token VARCHAR(100) NULL','contract_id INT NULL','quotation_id INT NULL','contract_code VARCHAR(100) NULL','contract_date DATE NULL','client_name VARCHAR(255) NULL','client_contact VARCHAR(255) NULL','client_position VARCHAR(255) NULL','client_address TEXT NULL','client_tax_code VARCHAR(100) NULL','service_summary TEXT NULL','total_value DECIMAL(15,2) DEFAULT 0','paid_amount DECIMAL(15,2) DEFAULT 0','remaining_amount DECIMAL(15,2) DEFAULT 0','payment_due_days INT DEFAULT 5','status VARCHAR(50) DEFAULT \'draft\'','signed_date DATE NULL','note TEXT NULL','created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP','updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP'
  ] as $ddl) acc_add_col($pdo,'acceptances',$ddl);
  foreach(['sort_order INT DEFAULT 0','service_name VARCHAR(255) NULL','description TEXT NULL','quantity DECIMAL(12,2) DEFAULT 1','unit VARCHAR(50) NULL','unit_price DECIMAL(15,2) DEFAULT 0','subtotal DECIMAL(15,2) DEFAULT 0','vat_rate DECIMAL(5,2) DEFAULT 10','vat_amount DECIMAL(15,2) DEFAULT 0','total DECIMAL(15,2) DEFAULT 0'] as $ddl) acc_add_col($pdo,'acceptance_items',$ddl);
}
acc_ensure_schema($pdo);

function acc_money_num($v){ return (float)str_replace(['.',',',' '],['','',''],(string)$v); }
function acc_public_url(PDO $pdo, array $a): string {
  $token=trim((string)($a['public_token'] ?? ''));
  $id=(int)($a['id'] ?? 0);
  if($token==='' && $id>0){ try{ $token=bin2hex(random_bytes(20)); $pdo->prepare('UPDATE acceptances SET public_token=? WHERE id=?')->execute([$token,$id]); }catch(Exception $e){} }
  return $token!=='' ? 'public_acceptance.php?token='.rawurlencode($token) : 'public_acceptance.php?id='.$id;
}
function acc_next_code(PDO $pdo): string {
  if(function_exists('next_auto_code')) return next_auto_code($pdo,'ACC','acceptances','acceptance_code');
  return 'ACC-'.date('Y').'-'.str_pad((string)random_int(1,9999),4,'0',STR_PAD_LEFT);
}
function acc_seed_items(PDO $pdo, int $acceptanceId, int $quotationId): void {
  if($quotationId<=0) return;
  $st=$pdo->prepare('SELECT * FROM quotation_items WHERE quotation_id=? ORDER BY sort_order,id');
  $st->execute([$quotationId]);
  $items=$st->fetchAll();
  if(!$items) return;
  $ins=$pdo->prepare('INSERT INTO acceptance_items(acceptance_id,sort_order,service_name,description,quantity,unit,unit_price,subtotal,vat_rate,vat_amount,total) VALUES(?,?,?,?,?,?,?,?,?,?,?)');
  foreach($items as $i=>$it){
    $qty=(float)($it['quantity'] ?? 1); $unit=$it['unit'] ?? 'Gói';
    $unitPrice=(float)($it['unit_price'] ?? 0); $subtotal=(float)($it['subtotal'] ?? 0); $vatRate=(float)($it['vat_rate'] ?? ($it['vat_percent'] ?? 10)); $vat=(float)($it['vat_amount'] ?? 0); $total=(float)($it['total'] ?? ($subtotal+$vat));
    $ins->execute([$acceptanceId,(int)($it['sort_order'] ?? $i+1),$it['service_name'] ?? ($it['item_name'] ?? 'Dịch vụ'),$it['description'] ?? '',$qty,$unit,$unitPrice,$subtotal,$vatRate,$vat,$total]);
  }
}

if(isset($_GET['mark_completed'])){
  $pdo->prepare("UPDATE acceptances SET status='completed', signed_date=COALESCE(signed_date,CURDATE()) WHERE id=?")->execute([(int)$_GET['mark_completed']]);
  redirect('app.php?page=acceptance');
}
if(isset($_GET['delete'])){
  $id=(int)$_GET['delete'];
  $pdo->prepare('DELETE FROM acceptance_items WHERE acceptance_id=?')->execute([$id]);
  $pdo->prepare('DELETE FROM acceptances WHERE id=?')->execute([$id]);
  redirect('app.php?page=acceptance');
}

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['create_acceptance'])){
  $contractId=(int)($_POST['contract_id'] ?? 0);
  $quotationId=(int)($_POST['quotation_id'] ?? 0);
  $contract=null; $quote=null;
  if($contractId>0){ $st=$pdo->prepare('SELECT * FROM contracts WHERE id=? LIMIT 1'); $st->execute([$contractId]); $contract=$st->fetch(); }
  if($quotationId<=0 && $contract && !empty($contract['quotation_id'])) $quotationId=(int)$contract['quotation_id'];
  if($quotationId>0){ $st=$pdo->prepare('SELECT * FROM quotations WHERE id=? LIMIT 1'); $st->execute([$quotationId]); $quote=$st->fetch(); }
  $clientName=$_POST['client_name'] ?: (($quote['client_name'] ?? '') ?: ($contract['client_name'] ?? 'Quý khách'));
  $clientContact=$_POST['client_contact'] ?: (($quote['client_contact'] ?? '') ?: 'Đang cập nhật');
  $contractCode=$_POST['contract_code'] ?: ($contract['contract_code'] ?? '');
  $total=(float)($_POST['total_value'] ?? 0);
  if($total<=0){
    if($contract && isset($contract['total_value'])) $total=(float)$contract['total_value'];
    elseif($quotationId>0 && function_exists('quotation_totals')){ $tt=quotation_totals($pdo,$quotationId); $total=(float)($tt['total'] ?? 0); }
  }
  $paid=0;
  if($contractId>0){ $st=$pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM payment_schedules WHERE contract_id=? AND status='paid'"); $st->execute([$contractId]); $paid=(float)$st->fetchColumn(); }
  if($paid<=0 && $quotationId>0){ $st=$pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM payment_schedules WHERE quotation_id=? AND status='paid'"); $st->execute([$quotationId]); $paid=(float)$st->fetchColumn(); }
  $remaining=max(0,$total-$paid);
  $code=acc_next_code($pdo);
  $token=bin2hex(random_bytes(20));
  $pdo->prepare('INSERT INTO acceptances(acceptance_code,public_token,contract_id,quotation_id,contract_code,contract_date,client_name,client_contact,client_position,client_address,client_tax_code,service_summary,total_value,paid_amount,remaining_amount,payment_due_days,status,note) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
    ->execute([$code,$token,$contractId?:null,$quotationId?:null,$contractCode,$_POST['contract_date']?:($contract['signed_date'] ?? null),$clientName,$clientContact,$_POST['client_position'] ?: 'Đại diện',$_POST['client_address'] ?: '',$_POST['client_tax_code'] ?: '',$_POST['service_summary'] ?: (($quote['title'] ?? '') ?: 'Cung cấp dịch vụ theo hợp đồng'),$total,$paid,$remaining,(int)($_POST['payment_due_days'] ?? 5),'draft',$_POST['note'] ?: '']);
  $aid=(int)$pdo->lastInsertId();
  acc_seed_items($pdo,$aid,$quotationId);
  redirect('app.php?page=acceptance&view='.$aid);
}

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['save_acceptance'])){
  $id=(int)$_POST['acceptance_id'];
  $total=acc_money_num($_POST['total_value'] ?? 0); $paid=acc_money_num($_POST['paid_amount'] ?? 0); $remaining=max(0,$total-$paid);
  $pdo->prepare('UPDATE acceptances SET contract_code=?, contract_date=?, client_name=?, client_contact=?, client_position=?, client_address=?, client_tax_code=?, service_summary=?, total_value=?, paid_amount=?, remaining_amount=?, payment_due_days=?, status=?, signed_date=?, note=? WHERE id=?')
    ->execute([$_POST['contract_code'],$_POST['contract_date']?:null,$_POST['client_name'],$_POST['client_contact'],$_POST['client_position'],$_POST['client_address'],$_POST['client_tax_code'],$_POST['service_summary'],$total,$paid,$remaining,(int)$_POST['payment_due_days'],$_POST['status'],$_POST['signed_date']?:null,$_POST['note'],$id]);
  redirect('app.php?page=acceptance&view='.$id);
}

$viewId=(int)($_GET['view'] ?? 0);
$selectedContractId=(int)($_GET['contract_id'] ?? 0);
$selectedQuotationId=(int)($_GET['quotation_id'] ?? ($_GET['id'] ?? 0));
$contracts=safe_rows($pdo,"SELECT id,contract_code,client_name,total_value,signed_date,quotation_id FROM contracts ORDER BY id DESC LIMIT 200");
$quotes=safe_rows($pdo,"SELECT id,quote_code,client_name,title FROM quotations ORDER BY id DESC LIMIT 200");

if($viewId>0){
  $st=$pdo->prepare('SELECT * FROM acceptances WHERE id=?'); $st->execute([$viewId]); $a=$st->fetch();
  if(!$a) echo '<div class="card">Không tìm thấy biên bản.</div>'; else {
    $it=$pdo->prepare('SELECT * FROM acceptance_items WHERE acceptance_id=? ORDER BY sort_order,id'); $it->execute([$viewId]); $items=$it->fetchAll();
?>
<div class="tabs">
  <a href="app.php?page=acceptance">Acceptance Center</a>
  <a class="active" href="app.php?page=acceptance&view=<?= $viewId ?>">Chi tiết</a>
  <a href="<?= e(acc_public_url($pdo,$a)) ?>" target="_blank">Public PDF</a>
</div>
<section class="workspace-hero finance-hero">
  <div><span class="eyebrow">Acceptance & Liquidation</span><h1><?= e($a['acceptance_code']) ?></h1><p class="muted"><?= e($a['client_name']) ?> · HĐ: <?= e($a['contract_code'] ?: 'Đang cập nhật') ?></p></div>
  <div class="actions"><a class="primary" href="<?= e(acc_public_url($pdo,$a)) ?>" target="_blank">Xuất BBNT</a></div>
</section>
<div class="stats-grid compact-stats">
  <div class="stat purple"><span>Giá trị nghiệm thu</span><strong><?= money($a['total_value']) ?></strong></div>
  <div class="stat mint"><span>Đã thanh toán</span><strong><?= money($a['paid_amount']) ?></strong></div>
  <div class="stat coral"><span>Còn phải thu</span><strong><?= money($a['remaining_amount']) ?></strong></div>
  <div class="stat yellow"><span>Trạng thái</span><strong><?= e($a['status']) ?></strong></div>
</div>
<section class="card"><div class="card-head"><h2>Thông tin biên bản</h2></div>
<form method="post" class="grid-2">
<input type="hidden" name="acceptance_id" value="<?= $viewId ?>">
<label>Mã hợp đồng<input name="contract_code" value="<?= e($a['contract_code']) ?>"></label>
<label>Ngày hợp đồng<input type="date" name="contract_date" value="<?= e($a['contract_date']) ?>"></label>
<label>Tên khách hàng<input name="client_name" value="<?= e($a['client_name']) ?>"></label>
<label>Người đại diện<input name="client_contact" value="<?= e($a['client_contact']) ?>"></label>
<label>Chức vụ<input name="client_position" value="<?= e($a['client_position']) ?>"></label>
<label>MST<input name="client_tax_code" value="<?= e($a['client_tax_code']) ?>"></label>
<label class="full">Địa chỉ<input name="client_address" value="<?= e($a['client_address']) ?>"></label>
<label class="full">Nội dung nghiệm thu<textarea name="service_summary" rows="3"><?= e($a['service_summary']) ?></textarea></label>
<label>Tổng giá trị<input name="total_value" value="<?= e(number_format((float)$a['total_value'],0,',','.')) ?>"></label>
<label>Đã thanh toán<input name="paid_amount" value="<?= e(number_format((float)$a['paid_amount'],0,',','.')) ?>"></label>
<label>Số ngày thanh toán còn lại<input type="number" name="payment_due_days" value="<?= (int)$a['payment_due_days'] ?>"></label>
<label>Trạng thái<select name="status"><option value="draft" <?= $a['status']=='draft'?'selected':'' ?>>Draft</option><option value="sent" <?= $a['status']=='sent'?'selected':'' ?>>Sent</option><option value="signed" <?= $a['status']=='signed'?'selected':'' ?>>Signed</option><option value="completed" <?= $a['status']=='completed'?'selected':'' ?>>Completed</option></select></label>
<label>Ngày ký<input type="date" name="signed_date" value="<?= e($a['signed_date']) ?>"></label>
<label class="full">Ghi chú<textarea name="note" rows="2"><?= e($a['note']) ?></textarea></label>
<div class="full actions"><button class="primary" name="save_acceptance" value="1">Lưu biên bản</button><a class="btn btn-soft" href="app.php?page=acceptance">Quay lại</a></div>
</form></section>
<section class="card"><div class="card-head"><h2>Nội dung thực hiện</h2></div><table class="dense-table mobile-card-table"><thead><tr><th>STT</th><th>Nội dung</th><th>Chi tiết</th><th>SL</th><th>Đơn giá</th><th>Tổng</th></tr></thead><tbody><?php foreach($items as $i=>$item): ?><tr><td><?= $i+1 ?></td><td><b><?= e($item['service_name']) ?></b></td><td><?= nl2br(e($item['description'])) ?></td><td><?= e($item['quantity'].' '.$item['unit']) ?></td><td><?= money($item['unit_price']) ?></td><td><?= money($item['total']) ?></td></tr><?php endforeach; ?></tbody></table></section>
<?php }} else {
$rows=safe_rows($pdo,"SELECT a.*,c.contract_code AS c_code FROM acceptances a LEFT JOIN contracts c ON c.id=a.contract_id ORDER BY a.id DESC LIMIT 200");
?>
<section class="workspace-hero finance-hero"><div><span class="eyebrow">Sprint 6.9</span><h1>Acceptance & Liquidation Center</h1><p class="muted">Tạo biên bản nghiệm thu và thanh lý hợp đồng, tự tính đã thanh toán và còn phải thu.</p></div></section>
<section class="card"><div class="card-head"><div><h2>Tạo biên bản nghiệm thu</h2><p class="muted">Chọn hợp đồng hoặc báo giá để Everyday tự lấy dữ liệu và tạo chứng từ public PDF.</p></div></div>
<form method="post" class="grid-2">
<label>Hợp đồng<select name="contract_id"><option value="0">-- Chọn hợp đồng --</option><?php foreach($contracts as $c): ?><option value="<?= (int)$c['id'] ?>" <?= ((int)$c['id']===$selectedContractId)?'selected':'' ?>><?= e($c['contract_code'].' · '.$c['client_name']) ?></option><?php endforeach; ?></select></label>
<label>Báo giá<select name="quotation_id"><option value="0">-- Hoặc chọn báo giá --</option><?php foreach($quotes as $q): ?><option value="<?= (int)$q['id'] ?>" <?= ((int)$q['id']===$selectedQuotationId)?'selected':'' ?>><?= e($q['quote_code'].' · '.$q['client_name']) ?></option><?php endforeach; ?></select></label>
<label>Tên khách hàng<input name="client_name" placeholder="Tự lấy từ hợp đồng/báo giá nếu bỏ trống"></label>
<label>Người đại diện<input name="client_contact" placeholder="VD: Anh/Chị ..."></label>
<label>Chức vụ<input name="client_position" placeholder="Giám đốc / Đại diện"></label>
<label>Mã số thuế<input name="client_tax_code"></label>
<label class="full">Địa chỉ<input name="client_address"></label>
<label>Mã hợp đồng<input name="contract_code" placeholder="Tự lấy nếu có"></label>
<label>Ngày hợp đồng<input type="date" name="contract_date"></label>
<label>Tổng giá trị<input name="total_value" placeholder="Tự tính nếu bỏ trống"></label>
<label>Số ngày thanh toán<input type="number" name="payment_due_days" value="5"></label>
<label class="full">Nội dung nghiệm thu<textarea name="service_summary" rows="3" placeholder="VD: Bên B đã hoàn thành công việc cung cấp dịch vụ theo hợp đồng..."></textarea></label>
<label class="full">Ghi chú<textarea name="note" rows="2"></textarea></label>
<div class="full actions"><button class="primary" name="create_acceptance" value="1">+ Tạo biên bản</button></div>
</form></section>
<section class="card"><div class="card-head"><h2>Danh sách biên bản</h2></div><table class="dense-table mobile-card-table"><thead><tr><th>Mã BBNT</th><th>Khách hàng</th><th>Hợp đồng</th><th>Giá trị</th><th>Đã thu</th><th>Còn lại</th><th>Status</th><th>Action</th></tr></thead><tbody><?php foreach($rows as $r): ?><tr><td><b><?= e($r['acceptance_code']) ?></b></td><td><?= e($r['client_name']) ?></td><td><?= e($r['contract_code'] ?: $r['c_code']) ?></td><td><?= money($r['total_value']) ?></td><td><?= money($r['paid_amount']) ?></td><td><?= money($r['remaining_amount']) ?></td><td><span class="badge <?= badge_class($r['status']) ?>"><?= e($r['status']) ?></span></td><td class="actions"><a class="btn btn-soft" href="app.php?page=acceptance&view=<?= (int)$r['id'] ?>">Sửa</a><a class="btn btn-soft" target="_blank" href="<?= e(acc_public_url($pdo,$r)) ?>">PDF</a><?php if($r['status']!=='completed'): ?><a class="btn btn-soft" href="app.php?page=acceptance&mark_completed=<?= (int)$r['id'] ?>">Hoàn tất</a><?php endif; ?><a class="btn btn-soft" onclick="return confirm('Xóa biên bản này?')" href="app.php?page=acceptance&delete=<?= (int)$r['id'] ?>">Xóa</a></td></tr><?php endforeach; ?></tbody></table></section>
<?php } ?>
