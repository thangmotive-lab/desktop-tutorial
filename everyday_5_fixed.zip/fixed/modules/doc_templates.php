<?php
require_once __DIR__ . '/../services/documents/TemplateInspector.php';
if(!is_director_role() && !is_finance_role()) die('Bạn không có quyền xem Document Templates.');

if($_SERVER['REQUEST_METHOD']==='POST'){
  $path=$_POST['existing_path'] ?? '';
  if(!empty($_FILES['template_file']['name'])){
    $dir=__DIR__.'/../uploads/document_templates';
    if(!is_dir($dir)) mkdir($dir,0775,true);
    $ext=strtolower(pathinfo($_FILES['template_file']['name'],PATHINFO_EXTENSION));
    if($ext!=='docx') die('Chỉ hỗ trợ file DOCX.');
    $safe=preg_replace('/[^a-zA-Z0-9_-]+/','_',$_POST['template_code']);
    $path='uploads/document_templates/'.$safe.'_'.time().'.docx';
    move_uploaded_file($_FILES['template_file']['tmp_name'],__DIR__.'/../'.$path);
  }

  if(!empty($_POST['template_id'])){
    $pdo->prepare('UPDATE document_templates SET template_code=?,template_name=?,document_type=?,file_path=?,placeholder_note=?,is_active=? WHERE id=?')
      ->execute([$_POST['template_code'],$_POST['template_name'],$_POST['document_type'],$path,$_POST['placeholder_note'],isset($_POST['is_active'])?1:0,$_POST['template_id']]);
  } else {
    $pdo->prepare('INSERT INTO document_templates(template_code,template_name,document_type,file_path,placeholder_note,is_active,created_by) VALUES(?,?,?,?,?,?,?)')
      ->execute([$_POST['template_code'],$_POST['template_name'],$_POST['document_type'],$path,$_POST['placeholder_note'],isset($_POST['is_active'])?1:0,current_user()['id']]);
  }
  redirect('app.php?page=doc_templates');
}


if(isset($_GET['inspect'])){
  $id=(int)$_GET['inspect'];
  $st=$pdo->prepare('SELECT * FROM document_templates WHERE id=?');
  $st->execute([$id]);
  $tpl=$st->fetch();
  if($tpl){
    $result=TemplateInspector::inspect(__DIR__.'/../'.$tpl['file_path']);
    if($result['ok']){
      $pdo->prepare('UPDATE document_templates SET detected_placeholders=?, table_markers=? WHERE id=?')
        ->execute([json_encode($result['placeholders'],JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT),json_encode($result['markers'],JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT),$id]);
      $_SESSION['flash_doc_template']='✅ Scan thành công: '.$result['count'].' placeholders.';
    } else {
      $_SESSION['flash_doc_template']='❌ '.$result['message'];
    }
  }
  redirect('app.php?page=doc_templates');
}

if(isset($_GET['delete']) && user_is_admin()){
  $pdo->prepare('DELETE FROM document_templates WHERE id=?')->execute([(int)$_GET['delete']]);
  redirect('app.php?page=doc_templates');
}

$edit=null;
if(isset($_GET['edit'])){
  $st=$pdo->prepare('SELECT * FROM document_templates WHERE id=?');
  $st->execute([(int)$_GET['edit']]);
  $edit=$st->fetch();
}

$rows=safe_rows($pdo,"SELECT dt.*,u.name user_name FROM document_templates dt LEFT JOIN users u ON u.id=dt.created_by ORDER BY dt.document_type,dt.template_name");
?>
<?php $flashTpl=$_SESSION['flash_doc_template'] ?? ''; unset($_SESSION['flash_doc_template']); ?>
<?php if($flashTpl): ?><div class="alert success"><?= e($flashTpl) ?></div><?php endif; ?>
<section class="workspace-hero finance-hero ai-hero">
  <div>
    <span class="eyebrow">Document Template Engine</span>
    <h1>DOCX Templates</h1>
    <p class="muted">Upload và quản lý template Word chuẩn của Motive để merge dữ liệu tự động.</p>
  </div>
  <button class="btn btn-soft" onclick="openModal('templateModal')">+ Template</button>
</section>

<section class="card">
  <div class="card-head"><h2>Template Library</h2><a class="btn btn-soft" href="app.php?page=doc_generate">Generate Document</a></div>
  <table class="dense-table">
    <thead><tr><th>Code</th><th>Name</th><th>Type</th><th>File</th><th>Status</th><th>Placeholders</th><th>Note</th><th>Action</th></tr></thead>
    <tbody>
    <?php
require_once __DIR__ . '/../services/documents/TemplateInspector.php'; foreach($rows as $r): ?>
      <tr>
        <td><b><?= e($r['template_code']) ?></b></td>
        <td><?= e($r['template_name']) ?></td>
        <td><span class="badge purple"><?= e($r['document_type']) ?></span></td>
        <td><a href="<?= e($r['file_path']) ?>" target="_blank"><?= e(basename($r['file_path'])) ?></a></td>
        <td><span class="badge <?= $r['is_active']?'green':'gray' ?>"><?= $r['is_active']?'active':'off' ?></span></td>
        <td><?= !empty($r['detected_placeholders']) ? count(json_decode($r['detected_placeholders'],true) ?: []) : 0 ?></td>
        <td><?= e(mb_substr($r['placeholder_note']??'',0,90)) ?></td>
        <td><a class="btn btn-soft" href="app.php?page=doc_templates&inspect=<?= $r['id'] ?>">Scan</a> <a class="btn btn-soft" href="app.php?page=doc_templates&edit=<?= $r['id'] ?>">Edit</a><?php
require_once __DIR__ . '/../services/documents/TemplateInspector.php'; if(user_is_admin()): ?> <a class="btn btn-soft" onclick="return confirm('Xóa template?')" href="app.php?page=doc_templates&delete=<?= $r['id'] ?>">Xóa</a><?php
require_once __DIR__ . '/../services/documents/TemplateInspector.php'; endif; ?></td>
      </tr>
    <?php
require_once __DIR__ . '/../services/documents/TemplateInspector.php'; endforeach; ?>
    <?php
require_once __DIR__ . '/../services/documents/TemplateInspector.php'; if(empty($rows)): ?><tr><td colspan="8" class="muted">Chưa có template.</td></tr><?php
require_once __DIR__ . '/../services/documents/TemplateInspector.php'; endif; ?>
    </tbody>
  </table>
</section>

<div class="modal-backdrop <?= $edit?'active':'' ?>" id="templateModal">
  <div class="modal-panel">
    <button class="modal-close" onclick="closeModal('templateModal')">×</button>
    <h2><?= $edit?'Edit Template':'New Template' ?></h2>
    <form method="post" enctype="multipart/form-data">
      <input type="hidden" name="template_id" value="<?= e($edit['id']??'') ?>">
      <input type="hidden" name="existing_path" value="<?= e($edit['file_path']??'') ?>">
      <div class="form-row">
        <div><label>Template Code</label><input name="template_code" required value="<?= e($edit['template_code']??'') ?>" placeholder="MARKETING_CONTRACT"></div>
        <div><label>Document Type</label><select name="document_type"><option value="contract" <?= ($edit['document_type']??'')==='contract'?'selected':'' ?>>contract</option><option value="quotation" <?= ($edit['document_type']??'')==='quotation'?'selected':'' ?>>quotation</option><option value="acceptance" <?= ($edit['document_type']??'')==='acceptance'?'selected':'' ?>>acceptance</option><option value="payment_request" <?= ($edit['document_type']??'')==='payment_request'?'selected':'' ?>>payment_request</option></select></div>
      </div>
      <label>Template Name</label><input name="template_name" required value="<?= e($edit['template_name']??'') ?>">
      <label>DOCX File</label><input type="file" name="template_file" accept=".docx">
      <?php
require_once __DIR__ . '/../services/documents/TemplateInspector.php'; if(!empty($edit['file_path'])): ?><p class="muted">Current: <?= e($edit['file_path']) ?></p><?php
require_once __DIR__ . '/../services/documents/TemplateInspector.php'; endif; ?>
      <label>Placeholder Note</label><textarea name="placeholder_note"><?= e($edit['placeholder_note']??'') ?></textarea>
      <label class="check-row"><input type="checkbox" name="is_active" <?= ($edit['is_active']??1)?'checked':'' ?>> Active</label>
      <button class="primary">Save Template</button>
    </form>
  </div>
</div>
<?php
require_once __DIR__ . '/../services/documents/TemplateInspector.php'; if($edit): ?><script>document.addEventListener('DOMContentLoaded',()=>openModal('templateModal'));</script><?php
require_once __DIR__ . '/../services/documents/TemplateInspector.php'; endif; ?>
