<?php
$ratecards=$pdo->query('SELECT * FROM ratecard_items ORDER BY category, service_name')->fetchAll();
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $selected=$_POST['ratecard_ids'] ?? [];
  if(!$selected){
    $text=mb_strtolower(($_POST['industry']??'').' '.($_POST['objective']??'').' '.($_POST['title']??''),'UTF-8');
    foreach($ratecards as $r){
      foreach(array_filter(array_map('trim',explode(',',mb_strtolower($r['keywords']??'','UTF-8')))) as $k){
        if($k && str_contains($text,$k)){ $selected[]=$r['id']; break; }
      }
    }
    if(!$selected) $selected=array_slice(array_column($ratecards,'id'),0,4);
  }
  $code='ME-'.date('Y').'-'.str_pad((string)random_int(1,9999),4,'0',STR_PAD_LEFT);
  $token=public_token();
  $stmt=$pdo->prepare('INSERT INTO quotations(quote_code,public_token,client_name,client_contact,title,industry,objective,intro_text,valid_until,payment_terms,status,created_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)');
  $stmt->execute([$code,$token,$_POST['client_name'],$_POST['client_contact'],$_POST['title'],$_POST['industry'],$_POST['objective'],$_POST['intro_text'],$_POST['valid_until'],$_POST['payment_terms'],'Draft',current_user()['id']]);
  $qid=$pdo->lastInsertId();
  $in=implode(',',array_fill(0,count($selected),'?')); $stmt=$pdo->prepare("SELECT * FROM ratecard_items WHERE id IN ($in)"); $stmt->execute($selected);
  $order=1;
  foreach($stmt->fetchAll() as $r){
    $qty=(float)$r['default_quantity']; $price=(float)$r['unit_price']; $sub=$qty*$price; $vat=$sub*(float)$r['vat_rate']/100; $total=$sub+$vat;
    $pdo->prepare('INSERT INTO quotation_items(quotation_id,sort_order,service_name,description,quantity,unit,working_time,unit_price,subtotal,vat_rate,vat_amount,total,note) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)')->execute([$qid,$order++,$r['service_name'],$r['description'],$qty,$r['unit'],$r['working_time'],$price,$sub,$r['vat_rate'],$vat,$total,$r['note']]);
    if((float)$r['internal_cost_hint']>0) $pdo->prepare('INSERT INTO internal_cost_items(quotation_id,sort_order,cost_group,item_name,description,unit,quantity,unit_cost,total,owner,note) VALUES(?,?,?,?,?,?,?,?,?,?,?)')->execute([$qid,$order,'Cost hint',$r['service_name'],$r['description'],$r['unit'],1,$r['internal_cost_hint'],$r['internal_cost_hint'],'','Auto from ratecard']);
  }
  log_activity($pdo,'create','quotation',$qid,'Tạo báo giá '.$code);
  redirect('app.php?page=quotation_edit&id='.$qid);
}
?>
<div class="two-col"><section class="card"><div class="card-head"><h2>Smart Generate từ Ratecard</h2></div><form method="post">
<div class="form-row"><div><label>Khách hàng</label><input name="client_name" required></div><div><label>Người liên hệ</label><input name="client_contact"></div></div>
<label>Tiêu đề báo giá</label><input name="title" required><div class="form-row"><div><label>Ngành hàng</label><input name="industry"></div><div><label>Hiệu lực</label><input name="valid_until" type="date" value="<?= date('Y-m-d',strtotime('+30 days')) ?>"></div></div>
<label>Objective / brief</label><textarea name="objective"></textarea><label>Lời mở đầu</label><textarea name="intro_text">Motive Agency gửi tới Quý khách đề xuất dịch vụ truyền thông phù hợp với mục tiêu triển khai.</textarea>
<label>Payment terms</label><input name="payment_terms" value="50% sau khi duyệt báo giá, 50% sau nghiệm thu.">
<div class="card" style="box-shadow:none;background:#f9fafb"><h2 style="font-size:18px">Chọn ratecard</h2><p class="muted">Không chọn thì hệ thống tự match keyword.</p>
<?php foreach($ratecards as $r): ?><label style="display:flex;gap:10px;align-items:flex-start;font-weight:700;margin-bottom:10px"><input type="checkbox" name="ratecard_ids[]" value="<?= $r['id'] ?>" style="width:auto;margin-top:3px"><span><b><?= e($r['service_name']) ?></b> — <?= money($r['unit_price']) ?><br><span class="muted"><?= e($r['category']) ?> · VAT <?= (float)$r['vat_rate'] ?>% · <?= e($r['working_time']) ?></span></span></label><?php endforeach; ?>
</div><button class="primary">✨ Generate Quotation</button></form></section>
<section class="card"><h2>Smart Generate 3A</h2><p class="muted">Bản này chưa gọi API AI thật. Logic đang dựa trên keyword trong ratecard để sinh draft báo giá.</p><div class="summary-box"><div class="row"><span>Source</span><b>Ratecard</b></div><div class="row"><span>Editable</span><b>100%</b></div><div class="row"><span>Client Link</span><b>Landing Page</b></div><div class="row"><span>Internal Cost</span><b>Private</b></div></div></section></div>
