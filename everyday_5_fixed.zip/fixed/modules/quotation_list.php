<?php
$statuses=['Draft','Sent','Feedback','Pending','Reject','Contract Signed','Completed'];
$month=$_GET['month'] ?? date('Y-m');
$status=trim($_GET['status']??'');
$owner=(int)($_GET['owner_id']??0);
$qstr=trim($_GET['q']??'');

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['bulk_quote_action'])){
  $ids=array_values(array_filter(array_map('intval', $_POST['quote_ids'] ?? [])));
  $action=$_POST['bulk_action'] ?? '';
  if(!empty($ids)){
    $ph=implode(',', array_fill(0,count($ids),'?'));
    if($action==='delete' && user_is_admin()){
      $pdo->prepare("DELETE FROM quotation_items WHERE quotation_id IN ($ph)")->execute($ids);
      $pdo->prepare("DELETE FROM quotation_versions WHERE quotation_id IN ($ph)")->execute($ids);
      try{ $pdo->prepare("DELETE FROM quotation_ai_drafts WHERE quotation_id IN ($ph)")->execute($ids); }catch(Exception $e){}
      $pdo->prepare("DELETE FROM quotations WHERE id IN ($ph)")->execute($ids);
    } elseif($action==='move_month'){
      $monthTarget=$_POST['bulk_quote_month'] ?: date('Y-m');
      $pdo->prepare("UPDATE quotations SET quote_month=? WHERE id IN ($ph)")->execute(array_merge([$monthTarget],$ids));
    } elseif($action==='change_status'){
      $newStatus=$_POST['bulk_status'] ?? 'Draft';
      $pdo->prepare("UPDATE quotations SET status=? WHERE id IN ($ph)")->execute(array_merge([$newStatus],$ids));
    } elseif($action==='mark_lost'){
      $pdo->prepare("UPDATE quotations SET status='Reject', contract_status='lost', lost_at=CURDATE() WHERE id IN ($ph)")->execute($ids);
    } elseif($action==='mark_agreed'){
      $pdo->prepare("UPDATE quotations SET contract_status='client_agreed', won_at=COALESCE(won_at,CURDATE()) WHERE id IN ($ph)")->execute($ids);
    }
  }
  redirect('app.php?page=quotation_list&month='.$month);
}

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['update_quote_meta'])){
  $qid=(int)$_POST['quotation_id'];
  $quoteDate=$_POST['quote_date'] ?: null;
  $quoteMonth=$_POST['quote_month'] ?: ($quoteDate ? substr($quoteDate,0,7) : null);
  $expiredAt=$_POST['expired_at'] ?: null;
  $contractStatus=$_POST['contract_status'] ?? 'none';
  $expected=(float)str_replace(['.',',',' '],['','',''],($_POST['expected_revenue'] ?? 0));
  $statusPost=$_POST['status'] ?? null;
  $completedAt=$_POST['completed_at'] ?: null;
  $wonAt=$_POST['won_at'] ?: null;
  $lostAt=$_POST['lost_at'] ?: null;
  $createdAt=$_POST['created_at'] ? str_replace('T',' ',$_POST['created_at']).':00' : null;
  $pdo->prepare("UPDATE quotations SET quote_date=?, quote_month=?, expired_at=?, contract_status=?, expected_revenue=?, status=COALESCE(?,status), completed_at=?, won_at=?, lost_at=?, created_at=COALESCE(?,created_at) WHERE id=?")
      ->execute([$quoteDate,$quoteMonth,$expiredAt,$contractStatus,$expected,$statusPost,$completedAt,$wonAt,$lostAt,$createdAt,$qid]);
  redirect('app.php?page=quotation_list&month='.($quoteMonth ?: $month));
}

if(isset($_GET['delete']) && user_is_admin()){
  $id=(int)$_GET['delete'];
  $pdo->prepare('DELETE FROM quotation_items WHERE quotation_id=?')->execute([$id]);
  $pdo->prepare('DELETE FROM quotation_versions WHERE quotation_id=?')->execute([$id]);
  try{ $pdo->prepare('DELETE FROM quotation_ai_drafts WHERE quotation_id=?')->execute([$id]); }catch(Exception $e){}
  $pdo->prepare('DELETE FROM quotations WHERE id=?')->execute([$id]);
  log_activity($pdo,'delete','quotation',$id,'Xóa báo giá');
  redirect('app.php?page=quotation_list');
}

$where=[];$params=[];
if($month){ $where[]="COALESCE(q.quote_month, DATE_FORMAT(COALESCE(q.quote_date,q.created_at),'%Y-%m'))=?"; $params[]=$month; }
if($status){ $where[]='q.status=?'; $params[]=$status; }
if($owner){ $where[]='q.owner_id=?'; $params[]=$owner; }
if($qstr!==''){ $where[]='(q.client_name LIKE ? OR q.quote_code LIKE ? OR q.title LIKE ? OR q.objective LIKE ?)'; array_push($params,"%$qstr%","%$qstr%","%$qstr%","%$qstr%"); }

$sql="SELECT q.*,u.name owner_name,u.avatar owner_avatar,
      v.id version_id,v.version_no,v.total version_total,v.subtotal version_subtotal,v.vat version_vat
      FROM quotations q
      LEFT JOIN users u ON u.id=q.owner_id
      LEFT JOIN quotation_versions v ON v.quotation_id=q.id AND v.version_no=q.current_version";
if($where) $sql .= " WHERE ".implode(" AND ",$where);
$sql .= " ORDER BY COALESCE(q.quote_date,q.created_at) DESC,q.id DESC";
$stmt=$pdo->prepare($sql);$stmt->execute($params);$rows=$stmt->fetchAll();

$users=$pdo->query('SELECT id,name FROM users ORDER BY name')->fetchAll();
$summary=['count'=>count($rows),'total'=>0,'signed'=>0,'agreed'=>0,'pending'=>0,'reject'=>0];
foreach($rows as $r){
  $value=(float)($r['expected_revenue'] ?: ($r['version_total']??0));
  $contractStatus=$r['contract_status'] ?? 'none';

  // Tổng giá trị chỉ tính báo giá khách đã đồng ý/chờ ký hoặc đã ký hợp đồng.
  if(in_array($contractStatus, ['client_agreed','contract_signed'], true) || $r['status']==='Contract Signed'){
    $summary['total'] += $value;
  }

  if($contractStatus==='contract_signed' || $r['status']==='Contract Signed') $summary['signed'] += $value;
  if($contractStatus==='client_agreed') $summary['agreed'] += $value;
  if($r['status']==='Pending') $summary['pending'] += (float)($r['version_total']??0);
  if($r['status']==='Reject' || $contractStatus==='lost') $summary['reject'] += (float)($r['version_total']??0);
}
?>

<?php
$pipeline=['Draft'=>0,'Sent'=>0,'Feedback'=>0,'Pending'=>0,'Contract Signed'=>0,'Reject'=>0];
$expiring=0;
foreach($rows as $r){
  $st=$r['status'] ?? 'Draft';
  if(isset($pipeline[$st])) $pipeline[$st]++;
  if(!empty($r['expired_at']) && strtotime($r['expired_at'])>=strtotime(date('Y-m-d')) && strtotime($r['expired_at'])<=strtotime('+7 days')) $expiring++;
}
?>
<style>
/* Quotation Safe Layout Hotfix — inline to avoid cache/load issues */
.quote-safe-wrap{margin:16px}
.quotation-v3-hero{
  margin:16px;
  padding:28px;
  border-radius:32px;
  border:1px solid rgba(191,219,254,.72);
  background:linear-gradient(135deg,#fff,#ecfeff,#f5f3ff);
  box-shadow:0 24px 70px rgba(15,23,42,.08);
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap:18px;
}
.quotation-v3-hero h1{margin:4px 0 8px;font-size:38px;letter-spacing:-.06em}
.quotation-v3-hero p{margin:0;color:#667085;font-weight:750}
.quote-v3-kpi{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:12px;margin:16px}
.qkpi{padding:18px;border-radius:24px;background:#fff;border:1px solid #e5e7eb;box-shadow:0 16px 42px rgba(15,23,42,.04)}
.qkpi span,.qkpi strong{display:block}.qkpi span{color:#667085;font-weight:900}.qkpi strong{font-size:30px;letter-spacing:-.06em;margin-top:8px}
.qkpi.signed{background:#ecfdf5}.qkpi.agreed{background:#ecfeff}.qkpi.pipeline{background:#fff7ed}.qkpi.expiring{background:#fff1f2}.qkpi.total{background:#f5f3ff}
.quote-v3-filter-card{margin:16px!important}
.quote-v3-filter{display:grid;grid-template-columns:minmax(260px,1.6fr) 180px 180px 160px auto auto;gap:10px;align-items:center}
.quote-search-box{display:flex;align-items:center;gap:8px;min-height:48px;border:1px solid #e5e7eb;border-radius:18px;background:#fff;padding:0 12px;color:#7c3aed;font-weight:950}
.quote-search-box input{border:0!important;background:transparent!important;padding:0!important;min-height:42px!important}
.quote-pipeline-strip{display:grid!important;grid-template-columns:repeat(6,minmax(0,1fr));gap:10px;margin:16px}
.pipeline-chip{padding:14px;border:1px solid #e5e7eb;border-radius:20px;background:#fff;display:flex!important;justify-content:space-between;align-items:center;transition:.2s ease}
.pipeline-chip:hover,.pipeline-chip.active{transform:translateY(-1px);border-color:#a78bfa;background:#f5f3ff}
.pipeline-chip span{font-weight:900;color:#475467}.pipeline-chip b{font-size:22px}
.quote-v3-list-card{margin:16px!important}
.quote-v3-list-card .card-head{align-items:flex-start}
.quote-v3-bulk{display:none;grid-template-columns:auto 150px 150px 150px auto;gap:8px;align-items:center;max-width:620px}
.quote-v3-bulk.active{display:grid}
.quote-v3-table{display:grid!important;gap:8px;width:100%}
.quote-v3-head,.quote-v3-row{
  display:grid!important;
  grid-template-columns:34px minmax(140px,1.05fr) minmax(220px,1.5fr) minmax(110px,.8fr) minmax(120px,.85fr) minmax(120px,.9fr) minmax(250px,1.35fr);
  gap:12px;
  align-items:center;
}
.quote-v3-head{color:#667085;font-size:12px;font-weight:950;text-transform:uppercase;padding:0 12px 6px}
.quote-v3-row{padding:12px;border:1px solid #e5e7eb;border-radius:20px;background:#fff;min-height:72px}
.quote-v3-row.warning{border-color:#fdba74;background:#fff7ed}
.quote-v3-row.danger{border-color:#fca5a5;background:#fff1f2}
.quote-code-cell b,.quote-code-cell small,.quote-client-cell b,.quote-client-cell small,.quote-v3-row small{display:block}
.quote-code-cell small,.quote-client-cell small,.quote-v3-row small{color:#667085;margin-top:3px;line-height:1.35}
.quote-v3-actions{display:flex!important;gap:6px;flex-wrap:wrap;justify-content:flex-end}
.quote-v3-actions .btn{padding:8px 10px!important;border-radius:13px!important;font-size:13px!important;white-space:nowrap}
.quote-empty{padding:18px;border:1px dashed #cbd5e1;border-radius:18px;background:#fff}
.quote-mobile-label{display:none}
@media(max-width:1200px){
  .quote-v3-filter{grid-template-columns:1fr 1fr 1fr}
  .quote-v3-kpi,.quote-pipeline-strip{grid-template-columns:repeat(3,minmax(0,1fr))}
  .quote-v3-head{display:none!important}
  .quote-v3-row{grid-template-columns:30px 1fr!important;align-items:start}
  .quote-v3-row>div{grid-column:2}
  .quote-v3-row>label{grid-row:1 / span 5}
  .quote-v3-actions{justify-content:flex-start}
}
@media(max-width:700px){
  .quotation-v3-hero{flex-direction:column;align-items:flex-start}
  .quote-v3-filter,.quote-v3-kpi,.quote-pipeline-strip{grid-template-columns:1fr}
}
</style>

<section class="quotation-v3-hero">
  <div>
    <span class="eyebrow">Quotation Pipeline</span>
    <h1>Báo giá theo tháng</h1>
    <p>Pipeline doanh thu, báo giá chờ ký và các cơ hội cần follow trong tháng.</p>
  </div>
  <a class="primary" href="app.php?page=quotation_create">+ Tạo báo giá</a>
</section>

<section class="quote-v3-kpi">
  <div class="qkpi signed"><span>Đã ký</span><strong><?= money_short($summary['signed']) ?></strong></div>
  <div class="qkpi agreed"><span>Chờ ký</span><strong><?= money_short($summary['agreed']) ?></strong></div>
  <div class="qkpi pipeline"><span>Pipeline</span><strong><?= money_short($summary['pending']) ?></strong></div>
  <div class="qkpi expiring"><span>Sắp hết hạn</span><strong><?= (int)$expiring ?></strong></div>
  <div class="qkpi total"><span>Tổng BG</span><strong><?= (int)$summary['count'] ?></strong></div>
</section>

<section class="card quote-v3-filter-card">
  <form method="get" class="quote-v3-filter">
    <input type="hidden" name="page" value="quotation_list">
    <div class="quote-search-box">⌕<input name="q" value="<?= e($qstr) ?>" placeholder="Tìm mã báo giá, khách hàng, tên project..."></div>
    <input name="month" type="month" value="<?= e($month) ?>">
    <select name="owner_id"><option value="0">Tất cả owner</option><?php foreach($users as $u): ?><option value="<?= $u['id'] ?>" <?= $owner===$u['id']?'selected':'' ?>><?= e($u['name']) ?></option><?php endforeach; ?></select>
    <select name="status"><option value="">Status</option><?php foreach($statuses as $s): ?><option value="<?= e($s) ?>" <?= $status===$s?'selected':'' ?>><?= e($s) ?></option><?php endforeach; ?></select>
    <button class="btn btn-soft">Filter</button>
    <a class="btn btn-soft" href="export_quotations.php?month=<?= e($month) ?>&status=<?= e($status) ?>&owner_id=<?= e($owner) ?>&q=<?= e($qstr) ?>">Export</a>
  </form>
</section>

<section class="quote-pipeline-strip">
  <?php foreach($pipeline as $name=>$count): ?>
    <a class="pipeline-chip <?= $status===$name?'active':'' ?>" href="app.php?page=quotation_list&month=<?= e($month) ?>&status=<?= urlencode($name) ?>">
      <span><?= e($name) ?></span><b><?= (int)$count ?></b>
    </a>
  <?php endforeach; ?>
</section>

<form method="post" id="bulkQuoteForm">
<input type="hidden" name="bulk_quote_action" value="1">
<section class="card quote-v3-list-card">
  <div class="card-head">
    <div><h2>Danh sách báo giá</h2><p class="muted">Ưu tiên follow báo giá sắp hết hạn, giá trị lớn và đang chờ ký.</p></div>
    <div class="bulk-toolbar quote-v3-bulk" id="quoteBulkToolbar">
      <span id="bulkCount">0 đã chọn</span>
      <select name="bulk_action" id="bulkAction">
        <option value="move_month">Chuyển tháng</option>
        <option value="change_status">Đổi trạng thái</option>
        <option value="mark_agreed">Khách đồng ý</option>
        <option value="mark_lost">Lost</option>
        <?php if(user_is_admin()): ?><option value="delete">Xóa</option><?php endif; ?>
      </select>
      <input type="month" name="bulk_quote_month" value="<?= e($month) ?>">
      <select name="bulk_status"><?php foreach($statuses as $s): ?><option value="<?= e($s) ?>"><?= e($s) ?></option><?php endforeach; ?></select>
      <button class="btn btn-soft" onclick="return confirmBulkQuote()">Apply</button>
    </div>
  </div>

  <div class="quote-v3-table">
    <div class="quote-v3-head">
      <label><input type="checkbox" id="quoteSelectAll" onclick="toggleQuoteSelectAll(this)"></label>
      <span>Báo giá</span><span>Khách hàng</span><span>Giá trị</span><span>Status</span><span>Owner</span><span>Action</span>
    </div>
    <?php foreach($rows as $r):
      $value=(float)($r['version_total']??0);
      $expired=!empty($r['expired_at']) && strtotime($r['expired_at'])<strtotime(date('Y-m-d'));
      $soon=!empty($r['expired_at']) && !$expired && strtotime($r['expired_at'])<=strtotime('+7 days');
      $rowClass=$expired?'danger':($soon?'warning':'');
    ?>
      <div class="quote-v3-row <?= $rowClass ?>">
        <label><input type="checkbox" class="quote-check" name="quote_ids[]" value="<?= $r['id'] ?>" onchange="updateBulkCount()"></label>
        <div class="quote-code-cell">
          <b><?= e($r['quote_code']) ?></b>
          <small><?= e($r['quote_date'] ? date('d/m/Y',strtotime($r['quote_date'])) : date('d/m/Y',strtotime($r['created_at']))) ?><?= $r['expired_at']?' · Hết hạn '.e(date('d/m/Y',strtotime($r['expired_at']))):'' ?></small>
        </div>
        <div class="quote-client-cell">
          <b><?= e($r['client_name']) ?></b>
          <small><?= e($r['title']??'') ?></small>
        </div>
        <div><b><?= money($value) ?></b><small>V<?= (int)($r['version_no']??1) ?></small></div>
        <div><span class="badge <?= badge_class($r['status']) ?>"><?= e($r['status']) ?></span><small><?= e($r['contract_status'] ?? 'none') ?></small></div>
        <div><span class="user-chip"><?= avatar_html(['name'=>$r['owner_name'],'avatar'=>$r['owner_avatar']],true) ?><?= e($r['owner_name']) ?></span></div>
        <div class="quote-v3-actions">
          <a class="btn btn-soft" href="app.php?page=quotation_edit&id=<?= $r['id'] ?>">Edit</a>
          <button class="btn btn-soft" type="button" onclick="openModal('quoteMeta<?= $r['id'] ?>')">Meta</button>
          <a class="btn btn-soft" href="public_quote.php?token=<?= e($r['public_token']) ?>" target="_blank">Link</a>
          <?php if(($r['contract_status']??'')==='contract_signed' || $r['status']==='Contract Signed'): ?><a class="btn btn-green" href="app.php?page=project_detail&generate_from_quote=<?= $r['id'] ?>">Generate</a><?php endif; ?>
        </div>
      </div>
    <?php endforeach; ?>
    <?php if(empty($rows)): ?><div class="quote-empty muted">Chưa có báo giá trong bộ lọc này.</div><?php endif; ?>
  </div>
</section>
</form>

<?php foreach($rows as $r): ?>
<div class="modal-backdrop" id="quoteMeta<?= $r['id'] ?>">
  <div class="modal-panel">
    <button class="modal-close" onclick="closeModal('quoteMeta<?= $r['id'] ?>')">×</button>
    <h2>Meta báo giá <?= e($r['quote_code']) ?></h2>
    <form method="post">
      <input type="hidden" name="update_quote_meta" value="1">
      <input type="hidden" name="quotation_id" value="<?= $r['id'] ?>">
      <div class="form-row">
        <div><label>Ngày báo giá</label><input type="date" class="js-date-picker" name="quote_date" value="<?= e($r['quote_date'] ?? date('Y-m-d',strtotime($r['created_at']))) ?>"></div>
        <div><label>Ngày hết hạn</label><input type="date" class="js-date-picker" name="expired_at" value="<?= e($r['expired_at'] ?? $r['valid_until'] ?? '') ?>"></div>
      </div>
      <div class="form-row">
        <div><label>Status báo giá</label><select name="status"><?php foreach($statuses as $s): ?><option value="<?= e($s) ?>" <?= ($r['status']??'')===$s?'selected':'' ?>><?= e($s) ?></option><?php endforeach; ?></select></div>
        <div><label>Trạng thái HĐ</label><select name="contract_status">
          <?php foreach(['none'=>'Chưa có','potential'=>'Khả quan','client_agreed'=>'Khách đồng ý/chờ ký','contract_signed'=>'Đã ký HĐ','completed'=>'Hoàn thành','lost'=>'Lost'] as $k=>$v): ?>
            <option value="<?= $k ?>" <?= ($r['contract_status']??'none')===$k?'selected':'' ?>><?= $v ?></option>
          <?php endforeach; ?>
        </select></div>
      </div>
      <div class="form-row">
        <div><label>Tháng báo giá</label><input type="month" name="quote_month" value="<?= e($r['quote_month'] ?: ($r['quote_date'] ? substr($r['quote_date'],0,7) : date('Y-m',strtotime($r['created_at'])))) ?>"></div>
        <div><label>Thời gian khởi tạo</label><input type="datetime-local" name="created_at" value="<?= e(date('Y-m-d\TH:i',strtotime($r['created_at']))) ?>"></div>
      </div>
      <label>Khoản thu dự kiến</label><input class="money-input" inputmode="numeric" name="expected_revenue" value="<?= e(number_format((float)($r['expected_revenue'] ?: ($r['version_total']??0)),0,',','.')) ?>">
      <div class="form-row-3">
        <div><label>Ngày khách đồng ý</label><input type="date" name="won_at" value="<?= e($r['won_at']??'') ?>"></div>
        <div><label>Ngày lost</label><input type="date" name="lost_at" value="<?= e($r['lost_at']??'') ?>"></div>
        <div><label>Ngày hoàn thành</label><input type="date" name="completed_at" value="<?= e($r['completed_at']??'') ?>"></div>
      </div>
      <button class="primary">Lưu meta</button>
    </form>
  </div>
</div>
<?php endforeach; ?>

<script>
(function(){
  window.updateBulkCount=function(){
    var checks=document.querySelectorAll('.quote-check:checked');
    var count=document.getElementById('bulkCount');
    var toolbar=document.getElementById('quoteBulkToolbar');
    if(count) count.textContent=checks.length+' đã chọn';
    if(toolbar) toolbar.classList.toggle('active', checks.length>0);
  };
  window.toggleQuoteSelectAll=function(el){
    document.querySelectorAll('.quote-check').forEach(function(c){ c.checked=el.checked; });
    window.updateBulkCount();
  };
})();
</script>
