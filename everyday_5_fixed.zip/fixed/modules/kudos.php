<?php
mcoin_ensure_schema($pdo);
$me=current_user(); $success='';
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['send_kudos'])){
  $to=(int)$_POST['to_user_id']; $msg=trim($_POST['message'] ?? 'Cảm ơn bạn đã hỗ trợ team.'); $amt=(int)mcoin_get_setting($pdo,'kudos',1000);
  try{$pdo->prepare("INSERT INTO kudos(from_user_id,to_user_id,message,mcoin_amount) VALUES(?,?,?,?)")->execute([(int)$me['id'],$to,$msg,$amt]); mcoin_award($pdo,$to,$amt,'Kudos từ team','kudos',$pdo->lastInsertId(),null,$msg); $success='Đã gửi Kudos và cộng Mcoin.';}catch(Throwable $e){$success='Chưa gửi được Kudos.';}
}
$users=safe_rows($pdo,"SELECT id,name,role,avatar FROM users WHERE id<>? ORDER BY name",[(int)$me['id']]);
$rows=safe_rows($pdo,"SELECT k.*,fu.name from_name,fu.avatar from_avatar,tu.name to_name,tu.avatar to_avatar FROM kudos k LEFT JOIN users fu ON fu.id=k.from_user_id LEFT JOIN users tu ON tu.id=k.to_user_id ORDER BY k.id DESC LIMIT 60");
?>
<?php if($success): ?><div class="alert success"><?= e($success) ?></div><?php endif; ?>
<section class="card kudos-hero"><div class="card-head"><div><span class="eyebrow">Culture</span><h2>Kudos Board</h2><p class="muted">Gửi lời cảm ơn, ghi nhận đóng góp và thưởng Mcoin cho đồng đội.</p></div><button class="primary" onclick="openModal('kudosModal')">👏 Gửi Kudos</button></div></section>
<section class="card"><div class="kudos-feed"><?php foreach($rows as $k): ?><article class="kudos-card"><div><?= avatar_html(['name'=>$k['from_name'],'avatar'=>$k['from_avatar']],true) ?><span>gửi Kudos tới</span><?= avatar_html(['name'=>$k['to_name'],'avatar'=>$k['to_avatar']],true) ?><b><?= e($k['to_name']) ?></b></div><p>“<?= e($k['message']) ?>”</p><strong>+<?= number_format((int)$k['mcoin_amount'],0,',','.') ?> Mcoin</strong><small><?= e($k['created_at']) ?></small></article><?php endforeach; ?><?php if(empty($rows)): ?><p class="muted">Chưa có Kudos nào.</p><?php endif; ?></div></section>
<div class="modal-backdrop" id="kudosModal"><div class="modal-panel"><button type="button" class="modal-close" onclick="closeModal('kudosModal')">×</button><span class="eyebrow">Send Kudos</span><h2>Cảm ơn đồng đội</h2><form method="post"><input type="hidden" name="send_kudos" value="1"><label>Người nhận</label><select name="to_user_id"><?php foreach($users as $u): ?><option value="<?= (int)$u['id'] ?>"><?= e($u['name']) ?> · <?= e($u['role']) ?></option><?php endforeach; ?></select><label>Lời cảm ơn</label><textarea name="message" required placeholder="Ví dụ: Cảm ơn Hà Anh đã take care khách hàng rất tốt."></textarea><button class="primary">Gửi Kudos + Mcoin</button></form></div></div>
