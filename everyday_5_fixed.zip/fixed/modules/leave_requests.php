<?php
$me=current_user();
if(isset($_GET['approve']) && user_is_admin()){
  $id=(int)$_GET['approve']; $pdo->prepare("UPDATE leave_requests SET status='approved', approved_by=? WHERE id=?")->execute([$me['id'],$id]);
  log_activity($pdo,'approve','leave_request',$id,'Duyệt đơn từ');
  redirect('app.php?page=leave_requests');
}
if(isset($_GET['reject']) && user_is_admin()){
  $id=(int)$_GET['reject']; $pdo->prepare("UPDATE leave_requests SET status='rejected', approved_by=? WHERE id=?")->execute([$me['id'],$id]);
  log_activity($pdo,'reject','leave_request',$id,'Từ chối đơn từ');
  redirect('app.php?page=leave_requests');
}
if($_SERVER['REQUEST_METHOD']==='POST'){
  $stmt=$pdo->prepare("SELECT COUNT(*) FROM leave_requests WHERE user_id=? AND MONTH(start_date)=MONTH(CURDATE()) AND YEAR(start_date)=YEAR(CURDATE())");
  $stmt->execute([$me['id']]); $count=(int)$stmt->fetchColumn();
  if($count>=4){ echo '<div class="flash">Bạn đã dùng đủ 4 đơn trong tháng này.</div>'; }
  else {
    $stmt=$pdo->prepare('INSERT INTO leave_requests(user_id,type,start_date,end_date,reason,status) VALUES(?,?,?,?,?,?)');
    $stmt->execute([$me['id'],$_POST['type'],$_POST['start_date'],$_POST['end_date'],$_POST['reason'],'pending']);
    $lid=$pdo->lastInsertId();
    foreach($pdo->query("SELECT id FROM users WHERE role IN ('Founder','CEO','HR')") as $admin){ create_notification($pdo,$admin['id'],'Đơn từ mới',$me['name'].' gửi đơn '.$_POST['type'],'leave','app.php?page=leave_requests'); }
    log_activity($pdo,'create','leave_request',$lid,'Tạo đơn từ '.$_POST['type']);
    redirect('app.php?page=leave_requests');
  }
}
$where=user_is_admin()?'1=1':'lr.user_id='.(int)$me['id'];
$rows=$pdo->query("SELECT lr.*, u.name user_name, u.avatar user_avatar FROM leave_requests lr JOIN users u ON u.id=lr.user_id WHERE $where ORDER BY lr.id DESC")->fetchAll();
$stmt=$pdo->prepare("SELECT COUNT(*) FROM leave_requests WHERE user_id=? AND MONTH(start_date)=MONTH(CURDATE()) AND YEAR(start_date)=YEAR(CURDATE())"); $stmt->execute([$me['id']]); $used=(int)$stmt->fetchColumn();
?>
<div class="stats-grid"><div class="stat coral"><span>Đơn đã dùng tháng này</span><strong><?= $used ?>/4</strong><small>Tối đa 4 đơn/tháng</small></div><div class="stat mint"><span>Còn lại</span><strong><?= max(0,4-$used) ?></strong><small>Đơn có thể gửi</small></div></div>
<div class="two-col"><section class="card"><div class="card-head"><h2>Đơn từ cần xử lý</h2></div><table><thead><tr><th>Nhân sự</th><th>Loại đơn</th><th>Thời gian</th><th>Lý do</th><th>Status</th><th>Action</th></tr></thead><tbody>
<?php foreach($rows as $r): ?><tr><td><span class="user-chip"><?= avatar_html(['name'=>$r['user_name'],'avatar'=>$r['user_avatar']],true) ?><?= e($r['user_name']) ?></span></td><td><?= e($r['type']) ?></td><td><?= e($r['start_date']) ?> → <?= e($r['end_date']) ?></td><td><?= e($r['reason']) ?></td><td><span class="badge <?= badge_class($r['status']) ?>"><?= e($r['status']) ?></span></td><td><?php if(user_is_admin() && $r['status']==='pending'): ?><a class="btn btn-green" href="app.php?page=leave_requests&approve=<?= $r['id'] ?>">Duyệt</a><a class="btn btn-red" href="app.php?page=leave_requests&reject=<?= $r['id'] ?>">Từ chối</a><?php endif; ?></td></tr><?php endforeach; ?>
</tbody></table></section><section class="card"><h2>Gửi đơn mới</h2><form method="post"><label>Loại đơn</label><select name="type"><option>Nghỉ phép</option><option>Làm việc ở nhà</option><option>Nghỉ ốm</option><option>Đi muộn / về sớm</option></select><div class="form-row"><div><label>Từ ngày</label><input name="start_date" type="date" required></div><div><label>Đến ngày</label><input name="end_date" type="date" required></div></div><label>Lý do</label><textarea name="reason"></textarea><button class="primary">Gửi đơn</button></form></section></div>
