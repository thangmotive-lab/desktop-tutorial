<?php
$me=current_user();
$isManager=can_view_business_finance();
$month=$_GET['month'] ?? date('Y-m');
$targetUserId=$isManager && !empty($_GET['user_id']) ? (int)$_GET['user_id'] : (int)$me['id'];

if(isset($_GET['generate'])){
  $uid=$isManager && !empty($_GET['user_id']) ? (int)$_GET['user_id'] : (int)$me['id'];
  $pid=generate_ctv_payroll_for_user_month($pdo,$uid,$month);
  log_activity($pdo,'generate','ctv_payroll',$pid,'Generate CTV payroll '.$month);
  redirect('app.php?page=ctv_payroll&month='.$month.($isManager?'&user_id='.$uid:''));
}

if(isset($_GET['submit'])){
  $pid=(int)$_GET['submit'];
  $pdo->prepare("UPDATE ctv_payrolls SET status='pending' WHERE id=? AND user_id=?")->execute([$pid,$targetUserId]);
  $admins=$pdo->query("SELECT id FROM users WHERE role IN ('CEO','Director','Accounting','Finance','Kế toán') OR email='admin@motive.vn'")->fetchAll();
  foreach($admins as $a){ create_notification($pdo,$a['id'],'CTV payroll chờ duyệt','Có CTV payroll cần duyệt tháng '.$month,'payroll','app.php?page=ctv_approval&month='.$month); }
  redirect('app.php?page=ctv_payroll&month='.$month.($isManager?'&user_id='.$targetUserId:''));
}

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['update_deduction'])){
  $pid=(int)$_POST['payroll_id'];
  $deduction=(float)$_POST['deduction'];
  $note=$_POST['note'] ?? '';
  $pdo->prepare('UPDATE ctv_payrolls SET deduction=?, note=? WHERE id=?'.($isManager?'':' AND user_id='.(int)$me['id']))->execute([$deduction,$note,$pid]);
  recalc_ctv_payroll($pdo,$pid);
  redirect('app.php?page=ctv_payroll&month='.$month.($isManager?'&user_id='.$targetUserId:''));
}

$users=$pdo->query("SELECT id,name,role,avatar FROM users ORDER BY name")->fetchAll();
$payStmt=$pdo->prepare('SELECT cp.*,u.name user_name,u.avatar user_avatar,u.role user_role FROM ctv_payrolls cp JOIN users u ON u.id=cp.user_id WHERE cp.user_id=? AND cp.payroll_month=? LIMIT 1');
$payStmt->execute([$targetUserId,$month]);
$pay=$payStmt->fetch();
$items=[];
if($pay){
  $it=$pdo->prepare('SELECT i.*,t.title task_title,p.name project_name FROM ctv_payroll_items i LEFT JOIN tasks t ON t.id=i.task_id LEFT JOIN projects p ON p.id=i.project_id WHERE i.payroll_id=? ORDER BY i.id DESC');
  $it->execute([$pay['id']]);
  $items=$it->fetchAll();
}
?>
<section class="workspace-hero finance-hero">
  <div><span class="eyebrow">CTV Payroll</span><h1>CTV Payroll tháng <?= e($month) ?></h1><p class="muted">Tự tính tiền từ Task Done × Personal Rate.</p></div>
  <form method="get"><input type="hidden" name="page" value="ctv_payroll"><input type="month" name="month" value="<?= e($month) ?>"><?php if($isManager): ?><select name="user_id"><?php foreach($users as $u): ?><option value="<?= $u['id'] ?>" <?= $targetUserId==$u['id']?'selected':'' ?>><?= e($u['name'].' — '.$u['role']) ?></option><?php endforeach; ?></select><?php endif; ?><button class="btn btn-soft">Xem</button></form>
</section>
<div class="stats-grid compact-stats">
  <div class="stat coral"><span>Gross</span><strong><?= money_short($pay['gross_amount'] ?? 0) ?></strong></div>
  <div class="stat yellow"><span>Deduction</span><strong><?= money_short($pay['deduction'] ?? 0) ?></strong></div>
  <div class="stat mint"><span>Net</span><strong><?= money_short($pay['net_amount'] ?? 0) ?></strong></div>
  <div class="stat purple"><span>Status</span><strong style="font-size:20px"><?= e($pay['status'] ?? 'not generated') ?></strong></div>
</div>
<section class="card">
  <div class="card-head"><h2>Payroll Items</h2><div><a class="btn btn-soft" href="app.php?page=ctv_payroll&month=<?= e($month) ?><?= $isManager?'&user_id='.$targetUserId:'' ?>&generate=1">Generate từ task Done</a><?php if($pay && $pay['status']==='draft'): ?> <a class="btn btn-coral" href="app.php?page=ctv_payroll&month=<?= e($month) ?><?= $isManager?'&user_id='.$targetUserId:'' ?>&submit=<?= $pay['id'] ?>">Gửi duyệt</a><?php endif; ?></div></div>
  <table class="dense-table"><thead><tr><th>Task</th><th>Project</th><th>Deliverable</th><th>Qty</th><th>Rate</th><th>Amount</th></tr></thead><tbody>
    <?php foreach($items as $i): ?><tr><td><b><?= e($i['task_title']) ?></b><br><span class="muted"><?= e($i['note']) ?></span></td><td><?= e($i['project_name']) ?></td><td><?= e($i['deliverable_type']) ?></td><td><?= num($i['qty']) ?></td><td><?= money($i['unit_price']) ?></td><td><b><?= money($i['amount']) ?></b></td></tr><?php endforeach; ?>
    <?php if(empty($items)): ?><tr><td colspan="6" class="muted">Chưa có item. Bấm Generate từ task Done.</td></tr><?php endif; ?>
  </tbody></table>
</section>
<?php if($pay): ?>
<section class="card">
  <div class="card-head"><h2>Điều chỉnh</h2></div>
  <form method="post">
    <input type="hidden" name="update_deduction" value="1"><input type="hidden" name="payroll_id" value="<?= (int)$pay['id'] ?>">
    <label>Deduction</label><input type="number" name="deduction" value="<?= e($pay['deduction']) ?>">
    <label>Note</label><textarea name="note"><?= e($pay['note']) ?></textarea>
    <button class="primary">Lưu điều chỉnh</button>
  </form>
</section>
<?php endif; ?>
