<?php
$me=current_user();
$filter=$_GET['filter'] ?? 'all';
if(isset($_GET['read'])){
  $pdo->prepare('UPDATE notifications SET is_read=1 WHERE id=? AND user_id=?')->execute([(int)$_GET['read'],$me['id']]);
  redirect('app.php?page=notifications');
}
if(isset($_GET['read_all'])){
  $pdo->prepare('UPDATE notifications SET is_read=1 WHERE user_id=?')->execute([$me['id']]);
  redirect('app.php?page=notifications');
}
if(isset($_GET['delete'])){
  $pdo->prepare('DELETE FROM notifications WHERE id=? AND user_id=?')->execute([(int)$_GET['delete'],$me['id']]);
  redirect('app.php?page=notifications');
}
$where='user_id=?';$params=[$me['id']];
if($filter==='unread') $where.=' AND is_read=0';
if($filter==='task') $where.=" AND type='task'";
if($filter==='payment') $where.=" AND type IN ('payment','finance')";
if($filter==='mention') $where.=" AND type IN ('mention','chat')";
$st=$pdo->prepare("SELECT * FROM notifications WHERE $where ORDER BY is_read ASC,id DESC LIMIT 150");
$st->execute($params);$rows=$st->fetchAll();
$unread=(int)safe_sum($pdo,"SELECT COUNT(*) FROM notifications WHERE user_id=".(int)$me['id']." AND is_read=0");
function notification_icon_v2($type){
  return $type==='payment'||$type==='finance'?'💰':($type==='chat'||$type==='mention'?'💬':($type==='task'?'✅':($type==='payroll'?'💵':'🔔')));
}
?>
<section class="notification-hero notification-v2-hero">
  <div>
    <span class="eyebrow">Notification Center v2</span>
    <h2>Thông báo của bạn</h2>
    <p><?= $unread ?> thông báo chưa đọc</p>
  </div>
  <div class="actions"><a class="btn btn-soft" href="app.php?page=notifications&read_all=1">Mark all read</a></div>
</section>

<div class="notification-tabs">
  <?php foreach(['all'=>'Tất cả','unread'=>'Chưa đọc','task'=>'Task','payment'=>'Payment','mention'=>'Mention/Chat'] as $k=>$v): ?>
    <a class="<?= $filter===$k?'active':'' ?>" href="app.php?page=notifications&filter=<?= e($k) ?>"><?= e($v) ?></a>
  <?php endforeach; ?>
</div>

<section class="notification-list notification-v2-list">
  <?php foreach($rows as $n): ?>
    <article class="notification-card-v2 <?= $n['is_read']?'':'unread' ?>">
      <div class="notification-icon-v2"><?= notification_icon_v2($n['type']) ?></div>
      <div class="notification-body-v2">
        <div class="notification-title-row"><h3><?= e($n['title']) ?></h3><small><?= e($n['created_at']) ?></small></div>
        <p><?= e($n['message']) ?></p>
        <div class="notification-actions-v2">
          <?php if($n['link']): ?><a class="btn btn-soft" href="<?= e($n['link']) ?>">Mở</a><?php endif; ?>
          <?php if(!$n['is_read']): ?><a class="btn btn-soft" href="app.php?page=notifications&read=<?= $n['id'] ?>">Đã đọc</a><?php endif; ?>
          <a class="btn btn-soft" onclick="return confirm('Xóa notification?')" href="app.php?page=notifications&delete=<?= $n['id'] ?>">Xóa</a>
        </div>
      </div>
    </article>
  <?php endforeach; ?>
  <?php if(empty($rows)): ?><div class="card"><p class="muted">Không có notification.</p></div><?php endif; ?>
</section>
