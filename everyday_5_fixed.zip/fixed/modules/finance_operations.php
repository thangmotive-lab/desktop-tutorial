<?php
if(!can_view_business_finance()) die('Bạn không có quyền xem Finance Operations.');
$tab=$_GET['tab'] ?? 'approval';
$month=$_GET['month'] ?? date('Y-m');

function finance_ops_redirect($tab,$month){
  redirect('app.php?page=finance_operations&tab='.$tab.'&month='.$month);
}

if(isset($_GET['approve_ctv'])){
  $id=(int)$_GET['approve_ctv'];
  $pdo->prepare("UPDATE ctv_payrolls SET status='approved', approved_by=?, approved_at=NOW() WHERE id=?")->execute([current_user()['id'],$id]);
  $st=$pdo->prepare('SELECT * FROM ctv_payrolls WHERE id=?');$st->execute([$id]);$p=$st->fetch();
  if($p) create_notification($pdo,$p['user_id'],'CTV payroll đã được duyệt','Bảng thanh toán CTV tháng '.$p['payroll_month'].' đã được duyệt.','payroll','app.php?page=ctv_payroll&month='.$p['payroll_month']);
  finance_ops_redirect('approval',$month);
}
if(isset($_GET['approve_commission'])){
  $id=(int)$_GET['approve_commission'];
  $pdo->prepare("UPDATE sales_commissions SET status='approved', approved_by=?, approved_at=NOW() WHERE id=?")->execute([current_user()['id'],$id]);
  finance_ops_redirect('approval',$month);
}
if(isset($_GET['paid_ctv'])){
  $id=(int)$_GET['paid_ctv'];
  $proof='';
  if(!empty($_FILES['proof']['name'])){
    $dir=__DIR__.'/../uploads/payment_proofs'; if(!is_dir($dir)) mkdir($dir,0775,true);
    $ext=pathinfo($_FILES['proof']['name'],PATHINFO_EXTENSION);
    $proof='uploads/payment_proofs/ctv_'.$id.'_'.time().'.'.$ext;
    move_uploaded_file($_FILES['proof']['tmp_name'],__DIR__.'/../'.$proof);
  }
  $pdo->prepare("UPDATE ctv_payrolls SET status='paid', paid_by=?, paid_at=NOW(), payment_proof=COALESCE(NULLIF(?,''),payment_proof) WHERE id=?")->execute([current_user()['id'],$proof,$id]);
  if($proof) $pdo->prepare('INSERT INTO payment_proofs(target_type,target_id,file_path,note,uploaded_by) VALUES(?,?,?,?,?)')->execute(['ctv_payroll',$id,$proof,'CTV payment proof',current_user()['id']]);
  finance_ops_redirect('payment',$month);
}
if(isset($_GET['paid_commission'])){
  $id=(int)$_GET['paid_commission'];
  $pdo->prepare("UPDATE sales_commissions SET status='paid', paid_at=NOW() WHERE id=?")->execute([$id]);
  finance_ops_redirect('payment',$month);
}
if(isset($_POST['bulk_generate_commission'])){
  $contracts=$pdo->prepare("SELECT id FROM contracts WHERE DATE_FORMAT(COALESCE(signed_date,created_at),'%Y-%m')=? AND status IN ('Đã ký','Ký hợp đồng','Contract Signed','Hoàn thành','Đang thực hiện')");
  $contracts->execute([$month]);
  foreach($contracts->fetchAll() as $c){ generate_sales_commission_for_contract($pdo,$c['id']); }
  finance_ops_redirect('approval',$month);
}

$approvalCtv=$pdo->prepare("SELECT cp.*,u.name user_name,u.avatar user_avatar,u.role user_role FROM ctv_payrolls cp JOIN users u ON u.id=cp.user_id WHERE cp.payroll_month=? AND cp.status IN ('draft','pending') ORDER BY cp.net_amount DESC");
$approvalCtv->execute([$month]); $approvalCtv=$approvalCtv->fetchAll();

$approvalCom=$pdo->prepare("SELECT sc.*,u.name user_name,u.avatar user_avatar,c.contract_code,c.client_name FROM sales_commissions sc LEFT JOIN users u ON u.id=sc.user_id LEFT JOIN contracts c ON c.id=sc.contract_id WHERE sc.commission_month=? AND sc.status='pending' ORDER BY sc.amount DESC");
$approvalCom->execute([$month]); $approvalCom=$approvalCom->fetchAll();

$payCtv=$pdo->prepare("SELECT cp.*,u.name user_name,u.avatar user_avatar,u.role user_role FROM ctv_payrolls cp JOIN users u ON u.id=cp.user_id WHERE cp.payroll_month=? AND cp.status='approved' ORDER BY cp.net_amount DESC");
$payCtv->execute([$month]); $payCtv=$payCtv->fetchAll();

$payCom=$pdo->prepare("SELECT sc.*,u.name user_name,u.avatar user_avatar,c.contract_code,c.client_name FROM sales_commissions sc LEFT JOIN users u ON u.id=sc.user_id LEFT JOIN contracts c ON c.id=sc.contract_id WHERE sc.commission_month=? AND sc.status='approved' ORDER BY sc.amount DESC");
$payCom->execute([$month]); $payCom=$payCom->fetchAll();

$historyCtv=$pdo->prepare("SELECT cp.*,u.name user_name,u.avatar user_avatar FROM ctv_payrolls cp JOIN users u ON u.id=cp.user_id WHERE cp.payroll_month=? AND cp.status='paid' ORDER BY cp.paid_at DESC");
$historyCtv->execute([$month]); $historyCtv=$historyCtv->fetchAll();

$historyCom=$pdo->prepare("SELECT sc.*,u.name user_name,u.avatar user_avatar,c.contract_code,c.client_name FROM sales_commissions sc LEFT JOIN users u ON u.id=sc.user_id LEFT JOIN contracts c ON c.id=sc.contract_id WHERE sc.commission_month=? AND sc.status='paid' ORDER BY sc.paid_at DESC");
$historyCom->execute([$month]); $historyCom=$historyCom->fetchAll();

$totalApproval=0;foreach($approvalCtv as $r)$totalApproval+=(float)$r['net_amount'];foreach($approvalCom as $r)$totalApproval+=(float)$r['amount'];
$totalPayment=0;foreach($payCtv as $r)$totalPayment+=(float)$r['net_amount'];foreach($payCom as $r)$totalPayment+=(float)$r['amount'];
$totalPaid=0;foreach($historyCtv as $r)$totalPaid+=(float)$r['net_amount'];foreach($historyCom as $r)$totalPaid+=(float)$r['amount'];
?>
<section class="workspace-hero finance-hero">
  <div>
    <span class="eyebrow">Finance Operations</span>
    <h1>Approval & Payment Center</h1>
    <p class="muted">Gộp CTV Payroll, Sales Commission, Payment Proof vào một màn để CEO/Accounting xử lý nhanh.</p>
  </div>
  <form method="get">
    <input type="hidden" name="page" value="finance_operations">
    <input type="hidden" name="tab" value="<?= e($tab) ?>">
    <input type="month" name="month" value="<?= e($month) ?>">
    <button class="btn btn-soft">Xem</button>
  </form>
</section>

<div class="stats-grid compact-stats">
  <div class="stat yellow"><span>Waiting Approval</span><strong><?= money_short($totalApproval) ?></strong></div>
  <div class="stat coral"><span>Waiting Payment</span><strong><?= money_short($totalPayment) ?></strong></div>
  <div class="stat mint"><span>Paid</span><strong><?= money_short($totalPaid) ?></strong></div>
</div>

<div class="tabs">
  <a class="<?= $tab==='approval'?'active':'' ?>" href="app.php?page=finance_operations&tab=approval&month=<?= e($month) ?>">Approval Queue</a>
  <a class="<?= $tab==='payment'?'active':'' ?>" href="app.php?page=finance_operations&tab=payment&month=<?= e($month) ?>">Waiting Payment</a>
  <a class="<?= $tab==='history'?'active':'' ?>" href="app.php?page=finance_operations&tab=history&month=<?= e($month) ?>">Payment History</a>
  <a class="<?= $tab==='ownership'?'active':'' ?>" href="app.php?page=contract_owners">Contract Ownership</a>
</div>

<?php if($tab==='approval'): ?>
<section class="card">
  <div class="card-head"><h2>Approval Queue</h2><form method="post"><button class="btn btn-coral" name="bulk_generate_commission" value="1">Generate Commission tháng này</button></form></div>
  <h3>CTV Payroll</h3>
  <table class="dense-table"><thead><tr><th>CTV</th><th>Gross</th><th>Deduction</th><th>Net</th><th>Status</th><th>Action</th></tr></thead><tbody>
    <?php foreach($approvalCtv as $r): ?><tr><td><span class="user-chip"><?= avatar_html(['name'=>$r['user_name'],'avatar'=>$r['user_avatar']],true) ?><?= e($r['user_name']) ?></span><br><span class="muted"><?= e($r['user_role']) ?></span></td><td><?= money($r['gross_amount']) ?></td><td><?= money($r['deduction']) ?></td><td><b><?= money($r['net_amount']) ?></b></td><td><span class="badge <?= badge_class($r['status']) ?>"><?= e($r['status']) ?></span></td><td><a class="btn btn-coral" href="app.php?page=finance_operations&tab=approval&month=<?= e($month) ?>&approve_ctv=<?= $r['id'] ?>">Approve</a></td></tr><?php endforeach; ?>
    <?php if(empty($approvalCtv)): ?><tr><td colspan="6" class="muted">Không có CTV payroll chờ duyệt.</td></tr><?php endif; ?>
  </tbody></table>
  <h3>Sales Commission</h3>
  <table class="dense-table"><thead><tr><th>Owner</th><th>Contract</th><th>Client</th><th>Amount</th><th>Status</th><th>Action</th></tr></thead><tbody>
    <?php foreach($approvalCom as $r): ?><tr><td><span class="user-chip"><?= avatar_html(['name'=>$r['user_name'],'avatar'=>$r['user_avatar']],true) ?><?= e($r['user_name']) ?></span></td><td><?= e($r['contract_code']) ?></td><td><?= e($r['client_name']) ?></td><td><b><?= money($r['amount']) ?></b></td><td><span class="badge <?= badge_class($r['status']) ?>"><?= e($r['status']) ?></span></td><td><a class="btn btn-coral" href="app.php?page=finance_operations&tab=approval&month=<?= e($month) ?>&approve_commission=<?= $r['id'] ?>">Approve</a></td></tr><?php endforeach; ?>
    <?php if(empty($approvalCom)): ?><tr><td colspan="6" class="muted">Không có commission chờ duyệt.</td></tr><?php endif; ?>
  </tbody></table>
</section>
<?php elseif($tab==='payment'): ?>
<section class="card">
  <div class="card-head"><h2>Waiting Payment</h2></div>
  <h3>CTV Payroll</h3>
  <table class="dense-table"><thead><tr><th>CTV</th><th>Net</th><th>Proof</th><th>Action</th></tr></thead><tbody>
    <?php foreach($payCtv as $r): ?><tr><td><span class="user-chip"><?= avatar_html(['name'=>$r['user_name'],'avatar'=>$r['user_avatar']],true) ?><?= e($r['user_name']) ?></span></td><td><b><?= money($r['net_amount']) ?></b></td><td><?php if($r['payment_proof']): ?><a href="<?= e($r['payment_proof']) ?>" target="_blank">Proof</a><?php endif; ?></td><td><form method="post" enctype="multipart/form-data" action="app.php?page=finance_operations&tab=payment&month=<?= e($month) ?>&paid_ctv=<?= $r['id'] ?>" class="inline-upload"><input type="file" name="proof"><button class="btn btn-soft">Mark Paid</button></form></td></tr><?php endforeach; ?>
    <?php if(empty($payCtv)): ?><tr><td colspan="4" class="muted">Không có CTV payroll chờ chi.</td></tr><?php endif; ?>
  </tbody></table>
  <h3>Sales Commission</h3>
  <table class="dense-table"><thead><tr><th>Owner</th><th>Contract</th><th>Amount</th><th>Action</th></tr></thead><tbody>
    <?php foreach($payCom as $r): ?><tr><td><span class="user-chip"><?= avatar_html(['name'=>$r['user_name'],'avatar'=>$r['user_avatar']],true) ?><?= e($r['user_name']) ?></span></td><td><?= e($r['contract_code']) ?><br><span class="muted"><?= e($r['client_name']) ?></span></td><td><b><?= money($r['amount']) ?></b></td><td><a class="btn btn-soft" href="app.php?page=finance_operations&tab=payment&month=<?= e($month) ?>&paid_commission=<?= $r['id'] ?>">Mark Paid</a></td></tr><?php endforeach; ?>
    <?php if(empty($payCom)): ?><tr><td colspan="4" class="muted">Không có commission chờ chi.</td></tr><?php endif; ?>
  </tbody></table>
</section>
<?php else: ?>
<section class="card">
  <div class="card-head"><h2>Payment History</h2></div>
  <h3>CTV Payroll Paid</h3>
  <table class="dense-table"><thead><tr><th>CTV</th><th>Net</th><th>Paid at</th><th>Proof</th></tr></thead><tbody>
    <?php foreach($historyCtv as $r): ?><tr><td><span class="user-chip"><?= avatar_html(['name'=>$r['user_name'],'avatar'=>$r['user_avatar']],true) ?><?= e($r['user_name']) ?></span></td><td><b><?= money($r['net_amount']) ?></b></td><td><?= e($r['paid_at']) ?></td><td><?php if($r['payment_proof']): ?><a class="btn btn-soft" href="<?= e($r['payment_proof']) ?>" target="_blank">Proof</a><?php endif; ?></td></tr><?php endforeach; ?>
    <?php if(empty($historyCtv)): ?><tr><td colspan="4" class="muted">Chưa có CTV paid.</td></tr><?php endif; ?>
  </tbody></table>
  <h3>Commission Paid</h3>
  <table class="dense-table"><thead><tr><th>Owner</th><th>Contract</th><th>Amount</th><th>Paid at</th></tr></thead><tbody>
    <?php foreach($historyCom as $r): ?><tr><td><span class="user-chip"><?= avatar_html(['name'=>$r['user_name'],'avatar'=>$r['user_avatar']],true) ?><?= e($r['user_name']) ?></span></td><td><?= e($r['contract_code']) ?><br><span class="muted"><?= e($r['client_name']) ?></span></td><td><b><?= money($r['amount']) ?></b></td><td><?= e($r['paid_at']) ?></td></tr><?php endforeach; ?>
    <?php if(empty($historyCom)): ?><tr><td colspan="4" class="muted">Chưa có commission paid.</td></tr><?php endif; ?>
  </tbody></table>
</section>
<?php endif; ?>
