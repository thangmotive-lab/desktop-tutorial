<?php
if(!is_director_role($me) && !is_finance_role($me)) die('Bạn không có quyền xem Approval Workflow.');
try{
  $pdo->exec("CREATE TABLE IF NOT EXISTS approval_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    item_type VARCHAR(50) NOT NULL,
    item_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    requested_by INT NULL,
    approved_by INT NULL,
    status VARCHAR(30) DEFAULT 'pending',
    note TEXT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    decided_at DATETIME NULL,
    INDEX(item_type,item_id), INDEX(status)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}catch(Exception $e){}

if(isset($_GET['approve'])){
  $id=(int)$_GET['approve'];
  $pdo->prepare("UPDATE approval_requests SET status='approved',approved_by=?,decided_at=NOW() WHERE id=?")->execute([$me['id'],$id]);
  log_activity($pdo,'approve','approval_request',$id,'Duyệt approval request');
  redirect('app.php?page=approval_workflow&done=1');
}
if(isset($_GET['return'])){
  $id=(int)$_GET['return'];
  $pdo->prepare("UPDATE approval_requests SET status='returned',approved_by=?,decided_at=NOW() WHERE id=?")->execute([$me['id'],$id]);
  log_activity($pdo,'return','approval_request',$id,'Trả lại approval request');
  redirect('app.php?page=approval_workflow');
}

// Auto seed pending approval objects from core modules if approval_requests is empty for that item.
$seedTasks=safe_rows($pdo,"SELECT id,title,assignee_id FROM tasks WHERE status='Waiting Approval' ORDER BY id DESC LIMIT 100");
foreach($seedTasks as $t){ try{ $st=$pdo->prepare("SELECT id FROM approval_requests WHERE item_type='task' AND item_id=? LIMIT 1"); $st->execute([$t['id']]); if(!$st->fetch()) $pdo->prepare("INSERT INTO approval_requests(item_type,item_id,title,requested_by,status) VALUES('task',?,?,?,'pending')")->execute([$t['id'],$t['title'],$t['assignee_id']]); }catch(Exception $e){} }
$seedQuotes=safe_rows($pdo,"SELECT id,quote_code,client_name,created_by FROM quotations WHERE status IN ('Pending','Chờ duyệt','Waiting Approval') ORDER BY id DESC LIMIT 100");
foreach($seedQuotes as $q){ try{ $st=$pdo->prepare("SELECT id FROM approval_requests WHERE item_type='quotation' AND item_id=? LIMIT 1"); $st->execute([$q['id']]); if(!$st->fetch()) $pdo->prepare("INSERT INTO approval_requests(item_type,item_id,title,requested_by,status) VALUES('quotation',?,?,?,'pending')")->execute([$q['id'],($q['quote_code']?:'Báo giá').' · '.$q['client_name'],$q['created_by']??null]); }catch(Exception $e){} }
$seedContracts=safe_rows($pdo,"SELECT id,contract_code,client_name,created_by FROM contracts WHERE status IN ('Pending','Chờ duyệt','Waiting Approval') ORDER BY id DESC LIMIT 100");
foreach($seedContracts as $c){ try{ $st=$pdo->prepare("SELECT id FROM approval_requests WHERE item_type='contract' AND item_id=? LIMIT 1"); $st->execute([$c['id']]); if(!$st->fetch()) $pdo->prepare("INSERT INTO approval_requests(item_type,item_id,title,requested_by,status) VALUES('contract',?,?,?,'pending')")->execute([$c['id'],($c['contract_code']?:'Hợp đồng').' · '.$c['client_name'],$c['created_by']??null]); }catch(Exception $e){} }

$tab=$_GET['tab'] ?? 'pending';
$where=$tab==='all'?'1=1':'ar.status='.$pdo->quote($tab);
$rows=safe_rows($pdo,"SELECT ar.*,u.name requested_name,au.name approved_name FROM approval_requests ar LEFT JOIN users u ON u.id=ar.requested_by LEFT JOIN users au ON au.id=ar.approved_by WHERE $where ORDER BY FIELD(ar.status,'pending','returned','approved'), ar.created_at DESC LIMIT 200");
$counts=[
 'pending'=>safe_sum($pdo,"SELECT COUNT(*) FROM approval_requests WHERE status='pending'"),
 'approved'=>safe_sum($pdo,"SELECT COUNT(*) FROM approval_requests WHERE status='approved'"),
 'returned'=>safe_sum($pdo,"SELECT COUNT(*) FROM approval_requests WHERE status='returned'")
];
?>
<?php if(!empty($_GET['done'])): ?><div class="yay-toast">Approved ✨</div><?php endif; ?>
<section class="workspace-hero approval-workflow-hero"><div><span class="eyebrow">Sprint 3</span><h1>Approval Workflow</h1><p class="muted">Một luồng duyệt chung cho task, báo giá, hợp đồng và bảng lương. Không cần mở từng module riêng.</p></div><a class="btn btn-soft" href="app.php?page=approval_center">Approval Center cũ</a></section>
<div class="stats-grid compact-stats"><div class="stat yellow"><span>Pending</span><strong><?= (int)$counts['pending'] ?></strong></div><div class="stat mint"><span>Approved</span><strong><?= (int)$counts['approved'] ?></strong></div><div class="stat coral"><span>Returned</span><strong><?= (int)$counts['returned'] ?></strong></div></div>
<div class="tabs"><a class="<?= $tab==='pending'?'active':'' ?>" href="app.php?page=approval_workflow&tab=pending">Pending</a><a class="<?= $tab==='approved'?'active':'' ?>" href="app.php?page=approval_workflow&tab=approved">Approved</a><a class="<?= $tab==='returned'?'active':'' ?>" href="app.php?page=approval_workflow&tab=returned">Returned</a><a class="<?= $tab==='all'?'active':'' ?>" href="app.php?page=approval_workflow&tab=all">All</a></div>
<section class="card"><div class="card-head"><div><h2>Danh sách cần duyệt</h2><p class="muted">Sprint này tạo nền approval chung. Các module sau sẽ push request vào đây.</p></div></div><table class="dense-table mobile-card-table"><thead><tr><th>Loại</th><th>Nội dung</th><th>Người gửi</th><th>Status</th><th>Ngày tạo</th><th>Action</th></tr></thead><tbody><?php foreach($rows as $r): ?><tr><td data-label="Loại"><span class="badge purple"><?= e($r['item_type']) ?></span></td><td data-label="Nội dung"><b><?= e($r['title']) ?></b><br><span class="muted">#<?= (int)$r['item_id'] ?></span></td><td data-label="Người gửi"><?= e($r['requested_name'] ?: '-') ?></td><td data-label="Status"><span class="badge <?= badge_class($r['status']) ?>"><?= e($r['status']) ?></span></td><td data-label="Ngày tạo"><?= e($r['created_at']) ?></td><td data-label="Action" class="actions"><?php if($r['status']==='pending'): ?><a class="btn btn-coral" href="app.php?page=approval_workflow&approve=<?= (int)$r['id'] ?>">Duyệt</a><a class="btn btn-soft" href="app.php?page=approval_workflow&return=<?= (int)$r['id'] ?>">Trả lại</a><?php else: ?><span class="muted"><?= e($r['approved_name'] ?: '-') ?></span><?php endif; ?></td></tr><?php endforeach; ?><?php if(empty($rows)): ?><tr><td colspan="6" class="muted">Chưa có yêu cầu duyệt.</td></tr><?php endif; ?></tbody></table></section>
