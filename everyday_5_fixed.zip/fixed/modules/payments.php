<?php
if(!can_view_business_finance()) die('Bạn không có quyền xem công nợ.');

$month=$_GET['month'] ?? date('Y-m');
$statusFilter=$_GET['status'] ?? '';
$quotePaymentId = (int)($_GET['quotation_id'] ?? ($_GET['id'] ?? 0));

function normalize_money_input($v){ return (float)str_replace(['.',',',' '],['','',''],(string)$v); }

function payment_has_col(PDO $pdo, string $table, string $col): bool {
  try{
    $stmt=$pdo->prepare("SHOW COLUMNS FROM `$table` LIKE ?");
    $stmt->execute([$col]);
    return (bool)$stmt->fetch();
  }catch(Exception $e){ return false; }
}
function payment_add_col(PDO $pdo, string $table, string $ddl): void {
  $col=trim(strtok($ddl,' '));
  if(!payment_has_col($pdo,$table,$col)){
    try{ $pdo->exec("ALTER TABLE `$table` ADD COLUMN $ddl"); }catch(Exception $e){}
  }
}
function payment_ensure_schema(PDO $pdo): void {
  try{
    $pdo->exec("CREATE TABLE IF NOT EXISTS payment_schedules(
      id INT AUTO_INCREMENT PRIMARY KEY,
      contract_id INT NULL,
      quotation_id INT NULL,
      payment_code VARCHAR(50) NULL,
      title VARCHAR(255) NULL,
      milestone VARCHAR(255) NULL,
      amount DECIMAL(15,2) DEFAULT 0,
      due_date DATE NULL,
      paid_date DATE NULL,
      status VARCHAR(50) DEFAULT 'pending',
      note TEXT NULL,
      carry_month VARCHAR(7) NULL,
      moved_from_month VARCHAR(7) NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  }catch(Exception $e){}
  payment_add_col($pdo,'payment_schedules','quotation_id INT NULL');
  payment_add_col($pdo,'payment_schedules','payment_code VARCHAR(50) NULL');
  payment_add_col($pdo,'payment_schedules','title VARCHAR(255) NULL');
  payment_add_col($pdo,'payment_schedules','milestone VARCHAR(255) NULL');
  payment_add_col($pdo,'payment_schedules','paid_date DATE NULL');
  payment_add_col($pdo,'payment_schedules','carry_month VARCHAR(7) NULL');
  payment_add_col($pdo,'payment_schedules','moved_from_month VARCHAR(7) NULL');
}
payment_ensure_schema($pdo);

function valid_payment_fk_id(PDO $pdo, string $table, $id): ?int {
  $id=(int)$id;
  if($id<=0) return null;
  $allowed=['contracts','quotations'];
  if(!in_array($table,$allowed,true)) return null;
  $stmt=$pdo->prepare("SELECT id FROM $table WHERE id=? LIMIT 1");
  $stmt->execute([$id]);
  return $stmt->fetchColumn() ? $id : null;
}

function quotation_id_from_contract(PDO $pdo, $contractId): ?int {
  $contractId=(int)$contractId;
  if($contractId<=0) return null;
  try{
    $stmt=$pdo->prepare("SELECT quotation_id FROM contracts WHERE id=? LIMIT 1");
    $stmt->execute([$contractId]);
    $qid=(int)$stmt->fetchColumn();
    return valid_payment_fk_id($pdo,'quotations',$qid);
  }catch(Exception $e){
    return null;
  }
}

function payment_redirect_target($quotePaymentId, $month){
  return $quotePaymentId>0 ? ('app.php?page=payments&id='.$quotePaymentId) : ('app.php?page=payments&month='.$month);
}

if($quotePaymentId>0){
  $qst=$pdo->prepare('SELECT * FROM quotations WHERE id=? LIMIT 1');
  $qst->execute([$quotePaymentId]);
  $q=$qst->fetch();
  if(!$q) die('Không tìm thấy báo giá để tạo lịch thanh toán.');

  $version=ensure_quotation_version($pdo,$quotePaymentId);
  $totals=quotation_version_totals($pdo,(int)$version['id']);
  $contractId=null;
  try{
    $st=$pdo->prepare('SELECT id FROM contracts WHERE quotation_id=? ORDER BY id DESC LIMIT 1');
    $st->execute([$quotePaymentId]);
    $contractId=(int)$st->fetchColumn() ?: null;
  }catch(Exception $e){}

  if(isset($_GET['delete_payment'])){
    $pdo->prepare('DELETE FROM payment_schedules WHERE id=? AND quotation_id=?')->execute([(int)$_GET['delete_payment'],$quotePaymentId]);
    redirect('app.php?page=payments&id='.$quotePaymentId);
  }

  if(isset($_GET['mark_paid'])){
    $pdo->prepare("UPDATE payment_schedules SET status='paid', paid_date=COALESCE(paid_date,CURDATE()) WHERE id=? AND quotation_id=?")->execute([(int)$_GET['mark_paid'],$quotePaymentId]);
    redirect('app.php?page=payments&id='.$quotePaymentId);
  }

  if(isset($_POST['auto_5050'])){
    $pdo->prepare('DELETE FROM payment_schedules WHERE quotation_id=? AND contract_id IS NULL')->execute([$quotePaymentId]);
    $total=(float)$totals['total'];
    $first=round($total*0.5);
    $second=$total-$first;
    $today=date('Y-m-d');
    $due2=date('Y-m-d',strtotime('+30 days'));
    $rows=[['Đợt 1 - Tạm ứng 50%',$first,$today],['Đợt 2 - Thanh toán 50% còn lại',$second,$due2]];
    foreach($rows as $r){
      $code=next_auto_code($pdo,'PAY','payment_schedules','payment_code');
      $pdo->prepare('INSERT INTO payment_schedules(contract_id,quotation_id,payment_code,title,milestone,amount,due_date,status,note,carry_month) VALUES(?,?,?,?,?,?,?,?,?,?)')
        ->execute([$contractId,$quotePaymentId,$code,$r[0],$r[0],$r[1],$r[2],'pending','Generated from quotation builder',(isset($r[2]) && $r[2]!==null ? substr((string)$r[2],0,7) : date('Y-m'))]);
    }
    $pdo->prepare('UPDATE quotations SET payment_terms=? WHERE id=?')->execute(['50% sau khi duyệt báo giá, 50% sau nghiệm thu.',$quotePaymentId]);
    redirect('app.php?page=payments&id='.$quotePaymentId);
  }

  if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['save_quote_payment'])){
    $amount=normalize_money_input($_POST['amount'] ?? 0);
    $due=$_POST['due_date'] ?: null;
    $carry=$_POST['carry_month'] ?: ($due ? substr((string)$due,0,7) : date('Y-m'));
    $pid=(int)($_POST['payment_id'] ?? 0);
    if($pid>0){
      $pdo->prepare('UPDATE payment_schedules SET contract_id=?, quotation_id=?, title=?, milestone=?, amount=?, due_date=?, paid_date=?, status=?, note=?, carry_month=? WHERE id=? AND quotation_id=?')
        ->execute([$contractId,$quotePaymentId,$_POST['title'],$_POST['title'],$amount,$due,$_POST['paid_date']?:null,$_POST['status'],$_POST['note'],$carry,$pid,$quotePaymentId]);
    }else{
      $code=next_auto_code($pdo,'PAY','payment_schedules','payment_code');
      $pdo->prepare('INSERT INTO payment_schedules(contract_id,quotation_id,payment_code,title,milestone,amount,due_date,paid_date,status,note,carry_month) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
        ->execute([$contractId,$quotePaymentId,$code,$_POST['title'],$_POST['title'],$amount,$due,$_POST['paid_date']?:null,$_POST['status'],$_POST['note'],$carry]);
    }
    redirect('app.php?page=payments&id='.$quotePaymentId);
  }

  $edit=null;
  if(isset($_GET['edit_payment'])){
    $st=$pdo->prepare('SELECT * FROM payment_schedules WHERE id=? AND quotation_id=?');
    $st->execute([(int)$_GET['edit_payment'],$quotePaymentId]);
    $edit=$st->fetch();
  }
  $st=$pdo->prepare('SELECT * FROM payment_schedules WHERE quotation_id=? ORDER BY status="paid", due_date IS NULL, due_date ASC, id ASC');
  $st->execute([$quotePaymentId]);
  $payments=$st->fetchAll();
  $paid=0;$pending=0;
  foreach($payments as $p){ if(($p['status']??'')==='paid') $paid+=(float)$p['amount']; else $pending+=(float)$p['amount']; }
  $scheduled=$paid+$pending;
  $remaining=max(0,(float)$totals['total']-$scheduled);
?>
<div class="tabs">
  <a href="app.php?page=quotation_edit&id=<?= $quotePaymentId ?>">Builder V<?= (int)$version['version_no'] ?></a>
  <a href="public_quote.php?token=<?= e($q['public_token']) ?>" target="_blank">Client Landing Page</a>
  <a href="app.php?page=internal_costs&id=<?= $quotePaymentId ?>">Internal Cost</a>
  <a class="active" href="app.php?page=payments&id=<?= $quotePaymentId ?>">Payment</a>
  <?php if(($q['status']??'')==='Contract Signed'): ?><a href="app.php?page=contract_generate&amp;quotation_id=<?= $quotePaymentId ?>">Generate Contract</a><?php endif; ?>
</div>

<section class="workspace-hero finance-hero">
  <div>
    <span class="eyebrow">Quotation Payment</span>
    <h1>Lịch thanh toán báo giá</h1>
    <p class="muted"><?= e($q['quote_code']) ?> · <?= e($q['client_name']) ?> · <?= e($q['title']) ?></p>
  </div>
  <div class="actions">
    <form method="post" style="display:inline"><button class="btn btn-soft" name="auto_5050" value="1" type="submit">Tạo nhanh 50/50</button></form>
    <button type="button" class="primary" onclick="openModal('quotePaymentModal')">+ Thêm đợt thanh toán</button>
  </div>
</section>

<div class="stats-grid compact-stats">
  <div class="stat mint"><span>Tổng báo giá</span><strong><?= money($totals['total']) ?></strong></div>
  <div class="stat yellow"><span>Đã lên lịch</span><strong><?= money($scheduled) ?></strong></div>
  <div class="stat coral"><span>Còn thiếu</span><strong><?= money($remaining) ?></strong></div>
  <div class="stat purple"><span>Đã thu</span><strong><?= money($paid) ?></strong></div>
</div>

<section class="card">
  <div class="card-head"><div><h2>Payment Schedule</h2><p class="muted">Dùng phần này để lên các đợt thanh toán ngay trong Quotation Builder trước khi chuyển sang hợp đồng.</p></div></div>
  <table class="dense-table mobile-card-table">
    <thead><tr><th>Mã PAY</th><th>Đợt</th><th>Số tiền</th><th>Due</th><th>Paid</th><th>Status</th><th>Action</th></tr></thead>
    <tbody>
    <?php foreach($payments as $p): ?>
      <tr>
        <td data-label="Mã PAY"><b><?= e($p['payment_code']) ?></b></td>
        <td data-label="Đợt"><?= e($p['title'] ?: $p['milestone']) ?><br><span class="muted"><?= e($p['note']) ?></span></td>
        <td data-label="Số tiền"><?= money($p['amount']) ?></td>
        <td data-label="Due"><?= e($p['due_date']) ?></td>
        <td data-label="Paid"><?= e($p['paid_date']) ?></td>
        <td data-label="Status"><span class="badge <?= badge_class($p['status']) ?>"><?= ($p['status']??'pending')==='paid'?'Đã thanh toán':'Chờ thanh toán' ?></span></td>
        <td data-label="Action" class="actions">
          <a class="btn btn-soft" href="app.php?page=payments&id=<?= $quotePaymentId ?>&edit_payment=<?= $p['id'] ?>">Edit</a>
          <?php if(($p['status']??'')!=='paid'): ?><a class="btn btn-soft" href="app.php?page=payments&id=<?= $quotePaymentId ?>&mark_paid=<?= $p['id'] ?>">Đã thu</a><?php endif; ?>
          <a class="btn btn-soft" onclick="return confirm('Xóa đợt thanh toán này?')" href="app.php?page=payments&id=<?= $quotePaymentId ?>&delete_payment=<?= $p['id'] ?>">Xóa</a>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if(empty($payments)): ?><tr><td colspan="7" class="muted">Chưa có lịch thanh toán. Bấm “Tạo nhanh 50/50” hoặc “Thêm đợt thanh toán”.</td></tr><?php endif; ?>
    </tbody>
  </table>
</section>

<div class="modal-backdrop <?= $edit?'active':'' ?>" id="quotePaymentModal">
  <div class="modal-panel">
    <button class="modal-close" type="button" onclick="closeModal('quotePaymentModal')">×</button>
    <h2><?= $edit?'Sửa đợt thanh toán':'Thêm đợt thanh toán' ?></h2>
    <form method="post">
      <input type="hidden" name="save_quote_payment" value="1">
      <input type="hidden" name="payment_id" value="<?= e($edit['id']??'') ?>">
      <label>Tên đợt thanh toán</label><input name="title" value="<?= e($edit['title']??$edit['milestone']??'') ?>" required>
      <label>Số tiền</label><input class="money-input" inputmode="numeric" name="amount" value="<?= e(number_format((float)($edit['amount']??$remaining),0,',','.')) ?>">
      <div class="form-row"><div><label>Tháng công nợ</label><input type="month" name="carry_month" value="<?= e($edit['carry_month']??date('Y-m')) ?>"></div><div><label>Due date</label><input type="date" class="js-date-picker" name="due_date" value="<?= e($edit['due_date']??'') ?>"></div></div>
      <div class="form-row"><div><label>Paid date</label><input type="date" class="js-date-picker" name="paid_date" value="<?= e($edit['paid_date']??'') ?>"></div><div><label>Status</label><select name="status"><option value="pending" <?= ($edit['status']??'pending')==='pending'?'selected':'' ?>>Chờ thanh toán</option><option value="paid" <?= ($edit['status']??'')==='paid'?'selected':'' ?>>Đã thanh toán</option></select></div></div>
      <label>Note</label><textarea name="note"><?= e($edit['note']??'') ?></textarea>
      <button class="primary">Lưu payment</button>
    </form>
  </div>
</div>
<?php if($edit): ?><script>document.addEventListener('DOMContentLoaded',()=>openModal('quotePaymentModal'));</script><?php endif; ?>
<?php
  return;
}

if(isset($_GET['delete_payment'])){
  $pdo->prepare('DELETE FROM payment_schedules WHERE id=?')->execute([(int)$_GET['delete_payment']]);
  redirect('app.php?page=payments&month='.$month);
}

if(isset($_GET['move_payment'])){
  $id=(int)$_GET['move_payment'];
  $to=$_GET['to'] ?? date('Y-m',strtotime('+1 month'));
  $pdo->prepare("UPDATE payment_schedules SET moved_from_month=COALESCE(carry_month,DATE_FORMAT(COALESCE(due_date,CURDATE()),'%Y-%m')), carry_month=?, due_date=COALESCE(due_date, STR_TO_DATE(CONCAT(?,'-28'),'%Y-%m-%d')) WHERE id=?")
      ->execute([$to,$to,$id]);
  redirect('app.php?page=payments&month='.$to);
}

if(isset($_GET['duplicate_payment'])){
  $id=(int)$_GET['duplicate_payment'];
  $st=$pdo->prepare('SELECT * FROM payment_schedules WHERE id=?');
  $st->execute([$id]);
  $p=$st->fetch();
  if($p){
    $code=next_auto_code($pdo,'PAY','payment_schedules','payment_code');
    $contractId=valid_payment_fk_id($pdo,'contracts',$p['contract_id'] ?? null);
    $quotationId=quotation_id_from_contract($pdo,$contractId);
    $pdo->prepare('INSERT INTO payment_schedules(contract_id,quotation_id,payment_code,title,milestone,amount,due_date,status,note,carry_month) VALUES(?,?,?,?,?,?,?,?,?,?)')
      ->execute([$contractId,$quotationId,$code,($p['title']?:$p['milestone']).' Copy',$p['milestone'],$p['amount'],$p['due_date'],'pending',$p['note'],$p['carry_month']?:date('Y-m')]);
  }
  redirect('app.php?page=payments&month='.$month);
}

if($_SERVER['REQUEST_METHOD']==='POST'){
  $amount=normalize_money_input($_POST['amount'] ?? 0);
  $carry=$_POST['carry_month'] ?: ($_POST['due_date'] ? substr((string)$_POST['due_date'],0,7) : $month);
  $contractId=valid_payment_fk_id($pdo,'contracts',$_POST['contract_id'] ?? null);
  $quotationId=quotation_id_from_contract($pdo,$contractId);

  if(!empty($_POST['payment_id'])){
    $pdo->prepare('UPDATE payment_schedules SET contract_id=?, quotation_id=?, title=?, milestone=?, amount=?, due_date=?, paid_date=?, status=?, note=?, carry_month=? WHERE id=?')
      ->execute([$contractId,$quotationId,$_POST['title'],$_POST['title'],$amount,$_POST['due_date']?:null,$_POST['paid_date']?:null,$_POST['status'],$_POST['note'],$carry,$_POST['payment_id']]);
  } else {
    $code=next_auto_code($pdo,'PAY','payment_schedules','payment_code');
    $pdo->prepare('INSERT INTO payment_schedules(contract_id,quotation_id,payment_code,title,milestone,amount,due_date,paid_date,status,note,carry_month) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
      ->execute([$contractId,$quotationId,$code,$_POST['title'],$_POST['title'],$amount,$_POST['due_date']?:null,$_POST['paid_date']?:null,$_POST['status'],$_POST['note'],$carry]);
  }
  redirect('app.php?page=payments&month='.$carry);
}

$edit=null;
if(isset($_GET['edit_payment'])){
  $st=$pdo->prepare('SELECT * FROM payment_schedules WHERE id=?');
  $st->execute([(int)$_GET['edit_payment']]);
  $edit=$st->fetch();
}

$where=["COALESCE(ps.carry_month,DATE_FORMAT(COALESCE(ps.due_date,CURDATE()),'%Y-%m'))=?"];
$params=[$month];
if($statusFilter==='pending') $where[]="ps.status!='paid'";
if($statusFilter==='paid') $where[]="ps.status='paid'";
$whereSql='WHERE '.implode(' AND ',$where);

$detailsStmt=$pdo->prepare("SELECT ps.*,c.contract_code,c.client_name FROM payment_schedules ps LEFT JOIN contracts c ON c.id=ps.contract_id $whereSql ORDER BY ps.status='paid', ps.due_date ASC, ps.id ASC");
$detailsStmt->execute($params);
$details=$detailsStmt->fetchAll();

$sumPending=0;$sumPaid=0;
foreach($details as $d){ if($d['status']==='paid') $sumPaid+=(float)$d['amount']; else $sumPending+=(float)$d['amount']; }

$rowsStmt=$pdo->prepare("SELECT c.id contract_id,c.contract_code,c.client_name,c.total_value,c.status contract_status,
  COALESCE(SUM(ps.amount),0) scheduled,
  COALESCE(SUM(CASE WHEN ps.status='paid' THEN ps.amount ELSE 0 END),0) paid,
  COALESCE(SUM(CASE WHEN ps.status!='paid' THEN ps.amount ELSE 0 END),0) unpaid
  FROM contracts c
  LEFT JOIN payment_schedules ps ON ps.contract_id=c.id AND COALESCE(ps.carry_month,DATE_FORMAT(COALESCE(ps.due_date,CURDATE()),'%Y-%m'))=?
  GROUP BY c.id HAVING scheduled>0
  ORDER BY c.id DESC");
$rowsStmt->execute([$month]);
$rows=$rowsStmt->fetchAll();

$contracts=$pdo->query("SELECT id,contract_code,client_name FROM contracts ORDER BY id DESC")->fetchAll();
$nextMonth=date('Y-m',strtotime($month.'-01 +1 month'));
?>
<section class="workspace-hero finance-hero">
  <div>
    <span class="eyebrow">Finance</span>
    <h1>Công nợ theo tháng</h1>
    <p class="muted">Khoản chưa thanh toán có thể chuyển sang tháng tiếp theo để theo dõi dòng tiền.</p>
  </div>
</section>

<form method="get" class="asana-toolbar compact-filter">
  <input type="hidden" name="page" value="payments">
  <input type="month" name="month" value="<?= e($month) ?>">
  <select name="status"><option value="">Tất cả trạng thái</option><option value="pending" <?= $statusFilter==='pending'?'selected':'' ?>>Chờ thanh toán</option><option value="paid" <?= $statusFilter==='paid'?'selected':'' ?>>Đã thanh toán</option></select>
  <button class="primary">Lọc</button>
  <button type="button" class="btn btn-soft" onclick="openModal('paymentModal')">+ Thêm payment</button>
</form>

<div class="stats-grid compact-stats">
  <div class="stat yellow"><span>Chờ thanh toán</span><strong><?= money($sumPending) ?></strong></div>
  <div class="stat mint"><span>Đã thanh toán</span><strong><?= money($sumPaid) ?></strong></div>
  <div class="stat purple"><span>Tổng tháng</span><strong><?= money($sumPaid+$sumPending) ?></strong></div>
</div>

<section class="card">
  <div class="card-head"><h2>Công nợ theo hợp đồng</h2></div>
  <table class="dense-table">
    <thead><tr><th>Hợp đồng</th><th>Khách hàng</th><th>Giá trị HĐ</th><th>Đã thu</th><th>Chờ thu</th><th>Tiến độ</th><th>Status</th><th>Action</th></tr></thead>
    <tbody>
    <?php foreach($rows as $r): $pct=$r['total_value']>0?round($r['paid']/$r['total_value']*100):0; ?>
      <tr><td><b><?= e($r['contract_code']) ?></b></td><td><?= e($r['client_name']) ?></td><td><?= money($r['total_value']) ?></td><td><?= money($r['paid']) ?></td><td><?= money($r['unpaid']) ?></td><td><div class="progress"><span style="width:<?= min(100,$pct) ?>%"></span></div><?= $pct ?>%</td><td><span class="badge <?= badge_class($r['contract_status']) ?>"><?= e($r['contract_status']) ?></span></td><td><a class="btn btn-soft" href="app.php?page=contract_detail&id=<?= $r['contract_id'] ?>">Detail</a></td></tr>
    <?php endforeach; ?>
    <?php if(empty($rows)): ?><tr><td colspan="8" class="muted">Chưa có công nợ trong tháng này.</td></tr><?php endif; ?>
    </tbody>
  </table>
</section>

<section class="card">
  <div class="card-head"><h2>Lịch thanh toán chi tiết</h2></div>
  <table class="dense-table"><thead><tr><th>Mã PAY</th><th>Hợp đồng</th><th>Khách hàng</th><th>Đợt</th><th>Số tiền</th><th>Tháng</th><th>Due</th><th>Paid</th><th>Status</th><th>Action</th></tr></thead><tbody>
  <?php foreach($details as $d): ?><tr><td><?= e($d['payment_code']) ?></td><td><?= e($d['contract_code']) ?></td><td><?= e($d['client_name']) ?></td><td><?= e($d['title'] ?: $d['milestone']) ?></td><td><?= money($d['amount']) ?></td><td><?= e($d['carry_month'] ?: ($d['due_date'] ? substr((string)$d['due_date'],0,7) : '')) ?></td><td><?= e($d['due_date']) ?></td><td><?= e($d['paid_date']) ?></td><td><span class="badge <?= badge_class($d['status']) ?>"><?= $d['status']==='paid'?'Đã thanh toán':'Chờ thanh toán' ?></span></td><td><a class="btn btn-soft" href="app.php?page=payments&month=<?= e($month) ?>&edit_payment=<?= $d['id'] ?>">Edit</a><a class="btn btn-soft" href="app.php?page=payments&month=<?= e($month) ?>&duplicate_payment=<?= $d['id'] ?>">Nhân đôi</a><?php if($d['status']!=='paid'): ?><a class="btn btn-soft" href="app.php?page=payments&move_payment=<?= $d['id'] ?>&to=<?= e($nextMonth) ?>">Chuyển tháng sau</a><?php endif; ?><a class="btn btn-soft" onclick="return confirm('Xóa payment?')" href="app.php?page=payments&month=<?= e($month) ?>&delete_payment=<?= $d['id'] ?>">Xóa</a></td></tr><?php endforeach; ?>
  <?php if(empty($details)): ?><tr><td colspan="10" class="muted">Chưa có lịch thanh toán.</td></tr><?php endif; ?>
  </tbody></table>
</section>

<div class="modal-backdrop <?= $edit?'active':'' ?>" id="paymentModal">
  <div class="modal-panel">
    <button class="modal-close" onclick="closeModal('paymentModal')">×</button>
    <h2><?= $edit?'Edit payment':'Thêm payment' ?></h2>
    <form method="post">
      <input type="hidden" name="payment_id" value="<?= e($edit['id']??'') ?>">
      <label>Hợp đồng</label><select name="contract_id"><option value="">Chọn hợp đồng</option><?php foreach($contracts as $c): ?><option value="<?= $c['id'] ?>" <?= ($edit['contract_id']??'')==$c['id']?'selected':'' ?>><?= e($c['contract_code'].' - '.$c['client_name']) ?></option><?php endforeach; ?></select>
      <label>Đợt thanh toán</label><input name="title" value="<?= e($edit['title']??$edit['milestone']??'') ?>">
      <label>Số tiền</label><input class="money-input" inputmode="numeric" name="amount" value="<?= e(number_format((float)($edit['amount']??0),0,',','.')) ?>">
      <div class="form-row"><div><label>Tháng công nợ</label><input type="month" name="carry_month" value="<?= e($edit['carry_month']??$month) ?>"></div><div><label>Due date</label><input type="date" class="js-date-picker" name="due_date" value="<?= e($edit['due_date']??'') ?>"></div></div>
      <div class="form-row"><div><label>Paid date</label><input type="date" class="js-date-picker" name="paid_date" value="<?= e($edit['paid_date']??'') ?>"></div><div><label>Status</label><select name="status"><option value="pending" <?= ($edit['status']??'pending')==='pending'?'selected':'' ?>>Chờ thanh toán</option><option value="paid" <?= ($edit['status']??'')==='paid'?'selected':'' ?>>Đã thanh toán</option></select></div></div>
      <label>Note</label><textarea name="note"><?= e($edit['note']??'') ?></textarea>
      <button class="primary">Lưu payment</button>
    </form>
  </div>
</div>
<?php if($edit): ?><script>document.addEventListener('DOMContentLoaded',()=>openModal('paymentModal'));</script><?php endif; ?>
