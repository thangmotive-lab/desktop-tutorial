<?php
require_once __DIR__.'/../includes/mailer.php';
motive_email_ensure_schema($pdo);
$success='';$error='';
$defaults=[
 'email_method'=>'smtp','email_from_name'=>'MotiveEveryday','email_from_email'=>'hello.motivesocial@gmail.com',
 'email_smtp_host'=>'smtp.gmail.com','email_smtp_port'=>'587','email_smtp_secure'=>'tls','email_smtp_username'=>'hello.motivesocial@gmail.com','email_smtp_password'=>''
];
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['save_email_settings'])){
  foreach($defaults as $k=>$v){ motive_set_setting($pdo,$k,trim($_POST[$k] ?? '')); }
  $success='Đã lưu cấu hình email.';
}
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['send_test_email'])){
  foreach($defaults as $k=>$v){ if(isset($_POST[$k])) motive_set_setting($pdo,$k,trim($_POST[$k] ?? '')); }
  $to=trim($_POST['test_email'] ?? '');
  if($to){
    $ok=motive_send_email($pdo,$to,'Test email từ MotiveEveryday',motive_email_template('Email system đã hoạt động','<p>Đây là email test từ MotiveEveryday.</p><p>Nếu bạn nhận được email này, SMTP đã được cấu hình thành công.</p>'),['template_key'=>'test']);
    $success=$ok?'Đã gửi email test.':'Không gửi được email test. Kiểm tra Email Logs để xem lỗi.';
  } else $error='Vui lòng nhập email test.';
}
$settings=[]; foreach($defaults as $k=>$v){ $settings[$k]=motive_get_setting($pdo,$k,$v); }
$logs=$pdo->query('SELECT * FROM email_logs ORDER BY id DESC LIMIT 30')->fetchAll();
?>
<section class="card">
  <div class="card-head"><div><span class="eyebrow">SMTP</span><h2>Email Settings</h2></div></div>
  <?php if($success): ?><div class="alert success"><?= e($success) ?></div><?php endif; ?>
  <?php if($error): ?><div class="flash"><?= e($error) ?></div><?php endif; ?>
  <form method="post">
    <input type="hidden" name="save_email_settings" value="1">
    <div class="form-row-3">
      <div><label>Method</label><select name="email_method"><option value="smtp" <?= $settings['email_method']==='smtp'?'selected':'' ?>>SMTP</option><option value="mail" <?= $settings['email_method']==='mail'?'selected':'' ?>>PHP mail()</option></select></div>
      <div><label>From name</label><input name="email_from_name" value="<?= e($settings['email_from_name']) ?>"></div>
      <div><label>From email</label><input name="email_from_email" value="<?= e($settings['email_from_email']) ?>"></div>
    </div>
    <div class="form-row-3">
      <div><label>SMTP Host</label><input name="email_smtp_host" value="<?= e($settings['email_smtp_host']) ?>"></div>
      <div><label>SMTP Port</label><input name="email_smtp_port" value="<?= e($settings['email_smtp_port']) ?>"></div>
      <div><label>Security</label><select name="email_smtp_secure"><option value="tls" <?= $settings['email_smtp_secure']==='tls'?'selected':'' ?>>TLS</option><option value="ssl" <?= $settings['email_smtp_secure']==='ssl'?'selected':'' ?>>SSL</option><option value="none" <?= $settings['email_smtp_secure']==='none'?'selected':'' ?>>None</option></select></div>
    </div>
    <div class="form-row">
      <div><label>SMTP Username</label><input name="email_smtp_username" value="<?= e($settings['email_smtp_username']) ?>"></div>
      <div><label>SMTP App Password</label><input name="email_smtp_password" type="password" value="<?= e($settings['email_smtp_password']) ?>" placeholder="Google App Password"></div>
    </div>
    <p class="muted">Gmail Workspace: dùng <b>App Password</b>, không dùng mật khẩu Gmail thật. Tài khoản mặc định: hello.motivesocial@gmail.com</p>
    <button class="primary">Lưu cấu hình</button>
  </form>
</section>
<section class="card">
  <div class="card-head"><h2>Gửi email test</h2></div>
  <form method="post" class="form-row">
    <?php foreach($settings as $k=>$v): ?><input type="hidden" name="<?= e($k) ?>" value="<?= e($v) ?>"><?php endforeach; ?>
    <input type="hidden" name="send_test_email" value="1">
    <div><label>Email nhận test</label><input type="email" name="test_email" placeholder="hello.motivesocial@gmail.com"></div>
    <div style="display:flex;align-items:flex-end"><button class="btn-green">Gửi test</button></div>
  </form>
</section>
<section class="card">
  <div class="card-head"><h2>Email Logs</h2></div>
  <table class="dense-table"><thead><tr><th>Thời gian</th><th>Người nhận</th><th>Subject</th><th>Template</th><th>Status</th><th>Lỗi</th></tr></thead><tbody>
    <?php foreach($logs as $l): ?><tr><td><?= e($l['created_at']) ?></td><td><?= e($l['recipient_email']) ?></td><td><?= e($l['subject']) ?></td><td><?= e($l['template_key']) ?></td><td><span class="badge <?= $l['status']==='sent'?'green':'orange' ?>"><?= e($l['status']) ?></span></td><td><?= e($l['error_message']) ?></td></tr><?php endforeach; ?>
  </tbody></table>
</section>
