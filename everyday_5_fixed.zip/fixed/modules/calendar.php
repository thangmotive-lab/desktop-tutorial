<?php
function lunar_marker($date) {
  $base = strtotime('2026-02-17');
  $diff = floor((strtotime($date)-$base)/86400);
  $cycle = 29.530588853;
  $day = (int)floor(fmod((float)$diff, (float)$cycle)) + 1;
  if($day<=0) $day += 30;
  if($day===1) return 'Mùng 1';
  if($day===15) return '15 âm';
  if($day>=28) return 'Cuối tháng';
  return '';
}

if(isset($_GET['delete_event'])){
  $pdo->prepare('DELETE FROM calendar_event_attendees WHERE event_id=?')->execute([(int)$_GET['delete_event']]);
  $pdo->prepare('DELETE FROM calendar_events WHERE id=?')->execute([(int)$_GET['delete_event']]);
  redirect('app.php?page=calendar&month='.($_GET['month'] ?? date('Y-m')));
}

if($_SERVER['REQUEST_METHOD']==='POST'){
  if(!empty($_POST['event_id'])){
    $eid=(int)$_POST['event_id'];
    $pdo->prepare('UPDATE calendar_events SET title=?,event_type=?,start_datetime=?,end_datetime=?,location=?,project_id=?,description=? WHERE id=?')
      ->execute([$_POST['title'],$_POST['event_type'],$_POST['start_datetime'],$_POST['end_datetime'],$_POST['location'],$_POST['project_id']?:null,$_POST['description'],$eid]);
    $pdo->prepare('DELETE FROM calendar_event_attendees WHERE event_id=?')->execute([$eid]);
  } else {
    $stmt=$pdo->prepare('INSERT INTO calendar_events(title,event_type,start_datetime,end_datetime,location,project_id,owner_id,description) VALUES(?,?,?,?,?,?,?,?)');
    $stmt->execute([$_POST['title'],$_POST['event_type'],$_POST['start_datetime'],$_POST['end_datetime'],$_POST['location'],$_POST['project_id']?:null,current_user()['id'],$_POST['description']]);
    $eid=$pdo->lastInsertId();
    log_activity($pdo,'create','calendar_event',$eid,'Tạo lịch '.$_POST['title']);
  }
  foreach(array_unique(array_filter($_POST['attendees'] ?? [])) as $uidAtt){
    $pdo->prepare('INSERT INTO calendar_event_attendees(event_id,user_id) VALUES(?,?)')->execute([$eid,$uidAtt]);
    create_notification($pdo,$uidAtt,'Bạn được mời/cập nhật lịch','Lịch: '.$_POST['title'],'calendar','app.php?page=calendar');
  }
  redirect('app.php?page=calendar&month='.date('Y-m',strtotime($_POST['start_datetime'])).'&view='.($_GET['view']??'month'));
}

$month=$_GET['month'] ?? date('Y-m');
$view=$_GET['view'] ?? 'month';
$day=$_GET['day'] ?? date('Y-m-d');
$first=strtotime($month.'-01');
$days=(int)date('t',$first);
$startWeek=(int)date('N',$first);
$prev=date('Y-m',strtotime('-1 month',$first));
$next=date('Y-m',strtotime('+1 month',$first));
$today=date('Y-m-d');

if($view==='day'){
  $rangeStart=$day.' 00:00:00'; $rangeEnd=$day.' 23:59:59';
} elseif($view==='agenda'){
  $rangeStart=date('Y-m-d').' 00:00:00'; $rangeEnd=date('Y-m-d',strtotime('+14 days')).' 23:59:59';
} elseif($view==='week'){
  $weekStart=date('Y-m-d',strtotime('monday this week',strtotime($day)));
  $weekEnd=date('Y-m-d',strtotime($weekStart.' +6 days'));
  $rangeStart=$weekStart.' 00:00:00'; $rangeEnd=$weekEnd.' 23:59:59';
} else {
  $rangeStart=$month.'-01 00:00:00'; $rangeEnd=date('Y-m-t',strtotime($month.'-01')).' 23:59:59';
}

$eventsStmt=$pdo->prepare("SELECT ce.*,p.name project_name,u.name owner_name,u.avatar owner_avatar FROM calendar_events ce LEFT JOIN projects p ON p.id=ce.project_id LEFT JOIN users u ON u.id=ce.owner_id WHERE ce.start_datetime <= ? AND ce.end_datetime >= ? ORDER BY ce.start_datetime ASC");
$eventsStmt->execute([$rangeEnd,$rangeStart]);
$events=$eventsStmt->fetchAll();
$eventsByDay=[];
foreach($events as $ev){
  $sDay=strtotime(date('Y-m-d',strtotime($ev['start_datetime'])));
  $eDay=strtotime(date('Y-m-d',strtotime($ev['end_datetime'])));
  $monthS=strtotime($month.'-01'); $monthE=strtotime(date('Y-m-t', $monthS));
  for($cur=max($sDay,$monthS); $cur<=min($eDay,$monthE); $cur=strtotime('+1 day',$cur)){
    $d=(int)date('j',$cur);
    $ev['_continues'] = ($cur>$sDay || $cur<$eDay) ? 1 : 0;
    $ev['_day_start'] = ($cur==$sDay) ? 1 : 0;
    $eventsByDay[$d][]=$ev;
  }
}

$users=$pdo->query('SELECT id,name FROM users ORDER BY name')->fetchAll();
$projects=$pdo->query('SELECT id,name FROM projects ORDER BY name')->fetchAll();
$monthTitle = date('F Y', $first);
?>
<section class="gcal-shell">
  <div class="gcal-toolbar">
    <div class="gcal-left">
      <button class="gcal-create orange-create icon-action" onclick="openModal('calendarModal')" title="Tạo sự kiện">＋</button>
      <a class="gcal-nav" href="app.php?page=calendar&month=<?= e($prev) ?>&view=month">‹</a>
      <a class="gcal-nav" href="app.php?page=calendar&month=<?= e($next) ?>&view=month">›</a>
      <a class="gcal-today" href="app.php?page=calendar&month=<?= date('Y-m') ?>&day=<?= date('Y-m-d') ?>&view=<?= e($view) ?>">Today</a>
      <h2><?= e($view==='day'?date('d/m/Y',strtotime($day)):($view==='week'?'Week of '.date('d/m/Y',strtotime($weekStart??$day)):$monthTitle)) ?></h2>
    </div>
    <div class="gcal-right">
      <input type="date" class="js-date-picker" value="<?= e($day) ?>" onchange="location.href='app.php?page=calendar&view=day&day='+this.value+'&month='+this.value.substring(0,7)">
      <a class="gcal-view <?= $view==='month'?'active':'' ?>" href="app.php?page=calendar&view=month&month=<?= e($month) ?>">Month</a>
      <a class="gcal-view <?= $view==='week'?'active':'' ?>" href="app.php?page=calendar&view=week&day=<?= e($day) ?>&month=<?= e(substr($day,0,7)) ?>">Week</a>
      <a class="gcal-view <?= $view==='day'?'active':'' ?>" href="app.php?page=calendar&view=day&day=<?= e($day) ?>&month=<?= e(substr($day,0,7)) ?>">Day</a>
      <a class="gcal-view <?= $view==='agenda'?'active':'' ?>" href="app.php?page=calendar&view=agenda&day=<?= e($day) ?>&month=<?= e(substr($day,0,7)) ?>">Agenda</a>
    </div>
  </div>

  <?php if($view==='month'): ?>
  <div class="gcal-board">
    <div class="gcal-weeknames"><?php foreach(['MON','TUE','WED','THU','FRI','SAT','SUN'] as $i=>$label): ?><div class="<?= $i>=5?'weekend':'' ?>"><?= $label ?></div><?php endforeach; ?></div>
    <div class="gcal-grid">
      <?php for($blank=1;$blank<$startWeek;$blank++): ?><div class="gcal-day muted"></div><?php endfor; ?>
      <?php for($d=1;$d<=$days;$d++): $date=$month.'-'.str_pad($d,2,'0',STR_PAD_LEFT); $weekday=(int)date('N',strtotime($date)); $marker=lunar_marker($date); $dayEvents=$eventsByDay[$d] ?? []; ?>
        <div class="gcal-day <?= $weekday>=6?'weekend':'' ?> <?= $date===$today?'today':'' ?>">
          <div class="gcal-date"><span><?= $d ?></span><?php if($marker): ?><em><?= e($marker) ?></em><?php endif; ?></div>
          <div class="gcal-events">
            <?php foreach(array_slice($dayEvents,0,4) as $ev): ?>
              <button class="gcal-event <?= e($ev['event_type']) ?> <?= !empty($ev['_continues'])?'multi-day':'' ?>" onclick="openModal('eventEdit<?= $ev['id'] ?>')"><span><?= !empty($ev['_day_start']) ? e(date('H:i',strtotime($ev['start_datetime']))) : '↔' ?></span><b><?= e($ev['title']) ?></b></button>
            <?php endforeach; ?>
            <?php if(count($dayEvents)>4): ?><div class="gcal-more">+<?= count($dayEvents)-4 ?> more</div><?php endif; ?>
          </div>
        </div>
      <?php endfor; ?>
    </div>
  </div>
  <?php else: ?>
  <section class="card gcal-list-card">
    <div class="card-head"><h2><?= $view==='agenda'?'Agenda 14 ngày':($view==='week'?'Lịch theo tuần':'Lịch theo ngày') ?></h2></div>
    <table class="dense-table">
      <thead><tr><th>Thời gian</th><th>Event</th><th>Type</th><th>Project</th><th>Location</th><th>Action</th></tr></thead>
      <tbody>
      <?php foreach($events as $ev): ?><tr><td><?= e(date('d/m H:i',strtotime($ev['start_datetime'])).' - '.date('H:i',strtotime($ev['end_datetime']))) ?></td><td><b><?= e($ev['title']) ?></b><br><span class="muted"><?= e($ev['description']) ?></span></td><td><?= e($ev['event_type']) ?></td><td><?= e($ev['project_name']) ?></td><td><?= e($ev['location']) ?></td><td><button class="btn btn-soft icon-action" title="Sửa" onclick="openModal('eventEdit<?= $ev['id'] ?>')">✎</button></td></tr><?php endforeach; ?>
      <?php if(empty($events)): ?><tr><td colspan="6" class="muted">Không có lịch.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </section>
  <?php endif; ?>
</section>

<div class="modal-backdrop" id="calendarModal">
  <div class="modal-panel gcal-modal">
    <button class="modal-close" onclick="closeModal('calendarModal')">×</button>
    <h2>Create event</h2>
    <form method="post">
      <label>Title</label><input name="title" required placeholder="Meeting, shooting, deadline...">
      <div class="form-row"><div><label>Type</label><select name="event_type"><option>meeting</option><option>shooting</option><option>deadline</option><option>internal</option></select></div><div><label>Project</label><select name="project_id"><option value="">Không gắn</option><?php foreach($projects as $p): ?><option value="<?= $p['id'] ?>"><?= e($p['name']) ?></option><?php endforeach; ?></select></div></div>
      <div class="form-row"><div><label>Start</label><input type="datetime-local" name="start_datetime" required></div><div><label>End</label><input type="datetime-local" name="end_datetime" required></div></div>
      <label>Location</label><input name="location">
      <label>Guests</label><select name="attendees[]" multiple><?php foreach($users as $u): ?><option value="<?= $u['id'] ?>"><?= e($u['name']) ?></option><?php endforeach; ?></select>
      <label>Description</label><textarea name="description"></textarea>
      <button class="primary">Save event</button>
    </form>
  </div>
</div>

<?php foreach($events as $ev): ?>
<div class="modal-backdrop" id="eventEdit<?= $ev['id'] ?>">
  <div class="modal-panel gcal-modal">
    <button class="modal-close" onclick="closeModal('eventEdit<?= $ev['id'] ?>')">×</button>
    <h2>Edit event</h2>
    <form method="post">
      <input type="hidden" name="event_id" value="<?= $ev['id'] ?>">
      <label>Title</label><input name="title" required value="<?= e($ev['title']) ?>">
      <div class="form-row"><div><label>Type</label><select name="event_type"><?php foreach(['meeting','shooting','deadline','internal'] as $t): ?><option value="<?= $t ?>" <?= $ev['event_type']===$t?'selected':'' ?>><?= $t ?></option><?php endforeach; ?></select></div><div><label>Project</label><select name="project_id"><option value="">Không gắn</option><?php foreach($projects as $p): ?><option value="<?= $p['id'] ?>" <?= $ev['project_id']==$p['id']?'selected':'' ?>><?= e($p['name']) ?></option><?php endforeach; ?></select></div></div>
      <div class="form-row"><div><label>Start</label><input type="datetime-local" name="start_datetime" value="<?= e(date('Y-m-d\TH:i',strtotime($ev['start_datetime']))) ?>" required></div><div><label>End</label><input type="datetime-local" name="end_datetime" value="<?= e(date('Y-m-d\TH:i',strtotime($ev['end_datetime']))) ?>" required></div></div>
      <label>Location</label><input name="location" value="<?= e($ev['location']) ?>">
      <label>Description</label><textarea name="description"><?= e($ev['description']) ?></textarea>
      <div class="form-actions"><button class="primary icon-action" title="Lưu">💾</button><a class="btn btn-soft icon-action danger" title="Xóa" onclick="return confirm('Xóa event?')" href="app.php?page=calendar&delete_event=<?= $ev['id'] ?>&month=<?= e($month) ?>&view=<?= e($view) ?>">🗑</a></div>
    </form>
  </div>
</div>
<?php endforeach; ?>
