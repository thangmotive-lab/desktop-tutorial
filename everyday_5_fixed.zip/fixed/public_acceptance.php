<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';

function ac_money($n){ return number_format((float)$n,0,',','.').' VNĐ'; }
function ac_date($v){ $ts=strtotime((string)$v); return $ts?date('d/m/Y',$ts):date('d/m/Y'); }
function ac_setting(PDO $pdo,$key,$default=''){ try{ if(function_exists('get_setting')) return get_setting($pdo,$key,$default); }catch(Exception $e){} return $default; }
function ac_pct($n){ $n=(float)$n; return rtrim(rtrim(number_format($n,2,'.',''),'0'),'.'); }

$token=trim((string)($_GET['token']??''));
$id=(int)($_GET['id']??0);
$sql='SELECT a.*, c.contract_code ccode, c.signed_date cdate, q.quote_code, q.id qid
      FROM acceptances a
      LEFT JOIN contracts c ON c.id=a.contract_id
      LEFT JOIN quotations q ON q.id=a.quotation_id';
if($token!==''){
  $st=$pdo->prepare($sql.' WHERE a.public_token=? LIMIT 1');
  $st->execute([$token]);
}else{
  $st=$pdo->prepare($sql.' WHERE a.id=? LIMIT 1');
  $st->execute([$id]);
}
$a=$st->fetch();
if(!$a) die('Biên bản nghiệm thu không tồn tại hoặc link không hợp lệ.');

$it=$pdo->prepare('SELECT * FROM acceptance_deliverables WHERE acceptance_id=? ORDER BY sort_order,id');
$it->execute([$a['id']]);
$items=$it->fetchAll();

// Fallback: if deliverables were not imported yet, show quotation items without writing to DB.
if(empty($items) && !empty($a['quotation_id'])){
  try{
    $q=$pdo->prepare('SELECT * FROM quotation_items WHERE quotation_id=? ORDER BY sort_order,id');
    $q->execute([$a['quotation_id']]);
    $items=[];
    foreach($q->fetchAll() as $r){
      $items[]=[
        'title'=>$r['service_name'] ?? 'Hạng mục',
        'description'=>$r['description'] ?? '',
        'quoted_quantity'=>(float)($r['quantity'] ?? 1),
        'actual_quantity'=>(float)($r['quantity'] ?? 1),
        'unit'=>$r['unit'] ?? '',
        'unit_price'=>(float)($r['unit_price'] ?? 0),
        'vat_rate'=>(float)($r['vat_rate'] ?? ($r['vat_percent'] ?? 10)),
        'value_amount'=>(float)($r['subtotal'] ?? 0),
        'source_type'=>'quotation_item',
        'delivery_url'=>'',
        'status'=>'Đạt',
      ];
    }
  }catch(Exception $e){}
}

$logo=ac_setting($pdo,'logo_dark','');
if(!$logo && file_exists(__DIR__.'/assets/img/motive_logo_2026.png')) $logo='assets/img/motive_logo_2026.png';

$companyName=ac_setting($pdo,'company_name','CÔNG TY TNHH TRUYỀN THÔNG MOTIVE');
$companyTax=ac_setting($pdo,'company_tax_code','0110212832');
$companyPhone=ac_setting($pdo,'company_phone','0965.980.886');
$companyEmail=ac_setting($pdo,'company_email','hello.motivesocial@gmail.com');
$companyWebsite=ac_setting($pdo,'company_website','motiveagency.vn');
$companyAddress=ac_setting($pdo,'company_address','Số 5 ngách 15 ngõ 82 Yên Lãng, Đống Đa, Hà Nội');
$companyRep=ac_setting($pdo,'company_representative','Vũ Ngọc Thắng');
$companyRole=ac_setting($pdo,'company_representative_role','Giám đốc');
$bankAccount=ac_setting($pdo,'company_bank_account','199938888');
$bankName=ac_setting($pdo,'company_bank_name','MB Bank – Sở giao dịch 03');

$totalBeforeVat=0; $totalVat=0;
foreach($items as $d){
  $qty=(float)($d['actual_quantity'] ?? 0);
  $unitPrice=(float)($d['unit_price'] ?? 0);
  $line=$unitPrice>0 ? $qty*$unitPrice : (float)($d['value_amount'] ?? 0);
  $rate=(float)($d['vat_rate'] ?? 0);
  $totalBeforeVat += $line;
  $totalVat += $line*($rate/100);
}
$totalAfterVat=$totalBeforeVat+$totalVat;
if($totalAfterVat<=0) $totalAfterVat=(float)($a['accepted_value'] ?: $a['contract_value']);
$paid=(float)($a['paid_amount'] ?? 0);
$remaining=$totalAfterVat-$paid;
$contractCode=$a['contract_code'] ?: ($a['ccode'] ?? '');
$acceptedDate=$a['accepted_date'] ?: date('Y-m-d');
?>
<!doctype html>
<html lang="vi">
<head>
<meta charset="utf-8">
<title><?= e($a['acceptance_code']) ?> - <?= e($a['client_name']) ?></title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
*{box-sizing:border-box}:root{--ink:#111827;--muted:#6b7280;--line:#e5e7eb;--soft:#f8fafc;--purple:#6d28d9;--danger:#dc2626}body{margin:0;background:#f3f4f6;color:var(--ink);font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:1.42}.page{width:210mm;min-height:297mm;margin:14px auto;background:#fff;padding:8.5mm 10mm;box-shadow:0 14px 40px rgba(15,23,42,.12)}.top{display:grid;grid-template-columns:48mm 1fr;gap:8mm;align-items:center;border-bottom:1px solid var(--line);padding-bottom:6mm}.brand{width:48mm;height:17mm;display:flex;align-items:center;justify-content:flex-start;overflow:hidden}.brand img{max-width:48mm;max-height:17mm;width:auto;height:auto;object-fit:contain}.brand-fallback{background:#111827;color:#fff;border-radius:3mm;padding:4mm 7mm;font-weight:900;letter-spacing:.08em}.company h1{font-size:16px;margin:0 0 2mm;font-weight:900}.company p{margin:.8mm 0;color:var(--muted);font-size:10.2px}.title-row{display:grid;grid-template-columns:1fr 50mm;gap:8mm;padding:6mm 0;border-bottom:1px solid var(--line)}.doc-title{font-size:25px;line-height:1.04;font-weight:900;letter-spacing:-.03em;margin:0}.doc-sub{font-size:11px;color:var(--muted);margin-top:2mm}.meta div{display:flex;justify-content:space-between;border-bottom:1px solid #f1f5f9;padding:1.1mm 0;gap:4mm;font-size:10.2px}.meta span{color:var(--muted)}.parties{display:grid;grid-template-columns:1fr 1fr;gap:6mm;padding:5mm 0;border-bottom:1px solid var(--line)}.party{border:1px solid var(--line);border-radius:3mm;padding:3.6mm;background:#fff}.kicker{color:var(--purple);font-size:9.2px;font-weight:900;text-transform:uppercase;letter-spacing:.08em;margin-bottom:2mm}.info-row{display:grid;grid-template-columns:24mm 1fr;gap:2.5mm;margin:1.4mm 0}.info-row span{color:var(--muted)}.section-title{font-size:14px;font-weight:900;margin:5mm 0 2.8mm}.acceptance-table{width:100%;border-collapse:separate;border-spacing:0;border:1px solid var(--line);border-radius:3mm;overflow:hidden}.acceptance-table th{background:var(--soft);text-align:left;padding:2.2mm 1.8mm;font-size:8.7px;text-transform:uppercase}.acceptance-table td{padding:2.6mm 1.8mm;border-top:1px solid var(--line);vertical-align:top;font-size:10px}.text-right{text-align:right}.nowrap{white-space:nowrap}.service-name{font-weight:900;font-size:10.8px}.muted{color:var(--muted)}.settlement{display:grid;grid-template-columns:1.1fr .9fr;gap:6mm;margin-top:5mm;page-break-inside:avoid;break-inside:avoid}.settle-box{border:1px solid var(--line);border-radius:3mm;padding:4mm}.settle-box h3{margin:0 0 3mm;font-size:13px}.settle-row{display:flex;justify-content:space-between;gap:4mm;border-bottom:1px solid #f1f5f9;padding:1.8mm 0}.settle-row:last-child{border-bottom:0}.big-total{font-size:18px;font-weight:900;color:var(--purple)}.refund{font-size:18px;font-weight:900;color:var(--danger)}.article{margin-top:5mm;color:#374151;page-break-inside:avoid;break-inside:avoid}.article h3{font-size:13px;margin:0 0 2mm}.article p{margin:1.2mm 0}.signatures{display:grid;grid-template-columns:1fr 1fr;gap:18mm;margin-top:10mm;text-align:center;page-break-inside:avoid;break-inside:avoid}.sig-box{min-height:32mm;page-break-inside:avoid;break-inside:avoid}.sig-title{font-weight:900}.sig-line{margin-top:22mm;border-top:1px solid var(--line);padding-top:2mm;color:var(--muted)}.footer{margin-top:6mm;border-top:1px solid var(--line);padding-top:3mm;display:flex;justify-content:space-between;color:var(--muted);font-size:9.5px}.print-actions{position:fixed;right:18px;bottom:18px}.print-actions button{border:0;border-radius:999px;padding:10px 16px;background:#111827;color:#fff;font-weight:800}@media print{body{background:#fff}.page{margin:0;box-shadow:none;width:210mm;min-height:297mm;padding:8mm 9mm}.print-actions{display:none}.signatures,.sig-box,.settlement{page-break-inside:avoid;break-inside:avoid}@page{size:A4;margin:0}}@media(max-width:820px){.page{width:100%;margin:0;box-shadow:none;padding:18px}.top,.title-row,.parties,.settlement{grid-template-columns:1fr}.doc-title{font-size:26px}.acceptance-table{display:block;overflow-x:auto}}
</style>
</head>
<body>
<div class="page">
<header class="top">
  <div class="brand"><?php if($logo): ?><img src="<?= e($logo) ?>?v=<?= time() ?>" alt="Motive Agency"><?php else: ?><div class="brand-fallback">MOTIVE</div><?php endif; ?></div>
  <div class="company"><h1><?= e($companyName) ?></h1><p>MST: <?= e($companyTax) ?> · Hotline: <?= e($companyPhone) ?> · Email: <?= e($companyEmail) ?></p><p><?= e($companyAddress) ?> · <?= e($companyWebsite) ?></p></div>
</header>

<section class="title-row">
  <div><h2 class="doc-title">BIÊN BẢN NGHIỆM THU<br>VÀ THANH LÝ HỢP ĐỒNG</h2><div class="doc-sub">Acceptance & Settlement · <?= e($a['acceptance_code']) ?></div></div>
  <div class="meta"><div><span>Ngày nghiệm thu</span><strong><?= e(ac_date($acceptedDate)) ?></strong></div><div><span>Hợp đồng</span><strong><?= e($contractCode) ?></strong></div><?php if($a['quote_code']): ?><div><span>Báo giá</span><strong><?= e($a['quote_code']) ?></strong></div><?php endif; ?><div><span>Hạn thanh toán</span><strong><?= (int)$a['payment_due_days'] ?> ngày</strong></div></div>
</section>

<section class="parties">
  <div class="party"><div class="kicker">Bên A - Bên sử dụng dịch vụ</div><div class="info-row"><span>Tổ chức</span><strong><?= e($a['client_name']) ?></strong></div><div class="info-row"><span>Đại diện</span><strong><?= e($a['client_contact'] ?: 'Đang cập nhật') ?></strong></div><div class="info-row"><span>MST</span><strong><?= e($a['client_tax_code'] ?: 'Đang cập nhật') ?></strong></div><div class="info-row"><span>Địa chỉ</span><strong><?= e($a['client_address'] ?: 'Đang cập nhật') ?></strong></div></div>
  <div class="party"><div class="kicker">Bên B - Nhà cung cấp dịch vụ</div><div class="info-row"><span>Tổ chức</span><strong><?= e($companyName) ?></strong></div><div class="info-row"><span>Đại diện</span><strong><?= e($companyRep) ?></strong></div><div class="info-row"><span>Chức vụ</span><strong><?= e($companyRole) ?></strong></div><div class="info-row"><span>Địa chỉ</span><strong><?= e($companyAddress) ?></strong></div><div class="info-row"><span>MST</span><strong><?= e($companyTax) ?></strong></div><div class="info-row"><span>STK</span><strong><?= e($bankAccount) ?> · <?= e($bankName) ?></strong></div></div>
</section>

<h3 class="section-title">ĐIỀU I. SẢN PHẨM / HẠNG MỤC NGHIỆM THU THỰC TẾ</h3>
<table class="acceptance-table">
  <thead><tr><th style="width:9mm">STT</th><th>Nội dung nghiệm thu</th><th class="nowrap">SL BG</th><th class="nowrap">SL thực tế</th><th class="text-right nowrap">Đơn giá</th><th class="text-right nowrap">Thành tiền</th></tr></thead>
  <tbody>
    <?php foreach($items as $i=>$d):
      $qty=(float)($d['actual_quantity'] ?? 0);
      $unitPrice=(float)($d['unit_price'] ?? 0);
      $line=$unitPrice>0 ? $qty*$unitPrice : (float)($d['value_amount'] ?? 0);
    ?>
      <tr><td><?= $i+1 ?></td><td><div class="service-name"><?= e($d['title']) ?></div><?php if(!empty($d['description'])): ?><div class="muted"><?= e($d['description']) ?></div><?php endif; ?></td><td class="nowrap"><?= e($d['quoted_quantity']) ?> <?= e($d['unit']) ?></td><td class="nowrap"><strong><?= e($d['actual_quantity']) ?> <?= e($d['unit']) ?></strong></td><td class="text-right nowrap"><?= ac_money($unitPrice) ?></td><td class="text-right nowrap"><strong><?= ac_money($line) ?></strong></td></tr>
    <?php endforeach; ?>
    <?php if(empty($items)): ?><tr><td colspan="6" class="muted">Danh sách sản phẩm nghiệm thu sẽ được cập nhật theo thực tế bàn giao.</td></tr><?php endif; ?>
  </tbody>
</table>





<h3 class="section-title">ĐIỀU II. GIÁ TRỊ NGHIỆM THU VÀ THANH TOÁN</h3>
<section class="settlement">
  <div class="settle-box"><h3>Giá trị nghiệm thu</h3><div class="settle-row"><span>Tổng tiền trước VAT</span><strong><?= ac_money($totalBeforeVat) ?></strong></div><div class="settle-row"><span>VAT</span><strong><?= ac_money($totalVat) ?></strong></div><div class="settle-row"><span>Tổng tiền sau VAT</span><strong><?= ac_money($totalAfterVat) ?></strong></div><div class="settle-row"><span>Đã thanh toán</span><strong><?= ac_money($paid) ?></strong></div></div>
  <div class="settle-box"><h3>Kết luận thanh toán</h3><?php if($remaining>0): ?><div class="muted">Bên A còn phải thanh toán cho Bên B:</div><div class="big-total"><?= ac_money($remaining) ?></div><?php elseif($remaining<0): ?><div class="muted">Bên B cần hoàn lại cho Bên A:</div><div class="refund"><?= ac_money(abs($remaining)) ?></div><?php else: ?><div class="muted">Hai bên đã hoàn tất nghĩa vụ thanh toán.</div><div class="big-total">Đã tất toán</div><?php endif; ?></div>
</section>
<div class="page-break"></div>

<section class="financial-page">
<div class="article"><h3>ĐIỀU III. XÁC NHẬN VÀ ĐIỀU KHOẢN THANH TOÁN</h3><p>Bên A đồng ý nghiệm thu các sản phẩm/hạng mục thực tế do Bên B bàn giao theo danh sách và giá trị nêu tại Điều I và Điều II.</p><?php if($remaining>0): ?><p>Bên A thanh toán số tiền còn lại <strong><?= ac_money($remaining) ?></strong> trong vòng <strong><?= (int)$a['payment_due_days'] ?> ngày</strong> kể từ ngày ký biên bản này.</p><?php elseif($remaining<0): ?><p>Bên B thực hiện hoàn lại số tiền <strong><?= ac_money(abs($remaining)) ?></strong> hoặc đối trừ vào nghĩa vụ tài chính khác theo thỏa thuận giữa hai bên.</p><?php endif; ?><p>Biên bản này là căn cứ để hai bên tiến hành thanh lý hợp đồng và hoàn tất các nghĩa vụ còn lại.</p><?php if($a['note']): ?><p class="muted">Ghi chú: <?= e($a['note']) ?></p><?php endif; ?></div>
</section>
<div class="signatures"><div class="sig-box"><div class="sig-title">ĐẠI DIỆN BÊN A</div><div class="muted">Ký, ghi rõ họ tên</div><div class="sig-line"><?= e($a['client_contact'] ?: 'Khách hàng') ?></div></div><div class="sig-box"><div class="sig-title">ĐẠI DIỆN BÊN B</div><div class="muted">Ký, ghi rõ họ tên</div><div class="sig-line"><?= e($companyRep) ?></div></div></div>
<footer class="footer"><span>Motive Agency · Keep Moving Forward</span><span>Tạo tự động từ MotiveEveryday</span></footer>
</div><div class="print-actions"><button onclick="window.print()">Print / PDF</button></div>
</body></html>
