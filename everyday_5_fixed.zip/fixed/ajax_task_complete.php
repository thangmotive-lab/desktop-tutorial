<?php
ob_start();
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';

header('Content-Type: application/json; charset=utf-8');

function ajax_column_exists($pdo, $table, $column) {
    try {
        $stmt = $pdo->prepare("SHOW COLUMNS FROM `$table` LIKE ?");
        $stmt->execute([$column]);
        return (bool)$stmt->fetch();
    } catch (Throwable $e) {
        return false;
    }
}

try {
    if (!function_exists('is_logged_in') || !is_logged_in()) {
        http_response_code(401);
        echo json_encode(['ok'=>false,'error'=>'not_logged_in']);
        exit;
    }

    $me = current_user();
    $uid = (int)($me['id'] ?? 0);
    $tid = (int)($_POST['task_id'] ?? $_GET['task_id'] ?? 0);

    if ($tid <= 0) {
        http_response_code(400);
        echo json_encode(['ok'=>false,'error'=>'missing_task_id']);
        exit;
    }

    $stmt = $pdo->prepare("SELECT * FROM tasks WHERE id=? LIMIT 1");
    $stmt->execute([$tid]);
    $task = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$task) {
        http_response_code(404);
        echo json_encode(['ok'=>false,'error'=>'task_not_found']);
        exit;
    }

    $isAdmin = function_exists('user_is_admin') ? user_is_admin() : false;
    $assigneeId = isset($task['assignee_id']) ? (int)$task['assignee_id'] : 0;
    $createdBy = isset($task['created_by']) ? (int)$task['created_by'] : 0;

    $canUpdate = $isAdmin || $assigneeId === $uid || $createdBy === $uid;

    if (!$canUpdate) {
        http_response_code(403);
        echo json_encode(['ok'=>false,'error'=>'forbidden']);
        exit;
    }

    $sets = ["status=?"];
    $params = ['Done'];

    if (ajax_column_exists($pdo, 'tasks', 'completed_at')) {
        $sets[] = "completed_at=NOW()";
    }

    if (ajax_column_exists($pdo, 'tasks', 'updated_at')) {
        $sets[] = "updated_at=NOW()";
    }

    if (ajax_column_exists($pdo, 'tasks', 'completed_by')) {
        $sets[] = "completed_by=?";
        $params[] = $uid;
    }

    $params[] = $tid;

    $sql = "UPDATE tasks SET " . implode(", ", $sets) . " WHERE id=?";
    $pdo->prepare($sql)->execute($params);

    if (function_exists('log_activity')) {
        try {
            log_activity($pdo, 'complete', 'task', $tid, 'Task Delight V2 complete');
        } catch (Throwable $e) {
            // Ignore logging error so task completion still works.
        }
    }

    $mcoinAward = 0;
    if (function_exists('mcoin_award')) {
        try {
            // Mcoin chỉ thưởng cho task có nguồn từ project hoặc do người khác giao.
            // Task private/cá nhân tự tạo không được tính thưởng.
            $projectId = isset($task['project_id']) ? (int)$task['project_id'] : 0;
            $createdBy = isset($task['created_by']) ? (int)$task['created_by'] : 0;
            $isPrivate = false;
            foreach (['is_private','private','personal_task'] as $privateCol) {
                if (isset($task[$privateCol]) && (int)$task[$privateCol] === 1) { $isPrivate = true; break; }
            }
            $eligibleForMcoin = !$isPrivate && ($projectId > 0 || ($createdBy > 0 && $createdBy !== $uid));
            if ($eligibleForMcoin) {
                $deadlineTs = !empty($task['deadline']) ? strtotime($task['deadline']) : 0;
                $isEarly = $deadlineTs && $deadlineTs > time();
                $mcoinAward = (int)mcoin_get_setting($pdo, $isEarly ? 'task_done_early' : 'task_done', $isEarly ? 2000 : 1000);
                if ($mcoinAward > 0) {
                    $okAward = mcoin_award($pdo, $uid, $mcoinAward, $isEarly ? 'Hoàn thành task sớm' : 'Hoàn thành task', 'task', $tid, 'task_done:'.$tid.':'.$uid, $task['title'] ?? '');
                    if(!$okAward) $mcoinAward = 0; else { if(function_exists('achievement_award')) achievement_award($pdo,$uid,'first_task'); }
                }
            }
        } catch (Throwable $e) { $mcoinAward = 0; }
    }

    echo json_encode([
        'ok' => true,
        'task_id' => $tid,
        'message' => 'task_completed',
        'mcoin_award' => $mcoinAward
    ]);
    exit;

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'ok' => false,
        'error' => 'server_error',
        'message' => $e->getMessage()
    ]);
    exit;
}
