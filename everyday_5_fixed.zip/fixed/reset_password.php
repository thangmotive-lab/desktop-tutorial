<?php
ob_start();
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';

if (is_logged_in()) redirect('app.php?page=workspace');

$token=$_GET['token'] ?? $_POST['token'] ?? '';
$error='';$success='';
$user=null;
if($token){
  $stmt=$pdo->prepare("SELECT id,email,name FROM users WHERE reset_token=? AND reset_expires_at > NOW() LIMIT 1");
  $stmt->execute([$token]);
  $user=$stmt->fetch();
}
if(!$token || !$user) $error='Link đặt lại mật khẩu không hợp lệ hoặc đã hết hạn.';

if($_SERVER['REQUEST_METHOD']==='POST' && $user){
  $pass=$_POST['password'] ?? '';
  $confirm=$_POST['confirm_password'] ?? '';
  if(strlen($pass)<6) $error='Mật khẩu cần tối thiểu 6 ký tự.';
  elseif($pass!==$confirm) $error='Mật khẩu xác nhận không khớp.';
  else{
    $hash=password_hash($pass,PASSWORD_DEFAULT);
    $pdo->prepare("UPDATE users SET password_hash=?, reset_token=NULL, reset_expires_at=NULL WHERE id=?")->execute([$hash,$user['id']]);
    $success='Đã đổi mật khẩu thành công. Bạn có thể đăng nhập lại.';
  }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <title>Đặt lại mật khẩu - Motive Everyday</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    *{box-sizing:border-box} body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px;font-family:Inter,Arial,sans-serif;color:#101828;background:linear-gradient(135deg,#fff7ed,#ecfeff,#f5f3ff)}
    .auth-card{width:min(520px,100%);background:rgba(255,255,255,.88);border:1px solid rgba(255,255,255,.7);border-radius:30px;padding:34px;box-shadow:0 24px 70px rgba(15,23,42,.12)}
    .eyebrow{font-size:12px;font-weight:950;letter-spacing:.08em;text-transform:uppercase;color:#ff6b4a} h1{font-size:36px;letter-spacing:-.06em;margin:8px 0 10px} p{color:#667085;line-height:1.55}
    label{display:block;font-weight:850;margin:18px 0 8px} input{width:100%;min-height:52px;border:1px solid #e5e7eb;border-radius:18px;padding:12px 14px;font-size:15px}
    button,a.btn{display:inline-flex;align-items:center;justify-content:center;text-decoration:none;border:0;border-radius:18px;min-height:50px;padding:12px 16px;font-weight:900;cursor:pointer}
    button{width:100%;background:#111827;color:#fff;margin-top:18px}.btn{background:#f3f4f6;color:#111827;margin-top:12px}
    .alert{padding:12px 14px;border-radius:16px;margin:12px 0;font-weight:800}.ok{background:#ecfdf5;color:#047857}.err{background:#fff1f2;color:#be123c}
  </style>
</head>
<body>
  <main class="auth-card">
    <span class="eyebrow">Reset Password</span>
    <h1>Đặt lại mật khẩu</h1>
    <?php if($error): ?><div class="alert err"><?= e($error) ?></div><?php endif; ?>
    <?php if($success): ?><div class="alert ok"><?= e($success) ?></div><a class="btn" href="login.php">Đăng nhập</a><?php elseif($user): ?>
      <p>Tài khoản: <b><?= e($user['email']) ?></b></p>
      <form method="post">
        <input type="hidden" name="token" value="<?= e($token) ?>">
        <label>Mật khẩu mới</label><input type="password" name="password" required>
        <label>Nhập lại mật khẩu</label><input type="password" name="confirm_password" required>
        <button>Lưu mật khẩu mới</button>
      </form>
    <?php else: ?><a class="btn" href="forgot_password.php">Tạo link mới</a><?php endif; ?>
  </main>
</body>
</html>
