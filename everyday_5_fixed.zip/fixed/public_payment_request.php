<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';

function pr_has_col(PDO $pdo, string $table, string $col): bool {
  try{
    $st=$pdo->prepare("SHOW COLUMNS FROM `$table` LIKE ?");
    $st->execute([$col]);
    return (bool)$st->fetch();
  }catch(Exception $e){ return false; }
}
function pr_add_col(PDO $pdo, string $table, string $ddl): void {
  $col=trim(strtok($ddl,' '));
  if(!pr_has_col($pdo,$table,$col)){
    try{ $pdo->exec("ALTER TABLE `$table` ADD COLUMN $ddl"); }catch(Exception $e){}
  }
}
function pr_safe_date($v, $fallback=null){
  $v=trim((string)$v);
  if($v==='') $v=$fallback ?: date('Y-m-d');
  $ts=strtotime($v);
  return $ts ? date('d/m/Y',$ts) : date('d/m/Y');
}
function pr_money($n){ return number_format((float)$n,0,',','.').' VNĐ'; }

try{
  pr_add_col($pdo,'payment_schedules','public_token VARCHAR(80) NULL');
}catch(Exception $e){}

$token=trim((string)($_GET['token'] ?? ''));
$id=(int)($_GET['id'] ?? 0);

$sqlBase="SELECT ps.*,
  c.contract_code,c.client_name AS contract_client_name,c.total_value AS contract_total,
  q.quote_code,q.title AS quote_title,q.client_name AS quote_client_name,q.client_contact,q.public_token AS quote_public_token
  FROM payment_schedules ps
  LEFT JOIN contracts c ON c.id=ps.contract_id
  LEFT JOIN quotations q ON q.id=ps.quotation_id";

if($token!==''){
  $st=$pdo->prepare($sqlBase." WHERE ps.public_token=? LIMIT 1");
  $st->execute([$token]);
}else{
  $st=$pdo->prepare($sqlBase." WHERE ps.id=? LIMIT 1");
  $st->execute([$id]);
}
$p=$st->fetch();
if(!$p) die('Đề nghị thanh toán không tồn tại hoặc link không hợp lệ.');

if(empty($p['public_token'])){
  try{
    $newToken=bin2hex(random_bytes(20));
    $pdo->prepare("UPDATE payment_schedules SET public_token=? WHERE id=?")->execute([$newToken,(int)$p['id']]);
    $p['public_token']=$newToken;
  }catch(Exception $e){}
}

$paymentCode=$p['payment_code'] ?: ('PAY-'.str_pad((string)$p['id'],4,'0',STR_PAD_LEFT));
$clientName=$p['quote_client_name'] ?: $p['contract_client_name'] ?: 'Quý khách';
$clientContact=$p['client_contact'] ?: '';
$title=$p['title'] ?: $p['milestone'] ?: 'Đợt thanh toán';
$note=$p['note'] ?: '';
$dueDate=$p['due_date'] ?: date('Y-m-d');
$createdRaw = $p['created_at'] ?? $p['paid_date'] ?? $p['due_date'] ?? date('Y-m-d');
$total=(float)($p['amount'] ?? 0);
$subtotal=round($total/1.1);
$vat=max(0,$total-$subtotal);
$serviceTitle = $p['quote_title'] ?: 'Báo giá dịch vụ';
$contractCode = $p['contract_code'] ?: '';
$quoteCode = $p['quote_code'] ?: '';
?>
<!doctype html>
<html lang="vi">
<head>
<meta charset="utf-8">
<title><?= e($paymentCode) ?> - <?= e($clientName) ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
*{box-sizing:border-box}
:root{--ink:#111827;--muted:#6b7280;--line:#e5e7eb;--soft:#f8fafc;--purple:#6d28d9}
body{margin:0;background:#f3f4f6;color:var(--ink);font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:1.48}
.page{width:210mm;min-height:297mm;margin:14px auto;background:#fff;padding:10mm 11mm;box-shadow:0 14px 40px rgba(15,23,42,.12)}
.top{display:grid;grid-template-columns:28% 72%;gap:10mm;align-items:start;border-bottom:1px solid var(--line);padding-bottom:8mm}
.logo-mark{display:inline-flex;width:42mm;height:13mm;align-items:center;justify-content:center;background:#111827;color:white;border-radius:3mm;font-weight:900;font-size:20px;letter-spacing:.08em}
.logo-sub{font-size:8px;letter-spacing:.18em;color:#d1d5db;margin-left:1mm}
.company h1{font-size:18px;margin:0 0 3mm;font-weight:900;letter-spacing:-.02em}
.company p{margin:1.5mm 0;color:var(--muted);font-size:11px}
.title-row{display:grid;grid-template-columns:1fr 46mm;gap:10mm;padding:8mm 0 7mm;border-bottom:1px solid var(--line)}
.doc-title{font-size:33px;font-weight:900;letter-spacing:-.045em;margin:0}
.doc-sub{font-size:13px;color:var(--muted);margin-top:2mm}
.meta{display:grid;grid-template-columns:1fr;gap:2.5mm;font-size:11px}
.meta div{display:flex;justify-content:space-between;gap:5mm;border-bottom:1px solid #f1f5f9;padding-bottom:1.5mm}
.meta span{color:var(--muted)}
.meta strong{font-size:11px}
.parties{display:grid;grid-template-columns:1fr 1fr;gap:10mm;padding:7mm 0;border-bottom:1px solid var(--line)}
.kicker{color:var(--purple);font-size:10px;font-weight:900;letter-spacing:.08em;text-transform:uppercase;margin-bottom:3mm}
.info-row{display:grid;grid-template-columns:27mm 1fr;gap:4mm;margin:2.3mm 0}
.info-row span{color:var(--muted)}
.info-row strong{font-weight:800}
.section-title{font-size:16px;font-weight:900;margin:7mm 0 3.5mm}
table{width:100%;border-collapse:separate;border-spacing:0;border:1px solid var(--line);border-radius:4mm;overflow:hidden}
th{background:var(--soft);text-align:left;padding:3mm 2.5mm;font-size:10px;text-transform:uppercase;letter-spacing:.04em}
td{padding:4mm 2.5mm;border-top:1px solid var(--line);vertical-align:top;font-size:11px}
.service-name{font-weight:900;font-size:12px;margin-bottom:1.5mm}
.service-desc{color:var(--muted);font-size:10.5px;line-height:1.5}
.nowrap{white-space:nowrap}
.payment-grid{display:grid;grid-template-columns:1.18fr .82fr;gap:8mm;margin-top:7mm}
.box{border:1px solid var(--line);border-radius:4mm;padding:5mm}
.box h3{font-size:15px;margin:0 0 4mm;font-weight:900}
.bank-row,.sum-row{display:grid;grid-template-columns:30mm 1fr;gap:4mm;margin:2.6mm 0}
.bank-row span,.sum-row span{color:var(--muted)}
.sum-row{grid-template-columns:1fr auto}
.total-line{border-top:1px solid var(--line);margin-top:4mm;padding-top:4mm}
.total-line strong:last-child{font-size:22px;color:var(--purple);letter-spacing:-.03em}
.note{margin-top:7mm;color:var(--muted);font-size:10.5px;line-height:1.55}
.footer{margin-top:8mm;border-top:1px solid var(--line);padding-top:4mm;display:flex;justify-content:space-between;color:var(--muted);font-size:10px}
.print-actions{position:fixed;right:18px;bottom:18px;display:flex;gap:8px}
.print-actions button{border:0;border-radius:999px;padding:10px 16px;background:#111827;color:white;font-weight:800;cursor:pointer}
@media print{
  body{background:#fff}
  .page{margin:0;box-shadow:none;width:210mm;min-height:297mm;padding:9mm 10mm}
  .print-actions{display:none}
  @page{size:A4;margin:0}
}
@media(max-width:820px){
  body{background:white}
  .page{width:100%;min-height:auto;margin:0;padding:18px;box-shadow:none}
  .top,.title-row,.parties,.payment-grid{grid-template-columns:1fr;gap:18px}
  .doc-title{font-size:30px}
  table{display:block;overflow-x:auto}
}
</style>
</head>
<body>
<div class="page">
  <header class="top">
    <div>
      <div class="logo-mark">MOTIVE</div>
    </div>
    <div class="company">
      <h1>CÔNG TY TNHH TRUYỀN THÔNG MOTIVE</h1>
      <p>MST: 0110212832 · Hotline: 0965.980.886 · Email: hello.motivesocial@gmail.com</p>
      <p>Số 5 ngách 15 ngõ 82 Yên Lãng, Đống Đa, Hà Nội · motiveagency.vn</p>
    </div>
  </header>

  <section class="title-row">
    <div>
      <h2 class="doc-title">ĐỀ NGHỊ THANH TOÁN</h2>
      <div class="doc-sub">Payment Request · <?= e($paymentCode) ?></div>
    </div>
    <div class="meta">
      <div><span>Ngày tạo</span><strong><?= e(pr_safe_date($createdRaw)) ?></strong></div>
      <div><span>Hạn TT</span><strong><?= e(pr_safe_date($dueDate)) ?></strong></div>
      <?php if($quoteCode): ?><div><span>Báo giá</span><strong><?= e($quoteCode) ?></strong></div><?php endif; ?>
      <?php if($contractCode): ?><div><span>Hợp đồng</span><strong><?= e($contractCode) ?></strong></div><?php endif; ?>
    </div>
  </section>

  <section class="parties">
    <div>
      <div class="kicker">Bên yêu cầu thanh toán</div>
      <div class="info-row"><span>Tên tổ chức</span><strong>Công ty TNHH Truyền thông Motive</strong></div>
      <div class="info-row"><span>Người gửi</span><strong>Vũ Ngọc Thắng</strong></div>
      <div class="info-row"><span>Mã số thuế</span><strong>0110212832</strong></div>
    </div>
    <div>
      <div class="kicker">Bên thanh toán</div>
      <div class="info-row"><span>Tên tổ chức</span><strong><?= e($clientName) ?></strong></div>
      <div class="info-row"><span>Người nhận</span><strong><?= e($clientContact ?: 'Đang cập nhật') ?></strong></div>
      <div class="info-row"><span>Mã số thuế</span><strong>Đang cập nhật</strong></div>
    </div>
  </section>

  <h3 class="section-title">CHI TIẾT DỊCH VỤ</h3>
  <table>
    <thead>
      <tr>
        <th style="width:42%">Dịch vụ / Nội dung</th>
        <th>Thời gian</th>
        <th>Đơn giá</th>
        <th>VAT</th>
        <th>Tổng tiền</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>
          <div class="service-name"><?= e($serviceTitle) ?></div>
          <div class="service-desc"><?= e($title) ?><?= $note ? ' · '.e($note) : '' ?></div>
        </td>
        <td class="nowrap">Hạn TT:<br><strong><?= e(pr_safe_date($dueDate)) ?></strong></td>
        <td class="nowrap"><?= e(pr_money($subtotal)) ?></td>
        <td class="nowrap"><?= e(pr_money($vat)) ?></td>
        <td class="nowrap"><strong><?= e(pr_money($total)) ?></strong></td>
      </tr>
    </tbody>
  </table>

  <section class="payment-grid">
    <div class="box">
      <h3>THÔNG TIN CHUYỂN KHOẢN</h3>
      <div class="bank-row"><span>Tên tài khoản</span><strong>Công ty TNHH Truyền thông Motive</strong></div>
      <div class="bank-row"><span>Số tài khoản</span><strong>199938888</strong></div>
      <div class="bank-row"><span>Ngân hàng</span><strong>MB Bank – Sở giao dịch 03</strong></div>
      <div class="bank-row"><span>Nội dung CK</span><strong><?= e($paymentCode.' '.$clientName) ?></strong></div>
    </div>
    <div class="box">
      <h3>SỐ TIỀN THANH TOÁN</h3>
      <div class="sum-row"><span>Tạm tính</span><strong><?= e(pr_money($subtotal)) ?></strong></div>
      <div class="sum-row"><span>VAT 10%</span><strong><?= e(pr_money($vat)) ?></strong></div>
      <div class="sum-row total-line"><strong>Cần thanh toán</strong><strong><?= e(pr_money($total)) ?></strong></div>
    </div>
  </section>

  <p class="note">Đề nghị thanh toán này được lập theo thỏa thuận dịch vụ đã được hai bên xác nhận. Sau khi nhận thanh toán, Motive sẽ tiến hành triển khai/gia hạn và duy trì dịch vụ theo thời gian nêu trên.</p>

  <footer class="footer">
    <span>Motive Agency · Keep Moving Forward</span>
    <span>Tạo tự động từ MotiveEveryday</span>
  </footer>
</div>
<div class="print-actions"><button onclick="window.print()">Print / PDF</button></div>
</body>
</html>
